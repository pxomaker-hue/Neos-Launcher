# Neos 0.6.3 — Installation sur Nextcloud 35 / OMV

Cette version ajoute un Agenda et des Tâches CalDAV interactifs. Elle conserve l'identifiant technique **novadashboard**, le design et les correctifs PDF/favoris des versions précédentes. Les fichiers utilisateur et la base MariaDB ne sont pas modifiés par l'installation.

## 1. Transférer le ZIP depuis PowerShell (Windows)

Copier **une commande à la fois** :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.3.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifications et sauvegarde sur OMV

Vérifier d'abord que Nextcloud 35 a `maintenance: false` et `needsDbUpgrade: false` :

```bash
sudo docker exec nextcloud occ status
```

Repérer le chemin réel de l'application (ne pas présumer `/config/www/...` après la recréation de Docker) :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
echo "$APP_PATH"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo 'Application trouvée'
```

Arrêter ici si le message ne s'affiche pas.

Sauvegarder le code et les préférences de l'application :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v063.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v063.tar.gz
```

## 3. Installer, une ligne à la fois

```bash
mkdir -p /tmp/neos-v063
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.3.zip /tmp/neos-v063
```

```bash
test -f /tmp/neos-v063/novadashboard/appinfo/info.xml && echo 'ZIP valide'
```

```bash
sudo docker cp /tmp/neos-v063/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Le résultat attendu est `novadashboard: 0.6.3`. Recharger l'interface avec Ctrl+F5. Aucun `occ upgrade` n'est nécessaire dans la situation normale (`needsDbUpgrade: false`).

## 4. Vérifier Agenda et Tâches avec des données de test

1. Dans l'onglet **Agenda**, créer « Test Neos » pour demain. Vérifier qu'il apparaît également dans l'application Agenda Nextcloud.
2. Dans **Tâches**, créer « Test Neos » dans une liste autorisant VTODO. Vérifier dans l'application Tâches native.
3. Modifier le titre et l'échéance depuis Neos, puis cocher « terminée ». Vérifier dans l'application Tâches.
4. Sur mobile, ouvrir les deux onglets et tester le formulaire.

La découverte et les requêtes CalDAV nécessitent que les calendriers et tâches soient activés pour le compte. Si une liste est en lecture seule, Neos n'autorisera pas les modifications. Les événements récurrents complexes restent à modifier dans Agenda. Les tâches complexes avec plusieurs composants VTODO ne sont pas réécrites dans Neos.

Les créations utilisent `If-None-Match: *` et les modifications `If-Match` avec l'ETag fourni par le serveur. Le serveur peut refuser une opération si la ressource a changé (HTTP 412), afin d'éviter un écrasement silencieux.

## 5. Retour arrière du code si nécessaire

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v063.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

Puis Ctrl+F5. **Cela restaure le code uniquement, pas les modifications déjà enregistrées dans Agenda et Tâches.**

## Limitations et validation

Le logiciel a été validé par syntaxe PHP/JS, intégrité ZIP, tests Chromium desktop/mobile et simulations de requêtes CalDAV PROPFIND/REPORT/PUT avec vérifications des ETags. **Aucun test n'a été effectué sur le NAS réel ou la version exacte des applications Agenda/Tâches de ce NAS.** Tester d'abord avec des éléments temporaires.
