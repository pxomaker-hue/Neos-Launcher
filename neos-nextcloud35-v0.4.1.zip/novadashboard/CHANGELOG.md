# Neos — Journal des versions

## 0.4.1 — Orbital

- **Pleine largeur restaurée** au sein de Nextcloud 35, sans modifier les volumes Docker.
- Fond orbital animé persistant : grille perspective, aurore, tracés SVG, faisceaux, scintillements et halos.
- Entrées en cascade et micro-interactions orchestrées par les Web Animations API selon les principes d'Anime.js 4.
- Contraste et espacements des widgets revus, pour un rendu plus dense et moins générique.
- Gestionnaire de fichiers à deux panneaux : historique précédent/suivant, recherche conservant le focus, raccourci `/`, tri, grille/liste, favoris.
- Aperçus internes : image, texte, CSV/TSV, PDF (selon navigateur), aperçu limité Office ; agrandissement en panneau dédié.
- Menus contextuels : aperçu, téléchargement, copie du lien et ouverture dans Fichiers.
- Panneau de personnalisation : fermeture par Échap, clic extérieur, croix, Terminer ; animations configurables et respect de `prefers-reduced-motion`.
- Icône vectorielle locale Neos incluse.
- Styles entièrement préfixés par la racine de l'application afin d'éviter les conflits avec Nextcloud.

## 0.4.0
- Renommage de Nova en Neos, hub d'applications et fichiers intégrés.
