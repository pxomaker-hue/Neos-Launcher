# Neos v0.4.1 — mise à jour OMV / Nextcloud 35

Cible : OpenMediaVault, image `ghcr.io/linuxserver/nextcloud`, conteneur `nextcloud`, Nextcloud **35.x**.

Cette version **conserve l'identifiant technique `novadashboard`** ainsi que les préférences. Le nom visible est **Neos**. Aucune modification du `docker-compose.yml` et aucun nouveau service ne sont nécessaires.

## 1. Depuis Windows Terminal — transférer le ZIP

Enregistre le ZIP dans `X:\Travail\Apprentissage\Codage`, puis exécute sous PowerShell :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.4.1.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Avant installation — état et sauvegarde

Depuis le terminal SSH du NAS :

```bash
sudo docker exec nextcloud occ status
```

Vérifie `maintenance: false`, `needsDbUpgrade: false` et la version `35.x`. Si l'un de ces éléments diffère, n'installe pas encore Neos.

Sauvegarde la version actuelle de l'application :

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v041.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

Vérifie que la sauvegarde existe :

```bash
sudo docker exec nextcloud ls -lh /config/novadashboard-backup-avant-v041.tar.gz
```

Cela sauvegarde l'application Neos/Nova ; conserve **en plus** une sauvegarde complète et récente des volumes Nextcloud et de la base de données pour une utilisation en production.

## 3. Décompresser et installer

```bash
mkdir -p /tmp/neos-v041
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.4.1.zip /tmp/neos-v041
ls /tmp/neos-v041/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v041/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

La copie ne remplace pas les fichiers des utilisateurs. Elle met à jour le dossier de l'application uniquement.

## 4. Vérification

```bash
sudo docker exec nextcloud php -l /config/www/nextcloud/apps/novadashboard/lib/Controller/PageController.php
sudo docker exec nextcloud occ status
```

Puis ouvre Neos dans Nextcloud et recharge complètement avec `Ctrl + F5` (Windows).

Vérifie l'affichage pleine largeur, la navigation dossiers, le panneau de personnalisation, le hub d'apps et les aperçus. Les aperçus Office dépendent de la configuration des applications Nextcloud installées.

## 5. Retour arrière en cas de problème

Ne supprime **pas** le volume `/config` ni le conteneur. Pour restaurer la version précédente :

```bash
sudo docker exec nextcloud sh -c 'test -f /config/novadashboard-backup-avant-v041.tar.gz && tar -tzf /config/novadashboard-backup-avant-v041.tar.gz | head'
```

Si la sauvegarde est valide, restaure-la dans le dossier de l'application :

```bash
sudo docker exec nextcloud sh -c 'rm -rf /config/www/nextcloud/apps/novadashboard && tar -xzf /config/novadashboard-backup-avant-v041.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Le répertoire `novadashboard` est le seul remplacé ; la base de données et les données utilisateurs ne sont pas touchées.

Si Nextcloud passe en mode maintenance de manière inattendue, examine d'abord `occ status` et les logs. **Ne force pas** la sortie du mode maintenance si une mise à jour de base de données est en cours.

## Limites

- Prévisualisation native en lecture seule : images, PDF lorsque le navigateur l'autorise, texte/Markdown, CSV/TSV. La taille des textes chargés est limitée.
- XLSX, PPTX et DOCX : ouverture via Nextcloud / l'éditeur configuré ; pas d'édition Office embarquée par Neos.
- Les actions de modification, partage, déplacement et suppression sont volontairement déléguées à l'application Fichiers.
- Les animations utilisent les Web Animations API natives, avec une orchestration inspirée de la documentation Anime.js. Aucun script externe ni CDN.
- Un monogramme SVG Neos est fourni dans `img/app.svg` et `img/neos-mark.svg` et peut être remplacé par les ressources définitives.
