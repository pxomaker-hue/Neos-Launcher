# Neos Launcher v0.6.18 — Nextcloud 35

Extension Nextcloud **novadashboard**, conçue pour OMV / LinuxServer.io. Theme Flat Cyber, topbar personnalisable, Planning, Agenda, Tâches, Deck, Explorateur, Notes, Talk, Activité, Contacts et Mail.

**v0.6.18 :** sauvegarde explicite de brouillons Mail côté serveur, suivi en lecture seule de la boîte d'envoi et diagnostic des envois non confirmés. Aucun renvoi automatique. Pour rouvrir un brouillon après une nouvelle connexion, passer par **Mail natif → Brouillons** ; la reprise directe dans Neos viendra dans une version future.

Consulter `INSTALLATION-OMV.md` avant toute mise à jour. Les tests de simulation ne remplacent pas les tests sur le NAS.
