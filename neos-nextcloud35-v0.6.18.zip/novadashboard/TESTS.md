# Vérifications effectuées — Neos v0.6.18

- JavaScript : `node --check js/app.js` — OK.
- PHP : `php -l` sur les fichiers PHP — OK.
- XML : `appinfo/info.xml` analysé — OK.
- ZIP : chaque fichier accessible, test CRC et structure `novadashboard/` — OK.
- Tests de navigateur Chromium, données fictives : ouverture de Mail, enregistrement d'un brouillon, affichage du numéro, fermeture et ouverture de la boîte d'envoi, actualisation des statuts — OK.
- Tests visuels : captures ordinateur/mobile réelles sur le HTML interactif livré ; pas de `pageerror` pendant ces scénarios — OK.
- Tests d'API simulée : `POST /api/drafts` (création), `PUT /api/drafts/{id}` (modification), `GET /api/outbox` (lecture seule) — OK ; aucun envoi lancé dans ces scénarios.
- Les brouillons sont sauvegardés par une action volontaire dans Nextcloud Mail et non par un stockage navigateur. Les brouillons existants sont à reprendre dans Mail natif après reconnexion ; leur édition directe dans Neos n'est pas encore développée.

**Non validé :** écriture réelle de brouillons et lecture réelle des états Outbox sur le NAS Nextcloud 35 / Mail 5.13.2. Ces tests doivent être faits avec une fiche de brouillon fictive et sans expédition.
