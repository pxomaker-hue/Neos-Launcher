# Neos v0.6.18 — Installation OMV / Nextcloud 35

Cette version part de **Neos v0.6.17**, validée sur ton NAS OpenMediaVault avec Docker LinuxServer.io. Elle conserve le thème Flat Cyber, les onglets personnalisables, Planning, Deck, Talk, Contacts, Activité et la synchronisation Mail.

## Changements

- **Brouillons Mail enregistrés côté serveur** : bouton « Enregistrer le brouillon » (`POST /apps/mail/api/drafts`), puis « Mettre à jour le brouillon » (`PUT /apps/mail/api/drafts/{id}`). Un enregistrement explicite est nécessaire. Le contenu des mails n'est pas mis en cache dans les préférences Neos ou dans le navigateur ; les brouillons sauvegardés restent accessibles depuis **Mail natif → Brouillons** après reconnexion. L'édition dans Neos d'un ancien brouillon après reconnexion n'est pas encore prise en charge.
- **Boîte d'envoi** : nouveau panneau en lecture seule (`GET /apps/mail/api/outbox`), liste des messages en attente et libellés de statut. Un état en attente ne déclenche **aucun** renvoi automatique.
- **Envoi incertain** : bouton « Vérifier l'état » (`GET /apps/mail/api/outbox/{id}`), sans renvoi automatique.
- Prévention du double envoi conservée ; un brouillon Neos enregistré est supprimé après expédition confirmée si l'API le permet. Si cette suppression échoue, vérifie les doublons éventuels dans « Brouillons » de Mail natif.

## 1. Windows — PowerShell, une commande à la fois

Enregistre le ZIP sous : `X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.18.zip`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.18.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. NAS OMV — vérifier puis sauvegarder

```bash
sudo docker exec nextcloud occ status
```

**Arrête-toi** si `maintenance: true` ou `needsDbUpgrade: true`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.18.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

**Arrête-toi** si « Neos trouvé » n'apparaît pas.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0618.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0618.tar.gz
```

## 3. Extraire et installer

```bash
mkdir -p /tmp/neos-v0618
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.18.zip /tmp/neos-v0618
```

```bash
test -f /tmp/neos-v0618/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**Arrête-toi** si « Archive prête » n'apparaît pas.

```bash
sudo docker cp /tmp/neos-v0618/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : **`novadashboard: 0.6.18`**. Recharge Neos avec **Ctrl + F5**.

## 4. Tests sur le NAS (sans envoi réel)

1. Ouvre **Neos → Mail → Rédiger**. Remplis un **brouillon fictif** puis clique « Enregistrer le brouillon ». Vérifie dans F12 → Réseau que `POST /apps/mail/api/drafts` renvoie un succès et qu'un identifiant de brouillon est affiché.
2. Modifie le brouillon, reclique « Mettre à jour le brouillon ». Vérifie le succès de `PUT /apps/mail/api/drafts/{id}` ; contrôle la fiche dans **Mail natif → Brouillons**.
3. Ouvre **Boîte d'envoi**. Vérifie `GET /apps/mail/api/outbox` et les statuts. Ne clique sur aucun bouton d'envoi dans Mail natif pour le test.
4. Vérifie que la synchronisation Mail fonctionne toujours, que Talk et Contacts s'ouvrent, et que la topbar conserve son ordre.

Attention : en cas de requête de brouillon incertaine (erreur réseau/timeout), inspecte les brouillons dans Mail natif **avant de recliquer**, pour éviter les doublons. Aucun envoi n'est déclenché par les actions « Enregistrer le brouillon », « Boîte d'envoi » ou « Vérifier l'état ».

## 5. Retour arrière vers la v0.6.17

Une commande à la fois sur OMV :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
sudo docker exec nextcloud test -f /config/neos-backup-avant-v0618.tar.gz && echo "Sauvegarde trouvée"
```

Si la sauvegarde a été trouvée :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0618.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : **`novadashboard: 0.6.17`**. Termine par Ctrl + F5. Le retour arrière de Neos ne supprime pas les brouillons enregistrés dans Mail natif.
