# Neos — Feuille de route vers la v0.7 après la v0.6.18

## Fonctionnalités déjà confirmées sur NAS

- Neos v0.6.17 : synchronisation de la boîte Mail sans ouvrir Mail natif.
- Mail : lecture HTML, réponse et envoi de texte après configuration du dossier « Envoyés ».
- Talk : lecture et envoi de messages ; Contacts : création et modification CardDAV.
- Planning, Agenda, Tâches, Deck : intégrés, validation des tâches opérationnelle.
- Personnalisation du thème Flat Cyber, icône Planning et ordre des onglets enregistrable.

## Nouveautés v0.6.18 — en attente de test sur NAS

- Enregistrement de brouillons côté Nextcloud Mail ; mises à jour successives.
- Boîte d'envoi en lecture seule avec codes d'état compréhensibles.
- Consultation du statut d'une expédition incertaine, sans renvoi automatique.
- Captures réelles du code sur Chromium desktop et mobile ; API simulées.

## Prochaines étapes jusqu'à la v0.7

1. **Mail** : reprendre des brouillons existants directement dans Neos (sans doublon ni écrasement), pièces jointes, vérification des réponses et alias d'expédition ; gestion des dossiers supplémentaires.
2. **Talk** : compteurs non lus fiables, actualisation douce des conversations, ergonomie des réponses.
3. **Contacts** : champs e-mail/téléphone multiples, suppression avec confirmation et protection ETag.
4. **Activité** : pagination robuste, filtres serveur, messages en cas de droits insuffisants.
5. **Stabilisation** : tests de régression, sécurité HTML Mail, responsive mobile, code HTTP et rollback ; publication v0.7 uniquement après validation du NAS.
