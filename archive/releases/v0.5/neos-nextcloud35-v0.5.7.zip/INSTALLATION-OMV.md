# Neos v0.5.7 — Installation OMV / Nextcloud 35

Identifiant technique : `novadashboard`. Nom affiché : **Neos**.

Cette mise à jour conserve le thème Flat Cyber de la version 0.5.6 et ajoute les fonctions **File Manager Pro**. Elle ne modifie ni les volumes Docker ni le schéma de la base de données.

## 1. Depuis Windows PowerShell

Enregistre le ZIP dans ce dossier :

```text
X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.7.zip
```

Transfère-le, puis connecte-toi :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.7.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier Nextcloud avant installation

```bash
sudo docker exec nextcloud occ status
```

Ne continue que si Nextcloud est toujours en version **35.x**, que `maintenance: false`, `needsDbUpgrade: false`, et qu'aucune mise à jour n'est en cours.

## 3. Sauvegarder Neos

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v057.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v057.tar.gz
```

Cette archive ne remplace pas tes sauvegardes habituelles de Nextcloud (volumes, base, configuration).

## 4. Installer

```bash
mkdir -p /tmp/neos-v057
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.7.zip /tmp/neos-v057
ls -l /tmp/neos-v057/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v057/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Recharge ensuite Neos avec **Ctrl + F5**.

## 5. Essai recommandé, sans risque de perte de fichiers

Dans **Fichiers** :

1. Crée un dossier `Test Neos` et deux petits fichiers de test, par exemple `essai-a.txt` et `essai-b.txt`.
2. Coche deux fichiers, clique **Copier**, ouvre `Test Neos`, puis **Coller**.
3. Essaie **Dupliquer** : un nouveau nom « (copie) » doit apparaître sans écrasement.
4. Teste un déplacement avec **Déplacer** puis **Coller** dans un autre dossier.
5. Dépose un fichier depuis le PC sur un dossier. En cas de nom existant, Neos ne doit pas le remplacer automatiquement.
6. Essaie une suppression groupée **uniquement sur des fichiers de test**.

Le presse-papiers de Neos est **interne au dashboard**. Il n'est pas synchronisé avec le presse-papiers Windows. Le déplacement et la copie exigent les permissions nécessaires côté Nextcloud. Le résultat peut varier selon les montages externes.

## 6. Restaurer l'ancienne version (code Neos seulement)

Si une erreur survient, restaure la sauvegarde faite à l'étape 3 :

```bash
sudo docker exec nextcloud sh -c 'mv /config/www/nextcloud/apps/novadashboard /config/neos-v057-a-verifier'
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v057.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Si `/config/neos-v057-a-verifier` existe déjà, choisis un autre nom pour éviter d'écraser une sauvegarde. Cette restauration ne revient **pas** sur les opérations de fichiers effectuées entre-temps : celles-ci sont de véritables opérations WebDAV.

## Vérifications réalisées sur le paquet

- Contrôle de syntaxe PHP / JS et validation XML ;
- Test du ZIP ;
- Tests visuels simulés sur ordinateur et mobile ;
- Tests WebDAV **simulés** : sélection, copie, conflit avec renumérotation, déplacement, téléversement conditionnel, glisser-déposer, suppression par lot.

Les opérations WebDAV n'ont **pas** été testées sur ton serveur réel. Exécute le premier essai sur des fichiers sans importance.
