# Neos v0.5.6 — mise à jour OMV / Nextcloud 35

Version technique `novadashboard`, nom affiché **Neos**. Cette mise à jour concerne le code, les feuilles de style et les ressources locales de l'application. Elle ne remplace pas l'image Nextcloud et ne doit pas être utilisée pour mettre à jour le serveur Nextcloud lui-même.

## 1. Envoyer le ZIP depuis Windows Terminal (PowerShell)

Enregistre le fichier dans ton dossier :

```text
X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.6.zip
```

Puis lance :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.6.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier le serveur avant de continuer

```bash
sudo docker exec nextcloud occ status
```

Vérifie que Nextcloud est en **version 35.x** et que `maintenance: false` et `needsDbUpgrade: false`. Si l'un des deux est `true`, ne poursuis pas avant d'avoir vérifié la cause.

## 3. Sauvegarder le code actuel de Neos

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v056.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v056.tar.gz
```

La sauvegarde du seul code Neos n'est pas une sauvegarde complète de Nextcloud. Conserve aussi tes sauvegardes habituelles des volumes, de la configuration et de la base de données.

## 4. Installer les nouveaux fichiers

```bash
mkdir -p /tmp/neos-v056
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.6.zip /tmp/neos-v056
ls -l /tmp/neos-v056/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v056/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Ne lance pas `occ upgrade` par réflexe pour cette mise à jour de l'interface ; s'il apparaît une demande de migration, vérifie d'abord l'état de Nextcloud et les journaux.

## 5. Vérifier le navigateur

Actualise Neos avec **Ctrl + F5** (ou Ctrl + Maj + R). Dans l'onglet Accueil, vérifie :

- Horloge : nouveau cadran holographique avec aiguilles locales ;
- Stockage : cercle de quota et barre animée ; si le quota n'est pas défini, message « Quota illimité » ;
- Widgets : les courts traits en haut des en-têtes ont disparu ;
- Onglets Notes, Deck, Photos et Fichiers : habillage cohérent avec l'accueil ;
- Hub : la nouvelle icône Accueil doit apparaître.

La nouvelle icône est livrée sous ce nom :

```text
novadashboard/img/neos-home-cyan-v056-256.png
```

Si l'ancienne reste visible après actualisation, vérifie **l'existence réelle du fichier déployé** :

```bash
sudo docker exec nextcloud ls -lh /config/www/nextcloud/apps/novadashboard/img/neos-home-cyan-v056-256.png
```

Si le fichier existe, dans les outils de développement (F12 → Réseau), contrôle que le navigateur demande bien `neos-home-cyan-v056-256.png` et reçoit un statut HTTP 200. Un ancien nom de fichier dans la page indique souvent un JS mis en cache.

## Retour arrière (code Neos uniquement)

Le code actuel sera déplacé vers `/config/neos-v056-a-verifier` puis la sauvegarde restaurée :

```bash
sudo docker exec nextcloud sh -c 'mv /config/www/nextcloud/apps/novadashboard /config/neos-v056-a-verifier'
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v056.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Si `/config/neos-v056-a-verifier` existe déjà, choisis un autre chemin avant le `mv`. Une restauration complète de Nextcloud (config, données, base) est une procédure distincte.

## Tests

Tests hors NAS : syntaxe PHP et JavaScript, validité du XML, intégrité ZIP, rendu Chromium simulé 1 440 px / 900 px / 390 px, présence de l'icône Accueil, horloge et jauge, ouverture/fermeture de panneau. Les appels réels du serveur (WebDAV, Notes, Deck) ne sont pas couverts par la démonstration et devront être vérifiés sur ton instance.
