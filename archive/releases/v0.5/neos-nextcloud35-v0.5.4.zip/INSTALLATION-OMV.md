# Neos v0.5.4 — Installation sur Nextcloud 35 / OMV (LinuxServer.io)

L'app conserve l'identifiant technique `novadashboard`. La mise à jour remplace seulement les fichiers de cette application, sans recréer le conteneur Docker ni modifier tes volumes Nextcloud.

## 1. Transfert depuis Windows Terminal (PowerShell)

Enregistre d'abord l'archive `neos-nextcloud35-v0.5.4.zip` dans ton dossier Windows habituel :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.4.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier l'état de Nextcloud

```bash
sudo docker exec nextcloud occ status
```

Vérifie la version 35.x, et que `maintenance` et `needsDbUpgrade` sont tous les deux `false`. Arrête-toi si une mise à jour Nextcloud est en cours. Il est préférable de disposer d'une sauvegarde complète de Nextcloud (données, configuration, base SQL) avant toute modification d'application.

## 3. Sauvegarder l'application actuelle

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v054.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v054.tar.gz
```

## 4. Décompresser et vérifier le nouveau paquet

```bash
mkdir -p /tmp/neos-v054
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.4.zip /tmp/neos-v054
ls -l /tmp/neos-v054/novadashboard/appinfo/info.xml
```

## 5. Déployer l'application

```bash
sudo docker cp /tmp/neos-v054/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Actualise avec `Ctrl + F5` puis vérifie : Accueil > Deck ; Personnaliser > Disposition > Libre > Réorganiser > largeur/hauteur ; topbar Accueil et hub Applications.

Si Nextcloud affiche « Mise à jour nécessaire » ou `needsDbUpgrade: true`, **ne désactive pas la maintenance à l'aveugle** : vérifie la sauvegarde et le statut de Nextcloud avant un éventuel `sudo docker exec nextcloud occ upgrade`.

## Retour arrière

Si la version pose problème, vérifie que le serveur n'est pas en train d'exécuter une migration. Puis, pour restaurer **le code applicatif** de la sauvegarde :

```bash
sudo docker exec nextcloud sh -c 'mv /config/www/nextcloud/apps/novadashboard /config/novadashboard-v054-mise-de-cote'
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v054.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Cette restauration remet les fichiers de l'application, pas une base de données éventuellement migrée. Si une migration de base a effectivement eu lieu, restaurer une sauvegarde complète cohérente peut être nécessaire.

## Limites

- Les tableaux du widget Deck dépendent de l'application Deck activée pour le compte et de son API sur ce serveur.
- La nouvelle grille est testée en navigateur simulé et respecte la largeur mobile ; elle reste à valider sur ton Nextcloud réel.
- Les hauteurs choisies sont des **minima** : aucun contenu n'est volontairement coupé pour atteindre une hauteur plus petite.
