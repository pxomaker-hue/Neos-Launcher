# Neos — Journal des versions

## 0.4.3 — Copper Circuit

- Nouvelle identité visuelle cuivre / turquoise, cadrages techniques, motifs de coin, surfaces plus sobres.
- Logos et icônes issus de la planche fournie par l'utilisateur (WebP locaux optimisés).
- Une seule position pour le lanceur d'applications : **topbar** ou **widget**, au choix dans Personnaliser. Le bouton Apps ouvre le catalogue complet.
- Suppression du bandeau de raccourcis redondant et des indicateurs répétés. Les fichiers occupent immédiatement la première zone utile.
- Panneau Apps illustré avec les images fournies, sans répéter les libellés présents dans les images.
- Animations d'entrée plus légères, gestes d'ouverture/fermeture plus fluides, respect de `prefers-reduced-motion`.
- Correction de la résolution des ressources statiques via l'API URL Nextcloud pour les installations sous un sous-chemin.
- Conservé : explorateur, navigation, favoris, aperçus et téléchargement ; aucune nouvelle permission ni migration SQL.

## 0.4.2 — Illustrated Cyber

- **Interface plus illustrée** avec cartes d’applications visuelles dans le bandeau principal et intégration des logos fournis dans le hub.
- **Langage plus cybernétique** : surfaces vitrées plus nettes, lignes de balayage, accent lumineux, orbites renforcées et micro-détails techniques.
- **Transitions plus fluides** pour les panneaux, le hub, les aperçus et l’ouverture de la personnalisation.
- **Panneau de personnalisation transformé en side sheet** plus rapide à utiliser.
- **Hub applications enrichi** avec panneau illustré et structure plus dense.
- Amélioration des survols et de la sensation de profondeur sur les cartes, lignes de fichiers et contrôles.

## 0.4.1 — Orbital

- **Pleine largeur restaurée** au sein de Nextcloud 35, sans modifier les volumes Docker.
- Fond orbital animé persistant : grille perspective, aurore, tracés SVG, faisceaux, scintillements et halos.
- Entrées en cascade et micro-interactions orchestrées par les Web Animations API selon les principes d'Anime.js 4.
- Contraste et espacements des widgets revus, pour un rendu plus dense et moins générique.
- Gestionnaire de fichiers à deux panneaux : historique précédent/suivant, recherche conservant le focus, raccourci `/`, tri, grille/liste, favoris.
- Aperçus internes : image, texte, CSV/TSV, PDF (selon navigateur), aperçu limité Office ; agrandissement en panneau dédié.
- Menus contextuels : aperçu, téléchargement, copie du lien et ouverture dans Fichiers.
- Panneau de personnalisation : fermeture par Échap, clic extérieur, croix, Terminer ; animations configurables et respect de `prefers-reduced-motion`.
- Icône vectorielle locale Neos incluse.
- Styles entièrement préfixés par la racine de l'application afin d'éviter les conflits avec Nextcloud.

## 0.4.0
- Renommage de Nova en Neos, hub d'applications et fichiers intégrés.