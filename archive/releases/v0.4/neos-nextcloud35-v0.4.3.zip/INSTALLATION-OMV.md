# Neos 0.4.3 — installation sur OpenMediaVault et Nextcloud 35

**Cible vérifiée pour ce paquet :** Nextcloud 35.x, image LinuxServer.io, conteneur Docker nommé `nextcloud` et application installée sous `/config/www/nextcloud/apps/novadashboard`.

L'application conserve l'identifiant **`novadashboard`** et les préférences existantes. Le nom affiché reste **Neos**. Aucun nouveau conteneur, service externe ou changement de base de données n'est nécessaire.

## 1. Copier l'archive depuis PowerShell

Enregistre `neos-nextcloud35-v0.4.3.zip` dans `X:\Travail\Apprentissage\Codage`, puis :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.4.3.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier l'instance et sauvegarder

```bash
sudo docker exec nextcloud occ status
```

La version doit être **35.x**, `maintenance` **false** et `needsDbUpgrade` **false**. Si ces valeurs diffèrent, ne commence pas la copie.

Sauvegarde le code de la version précédente dans `/config` :

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v043.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/novadashboard-backup-avant-v043.tar.gz
```

Ce tar concerne uniquement l'application. Pour une installation de production, garde aussi une sauvegarde récente des volumes Nextcloud et de la base de données.

## 3. Décompresser et installer

```bash
mkdir -p /tmp/neos-v043
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.4.3.zip /tmp/neos-v043
ls /tmp/neos-v043/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v043/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Ce déploiement remplace le code de l'application sans toucher aux fichiers utilisateurs. Ne supprime pas les données Docker ni le dossier `/config`.

## 4. Vérifier

```bash
sudo docker exec nextcloud occ status
sudo docker exec nextcloud php -l /config/www/nextcloud/apps/novadashboard/lib/Controller/PageController.php
```

Ouvre Neos et actualise avec **Ctrl + F5**. Vérifie particulièrement le hub illustré, l'explorateur, et le paramètre **Personnaliser > Position du lanceur : Barre supérieure / Widget**.

Si Nextcloud affiche **Mode maintenance**, examine `occ status` et `docker logs --tail 80 nextcloud` avant de désactiver ce mode : ne force pas `maintenance:mode --off` si une mise à jour de base est en cours.

## 5. Retour arrière

Vérifie d'abord la sauvegarde :

```bash
sudo docker exec nextcloud sh -c 'tar -tzf /config/novadashboard-backup-avant-v043.tar.gz | head'
```

Puis, si besoin :

```bash
sudo docker exec nextcloud sh -c 'rm -rf /config/www/nextcloud/apps/novadashboard && tar -xzf /config/novadashboard-backup-avant-v043.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Recharge ensuite Nextcloud. Ces commandes ne touchent qu'au répertoire de l'application `novadashboard`.

## Limites

- Explorateur intégré **en lecture seule** : navigation, fichiers récents, images, PDF selon le navigateur, texte/Markdown, CSV/TSV et aperçu limité Office.
- Les formats XLSX/DOCX/PPTX passent toujours par les applications Office disponibles dans Nextcloud pour une véritable édition/lecture avancée.
- Édition, déplacement, partage, suppression et upload restent dans Fichiers.
- Les illustrations locales proviennent de la planche fournie. Les nouvelles bordures sont réalisées en CSS/SVG dans le même esprit ; aucun CDN.
- Transitions Web Animations API inspirées des principes d'Anime.js, respect de `prefers-reduced-motion`.
