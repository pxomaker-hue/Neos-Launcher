# Installation Neos v0.4.0 sur OMV / Nextcloud 35

Le paquet conserve l'identifiant d'application `novadashboard` pour permettre une mise à jour par remplacement.
Le nom visible dans l'interface devient **Neos**.

## 1) Copier l'archive sur le NAS
Depuis Windows PowerShell :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.4.0.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2) Vérifier Nextcloud

```bash
sudo docker exec nextcloud occ status
```

Les champs `maintenance` et `needsDbUpgrade` doivent être à `false`.

## 3) Sauvegarder l'app actuelle

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v040.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

## 4) Décompresser l'archive

```bash
mkdir -p /tmp/neos-v040
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.4.0.zip /tmp/neos-v040
```

## 5) Déployer les fichiers

```bash
sudo docker cp /tmp/neos-v040/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

## 6) Rafraîchir
Fais ensuite un rechargement complet du navigateur : `Ctrl + F5`.

## 7) Retour arrière si besoin

```bash
sudo docker exec nextcloud rm -rf /config/www/nextcloud/apps/novadashboard/*
sudo docker exec nextcloud sh -c 'tar -xzf /config/novadashboard-backup-avant-v040.tar.gz -C /config/www/nextcloud/apps/'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

## Notes
- lecture directe intégrée : images, texte, CSV/TSV, PDF
- pour les formats Office, l'intégration dépend aussi des apps présentes sur ton Nextcloud
- édition/partage/suppression restent gérés par l'app Fichiers native
