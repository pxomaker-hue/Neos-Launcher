# Changelog

## 0.4.0 — Neos
- Renommage visuel de Nova Dashboard vers **Neos**.
- Nouvelle interface plus dense, pleine largeur et moins "présentation".
- Fond animé renforcé : grille perspective, halos, anneaux et micro-interactions.
- Hub d’applications : barre supérieure configurable + widget d’apps.
- Explorateur intégré revu : navigation, favoris, aperçu direct des images, textes, CSV/TSV et PDF.
- Panneau de personnalisation mis à jour (apps visibles, widgets, densité, animations, accent, largeur).
- Métadonnées de fichiers enrichies (`davUrl`, `previewUrl`) pour les aperçus internes.
- Messages et libellés simplifiés pour un rendu plus produit.

## 0.3.0
- Première version Aurora avec explorateur intégré, animations et personnalisation avancée.
