# Neos 0.4.0

Neos est une évolution de Nova Dashboard pour Nextcloud 35.

## Points clés
- affichage pleine largeur
- hub d'applications configurable en topbar
- explorateur de fichiers intégré
- aperçu direct : images, texte, CSV/TSV, PDF
- accès rapide vers l'application Fichiers pour les actions avancées
- panneau de personnalisation par utilisateur

## Limites actuelles
- édition, partage et suppression continuent d'être gérés par l'application Fichiers native
- les formats Office (xlsx, pptx, docx, ods, odp, odt) affichent surtout un aperçu léger / une bascule vers l'application associée
- le support exact dépend aussi des apps Nextcloud installées sur l'instance

## Compatibilité
- Nextcloud 35
- PHP 8.3+
