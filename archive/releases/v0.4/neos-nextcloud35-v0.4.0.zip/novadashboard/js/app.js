/** Neos Dashboard 0.4.0 — polished workspace for Nextcloud 35. */
(() => {
  'use strict';
  const root = document.getElementById('nova-root');
  if (!root) return;
  root.innerHTML = '<div id="neos-surface"></div><div id="neos-editor-host"></div><div id="neos-pop-host"></div><div id="neos-toast-host" aria-live="polite"></div>';
  const surface = root.querySelector('#neos-surface');
  const editorHost = root.querySelector('#neos-editor-host');
  const popHost = root.querySelector('#neos-pop-host');
  const toastHost = root.querySelector('#neos-toast-host');

  const demo = window.NOVA_DEMO_DATA && root.dataset.demo === 'true' ? window.NOVA_DEMO_DATA : null;
  const csrfToken = () => document.head?.getAttribute('data-requesttoken') || window.OC?.requestToken || '';

  const icons = {
    sparkles:'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 17 .8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',
    check:'<rect x="3" y="4" width="18" height="17" rx="3"/><path d="m8 12 3 3 5-6"/>',
    storage:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 12h18m-5 4h2"/><circle cx="7" cy="16" r="1"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-6-6L4 21"/>',
    message:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
    settings:'<path d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.8 9A7.5 7.5 0 0 1 19 6l1 1M4 17l1 1a7.5 7.5 0 0 0 13.2-3"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    close:'<path d="M5 5l14 14M19 5 5 19"/>',
    grip:'<circle cx="9" cy="5" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="19" r="1"/>',
    file:'<path d="M6 2h9l5 5v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z"/><path d="M14 2v6h6"/>',
    external:'<path d="M14 4h6v6m-9 3 9-9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
    alert:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3v.1"/>',
    cloud:'<path d="M5 18a4 4 0 0 1-.4-8 7 7 0 0 1 13-1 4.5 4.5 0 0 1 1 9H5Z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7 .2l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7-.2l-3 3a5 5 0 1 0 7.1 7.1l1.7-1.7"/>',
    note:'<path d="M4 3h16v18H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    chart:'<path d="M3 20h18M6 17v-4m6 4V6m6 11v-8"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
    star:'<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.3-5.7-3-5.7 3 1.1-6.3L2.8 9.7l6.4-.9L12 3Z"/>',
    list:'<path d="M9 5h12M9 12h12M9 19h12"/><path d="M3 5h.1M3 12h.1M3 19h.1"/>',
    sort:'<path d="M7 4v16m0 0-4-4m4 4 4-4M17 20V4m0 0-4 4m4-4 4 4"/>',
    arrow:'<path d="M4 12h16m-7-7 7 7-7 7"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
    bolt:'<path d="m13 2-9 12h7l-1 8 10-12h-7l0-8Z"/>',
    home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
    users:'<path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="4"/><path d="M17 11a4 4 0 1 0 0-8m4 18v-2a4 4 0 0 0-3-3.87"/>',
    mail:'<path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><path d="m22 7-10 7L2 7"/>',
    kanban:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16m6-16v9"/>',
    map:'<path d="M9 18 3 20V6l6-2 6 2 6-2v14l-6 2-6-2Z"/><path d="M9 4v14m6-12v14"/>',
    news:'<path d="M4 5h13a2 2 0 0 1 2 2v10H6a2 2 0 0 1-2-2V5Z"/><path d="M19 9h1a2 2 0 0 1 2 2v6H8"/><path d="M8 9h7M8 13h5"/>',
    sheet:'<path d="M4 4h16v16H4z"/><path d="M4 9h16M9 4v16m5-16v16"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    open:'<path d="M7 17 17 7"/><path d="M8 7h9v9"/>',
  };
  const icon = (name, size=18) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name] || icons.file}</svg>`;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeUrl = s => typeof s === 'string' && ((/^\/(?!\/)/.test(s) && !s.includes('\\')) || /^https?:\/\//i.test(s)) ? esc(s) : '#';
  const safeColor = s => /^#[0-9a-f]{6}$/i.test(String(s)) ? s : '#7f8dff';
  const number = n => Number.isFinite(Number(n)) ? Number(n) : 0;
  const humanSize = b => { if (b == null) return '—'; const n = Math.max(0, number(b)); const p = n ? Math.min(4, Math.floor(Math.log(n)/Math.log(1024))) : 0; return new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(n/Math.pow(1024,p)) + ' ' + ['o','Ko','Mo','Go','To'][p]; };
  const ago = ts => { const d = Math.max(0, Math.round((Date.now()-number(ts)*1000)/86400000)); return d===0?'Aujourd’hui':d===1?'Hier':`Il y a ${d} j`; };
  const fmtTime = iso => { if (!iso) return 'Sans échéance'; const d = new Date(iso); return Number.isNaN(+d) ? 'Date inconnue' : new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(d); };
  const ext = name => String(name || '').split('.').pop().toLowerCase();
  const isImage = e => String(e?.mime || '').startsWith('image/');
  const isPdf = e => String(e?.mime || '') === 'application/pdf' || ext(e?.name) === 'pdf';
  const isCsv = e => ['csv','tsv'].includes(ext(e?.name));
  const isText = e => String(e?.mime || '').startsWith('text/') || ['txt','md','markdown','json','log','ini','yaml','yml','xml','html','css','js','ts','php','sql','csv','tsv'].includes(ext(e?.name));
  const isOffice = e => ['xlsx','xls','ods','docx','doc','odt','pptx','ppt','odp'].includes(ext(e?.name));

  const widgetLabels = {
    explorer:'Fichiers', storage:'Stockage', shortcuts:'Hub apps', clock:'Horloge', files:'Récents',
    calendar:'Agenda', tasks:'Tâches', summary:'Synthèse', links:'Liens', notes:'Notes'
  };
  const widgetIcons = { explorer:'folder', storage:'storage', shortcuts:'grid', clock:'clock', files:'file', calendar:'calendar', tasks:'check', summary:'chart', links:'link', notes:'note' };
  const widgetIds = Object.keys(widgetLabels);
  const defaultSizes = { explorer:12, storage:3, shortcuts:6, clock:3, files:6, calendar:6, tasks:6, summary:6, links:6, notes:6 };
  const defaults = () => ({ theme:'system', density:'comfortable', accent:'indigo', layout:'wide', motion:'full', order:[...widgetIds], hidden:['links','notes'], sizes:{...defaultSizes}, links:[], notes:'', pins:[], topApps:['files','calendar','tasks','talk'] });

  let overview = null;
  let settings = null;
  let editing = false;
  let editorOpen = false;
  let saving = false;
  let saveQueued = false;
  let popMode = '';
  let browseGeneration = 0;
  let previewGeneration = 0;
  let hasEntered = false;
  let clockTimer = null;
  const browser = { path:'/', items:[], total:0, truncated:false, limit:160, filesUrl:'#', loading:true, error:'', query:'', sort:'name', type:'all', view:'list' };
  const preview = { entry:null, status:'empty', mode:'empty', text:'', rows:[], error:'', title:'' };

  const motionEnabled = () => settings && settings.motion !== 'off' && !(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  const motionFactor = () => settings?.motion === 'subtle' ? .7 : 1;

  function toast(message, type='info') {
    const node = document.createElement('div');
    node.className = `neos-toast neos-toast-${type}`;
    node.setAttribute('role','status');
    node.textContent = message;
    toastHost.replaceChildren(node);
    setTimeout(() => node.remove(), 3200);
  }

  async function api(url, options={}) {
    if (demo) throw new Error('Démo');
    const token = csrfToken();
    if (!token) throw new Error('Jeton CSRF manquant');
    const response = await fetch(url, {
      credentials:'same-origin', cache:'no-store', ...options,
      headers:{ Accept:'application/json', requesttoken:token, 'X-Requested-With':'XMLHttpRequest', ...(options.headers || {}) }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  function applyTheme() {
    const pref = settings?.theme || 'system';
    const light = pref === 'light' || (pref === 'system' && window.matchMedia?.('(prefers-color-scheme: light)').matches);
    root.classList.toggle('neos-light', !!light);
    root.classList.toggle('neos-dark', !light);
    root.dataset.accent = settings?.accent || 'indigo';
    root.dataset.density = settings?.density || 'comfortable';
    root.dataset.layout = settings?.layout || 'wide';
    root.dataset.motion = settings?.motion || 'full';
  }

  function animateIn(nodes, delay=40, base=0) {
    if (!motionEnabled()) return;
    [...nodes].forEach((el, i) => {
      if (!el?.animate) return;
      el.animate([
        { opacity:0, transform:'translate3d(0,14px,0) scale(.985)', filter:'blur(3px)' },
        { opacity:1, transform:'translate3d(0,0,0) scale(1)', filter:'blur(0)' }
      ], { duration:Math.round(520*motionFactor()), delay:base + i*delay*motionFactor(), fill:'both', easing:'cubic-bezier(.16,1,.3,1)' });
    });
  }

  function pulse(el) {
    if (!motionEnabled() || !el?.animate) return;
    el.animate([{transform:'scale(.985)'},{transform:'scale(1.02)'},{transform:'scale(1)'}], { duration:380*motionFactor(), easing:'cubic-bezier(.17,.89,.32,1.27)' });
  }

  function box(id, body, sub='', tools='') {
    const size = [3,4,6,8,12].includes(Number(settings.sizes?.[id])) ? Number(settings.sizes[id]) : 6;
    return `<section class="neos-card neos-${id}" data-widget="${id}" data-size="${size}" draggable="${editing}">
      <header class="neos-card-head"><div class="neos-card-name">${icon(widgetIcons[id],18)}<span>${esc(widgetLabels[id])}</span></div><div class="neos-card-actions">${tools}<span class="neos-card-sub">${editing ? icon('grip',15) : sub}</span></div></header>
      <div class="neos-card-body">${body}</div>
    </section>`;
  }

  function filesHomeUrl(){ return browser.filesUrl && browser.filesUrl !== '#' ? browser.filesUrl : ((overview?.shortcuts || []).find(x => x.id === 'files')?.url || '/index.php/apps/files/'); }

  function breadcrumb() {
    const names = browser.path.split('/').filter(Boolean);
    const crumbs = [`<button type="button" class="neos-crumb ${names.length ? '' : 'active'}" data-action="browse-path" data-path="/">${icon('home',14)}</button>`];
    let path = '';
    names.forEach((part, idx) => { path += '/' + part; crumbs.push(`${icon('chevron',12)}<button type="button" class="neos-crumb ${idx===names.length-1?'active':''}" data-action="browse-path" data-path="${esc(path)}">${esc(part)}</button>`); });
    return crumbs.join('');
  }

  function appColor(id){ return ({files:'#6f89ff',photos:'#76d2ff',calendar:'#85a2ff',tasks:'#86f3ca',talk:'#d9a2ff',contacts:'#ffbe7d',mail:'#89cbff',deck:'#f2a4ff',notes:'#ffd978',bookmarks:'#a0b6ff',news:'#95e2ff',maps:'#7df0dc',tables:'#7fa8ff',office:'#ffb28d',activity:'#cdb6ff'})[id] || '#90a4ff'; }
  function topApps(){ const allowed = new Set(settings.topApps || []); return (overview?.shortcuts || []).filter(x => allowed.has(x.id)).slice(0,8); }

  function hubGrid(compact=false) {
    const list = overview?.shortcuts || [];
    if (!list.length) return '<div class="neos-empty">Aucune application disponible.</div>';
    return `<div class="neos-hub-grid ${compact ? 'is-compact' : ''}">${list.map(app => `<a class="neos-app" href="${safeUrl(app.url)}" style="--app:${safeColor(appColor(app.id))}"><span class="neos-app-glyph">${icon(app.icon || 'grid',21)}</span><span>${esc(app.label)}</span></a>`).join('')}</div>`;
  }

  function summaryWidget() {
    const countFiles = number(browser.items.filter(x => x.kind === 'file').length);
    const countFolders = number(browser.items.filter(x => x.kind === 'folder').length);
    const appCount = number((overview?.shortcuts || []).length);
    return box('summary', `<div class="neos-metric-grid"><div class="neos-metric"><strong>${countFiles}</strong><span>fichiers</span></div><div class="neos-metric"><strong>${countFolders}</strong><span>dossiers</span></div><div class="neos-metric"><strong>${appCount}</strong><span>apps</span></div></div>`, `${browser.path}`);
  }

  function storageWidget(){
    const s = overview?.storage || {}; const p = Math.max(0, Math.min(100, number(s.percent)));
    return box('storage', `<div class="neos-stat-main">${humanSize(s.used)}</div><div class="neos-meter"><span style="width:${p}%"></span></div><p class="neos-subtle">${s.total == null ? 'illimité' : 'sur ' + humanSize(s.total)}</p>`);
  }
  function shortcutsWidget(){ return box('shortcuts', hubGrid(true)); }
  function clockWidget(){ return box('clock', `<div class="neos-clock" data-clock>--:--</div><div class="neos-subtle" data-clock-date>—</div>`); }
  function recentWidget(){
    const list = overview?.files || [];
    return box('files', list.length ? `<div class="neos-list">${list.map(f => `<button type="button" class="neos-item" data-action="preview-dav" data-url="${safeUrl(f.davUrl || '')}" data-name="${esc(f.name)}" data-mime="${esc(f.mime || '')}"><span class="neos-item-icon">${icon(String(f.mime||'').startsWith('image/') ? 'image' : 'file',16)}</span><span class="neos-item-title"><strong>${esc(f.name)}</strong><small>${esc(f.folder)} · ${ago(f.mtime)}</small></span><span class="neos-item-meta">${humanSize(f.size)}</span></button>`).join('')}</div>` : '<div class="neos-empty">Aucun fichier récent.</div>');
  }
  function calendarWidget(){
    const list = overview?.calendar || [];
    return box('calendar', list.length ? `<div class="neos-list">${list.map(x => `<div class="neos-item"><span class="neos-event-bar" style="background:${safeColor(x.color)}"></span><span class="neos-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.calendar)}</small></span><span class="neos-item-meta">${fmtTime(x.start)}</span></div>`).join('')}</div>` : '<div class="neos-empty">Aucun événement.</div>', '30 j');
  }
  function tasksWidget(){
    const list = overview?.tasks || [];
    return box('tasks', list.length ? `<div class="neos-list">${list.map(x => `<div class="neos-item"><span class="neos-item-icon">${icon('check',16)}</span><span class="neos-item-title"><strong>${esc(x.title)}</strong><small>${x.due ? fmtTime(x.due) : 'Sans échéance'}</small></span></div>`).join('')}</div>` : '<div class="neos-empty">Aucune tâche ouverte.</div>');
  }
  function linksWidget(){
    const list = settings.links || [];
    return box('links', list.length ? `<div class="neos-link-grid">${list.map(x => `<a href="${safeUrl(x.url)}" class="neos-link-card">${icon('link',15)}<span>${esc(x.title)}</span>${icon('open',14)}</a>`).join('')}</div>` : '<div class="neos-empty">Aucun lien.</div>');
  }
  function notesWidget(){
    return box('notes', `<textarea id="neos-note" class="neos-note" placeholder="" spellcheck="false">${esc(settings.notes || '')}</textarea><div class="neos-note-tools"><button type="button" data-action="save-note" class="neos-btn">${icon('check',16)} Enregistrer</button></div>`);
  }

  function browserItems() {
    if (browser.loading) return '<div class="neos-browser-state"><span class="neos-spinner"></span></div>';
    if (browser.error) return `<div class="neos-browser-state is-error">${icon('alert',20)}<strong>${esc(browser.error)}</strong></div>`;
    const term = browser.query.trim().toLocaleLowerCase('fr-FR');
    let items = browser.items.filter(x => (browser.type === 'all' || x.kind === browser.type) && (!term || String(x.name).toLocaleLowerCase('fr-FR').includes(term)));
    if (browser.sort === 'recent') items = [...items].sort((a,b) => number(b.mtime) - number(a.mtime));
    else if (browser.sort === 'size') items = [...items].sort((a,b) => number(b.size) - number(a.size));
    else items = [...items].sort((a,b) => (a.kind==='folder'?0:1) - (b.kind==='folder'?0:1) || String(a.name).localeCompare(String(b.name),'fr',{numeric:true}));
    if (!items.length) return '<div class="neos-browser-state">—</div>';

    const rows = items.map(item => {
      const pinned = (settings.pins || []).includes(item.path);
      const active = preview.entry?.path === item.path;
      const title = item.kind === 'folder' ? `Ouvrir ${item.name}` : `Prévisualiser ${item.name}`;
      const action = item.kind === 'folder' ? 'browse-path' : 'select-entry';
      const thumb = item.kind === 'file' && isImage(item) && item.previewUrl ? `<img class="neos-thumb" loading="lazy" alt="" src="${safeUrl(item.previewUrl)}">` : '';
      return `<div class="neos-file-row ${active ? 'is-active' : ''} ${item.kind==='folder' ? 'is-folder' : 'is-file'}">
        <button type="button" class="neos-file-main" data-action="${action}" data-path="${esc(item.path)}" title="${esc(title)}">
          <span class="neos-file-symbol">${thumb || icon(item.kind==='folder' ? 'folder' : isImage(item) ? 'image' : isPdf(item) ? 'file' : isOffice(item) ? 'sheet' : 'file',18)}</span>
          <span class="neos-file-label"><strong>${esc(item.name)}</strong><small>${item.kind==='folder' ? 'Dossier' : esc(item.mime || 'Fichier')} · ${ago(item.mtime)}</small></span>
          <span class="neos-file-size">${item.kind === 'folder' ? '—' : humanSize(item.size)}</span>
        </button>
        <div class="neos-file-actions">
          ${item.kind === 'folder' ? `<button type="button" class="neos-iconbtn ${pinned ? 'is-on' : ''}" data-action="pin-folder" data-path="${esc(item.path)}" title="${pinned ? 'Retirer des favoris' : 'Épingler'}">${icon('star',15)}</button>` : `<button type="button" class="neos-iconbtn" data-action="open-file" data-path="${esc(item.path)}" title="Ouvrir dans l'application Fichiers">${icon('external',15)}</button>`}
        </div>
      </div>`;
    }).join('');
    return `<div class="neos-file-list ${browser.view==='grid' ? 'is-grid' : ''}">${rows}</div>`;
  }

  function previewPane() {
    const entry = preview.entry;
    const actions = entry ? `<div class="neos-preview-actions">
        ${entry.kind === 'file' && entry.davUrl ? `<a href="${safeUrl(entry.davUrl)}" target="_blank" rel="noreferrer" class="neos-btn">${icon('open',15)} Ouvrir</a>` : ''}
        ${entry.url ? `<a href="${safeUrl(entry.url)}" class="neos-btn">${icon('external',15)} Fichiers</a>` : ''}
      </div>` : '';
    const head = entry ? `<div class="neos-preview-head"><div><strong>${esc(entry.name)}</strong><span>${entry.kind === 'folder' ? 'Dossier' : esc(entry.mime || 'Fichier')} · ${entry.kind === 'file' ? humanSize(entry.size) : browser.total + ' éléments'}</span></div>${actions}</div>` : `<div class="neos-preview-head"><div><strong>${browser.path === '/' ? 'Racine' : esc(browser.path.split('/').pop())}</strong><span>${browser.total} éléments</span></div></div>`;
    let body = '<div class="neos-preview-empty">Sélectionne un fichier.</div>';
    if (preview.status === 'loading') body = '<div class="neos-preview-loading"><span class="neos-spinner"></span></div>';
    else if (preview.status === 'error') body = `<div class="neos-preview-empty">${icon('alert',20)} <span>${esc(preview.error || 'Prévisualisation indisponible')}</span></div>`;
    else if (entry) {
      if (entry.kind === 'folder') {
        body = `<div class="neos-folder-preview"><div class="neos-folder-emblem">${icon('folder',38)}</div><div class="neos-preview-meta"><span>Chemin</span><code>${esc(entry.path)}</code></div></div>`;
      } else if (preview.mode === 'image') {
        body = `<div class="neos-image-preview"><img src="${safeUrl(entry.previewUrl || entry.davUrl || '')}" alt="${esc(entry.name)}"></div>`;
      } else if (preview.mode === 'text') {
        body = `<pre class="neos-text-preview">${esc(preview.text)}</pre>`;
      } else if (preview.mode === 'table') {
        body = `<div class="neos-table-preview"><table>${preview.rows.map((row, index) => `<tr>${row.map(cell => index===0?`<th>${esc(cell)}</th>`:`<td>${esc(cell)}</td>`).join('')}</tr>`).join('')}</table></div>`;
      } else if (preview.mode === 'pdf') {
        body = `<iframe class="neos-pdf-preview" src="${safeUrl(entry.davUrl || '')}"></iframe>`;
      } else if (preview.mode === 'office') {
        body = `<div class="neos-office-preview"><div class="neos-office-illustration">${icon('sheet',40)}</div><p>${esc(entry.name)}</p><span>Prévisualisation intégrée limitée pour ce format. Ouvre le fichier dans son application associée.</span>${entry.previewUrl ? `<img src="${safeUrl(entry.previewUrl)}" alt="" class="neos-office-thumb">` : ''}</div>`;
      } else {
        body = `<div class="neos-preview-empty"><span>${icon('file',22)}</span><span>Aucun aperçu enrichi pour ce type de fichier.</span></div>`;
      }
    }
    return `<aside class="neos-preview">${head}<div class="neos-preview-body">${body}</div></aside>`;
  }

  function explorerWidget() {
    const pins = (settings.pins || []).slice(0, 12);
    return box('explorer', `<div class="neos-browser-shell">
      <div class="neos-browser-tools">
        <div class="neos-breadcrumb">${breadcrumb()}</div>
        <div class="neos-browser-actions">
          ${pins.length ? `<div class="neos-pins">${pins.map(p => `<button type="button" class="neos-pin" data-action="browse-path" data-path="${esc(p)}">${icon('folder',13)} ${esc(p.split('/').pop())}</button>`).join('')}</div>` : ''}
          <label class="neos-search">${icon('search',16)}<input type="search" data-browser-search value="${esc(browser.query)}" placeholder=""></label>
          <select data-browser-type><option value="all" ${browser.type==='all'?'selected':''}>Tout</option><option value="folder" ${browser.type==='folder'?'selected':''}>Dossiers</option><option value="file" ${browser.type==='file'?'selected':''}>Fichiers</option></select>
          <select data-browser-sort><option value="name" ${browser.sort==='name'?'selected':''}>Nom</option><option value="recent" ${browser.sort==='recent'?'selected':''}>Récents</option><option value="size" ${browser.sort==='size'?'selected':''}>Taille</option></select>
          <button type="button" class="neos-iconbtn" data-action="toggle-view">${icon(browser.view === 'grid' ? 'list' : 'grid',16)}</button>
          <button type="button" class="neos-iconbtn" data-action="reload-folder">${icon('refresh',16)}</button>
          <a class="neos-btn" href="${safeUrl(filesHomeUrl())}">${icon('external',15)} Fichiers</a>
        </div>
      </div>
      <div class="neos-browser-main"><div class="neos-browser-list-wrap">${browserItems()}</div>${previewPane()}</div>
    </div>`, browser.path);
  }

  function render() {
    applyTheme();
    const warnings = overview?.warnings || [];
    const activeTopApps = topApps();
    const widgets = { explorer:explorerWidget, storage:storageWidget, shortcuts:shortcutsWidget, clock:clockWidget, files:recentWidget, calendar:calendarWidget, tasks:tasksWidget, summary:summaryWidget, links:linksWidget, notes:notesWidget };
    surface.innerHTML = `<main class="neos-shell">
      <div class="neos-background"><span class="neos-grid"></span><span class="neos-glow a"></span><span class="neos-glow b"></span><span class="neos-glow c"></span><span class="neos-ring r1"></span><span class="neos-ring r2"></span><span class="neos-stars"></span></div>
      <div class="neos-layout">
        <header class="neos-topbar">
          <div class="neos-brand"><span class="neos-brand-mark">${icon('sparkles',17)}</span><div><strong>Neos</strong><span>v0.4</span></div></div>
          <nav class="neos-launchbar">${activeTopApps.map(app => `<a class="neos-launch-chip" href="${safeUrl(app.url)}" style="--app:${safeColor(appColor(app.id))}">${icon(app.icon || 'grid',15)}<span>${esc(app.label)}</span></a>`).join('')}</nav>
          <div class="neos-top-actions"><button type="button" class="neos-btn" data-action="toggle-hub">${icon('grid',15)} Apps</button><button type="button" class="neos-iconbtn" data-action="refresh">${icon('refresh',16)}</button><button type="button" class="neos-btn neos-btn-primary" data-action="customize">${icon(editing?'check':'settings',16)} ${editing ? 'Terminer' : 'Personnaliser'}</button></div>
        </header>
        <section class="neos-headerband">
          <div class="neos-pathblock"><span>${browser.path}</span></div>
          <div class="neos-headmeta"><span data-clock-date>—</span><strong data-clock>--:--</strong></div>
        </section>
        ${warnings.length ? `<div class="neos-warning">${icon('info',15)} ${esc(warnings[0])}</div>` : ''}
        ${editing ? `<div class="neos-editbar">${icon('grip',16)} Réorganisation active</div>` : ''}
        <div class="neos-grid-cards">${settings.order.filter(id => !settings.hidden.includes(id)).map(id => widgets[id] ? widgets[id]() : '').join('')}</div>
      </div>
    </main>`;
    updateClock();
    if (!hasEntered) { hasEntered = true; animateIn(surface.querySelectorAll('.neos-topbar, .neos-headerband, .neos-card'), 36, 40); }
  }

  function updateClock() {
    const date = new Date();
    surface.querySelectorAll('[data-clock]').forEach(el => el.textContent = new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(date));
    surface.querySelectorAll('[data-clock-date]').forEach(el => el.textContent = new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(date));
  }

  function choosePreviewCandidate() {
    const current = preview.entry?.path && browser.items.find(x => x.path === preview.entry.path);
    if (current) return current;
    return browser.items.find(x => x.kind === 'file') || browser.items[0] || null;
  }

  async function browse(path, resetQuery=true) {
    if (!path || !path.startsWith('/')) return;
    browser.path = path;
    if (resetQuery) browser.query = '';
    browser.loading = true;
    browser.error = '';
    render();
    const g = ++browseGeneration;
    try {
      let data;
      if (demo) data = demo.browse?.[path] || { path, items:[], total:0, truncated:false, limit:160, filesUrl:'#' };
      else { const url = new URL(root.dataset.filesUrl, window.location.href); url.searchParams.set('path', path); data = await api(url.toString()); }
      if (g !== browseGeneration) return;
      browser.path = data.path || path;
      browser.items = Array.isArray(data.items) ? data.items : [];
      browser.total = number(data.total);
      browser.truncated = Boolean(data.truncated);
      browser.limit = number(data.limit) || 160;
      browser.filesUrl = data.filesUrl || '#';
      browser.loading = false;
      browser.error = '';
      render();
      const candidate = choosePreviewCandidate();
      if (candidate) { if (candidate.kind === 'file') void selectEntry(candidate.path, true); else preview.entry = candidate; }
      render();
    } catch (error) {
      if (g !== browseGeneration) return;
      console.error('[Neos] dossier indisponible', error);
      browser.loading = false;
      browser.error = 'Impossible de charger ce dossier.';
      render();
    }
  }

  async function previewFromDav(url, name, mime) {
    preview.entry = { name, mime, kind:'file', davUrl:url, url:filesHomeUrl(), size:null, path:'' };
    preview.mode = isText({name,mime}) ? 'text' : isImage({mime}) ? 'image' : 'meta';
    preview.status = 'loading';
    preview.error = '';
    render();
    if (isImage({mime})) { preview.status = 'ready'; preview.mode = 'image'; render(); return; }
    if (!isText({name,mime})) { preview.status = 'ready'; preview.mode = 'meta'; render(); return; }
    try {
      const response = await fetch(url, { credentials:'same-origin', cache:'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      preview.status = 'ready'; preview.mode = 'text'; preview.text = text.slice(0, 180000); render();
    } catch (error) { preview.status = 'error'; preview.error = 'Lecture impossible'; render(); }
  }

  function parseDelimited(text, delimiter) {
    return text.split(/\r?\n/).filter(Boolean).slice(0, 24).map(line => line.split(delimiter).slice(0, 12));
  }

  async function selectEntry(path, preserve=false) {
    const entry = browser.items.find(x => x.path === path);
    if (!entry) return;
    preview.entry = entry;
    preview.text = ''; preview.rows = []; preview.error = '';
    if (entry.kind === 'folder') { preview.status = 'ready'; preview.mode = 'folder'; render(); return; }
    preview.status = 'loading'; preview.mode = 'meta'; render();
    const g = ++previewGeneration;
    try {
      if (isImage(entry)) {
        preview.status = 'ready'; preview.mode = 'image';
      } else if (isPdf(entry)) {
        preview.status = 'ready'; preview.mode = 'pdf';
      } else if (isCsv(entry)) {
        const response = await fetch(entry.davUrl, { credentials:'same-origin', cache:'no-store' });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const text = await response.text();
        if (g !== previewGeneration) return;
        preview.status = 'ready'; preview.mode = 'table'; preview.rows = parseDelimited(text, ext(entry.name)==='tsv' ? '\t' : ',');
      } else if (isText(entry)) {
        const response = await fetch(entry.davUrl, { credentials:'same-origin', cache:'no-store' });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const text = await response.text();
        if (g !== previewGeneration) return;
        preview.status = 'ready'; preview.mode = 'text'; preview.text = text.slice(0, 180000);
      } else if (isOffice(entry)) {
        preview.status = 'ready'; preview.mode = 'office';
      } else {
        preview.status = 'ready'; preview.mode = 'meta';
      }
      render();
    } catch (error) {
      if (g !== previewGeneration) return;
      console.error('[Neos] aperçu indisponible', error);
      preview.status = 'error'; preview.error = 'Aperçu indisponible'; render();
    }
  }

  function encodeSettings() {
    const form = new URLSearchParams();
    const put = (key, value) => form.append(`settings[${key}]`, String(value));
    ['theme','density','accent','layout','motion','notes'].forEach(key => put(key, settings[key] || ''));
    settings.order.forEach((v,i) => form.append(`settings[order][${i}]`, v));
    settings.hidden.forEach((v,i) => form.append(`settings[hidden][${i}]`, v));
    Object.entries(settings.sizes || {}).forEach(([id,v]) => form.append(`settings[sizes][${id}]`, String(v)));
    (settings.links || []).forEach((l,i) => { form.append(`settings[links][${i}][title]`, l.title); form.append(`settings[links][${i}][url]`, l.url); });
    (settings.pins || []).forEach((p,i) => form.append(`settings[pins][${i}]`, p));
    (settings.topApps || []).forEach((id,i) => form.append(`settings[topApps][${i}]`, id));
    return form;
  }

  async function save() {
    if (saving) return;
    saving = true;
    while (saveQueued) {
      saveQueued = false;
      updateSaveIndicator('Enregistrement…');
      try {
        await api(root.dataset.settingsUrl, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:encodeSettings().toString() });
        updateSaveIndicator('Enregistré');
      } catch (error) {
        console.error('[Neos] sauvegarde impossible', error);
        updateSaveIndicator('Erreur');
        toast('Impossible d’enregistrer.', 'error');
        break;
      }
    }
    saving = false;
  }

  function queueSave() { saveQueued = true; if (!saving) void save(); }

  function radio(name, choices) {
    return `<div class="neos-choice-set">${choices.map(([value,label]) => `<label class="neos-choice"><input type="radio" name="${name}" value="${value}" ${settings[name]===value?'checked':''}><span>${label}</span></label>`).join('')}</div>`;
  }

  function renderEditor() {
    if (!editorOpen) { editorHost.replaceChildren(); return; }
    const appChoices = (overview?.shortcuts || []).map(app => `<label class="neos-check"><input type="checkbox" data-topapp="${esc(app.id)}" ${settings.topApps.includes(app.id)?'checked':''}><span>${esc(app.label)}</span></label>`).join('');
    editorHost.innerHTML = `<div class="neos-overlay" data-action="editor-backdrop"><aside class="neos-editor" role="dialog" aria-modal="true" aria-labelledby="neos-editor-title">
      <header class="neos-editor-head"><h2 id="neos-editor-title">Neos</h2><button type="button" class="neos-iconbtn" data-action="close-editor">${icon('close',18)}</button></header>
      <div class="neos-editor-body">
        <section><h3>Apparence</h3>${radio('theme',[['system','Auto'],['dark','Sombre'],['light','Clair']])}${radio('accent',[['indigo','Indigo'],['cyan','Cyan'],['emerald','Émeraude'],['rose','Rose'],['amber','Ambre']])}${radio('density',[['comfortable','Aérée'],['compact','Compacte']])}${radio('layout',[['wide','Pleine largeur'],['focused','Centrée']])}${radio('motion',[['full','Animé'],['subtle','Discret'],['off','Off']])}</section>
        <section><h3>Widgets</h3><div class="neos-pref-list">${settings.order.map((id, i) => `<div class="neos-pref-row"><label class="neos-check"><input type="checkbox" data-toggle="${id}" ${settings.hidden.includes(id)?'':'checked'}><span>${esc(widgetLabels[id])}</span></label><div class="neos-pref-tools"><select data-size="${id}">${[[3,'25%'],[4,'33%'],[6,'50%'],[8,'67%'],[12,'100%']].map(([s,t])=>`<option value="${s}" ${Number(settings.sizes[id])===s?'selected':''}>${t}</option>`).join('')}</select><button type="button" class="neos-iconbtn" data-action="move-up" data-id="${id}" ${i===0?'disabled':''}>↑</button><button type="button" class="neos-iconbtn" data-action="move-down" data-id="${id}" ${i===settings.order.length-1?'disabled':''}>↓</button></div></div>`).join('')}</div></section>
        <section><h3>Barre d’apps</h3><div class="neos-app-picks">${appChoices || '<div class="neos-empty">Aucune app détectée.</div>'}</div></section>
        <section><h3>Liens</h3><div class="neos-custom-links">${(settings.links || []).map((entry, i) => `<div class="neos-link-edit"><input data-link-title="${i}" value="${esc(entry.title)}" maxlength="80"><input data-link-url="${i}" value="${esc(entry.url)}" maxlength="600"><button type="button" class="neos-iconbtn" data-action="remove-link" data-index="${i}">${icon('trash',15)}</button></div>`).join('')}</div><button type="button" class="neos-btn" data-action="add-link">${icon('plus',15)} Ajouter</button></section>
      </div>
      <footer class="neos-editor-foot"><span data-save-indicator>Préférences individuelles</span><div><button type="button" class="neos-btn" data-action="arrange">Réorganiser</button><button type="button" class="neos-btn neos-btn-primary" data-action="close-editor">Terminer</button></div></footer>
    </aside></div>`;
  }
  function updateSaveIndicator(text){ const el = editorHost.querySelector('[data-save-indicator]'); if (el) el.textContent = text; }
  function openEditor(){ editing = true; editorOpen = true; render(); renderEditor(); surface.inert = true; }
  function closeEditor(keepEditing=false){ harvestLinks(); editorOpen = false; editing = keepEditing; surface.inert = false; renderEditor(); render(); }
  function harvestLinks(){ editorHost.querySelectorAll('[data-link-title]').forEach(input => { const i = Number(input.dataset.linkTitle); if (settings.links[i]) settings.links[i].title = input.value.trim().slice(0,80); }); editorHost.querySelectorAll('[data-link-url]').forEach(input => { const i = Number(input.dataset.linkUrl); if (settings.links[i]) settings.links[i].url = input.value.trim().slice(0,600); }); }

  function renderHubPanel() {
    if (popMode !== 'hub') { popHost.replaceChildren(); return; }
    popHost.innerHTML = `<div class="neos-pop-layer" data-action="close-pop"><div class="neos-hub-pop"><header><strong>Applications</strong><button type="button" class="neos-iconbtn" data-action="close-pop">${icon('close',18)}</button></header>${hubGrid(false)}${settings.links?.length ? `<div class="neos-hub-links">${settings.links.map(x => `<a href="${safeUrl(x.url)}" class="neos-link-card">${icon('link',14)}<span>${esc(x.title)}</span></a>`).join('')}</div>` : ''}</div></div>`;
  }

  async function load(silent=false) {
    try {
      const data = demo ? demo.overview : await api(root.dataset.overviewUrl);
      if (!data.overview || !data.settings) throw new Error('Réponse API inattendue');
      overview = data.overview;
      if (!settings || !silent) settings = { ...defaults(), ...data.settings, sizes:{...defaultSizes,...(data.settings.sizes||{})}, topApps:data.settings.topApps || ['files','calendar','tasks','talk'] };
      root.dataset.displayName = data.user?.name || 'toi';
      render();
      if (browser.loading || (!browser.items.length && !browser.error)) void browse(browser.path, false);
      if (silent) toast('Actualisé','success');
    } catch (error) {
      console.error('[Neos] chargement impossible', error);
      surface.innerHTML = `<div class="neos-fatal">${icon('alert',28)}<strong>Chargement impossible</strong><button type="button" class="neos-btn" data-action="refresh">Réessayer</button></div>`;
    }
  }

  surface.addEventListener('click', event => {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    if (action === 'refresh') { void load(true); void browse(browser.path,false); }
    else if (action === 'customize') { if (editorOpen) closeEditor(); else openEditor(); }
    else if (action === 'toggle-hub') { popMode = popMode === 'hub' ? '' : 'hub'; renderHubPanel(); }
    else if (action === 'browse-path') { void browse(target.dataset.path || '/'); }
    else if (action === 'reload-folder') { void browse(browser.path, false); }
    else if (action === 'toggle-view') { browser.view = browser.view === 'grid' ? 'list' : 'grid'; render(); }
    else if (action === 'pin-folder') {
      const path = target.dataset.path; if (!path) return;
      const current = settings.pins || [];
      settings.pins = current.includes(path) ? current.filter(x => x !== path) : [...current, path].slice(0,12);
      queueSave(); render();
    }
    else if (action === 'select-entry') { void selectEntry(target.dataset.path || ''); }
    else if (action === 'open-file') { const entry = browser.items.find(x => x.path === target.dataset.path); if (entry?.url) window.location.assign(entry.url); }
    else if (action === 'save-note') { settings.notes = surface.querySelector('#neos-note')?.value || ''; queueSave(); toast('Note enregistrée', 'success'); }
    else if (action === 'preview-dav') { void previewFromDav(target.dataset.url || '', target.dataset.name || '', target.dataset.mime || ''); }
    pulse(target);
  });

  surface.addEventListener('input', event => {
    const el = event.target;
    if (el.matches('[data-browser-search]')) { browser.query = el.value; render(); }
    if (el.matches('#neos-note')) settings.notes = el.value;
  });
  surface.addEventListener('change', event => {
    const el = event.target;
    if (el.matches('[data-browser-sort]')) { browser.sort = el.value; render(); }
    if (el.matches('[data-browser-type]')) { browser.type = el.value; render(); }
  });

  editorHost.addEventListener('click', event => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    const action = actionEl.dataset.action;
    if (action === 'editor-backdrop' && event.target === actionEl) { closeEditor(); return; }
    if (action === 'close-editor') { closeEditor(); return; }
    if (action === 'arrange') { closeEditor(true); return; }
    if (action === 'add-link') { harvestLinks(); if ((settings.links || []).length < 12) settings.links.push({title:'Lien', url:'/'}); queueSave(); renderEditor(); render(); }
    if (action === 'remove-link') { harvestLinks(); settings.links.splice(Number(actionEl.dataset.index), 1); queueSave(); renderEditor(); render(); }
    if (action === 'move-up' || action === 'move-down') {
      const id = actionEl.dataset.id; const idx = settings.order.indexOf(id); const next = idx + (action === 'move-up' ? -1 : 1); if (idx < 0 || next < 0 || next >= settings.order.length) return;
      [settings.order[idx], settings.order[next]] = [settings.order[next], settings.order[idx]]; queueSave(); renderEditor(); render();
    }
  });
  editorHost.addEventListener('change', event => {
    const el = event.target;
    if (el.matches('input[type="radio"]')) { settings[el.name] = el.value; queueSave(); render(); }
    else if (el.matches('[data-toggle]')) { const id = el.dataset.toggle; settings.hidden = el.checked ? settings.hidden.filter(x => x !== id) : [...settings.hidden, id]; queueSave(); render(); }
    else if (el.matches('[data-size]')) { settings.sizes[el.dataset.size] = Number(el.value); queueSave(); render(); }
    else if (el.matches('[data-topapp]')) {
      const id = el.dataset.topapp;
      settings.topApps = el.checked ? [...new Set([...(settings.topApps || []), id])] : (settings.topApps || []).filter(x => x !== id);
      queueSave(); render();
    }
    else if (el.matches('[data-link-title],[data-link-url]')) { harvestLinks(); queueSave(); }
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (editorOpen) { event.preventDefault(); closeEditor(); }
      else if (popMode) { popMode = ''; renderHubPanel(); }
    }
  }, true);
  popHost.addEventListener('click', event => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    if (actionEl.dataset.action === 'close-pop') { popMode = ''; renderHubPanel(); }
  });

  surface.addEventListener('dragstart', event => {
    if (!editing) return;
    const card = event.target.closest('[data-widget]'); if (!card) return;
    event.dataTransfer?.setData('text/plain', card.dataset.widget); if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
    card.classList.add('is-dragging');
  });
  surface.addEventListener('dragend', event => event.target.closest('[data-widget]')?.classList.remove('is-dragging'));
  surface.addEventListener('dragover', event => { if (editing && event.target.closest('[data-widget]')) event.preventDefault(); });
  surface.addEventListener('drop', event => {
    if (!editing) return;
    const target = event.target.closest('[data-widget]'); if (!target) return;
    event.preventDefault();
    const from = event.dataTransfer?.getData('text/plain'); const to = target.dataset.widget;
    if (!widgetIds.includes(from) || !widgetIds.includes(to) || from === to) return;
    const order = [...settings.order]; const fromIndex = order.indexOf(from), toIndex = order.indexOf(to); if (fromIndex < 0 || toIndex < 0) return;
    order.splice(fromIndex, 1); order.splice(toIndex, 0, from); settings.order = order; queueSave(); render();
  });

  surface.addEventListener('pointermove', event => {
    if (!motionEnabled() || event.pointerType === 'touch') return;
    const card = event.target.closest('.neos-card'); if (!card) return;
    const rect = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${event.clientX - rect.left}px`); card.style.setProperty('--my', `${event.clientY - rect.top}px`);
  }, { passive:true });

  clockTimer = setInterval(updateClock, 30000);
  void load();
})();
