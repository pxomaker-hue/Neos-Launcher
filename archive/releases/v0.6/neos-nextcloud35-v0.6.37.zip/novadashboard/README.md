## Neos v0.6.37 — Nouveau logo cyber du dashboard

Le logo de la barre supérieure associe un monogramme N angulaire à un lettrage NEOS original. Deux SVG adaptés aux thèmes sombre et clair garantissent sa lisibilité.

## Neos v0.6.36 — Logo du dashboard plus lisible

Le mot-symbole de la barre supérieure est plus lisible sur ordinateur et mobile, en thème sombre ou clair.

## Neos v0.6.33 — Widget Tâches incluant Deck

Le widget d’accueil montre les tâches CalDAV et Deck déjà consultables dans le module Tâches ; mise à jour non destructive. Installe via Deploy-Neos.ps1 après sauvegarde.

## Neos v0.6.32 — création de tâches CalDAV

Le widget Tâches mène au module complet. La création tient compte du droit DAV:bind sur les listes CalDAV ; les cartes Deck restent gérées par Deck. Consulte CHANGELOG.md et PLAN-v0.7.md.

# v0.6.29 : recherche au clavier contextuelle, effacement par Échap, accès direct au contenu et maintien du focus des filtres.

## Neos 0.6.26 — Activité : pagination fiable et résultats accessibles

Le module Activité affiche les activités chargées par lots de 15, même après plusieurs pages serveur. Filtres locaux par source et période (7/30 jours). Un compteur indique le nombre réellement chargé. Contacts optimise la recherche dans les grands carnets. Aucune mutation des données Nextcloud n'est ajoutée par cette version.

## Neos 0.6.25 — Contacts plus accessibles

Le module Contacts propose maintenant la recherche dans les deux numéros et les deux adresses mail, le choix du carnet et un affichage progressif par lots de 35. Les très grands carnets donnent un avertissement explicite sur les limites côté Neos. Les modifications CardDAV, Talk, Mail et Planning conservent leurs API et comportements déjà validés.

## Neos v0.6.24 — stabilité Talk/Mail

- Talk : actualisation non destructive des historiques, pagination et défilement préservés.
- Mail : reprise d'une lecture ayant échoué, sans suppression/envoi ; synchro Réception mise en pause pendant la consultation Brouillons.
- Contacts, Planning, Deck, Tâches, topbar et Flat Cyber conservés.

# Neos v0.6.20 — Nextcloud 35

Application `novadashboard` pour Nextcloud 35 et installation OMV/LinuxServer.io. Cette version corrige le transfert vers le dossier IMAP des brouillons Mail et ajoute un filtre de conversations Talk non lues. Design Flat Cyber et modules historiques conservés.

Voir `INSTALLATION-OMV.md`, `CHANGELOG.md`, `TESTS.md` et `PLAN-v0.7.md`. Ne pas envoyer de message réel pour tester les brouillons.

## Neos v0.6.28 — compteurs simplifiés

Les modules Mail, Talk, Contacts et Activité affichent désormais un nombre cyan suivi du seul mot « élément(s) ». Le compteur de résultats de recherche ne s’affiche que lorsqu’un filtre ou une recherche est appliqué. Les fonctions existantes restent inchangées.

## Neos v0.6.27

La pagination du flux Activité suit désormais le lien HTTP `rel="next"` et le curseur OCS. Le panneau Activité conserve l'accès à l'historique plus ancien même lorsque le serveur regroupe moins de 30 éléments dans sa réponse. Mail, Talk, Contacts et Activité utilisent un seul titre de panneau, sans répéter celui-ci dans le bandeau descriptif.
