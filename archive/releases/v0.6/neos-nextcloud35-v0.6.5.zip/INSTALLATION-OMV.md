# Neos v0.6.5 — Installation Nextcloud 35 / OMV

Mise à jour fonctionnelle depuis Neos 0.6.4. Identifiant technique conservé : `novadashboard`. Pas de modification des volumes Docker, de MariaDB ni des données `/data` sur sdb1.

## Nouveautés

- Onglet **Planning** : chronologie combinée événements Agenda (CalDAV), tâches datées non terminées et échéances de cartes Deck. Filtres 7 / 30 / 90 jours et par source ; lien direct aux fiches.
- Deck : lecture bornée à 8 tableaux (300 cartes datées maximum) pour limiter les requêtes.
- Écriture Tâches plus prudente : `GET` de la tâche courante, récupération de son ETag, recherche par UID si l'URL n'existe plus, modification conditionnelle `If-Match`, puis relecture de vérification.
- Si `PUT` retourne toujours 404 alors que `GET` fonctionne, Neos affiche explicitement le cas afin d'orienter le diagnostic vers le serveur ou proxy. Ne pas désactiver les protections du proxy sans diagnostic.

## Installation — une commande par ligne

Depuis **Windows PowerShell**, placer l'archive téléchargée dans `X:\Travail\Apprentissage\Codage\Neos Launcher` puis :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.5.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

Sur le NAS :

```bash
sudo docker exec nextcloud occ status
```

Continuer seulement si Nextcloud 35.x, `maintenance: false` et `needsDbUpgrade: false`.

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Si le message n’apparaît pas, arrêter ici.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v065.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v065.tar.gz
```

```bash
mkdir -p /tmp/neos-v065
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.5.zip /tmp/neos-v065
```

```bash
test -f /tmp/neos-v065/novadashboard/appinfo/info.xml && echo "Archive prête"
```

```bash
sudo docker cp /tmp/neos-v065/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Attendu : `novadashboard: 0.6.5`. Recharger Nextcloud : **Ctrl + F5**.

## Tester le 404 à la validation d'une tâche

1. Dans **Tâches**, crée une tâche de test (idéalement une tâche neuve avec échéance). Clique sur le bouton pour la terminer, puis vérifie son état après rechargement.
2. Si l'erreur persiste, ouvrir F12 → **Réseau**, filtrer `remote.php/dav/calendars`, refaire l'opération et relever les méthodes/status dans l'ordre (`GET`, `REPORT`, `PUT`), ainsi que le type de réponse (`text/calendar`, `text/html`, XML). Ne pas envoyer de cookies, jetons d'authentification ou la réponse brute si elle contient des données personnelles.
3. **GET 404** : la tâche a pu être supprimée/déplacée ou le lien CalDAV retourné est incorrect. Neos tente une recherche par UID dans les listes accessibles ; si rien de sûr n'est trouvé, il refuse la modification.
4. **GET 200 / PUT 404** : lecture du fichier CalDAV possible, mais refus de l'écriture. Examiner dans Nginx Proxy Manager / Nextcloud si la méthode PUT parvient à `/remote.php/dav/calendars/`. Ne pas désactiver globalement la CSP ou modifier les ACL au hasard.
5. **HTTP 412** : conflit ETag, actualiser et réessayer. Neos n'écrase pas un changement concurrent.

Ne pas tester sur une tâche importante avant validation sur le NAS réel.

## Retour arrière

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v065.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ status
```

Rafraîchir le navigateur. Ne lancer `occ upgrade` que si Nextcloud le réclame explicitement.
