# Neos v0.6.21 — Installation sur OpenMediaVault

**Plateforme :** Nextcloud 35, image LinuxServer.io (`nextcloud`), application `novadashboard`.

Cette version corrige la découverte du dossier Brouillons IMAP et ajoute la suppression contrôlée des contacts CardDAV. **Les données mail et les carnets restent sur Nextcloud, la mise à jour ne les migre pas.**

## 1. PowerShell Windows : une commande à la fois

Télécharge `neos-nextcloud35-v0.6.21.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.21.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. NAS OMV (terminal SSH)

Exécute **chaque commande séparément** et arrête-toi en cas d'erreur.

```bash
sudo docker exec nextcloud occ status
```

Vérifie `maintenance: false` et `needsDbUpgrade: false`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.21.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

### Sauvegarde de la v0.6.20

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0621.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0621.tar.gz
```

### Décompression et installation

```bash
mkdir -p /tmp/neos-v0621
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.21.zip /tmp/neos-v0621
```

```bash
test -f /tmp/neos-v0621/novadashboard/appinfo/info.xml && echo "Archive prête"
```

```bash
sudo docker cp /tmp/neos-v0621/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.21`.

Dans le navigateur, effectue **Ctrl + F5**.

## 3. Tests prioritaires

1. Dans **Neos → Mail → Brouillons**, vérifie que le dossier configuré est détecté et que les brouillons apparaissent. En cas de liste vide, utilise **Dossier Brouillons** pour sélectionner le dossier manuellement. Le diagnostic indique les dossiers consultés et le nombre de messages trouvés.
2. Ouvre un brouillon en lecture seule. Sa modification et ses pièces jointes restent protégées dans Mail natif.
3. Dans **Neos → Contacts**, ouvre une **fiche fictive de test**, sélectionne **Supprimer**, vérifie le panneau de confirmation, puis décide si tu souhaites valider la suppression. Pour ce test, n'utilise pas une fiche réelle importante.
4. Vérifie que Talk, Planning, Tâches et les onglets personnalisés fonctionnent toujours.

## 4. Retour arrière (si nécessaire)

Dans la **même session SSH**, après avoir récupéré `APP_PATH` comme ci-dessus, restaure la sauvegarde des fichiers applicatifs :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0621.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Termine avec **Ctrl + F5**. La restauration ne supprime pas d'éventuels fichiers supplémentaires ajoutés par la nouvelle version ; l'archive conserve les fichiers d'origine. Cette installation ne nécessite pas de migration de base de données.

## 5. Sécurité

- Aucun changement des protections CSP, CSRF ou du proxy.
- La suppression de contact est uniquement déclenchée par une confirmation explicite. Elle utilise `If-Match` pour contrôler l'ETag.
- Aucune suppression de brouillon, aucun envoi automatique.
- Ne partage jamais d'en-têtes `Cookie` ni de jetons d'authentification depuis F12.
