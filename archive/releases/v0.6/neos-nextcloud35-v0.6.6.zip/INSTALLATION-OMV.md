# Neos v0.6.6 — Installation OMV / Nextcloud 35

Cette version conserve l’application `novadashboard` et le design Flat Cyber (Agenda Mois/Semaine, Tâches, Deck, Planning et autres modules). **Ne modifie pas Docker, les volumes, la base de données ou la configuration CSP/proxy.**

## Nouveautés

- Correctif « Objet CalDAV illisible » : lecture GET de la tâche ; si la réponse est non-VTODO (par exemple une page HTML) ou si l’ETag manque, tentative `REPORT calendar-multiget` pour récupérer les données et l’ETag. Vérification UID, `If-Match`, lecture de contrôle et diagnostic précis. Les opérations restent sûres : jamais de PUT sans UID et ETag vérifiables.
- Planning : cartes et tâches sans échéance, indicateurs tâches en cours/en retard, bouton Terminer directement dans la liste sans date ; correction de la date pour `DUE;VALUE=DATE`.
- La correction est testée avec un faux serveur CalDAV, **pas encore sur ton NAS**. S’il y a toujours une erreur, relève les requêtes GET/REPORT/PUT et leurs codes dans F12 → Réseau, sans partager cookies ni données personnelles.

## Installation — une commande à la fois

**Sur PowerShell** (adapter le chemin local si nécessaire) :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.6.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

**Sur OMV** (vérifier `maintenance: false` et `needsDbUpgrade: false`) :

```bash
sudo docker exec nextcloud occ status
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

**Arrêter ici** si Neos n’est pas trouvé. Sauvegarde avant copie :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v066.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v066.tar.gz
```

```bash
mkdir -p /tmp/neos-v066
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.6.zip /tmp/neos-v066
```

```bash
test -f /tmp/neos-v066/novadashboard/appinfo/info.xml && echo "Archive prête"
```

```bash
sudo docker cp /tmp/neos-v066/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Version attendue : `novadashboard: 0.6.6`. Rafraîchir Nextcloud avec **Ctrl + F5**.

## Tests après installation

1. Dans Tâches, créer une tâche temporaire dans une liste modifiable ; cocher la tâche. Vérifier que l’état reste terminé après actualisation ; décocher pour tester la réouverture. Tester le passage Tâches → Planning.
2. Dans Planning, vérifier les événements, les échéances Deck et la rubrique **Sans échéance**. Terminer une tâche sans date pour vérifier sa disparition de la liste.
3. Créer une tâche avec échéance de demain dans Nextcloud : contrôler qu’elle garde le bon jour en édition et dans Planning.
4. Si une erreur apparaît, ouvrir F12 → Réseau → filtre `remote.php/dav/calendars`, noter les méthodes et codes HTTP : `GET`, `REPORT`, `PUT`. Vérifier aussi le `Content-Type` du GET. Ne pas copier les en-têtes contenant cookies ou `requesttoken`.
5. Vérifier le reste : Agenda Mois/Semaine, édition Deck, fichiers, aperçus et notes.

### Erreurs courantes

- **GET 200 HTML, REPORT 207 avec VTODO/ETag** : le repli devrait permettre la modification.
- **GET 200 HTML, REPORT 403/404 ou données manquantes** : analyser authentification, URL CalDAV et proxy ; le PUT n’est pas envoyé.
- **PUT 404** : l’objet a pu changer de chemin ou l’écriture peut être empêchée par le proxy/serveur.
- **PUT 412** : conflit de version ; actualiser, ne pas forcer l’écrasement.

## Retour arrière (si nécessaire)

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v066.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ status
```

Si `APP_PATH` n’est plus défini (nouvelle session SSH), relancer d’abord sa commande de définition. La sauvegarde est stockée dans `/config` **du conteneur**.
