# Plan vers Neos v0.7 — après v0.6.24

| Module | État fonctionnel | Reste avant la v0.7 |
| --- | --- | --- |
| Mail | Synchronisation IMAP, lecture filtrée, envoi, brouillons IMAP, copie texte y compris vide, relance de lecture et protection pendant synchronisation | Valider v0.6.24 sur NAS ; pièces jointes/édition en place uniquement avec garantie de conservation (sinon rester dans Mail natif) |
| Talk | Messages et envoi, marqueur « Lu » validé sur NAS en v0.6.22, historique et défilement préservés en v0.6.24 | Tester sur longues conversations et rafraîchissement réel, notifications avancées |
| Contacts | Création, édition, champs multiples, suppression validées sur NAS | Audit de performance des carnets volumineux et mobile |
| Activité | Filtres et pagination serveur | Volumes importants, filtres avancés |
| Planning / Deck / Tâches / Agenda | Parcours fonctionnels validés | Tests de non-régression et écrans mobiles |
| Interface | Flat Cyber, icône Planning orange, topbar personnalisable | Accessibilité clavier, états de chargement, optimisations |

**Principes :** pas de perte de brouillons/pièces jointes ; pas de modification destructive sans confirmation et vérification du serveur ; sauvegardes OMV avant chaque mise à jour.
