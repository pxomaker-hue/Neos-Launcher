# Neos 0.6.24 — robustesse Talk & Mail

- Talk : les actualisations conservent les messages déjà récupérés, y compris les pages d’historique anciennes, et gardent le curseur de pagination. Une erreur réseau durant le rafraîchissement automatique ne masque plus la conversation en cours.
- Talk : conservation de la position de défilement, et du focus/sélection dans la zone de rédaction lors d’un rafraîchissement ; heure de dernière actualisation affichée.
- Mail : suspendre la synchronisation périodique de la Réception lorsqu'un dossier Brouillons est consulté, afin de ne pas interrompre la lecture de brouillons. Le bouton de synchronisation principale est indisponible pendant une lecture/rédaction ouverte.
- Mail : bouton « Réessayer la lecture » pour les erreurs de lecture de message ou de brouillon IMAP (aucun envoi, déplacement ni suppression).
- Interface : version du pied de page mise à jour (bloquée à 0.6.19 depuis plusieurs versions), continuité Flat Cyber et icône Planning conservées.
- Aucun changement de l’API CardDAV de création/édition/suppression : préserver les fonctions Contacts déjà validées sur le NAS.
- Brouillons : reprise en copie texte uniquement, l'original IMAP reste intact.

# Neos 0.6.23 — correctif brouillons vides

- Mail : après chargement réussi, la reprise en copie autorise les brouillons IMAP sans texte. L’original reste intact.
- Mail : message vide explicitement signalé, champ Message facultatif pour enregistrer un brouillon ; l’envoi exige toujours un corps non vide.
- Talk, Contacts, Planning et autres fonctions conservés de v0.6.22.

# Neos 0.6.22

## Améliorations
- Mail : reprise prudente du texte d’un brouillon IMAP dans un **nouveau message** Neos. L’original IMAP reste intact ; pièces jointes, Cc/Cci et mise en forme ne sont pas copiés. Toute modification directe de l’original continue à se faire dans Mail natif.
- Talk : marqueur de lecture explicite avec confirmation du serveur via `POST /ocs/v2.php/apps/spreed/api/v1/chat/{token}/read`. Relecture périodique des messages lorsque le salon est ouvert, sans interférer avec un message en cours de rédaction.
- CSS : disposition adaptée aux petits écrans pour les nouvelles commandes.
- Maintien du thème Flat Cyber, du hub Planning, de la topbar personnalisable et de l’ensemble des modules de la version 0.6.21.

## Vérification sur NAS
- Valider le bouton « Marquer comme lu » dans Talk.
- Valider la reprise d’un brouillon texte fictif et constater que le brouillon original est toujours présent dans Mail natif.
- Aucun envoi automatique, aucune modification/destruction du brouillon original n’est déclenché par la reprise.

---

# Neos 0.6.21

## Correctifs
- Brouillons IMAP : récupération de l’identifiant `draftsMailboxId` depuis les données complètes du compte Mail (il était supprimé dans le résumé interne), indépendamment du nom du dossier.
- Sélecteur manuel de dossier si le serveur ne fournit pas de rôle IMAP reconnaissable. Affichage du nombre de dossiers détectés et des requêtes réellement exécutées.
- Diagnostic visible en cas de dossier absent, dossier non synchronisé ou réponse en erreur ; pas de faux message « dossier vide ».

## Nouveautés
- Contacts : suppression avec confirmation explicite, contrôle ETag avant requête conditionnelle `DELETE`, puis vérification d’absence. Aucune suppression automatique.
- Thème et fonctionnalités précédentes conservés.

## À valider sur le NAS
- Lecture du dossier Brouillons (Mail 5.13.2) et sélection manuelle au besoin.
- Suppression d'un contact fictif temporaire uniquement.
# Neos 0.6.20

- Mail : consultation des dossiers Brouillons IMAP dans Neos, avec aperçu filtré et lien direct vers l’édition de l’original dans Mail natif. Aucune écriture, suppression ou expédition depuis ce lecteur.
- Contacts : deux courriels et deux téléphones, tout en préservant les autres champs vCard lors des éditions via ETag.
- Conservation du design Flat Cyber, topbar et fonctionnalités des versions précédentes.

# Historique Neos

## 0.6.19 — Brouillons visibles dans Mail natif et Talk filtrable

- Correction de la confirmation trompeuse des brouillons dans la v0.6.18 : `POST /api/drafts` ou `PUT /api/drafts/{id}` crée/met à jour seulement un brouillon local à Nextcloud Mail.
- Après cette première étape, appel explicite à `POST /api/drafts/move/{id}`, qui demande à Nextcloud Mail 5.13.2 de transférer le brouillon dans le dossier IMAP Brouillons. Aucun envoi SMTP n'est effectué.
- Le formulaire est verrouillé après transfert accepté pour éviter de réutiliser un identifiant temporaire supprimé côté serveur ; l'édition/reprise du brouillon transféré s'effectue dans Mail natif. Cette limitation est affichée dans Neos.
- En cas de transfert non confirmé, message explicite avec identifiant local et blocage des essais répétitifs automatiques, pour ne pas créer de doublon. Avant un nouvel essai : examiner Mail natif.
- Filtre « Toutes / Non lues » dans les conversations Talk et actualisation de la liste au retour d'une conversation. Les non-lus proviennent de l'API Talk, sans marquage forcé.
- Conservés : ordre de topbar, icône Planning, Contacts, Agenda, Tâches, Deck, Activité, lecture HTML des mails, envoi, synchronisation des boîtes, suivi Outbox.

# Historique Neos

## 0.6.18 — Brouillons Mail et suivi des envois

- Enregistrer un brouillon dans Nextcloud Mail via POST /api/drafts ; mises à jour via PUT /api/drafts/{id}.
- Suivre les messages en boîte d'envoi via GET /api/outbox ; aucun renvoi automatique.
- Vérification non destructive de l'état d'une référence d'envoi (GET /api/outbox/{id}).
- Brouillons conservés côté serveur, sans stockage local du contenu ; reprise après reconnexion via Mail natif.
- Prévention de la réutilisation accidentelle d'un ancien brouillon comme « nouveau message ».
- Conserve les fonctionnalités v0.6.17 et précédentes.

## 0.6.17 — synchronisation de Mail

- Synchroniser la boîte IMAP avant de lire les messages (API Mail 5.13.2).
- Bouton Synchroniser visible, avec heure de dernière synchronisation réussie.
- Rafraîchissement toutes les 90 s quand l'espace Mail est actif et visible ; contrôle après envoi confirmé.
- Un seul rafraîchissement simultané ; gestion bornée des retours 428 (initialisation), 409 (occupé) et 500 (erreur).
- Conserve les messages précédemment mis en cache en cas d'échec temporaire.

## 0.6.16 — rédaction / envoi / réponse

- Interface de composition texte dans Mail, envoi en deux étapes via Outbox.
