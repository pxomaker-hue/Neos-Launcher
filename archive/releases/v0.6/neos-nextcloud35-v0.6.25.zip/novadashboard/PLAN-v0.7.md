# Feuille de route v0.7 — après v0.6.25

| Zone | Acquis | Reste à valider |
| --- | --- | --- |
| Contacts | Deux courriels, deux téléphones, création/édition/suppression ETag validées ; filtre par carnet et liste progressive en v0.6.25 | Tester les grands carnets réels, limites à 250 par carnet / 400 chargées ; rechercher une future pagination distante sans modifier les données |
| Talk | Envoi, lecture, marqueur lu ; actualisation prudente et conservation de l’historique | Vérifier la pagination sur historique long et l'actualisation sur NAS |
| Mail | Brouillons IMAP et reprise texte non destructive, lecture HTML sécurisée, envoi, relecture après erreur | Tester le bouton Réessayer sur NAS ; pièce jointe dans la copie uniquement après API validée |
| Activité | Filtres et pagination OCS | Tester un historique réel volumineux |
| Planning/Deck/Tâches/Agenda | Parcours fonctionnels validés | Audit de régression, échéances et permissions |
| Design | Flat Cyber, icône Planning orange et topbar réorganisable | Affiner l’accessibilité clavier et le mobile |

Toute modification destructive demeure conditionnée à une confirmation et, si applicable, à une vérification ETag. Les ZIP sont publiés sur GitHub et déployés après sauvegarde OMV.
