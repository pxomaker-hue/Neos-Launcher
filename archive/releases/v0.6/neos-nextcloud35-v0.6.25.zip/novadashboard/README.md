## Neos 0.6.25 — Contacts plus accessibles

Le module Contacts propose maintenant la recherche dans les deux numéros et les deux adresses mail, le choix du carnet et un affichage progressif par lots de 35. Les très grands carnets donnent un avertissement explicite sur les limites côté Neos. Les modifications CardDAV, Talk, Mail et Planning conservent leurs API et comportements déjà validés.

## Neos v0.6.24 — stabilité Talk/Mail

- Talk : actualisation non destructive des historiques, pagination et défilement préservés.
- Mail : reprise d'une lecture ayant échoué, sans suppression/envoi ; synchro Réception mise en pause pendant la consultation Brouillons.
- Contacts, Planning, Deck, Tâches, topbar et Flat Cyber conservés.

# Neos v0.6.20 — Nextcloud 35

Application `novadashboard` pour Nextcloud 35 et installation OMV/LinuxServer.io. Cette version corrige le transfert vers le dossier IMAP des brouillons Mail et ajoute un filtre de conversations Talk non lues. Design Flat Cyber et modules historiques conservés.

Voir `INSTALLATION-OMV.md`, `CHANGELOG.md`, `TESTS.md` et `PLAN-v0.7.md`. Ne pas envoyer de message réel pour tester les brouillons.
