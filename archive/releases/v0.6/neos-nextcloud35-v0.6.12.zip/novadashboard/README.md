# Neos Launcher v0.6.12 — Nextcloud 35

Module Nextcloud `novadashboard` développé pour l'environnement OMV / LinuxServer.io.

## Changements v0.6.12

- Contacts : création et modification de contacts CardDAV avec contrôle d’ETag, validation après sauvegarde et conservation des autres propriétés vCard.
- Mail : filtre de la boîte entre Tous et Non lus ; les opérations sensibles restent dans Mail natif.
- Les fonctions Talk, Activité, Agenda, Deck, Tâches, Planning, et la topbar personnalisable sont conservées.

Lire `INSTALLATION-OMV.md` avant toute installation.

Note : les captures/aperçus de démonstration utilisent des données fictives. Les opérations réseau ont été vérifiées d'après la documentation des API Nextcloud mais nécessitent validation sur le NAS réel.
