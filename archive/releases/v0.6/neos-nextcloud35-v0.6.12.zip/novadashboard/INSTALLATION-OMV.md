# Neos v0.6.12 — Installation sur OMV / Nextcloud 35

Module : `novadashboard`. Environnement validé jusqu'à v0.6.11 : NAS OpenMediaVault, conteneur Nextcloud LinuxServer.io, design Flat Cyber.

**Exécuter chaque commande séparément.** La mise à jour ne nécessite aucune modification de Nginx Proxy Manager, CSP, ni des dossiers personnels Nextcloud.

## 1. Sur Windows — PowerShell

Télécharge l'archive `neos-nextcloud35-v0.6.12.zip` et place-la dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.12.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Sur le NAS — terminal SSH

Vérifier que `maintenance: false` et `needsDbUpgrade: false` :

```bash
sudo docker exec nextcloud occ status
```

Vérifier le fichier reçu :

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.12.zip
```

Récupérer le chemin de l'application :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

Vérifier le chemin et l'application :

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé : $APP_PATH"
```

**Si la ligne « Neos trouvé » ne s'affiche pas, arrête-toi ici.**

Sauvegarder la version v0.6.11 :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0612.tar.gz -C "$APP_PATH" .
```

Vérifier la présence de la sauvegarde :

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0612.tar.gz
```

Préparer le dossier temporaire :

```bash
mkdir -p /tmp/neos-v0612
```

Extraire :

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.12.zip /tmp/neos-v0612
```

Vérifier le contenu de l'archive :

```bash
test -f /tmp/neos-v0612/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**Si « Archive prête » ne s'affiche pas, ne lance pas les étapes suivantes.**

Installer :

```bash
sudo docker cp /tmp/neos-v0612/novadashboard/. "nextcloud:$APP_PATH/"
```

Rétablir le propriétaire LinuxServer.io :

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

Vérifier la version :

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.12`. Dans le navigateur : **Ctrl + F5**.

## 3. Contrôles prioritaires

1. **Contacts** : dans Neos, ouvrir Contacts → Nouveau contact. Sélectionner le carnet **Personnel** (ou un carnet où tu as droit d'écriture), créer un contact **temporaire fictif** et vérifier son apparition dans Contacts natif.
2. Modifier ce contact dans Neos, recharger la liste et vérifier que les nouvelles valeurs ont été enregistrées dans Contacts natif.
3. Si une fiche provient d'un carnet en lecture seule, l'écriture doit être refusée explicitement (HTTP 403/405), sans modification.
4. **Mail** : tester le filtre « Non lus », puis « Tous ». La lecture complète et l'envoi restent dans Mail natif.
5. Vérifier qu'un message Talk peut toujours être envoyé, que les tâches se valident sans rechargement et que l'ordre de la topbar reste sauvegardé.

En cas d'erreur de contact, relever dans **F12 → Réseau** uniquement **la méthode (GET/PUT), le code HTTP et un message d'erreur sans donnée privée**. Ne jamais partager la vCard, les cookies, `requesttoken`, les adresses personnelles ni les coordonnées d'un contact réel.

## 4. Retour arrière vers v0.6.11

Avec `APP_PATH` toujours défini dans la **même session SSH**, exécuter séparément :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0612.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Terminer avec Ctrl + F5. La restauration de fichiers Neos ne revient **pas** sur les fiches Contacts créées ou modifiées ; elles restent dans Nextcloud et peuvent être gérées depuis l'application native.

## 5. Limites connues

- Création/édition Contacts : simulation CardDAV validée, à confirmer sur ton NAS. Contacts conserve les champs additionnels d'une fiche existante, mais Neos n'offre pour l'instant qu'un champ principal pour e-mail et téléphone.
- Carnets partagés complexes : selon les permissions Nextcloud, les opérations peuvent être refusées et doivent rester sécurisées.
- Mail : filtre local « Non lus », pas de lecture/réponse/envoi intégrés dans cette version ; dépend de la version réelle de Nextcloud Mail.
- Aucun identifiant ou mot de passe IMAP n'est enregistré dans Neos.
