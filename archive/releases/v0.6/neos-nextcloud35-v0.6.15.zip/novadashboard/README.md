# Neos Launcher v0.6.15 — Nextcloud 35

Suite de la v0.6.14 validée sur le NAS OMV. Design Flat Cyber et tous les modules préservés.

- Mail : rendu HTML filtré (éléments courants uniquement), images/scripts/formulaires/styles/ressources distantes supprimés.
- Mail : bascule Mise en forme / Texte ; navigation entre les messages.
- Compatibilité avec réponses `htmlBody`, `bodyHtml`, `body.html`, `plainBody` contenant du HTML.
- Aucun envoi de mail ni téléchargement de pièce jointe dans cette version ; utiliser Mail natif.
- Les corps de messages restent en mémoire de la page, sans stockage dans les préférences.

Les API Mail varient selon la version de l'application : valider les réponses HTML réelles sur le NAS.
