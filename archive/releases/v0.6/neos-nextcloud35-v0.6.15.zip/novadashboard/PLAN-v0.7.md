# Neos — feuille de route vers v0.7 après v0.6.15

## Déjà livré et confirmé sur ton NAS
- Tâches et Deck : validation de tâche opérationnelle.
- Planning : agenda, tâches, échéances Deck, tâches sans échéance, recherche et filtres.
- Topbar : ordre réorganisable sauvegardé.
- Talk : conversations et envoi texte.
- Contacts : création et édition CardDAV.
- Mail : comptes, dossiers et messages visibles en v0.6.14.

## v0.6.15 livrée — à confirmer sur NAS
- Courriels HTML rendus sans balises brutes.
- Filtrage strict des balises, blocage des images distantes et scripts.
- Bascule HTML/texte et navigation entre les messages.

## Prochaines fonctions avant 0.7
1. **Mail** : rédaction, brouillons, réponse et envoi avec contrôle de la version précise de l'application Mail. Ne pas activer l'envoi avant validation des endpoints et tests sur le NAS.
2. **Mail** : pièces jointes en lecture sécurisée, actions non lu/lu et pagination.
3. **Talk** : actualisation des non-lus, confort de conversation et pagination robuste.
4. **Contacts** : champs multiples, suppression avec confirmation et ETag.
5. **Activité** : filtres avancés et cohérence de la pagination.
6. **Stabilisation** : audit des erreurs, contrôles de régression, compatibilité Nextcloud 35 et mobile, documentation et retour arrière.

La v0.7 devra être validée sur le NAS avec les quatre espaces Talk, Activité, Contacts et Mail réellement utilisables, pas seulement accessibles par raccourci.
