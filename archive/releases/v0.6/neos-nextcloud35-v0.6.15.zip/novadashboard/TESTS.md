# Neos v0.6.15 — rapport de tests

- `node --check js/app.js` : OK.
- `php -l` template et contrôleur : OK.
- Tests Chromium via `page.set_content` de l'aperçu autonome : **OK ordinateur et mobile**.
- Ouverture d'un courriel HTML : titre, paragraphe, liste et emphase visibles.
- Bascule Mise en forme/Texte : OK.
- Bouton Suivant : OK en simulation.
- Filtrage HTML malveillant : les `<script>`, `<img>`, `<style>`, SVG, attributs `onclick`, liens `javascript:` ont été supprimés dans la sortie filtrée. Les liens HTTPS sûrs et les tableaux ont été préservés.
- Compatibilité avec `plainBody` contenant du HTML : OK.
- Aucune erreur JavaScript constatée dans les scénarios testés.
- Les images distantes ne sont pas chargées et ne sont pas ajoutées au DOM.

**Limite :** ces tests sont simulés, **pas réalisés sur le NAS Nextcloud**. Le rendu de messages réels, les différences de formats de réponse et les liens seront à valider par l'utilisateur.
