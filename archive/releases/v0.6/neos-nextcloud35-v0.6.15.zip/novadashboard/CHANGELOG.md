# Historique Neos

## v0.6.15 — Mail HTML filtré
- Lecture de courriels mis en forme sans exécuter de code ou charger d'images distantes.
- Affichage texte alternatif et navigation entre messages.
- Correction des messages HTML affichés comme du texte brut.
- Continuité depuis v0.6.14 : choix des boîtes et diagnostics préservés.
