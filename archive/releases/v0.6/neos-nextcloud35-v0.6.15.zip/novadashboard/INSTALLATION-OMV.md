# Neos v0.6.15 — Installation OMV / Nextcloud 35

## Nouveautés
- Lecture des courriels HTML **mise en forme** au lieu de balises affichées en brut.
- Rendu HTML filtré : suppression des scripts, formulaires, images distantes, ressources externes et attributs dangereux. Liens HTTP(S)/mailto autorisés avec ouverture dans un nouvel onglet.
- Bascule **Mise en forme / Texte**, boutons **Précédent / Suivant**.
- Tous les modules et la topbar de la v0.6.14 sont conservés.

**Important :** cette version ne prend pas en charge l'envoi ni la réponse depuis Neos. Les fonctions d'écriture restent dans Mail natif jusqu'à vérification de l'API de ta version de Mail.

## 1. Copier le ZIP depuis Windows

Télécharge `neos-nextcloud35-v0.6.15.zip` et range-le dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

Exécute **une commande à la fois** dans PowerShell :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.15.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier et sauvegarder sur OMV

Toutes les commandes suivantes se font **dans le terminal SSH du NAS**, séparément.

```bash
sudo docker exec nextcloud occ status
```

**Arrête-toi** si `maintenance: true` ou `needsDbUpgrade: true` : ne pas poursuivre la copie.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.15.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Si la réponse est `Neos trouvé` :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0615.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0615.tar.gz
```

## 3. Préparer puis installer v0.6.15

```bash
mkdir -p /tmp/neos-v0615
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.15.zip /tmp/neos-v0615
```

```bash
test -f /tmp/neos-v0615/novadashboard/appinfo/info.xml && echo "Archive prête"
```

Si `Archive prête` apparaît :

```bash
sudo docker cp /tmp/neos-v0615/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Version attendue : `novadashboard: 0.6.15`.

Termine avec **Ctrl + F5** dans ton navigateur.

## 4. Tests réels à effectuer

1. Ouvre Mail et un courriel contenant des paragraphes, gras, liens et listes : le HTML doit s'afficher comme du contenu mis en forme.
2. Clique sur **Texte** puis **Mise en forme** ; aucune balise HTML ne doit apparaître en clair.
3. Vérifie **Précédent / Suivant**, puis retour à la boîte.
4. Vérifie que l'ordre des onglets et les autres modules (Talk, Activité, Contacts, Deck, Planning, Tâches) sont conservés.

Les captures fournies représentent des messages fictifs. La mise à jour n'a pas encore été testée sur ton NAS.

## 5. Retour arrière vers v0.6.14

À effectuer sur OMV **uniquement si nécessaire**, après vérification de la sauvegarde :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
sudo docker exec nextcloud test -f /config/neos-backup-avant-v0615.tar.gz && echo "Sauvegarde trouvée"
```

Si la sauvegarde est trouvée :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0615.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Version attendue après retour arrière : `novadashboard: 0.6.14`. Recharge avec Ctrl + F5.

N'effectue pas de `occ upgrade` ni de modification du proxy Nginx pour cette mise à jour de fichiers.
