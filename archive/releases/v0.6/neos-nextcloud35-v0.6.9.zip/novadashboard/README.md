# Neos v0.6.0 — Flat Cyber Workspace pour Nextcloud 35

La v0.6.0 préserve les modules, le hub, les widgets holographiques et le gestionnaire de fichiers v0.5.9, avec trois évolutions de productivité : recherche filtrée, favoris natifs Nextcloud et fichiers consultés.

## Recherche

`Ctrl+K` ou `Partout` dans Fichiers : recherche par nom et filtres par type, modification, taille et tri. Parcours plafonné et limité aux fichiers de l'utilisateur. Aucun scan brut du NAS.

## Favoris

Utiliser les étoiles à côté des fichiers/dossiers ; enregistrement via WebDAV `oc:favorite`, lecture via `REPORT oc:filter-files`. Le raccourci de dossier épinglé à l'accueil est une fonction distincte.

## Récents

L'onglet « Consultés » affiche les chemins des 24 fichiers ouverts dans Neos sur ce navigateur, cloisonnés par identifiant utilisateur. Aucune donnée du fichier n'est conservée. L'historique est effaçable.

## Installation

Voir `INSTALLATION-OMV.md` dans le ZIP. Trouver le chemin réel avec `occ app:getpath novadashboard` plutôt que de supposer un ancien chemin. Identifiant technique : `novadashboard`.

# Neos — v0.5.4

Application personnalisée pour Nextcloud 35. L’identifiant technique reste `novadashboard` pour préserver la page d’accueil et les préférences existantes.

## Changements v0.5.4

- Disposition de l’accueil : **Adaptatif** (tailles calculées) et **Libre** (tailles personnalisables, de 25 % à 100 %).
- Déplacement des widgets directement sur l’accueil via une **poignée de glisser-déposer** avec repère de placement ; commandes de déplacement disponibles également pour mobile et clavier.
- Prévisualisation des réarrangements avec grille cyan, survol lumineux et animation d’atterrissage ; sauvegarde des préférences utilisateur dans Nextcloud.
- Deck : vérification de sa présence parmi les applications activées, essai des routes REST officielles puis OCS en cas de 404 ; messages d’erreur plus détaillés.
- Assets SVG du kit NEOS UI Kit v1 intégrés localement, dont le pictogramme de navigation `img/app.svg`.

## Limites

- L’erreur Deck 404 peut signifier une **application Deck absente/désactivée** ou une route indisponible sur l’instance. Neos ne peut pas activer Deck ni réparer sa configuration serveur.
- La confirmation du correctif Deck doit être faite sur une instance Nextcloud 35 avec Deck installé et actif pour l’utilisateur.
- Seuls les modules réellement implémentés dans Neos prennent en charge les actions intégrées ; les autres applications restent accessibles via leurs liens Nextcloud.
- Les suppressions et partages de fichiers demeurent des actions réelles sur les données Nextcloud : utiliser les confirmations.

## Installation

Consulter `INSTALLATION-OMV.md` à la racine de l’archive.

### Notes de la version 0.5.4
- PDF : aperçu dans Neos, sans téléchargement automatique (le bouton Télécharger reste disponible).
- Notes : si l'API Notes répond 404 ou si l'app Notes est désactivée, les notes `.md` et `.txt` dans le dossier Notes de l'utilisateur peuvent être consultées et modifiées. Le dossier peut être configuré par le paramètre Nextcloud Notes `defaultFolder`.
- Les modifications de notes en mode fichiers sont protégées par l'ETag pour éviter d'écraser une mise à jour concurrente.
- Le hub utilise en priorité les PNG 256 du kit graphique fourni.

## File Manager Pro (0.5.8)

Dans **Fichiers**, cochez plusieurs lignes ou utilisez `Ctrl/Cmd+clic` et `Maj+clic`.
Les actions groupées permettent de copier, déplacer, dupliquer ou supprimer les éléments.
Le presse-papiers est interne à Neos et reste actif pendant la session du dashboard.

- Copier : sélectionnez des éléments, **Copier**, naviguez vers le dossier cible, **Coller**.
- Déplacer : idem avec **Déplacer**. Les transferts utilisent WebDAV `MOVE`.
- Dupliquer : crée une nouvelle copie dans le même dossier, sans écraser l'original.
- Glisser-déposer : déposez un élément sur un dossier pour le déplacer (Ctrl/Cmd pour copier).
- Téléversement : déposez des fichiers de votre ordinateur dans le dossier cible. Les remplacements automatiques sont interdits.
- Supprimer : confirmation explicite pour toute sélection, y compris les sous-dossiers.

Les droits d’accès sont toujours contrôlés par Nextcloud. Les dossiers très volumineux restent limités aux premiers éléments retournés par le service de navigation. Les conflits et refus d'accès sont signalés, jamais contournés.


## v0.6.2 — Deck enrichi
- Création de cartes sans prompt, avec titre, description Markdown et échéance facultative.
- Édition : titre, description, colonne, échéance et case « Carte terminée ».
- Déplacement par glisser-déposer entre les colonnes sur ordinateur ; choix de colonne dans le formulaire sur mobile et clavier.
- Les mouvements réels sont vérifiés par une relecture de Deck après modification ; si l’API répond OK sans déplacer la carte, Neos tente la route de réorganisation compatible puis signale explicitement tout échec. Les dates, descriptions et statuts sont conservés dans la mise à jour.
- Aucune opération destructive automatisée ; pas de changement aux données, à MariaDB ni à la configuration de Nextcloud.


### v0.6.4
Agenda en vues Mois/Semaine et filtres Tâches, avec gestion explicite des listes VTODO absentes ou inaccessibles. Le bouton Ouvrir l’application Tâches native n’est affiché que si Nextcloud la déclare activée.


## v0.6.6
- Planning : Agenda, Tâches dues et échéances Deck (jusqu’à 8 tableaux), filtres 7/30/90 jours.
- Modification CalDAV VTODO : lecture fraîche GET, ETag courant, recherche UID si la tâche a changé de chemin, If-Match et relecture après PUT.
- Erreur PUT 404 détaillée pour faciliter le diagnostic du reverse proxy sans désactiver les protections.

### Neos 0.6.6

La lecture VTODO avant PUT utilise GET, puis `REPORT calendar-multiget` si la représentation reçue est invalide ou l’ETag est absent. Aucune écriture sans UID et ETag vérifiés. Planning affiche également les tâches sans échéance. Validation finale à effectuer sur Nextcloud 35 réel.

## v0.6.7 — Deck/CalDAV et Planning

Les objets VTODO provenant de `app-generated--deck--board-*` sont des projections CalDAV en lecture seule. Neos les affiche avec une étiquette **Deck** et passe par l’API Deck pour leur statut ; l’éditeur intégré ouvre la carte Deck. Les vraies tâches VTODO utilisent toujours CalDAV et la relecture sécurisée UID/ETag.

Le Planning intègre désormais les cartes Deck *sans date d'échéance* et permet de les marquer comme terminées directement. Les données Deck ne sont plus comptées deux fois dans la chronologie. Les autres modules sont préservés. La prise en charge des cartes dépend des droits Deck de l’utilisateur.


### Neos v0.6.8

- Validation / réouverture des cartes Deck via `PUT /apps/deck/cards/{cardId}/done|undone` plutôt que PUT de l'ensemble des champs ; état relu immédiatement.
- Recherche locale par texte (accents ignorés) et filtre « En retard » dans Planning.
- Les erreurs JSON fournies par Deck sont présentées sans afficher les jetons de session.
- La vérification sur une instance Nextcloud réelle reste obligatoire.

### Neos v0.6.9 : espaces Talk / Activité / Contacts / Mail

- **Talk :** `GET /ocs/v2.php/apps/spreed/api/v4/room` ; salons, dernier message et non-lus.
- **Activité :** `GET /ocs/v2.php/apps/activity/api/v2/activity?limit=50` ; journal des activités.
- **Contacts :** `PROPFIND` puis `REPORT addressbook-query` sur les carnets CardDAV de l'utilisateur connecté ; liste de contacts filtrable. Les carnets en lecture seule restent en lecture seule.
- **Mail :** lecture des comptes, dossiers et messages via l'API Mail (routes internes susceptibles de varier). Bouton « Rédiger » ouvrant la composition native, aucun secret IMAP collecté.
- Ces quatre modules sont des **étapes d'intégration en consultation** et non des remplacements complets des applications officielles. Avant v0.7 : conversation et envoi Talk, détails et filtres Activité, édition Contacts, lecture/rédaction et envoi Mail à réaliser après vérification des API et des droits de chaque instance.
- Après validation d'une tâche CalDAV, l'interface locale actualise son état immédiatement puis re-synchronise de façon non bloquante.

Sécurité : les contenus textuels affichés dans Neos sont échappés avant insertion HTML ; les requêtes utilisent la session Nextcloud courante, jamais d'identifiants Mail/Talk stockés dans Neos. Ne pas partager les en-têtes `Cookie` ou `requesttoken` des requêtes réseau.
