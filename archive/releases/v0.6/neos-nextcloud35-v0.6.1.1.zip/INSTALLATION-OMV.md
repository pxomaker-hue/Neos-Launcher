# Neos v0.6.1.1 — correctif PDF / favoris (Nextcloud 35)

Ce correctif conserve toutes les fonctions de la v0.6.1 et ne modifie aucune donnée Nextcloud.

## Modifications
- Favoris : l'URL WebDAV est construite à partir du webroot fourni par Nextcloud, et non du chemin de la route /api/overview. Avec un webroot vide, la cible attendue est /remote.php/dav/files/<uid>.
- Aperçu PDF : la réponse authentifiée de la route /api/inline-pdf utilise la CSP standard de Nextcloud qui autorise son intégration depuis le même domaine (`frame-ancestors 'self'`). Les autres pages du site ne sont pas affectées.
- Le contrôleur vérifie toujours les permissions de lecture et le format PDF. Pas de changement des montages Docker /data, /config ou MariaDB.

## Installation sur OMV — commandes UNE À LA FOIS

Depuis Windows PowerShell :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.1.1.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

Sur le NAS, vérifier `maintenance: false` et `needsDbUpgrade: false` :

```bash
sudo docker exec nextcloud occ status
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
echo "$APP_PATH"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Si le résultat est « Neos trouvé », sauvegarder l'application :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0611.tar.gz -C "$APP_PATH" .
```

```bash
mkdir -p /tmp/neos-v0611
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.1.1.zip /tmp/neos-v0611
```

```bash
sudo docker cp /tmp/neos-v0611/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Puis Ctrl + F5 dans le navigateur.

## Vérifications
1. Fichiers > Favoris ; dans le réseau navigateur la requête REPORT doit cibler `/remote.php/dav/files/PxoNas` (ou l'UID de l'utilisateur courant) et non `/apps/novadashboard/api/overview/remote.php/...`.
2. Ouvrir un PDF dont tu as les droits en aperçu Neos. L'iframe doit charger `/apps/novadashboard/api/inline-pdf?path=...` et afficher le document.
3. Si la prévisualisation reste vide, ouvrir F12 > Réseau, sélectionner la requête `inline-pdf` et relever son **statut HTTP**, son **Content-Type**, la chaîne de **redirections** et la **Content-Security-Policy**. Ne pas poster d'URL contenant un jeton de session ou de cookie.
4. `net::ERR_BLOCKED_BY_CLIENT` peut venir d'une extension de blocage ; vérifier dans une fenêtre privée sans extensions si nécessaire.

## Retour arrière
Réinstaller la sauvegarde **sur le même chemin** si nécessaire :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0611.tar.gz -C "$APP_PATH"
```

La sauvegarde peut être complétée par une restauration du code depuis le ZIP v0.6.1. Aucune migration SQL n'est déclenchée par ce paquet.
