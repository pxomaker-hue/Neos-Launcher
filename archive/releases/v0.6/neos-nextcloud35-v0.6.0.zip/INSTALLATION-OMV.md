# Neos v0.6.0 — installation sur OMV / Nextcloud 35

**Identifiant Nextcloud inchangé :** `novadashboard`. Les préférences et l'application par défaut restent en place.

Cette version apporte la recherche multi-dossiers filtrée, les favoris natifs Nextcloud (WebDAV) et les fichiers récemment consultés dans Neos. Aucun déplacement des données `/data`, aucune manipulation MariaDB, aucun `occ upgrade` n'est requis.

## Depuis Windows PowerShell (une commande par ligne)

Place `neos-nextcloud35-v0.6.0.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.0.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## Sur OMV, vérifier Nextcloud AVANT d'installer

```bash
sudo docker exec nextcloud occ status
```

Poursuivre **seulement** si Nextcloud 35 est installé, `maintenance: false` et `needsDbUpgrade: false`. Ne pas mettre Nextcloud en maintenance pour cette simple mise à jour de fichiers applicatifs.

Identifier le **chemin réellement utilisé** par Nextcloud, qui peut différer de l'ancien `/config/www/nextcloud/apps/novadashboard` :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
echo "$APP_PATH"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Application Neos trouvée"
```

**Ne pas continuer** si le chemin est vide ou si le test échoue.

## Sauvegarde de l'application actuelle

La sauvegarde est stockée dans le volume persistant `/config`, et non dans `/tmp`.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v060.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud tar -tzf /config/neos-backup-avant-v060.tar.gz | head
```

## Installation (une commande par ligne)

```bash
mkdir -p /tmp/neos-v060
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.0.zip /tmp/neos-v060
```

```bash
sudo docker cp /tmp/neos-v060/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ status
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Vérifier `novadashboard: 0.6.0`. Dans le navigateur, recharger avec **Ctrl+F5**. Aucune migration SQL ou redémarrage Docker n'est nécessaire pour cette version.

## Fonctions et essais

1. **Recherche** : `Ctrl+K` (ou bouton **Partout** dans Fichiers sur mobile) ; rechercher au moins 2 caractères, puis essayer Type, Modifié, Taille et Tri. La recherche porte sur les noms, pas le contenu, et respecte toujours la limite de 2 500 entrées, 6 niveaux et 40 résultats.
2. **Favoris Nextcloud** : dans Fichiers, utiliser **l'étoile** sur un fichier ou dossier ; ouvrir **Favoris** depuis Fichiers ou la palette. Vérifier également dans l'application Fichiers Nextcloud que le favori est présent. Les raccourcis de dossiers du widget Accueil restent distincts et utilisent désormais une icône maison.
3. **Consultés** : cliquer sur un fichier pour l'apercevoir, puis ouvrir l'onglet **Consultés**. Les 24 derniers chemins sont conservés dans **ce navigateur uniquement**, sous une clé spécifique à l'utilisateur (sans le contenu du fichier). On peut vider cet historique.

**Limites :** la liste des favoris se base sur l'API WebDAV de Nextcloud et a besoin des cookies de session, de permissions de lecture et du jeton CSRF pour les modifications. Si les favoris ne fonctionnent pas sur l'instance réelle, ouvrir les outils réseau du navigateur et noter le statut des requêtes `REPORT` / `PROPPATCH`. Ne pas modifier de permissions système pour contourner l'erreur.

## Retour arrière vers v0.5.9

Récupérer le chemin actuel (dans une nouvelle session SSH, les variables précédentes sont perdues) :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

Vérifier la sauvegarde :

```bash
sudo docker exec nextcloud tar -tzf /config/neos-backup-avant-v060.tar.gz | head
```

Restaurer les fichiers de la v0.5.9 sans toucher à `/data` ni à MariaDB :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v060.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ status
```

Actualiser ensuite avec Ctrl+F5. Les données Nextcloud restent sur **sdb1** ; Neos et sa configuration restent indépendants de ce déplacement de volume.

## Validation de cette archive

Syntaxe PHP/JS, intégrité ZIP, filtres côté serveur avec doubles de test, et tests Chromium de la recherche, des favoris et de l'historique en mode démo sur ordinateur/mobile. Les mutations WebDAV n'ont pas été exécutées sur le NAS réel ; tester l'étoile sur un fichier de test d'abord.
