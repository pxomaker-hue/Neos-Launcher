# Installation Neos v0.6.20 — Nextcloud 35 sur OMV / LinuxServer.io

Cette mise à jour remplace les fichiers de **novadashboard**, sans modifier la base de données, les paramètres proxy ou les applications natives. Exécuter **une commande à la fois**. Ne jamais poursuivre si une vérification échoue.

## 1. PowerShell — Windows

Enregistrer le ZIP à : `X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.20.zip`

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.20.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. NAS OMV — avant mise à jour

```bash
sudo docker exec nextcloud occ status
```

Continuer uniquement si `maintenance: false` et `needsDbUpgrade: false`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.20.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo 'Neos trouvé'
```

Si **Neos trouvé** n'apparaît pas, arrêter.

## 3. Sauvegarde obligatoire

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0620.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0620.tar.gz
```

## 4. Mise à jour

```bash
mkdir -p /tmp/neos-v0620
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.20.zip /tmp/neos-v0620
```

```bash
test -f /tmp/neos-v0620/novadashboard/appinfo/info.xml && echo 'Archive prête'
```

```bash
sudo docker cp /tmp/neos-v0620/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.20`. Faire **Ctrl + F5** dans le navigateur.

## 5. Vérifications sur NAS

1. Ouvrir **Neos → Mail → Brouillons** ; confirmer l'apparition des brouillons déjà enregistrés dans Mail natif.
2. Ouvrir un brouillon, lire son contenu, puis tester **Modifier ce brouillon dans Mail natif**. Le lecteur Neos n'envoie ni n'efface de message.
3. Dans **Contacts**, créer un contact fictif avec deux courriels et deux téléphones ; vérifier les quatre champs dans Contacts natif. Modifier une valeur et vérifier sa conservation.
4. Vérifier Talk, Activité, Planning, Tâches, Deck et l'ordre des onglets.

## 6. Retour arrière (si nécessaire)

Sur le NAS, après connexion SSH et récupération de `APP_PATH`, vérifie que la sauvegarde existe. Puis :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0620.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Ctrl + F5 après restauration. La sauvegarde ne concerne que l'application Neos, pas les données des applications Nextcloud.
