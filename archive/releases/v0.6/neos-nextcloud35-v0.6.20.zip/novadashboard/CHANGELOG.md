# Neos 0.6.20

- Mail : consultation des dossiers Brouillons IMAP dans Neos, avec aperçu filtré et lien direct vers l’édition de l’original dans Mail natif. Aucune écriture, suppression ou expédition depuis ce lecteur.
- Contacts : deux courriels et deux téléphones, tout en préservant les autres champs vCard lors des éditions via ETag.
- Conservation du design Flat Cyber, topbar et fonctionnalités des versions précédentes.

# Historique Neos

## 0.6.19 — Brouillons visibles dans Mail natif et Talk filtrable

- Correction de la confirmation trompeuse des brouillons dans la v0.6.18 : `POST /api/drafts` ou `PUT /api/drafts/{id}` crée/met à jour seulement un brouillon local à Nextcloud Mail.
- Après cette première étape, appel explicite à `POST /api/drafts/move/{id}`, qui demande à Nextcloud Mail 5.13.2 de transférer le brouillon dans le dossier IMAP Brouillons. Aucun envoi SMTP n'est effectué.
- Le formulaire est verrouillé après transfert accepté pour éviter de réutiliser un identifiant temporaire supprimé côté serveur ; l'édition/reprise du brouillon transféré s'effectue dans Mail natif. Cette limitation est affichée dans Neos.
- En cas de transfert non confirmé, message explicite avec identifiant local et blocage des essais répétitifs automatiques, pour ne pas créer de doublon. Avant un nouvel essai : examiner Mail natif.
- Filtre « Toutes / Non lues » dans les conversations Talk et actualisation de la liste au retour d'une conversation. Les non-lus proviennent de l'API Talk, sans marquage forcé.
- Conservés : ordre de topbar, icône Planning, Contacts, Agenda, Tâches, Deck, Activité, lecture HTML des mails, envoi, synchronisation des boîtes, suivi Outbox.

# Historique Neos

## 0.6.18 — Brouillons Mail et suivi des envois

- Enregistrer un brouillon dans Nextcloud Mail via POST /api/drafts ; mises à jour via PUT /api/drafts/{id}.
- Suivre les messages en boîte d'envoi via GET /api/outbox ; aucun renvoi automatique.
- Vérification non destructive de l'état d'une référence d'envoi (GET /api/outbox/{id}).
- Brouillons conservés côté serveur, sans stockage local du contenu ; reprise après reconnexion via Mail natif.
- Prévention de la réutilisation accidentelle d'un ancien brouillon comme « nouveau message ».
- Conserve les fonctionnalités v0.6.17 et précédentes.

## 0.6.17 — synchronisation de Mail

- Synchroniser la boîte IMAP avant de lire les messages (API Mail 5.13.2).
- Bouton Synchroniser visible, avec heure de dernière synchronisation réussie.
- Rafraîchissement toutes les 90 s quand l'espace Mail est actif et visible ; contrôle après envoi confirmé.
- Un seul rafraîchissement simultané ; gestion bornée des retours 428 (initialisation), 409 (occupé) et 500 (erreur).
- Conserve les messages précédemment mis en cache en cas d'échec temporaire.

## 0.6.16 — rédaction / envoi / réponse

- Interface de composition texte dans Mail, envoi en deux étapes via Outbox.
