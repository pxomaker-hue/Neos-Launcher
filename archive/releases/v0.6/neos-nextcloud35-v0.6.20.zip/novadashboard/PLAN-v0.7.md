# Neos — plan d'intégration avant v0.7 (après v0.6.20)

| Module | Fonctionnel / développé | Reste à tester ou développer |
| --- | --- | --- |
| Mail | Lecture HTML, envoi, synchronisation, sauvegarde IMAP de brouillons, suivi d'envoi, **consultation directe des brouillons IMAP** | Valider la consultation sur NAS ; reprendre l'édition complète des brouillons IMAP dans Neos en préservant pièces jointes et autres champs ; pièces jointes de message |
| Contacts | Création et modification CardDAV validées ; **deux courriels et deux téléphones** dans le formulaire | Valider champs supplémentaires sur NAS ; suppression sécurisée, prise en charge de toutes les entrées multiples |
| Talk | Consultation et envoi validés ; filtre Non lues | Améliorer les états lus/non lus et les échanges longs |
| Activité | Affichage, filtres, chargement de pages | Affinage et tests sur volumes importants |
| Planning / Agenda / Tâches / Deck | Fonctionnalités principales validées | Tests de régression, cas avancés et mobile |
| Interface | Flat Cyber, icône Planning personnelle, ordre d'onglets sauvegardé | Audit responsive, performance, accessibilité |

La v0.7 visera la stabilisation des intégrations sur Nextcloud 35. Aucun envoi automatique ni désactivation des protections de sécurité.
