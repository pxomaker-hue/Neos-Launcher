/** Neos 0.6.7 — CalDAV Deck read-only routing, Deck API + Planning. */
(() => {
  'use strict';
  const root = document.getElementById('nova-root');
  if (!root) return;
  root.innerHTML = '<div id="neos-surface"></div><div id="neos-editor-host"></div><div id="neos-pop-host"></div><div id="neos-toast-host" aria-live="polite"></div><div id="neos-upload-host" role="region" aria-label="Progression des téléversements"></div>';
  const surface = root.querySelector('#neos-surface');
  const editorHost = root.querySelector('#neos-editor-host');
  const popHost = root.querySelector('#neos-pop-host');
  const toastHost = root.querySelector('#neos-toast-host');
  const uploadHost = root.querySelector('#neos-upload-host');
  const ambientHost = document.createElement('div');
  ambientHost.className = 'neos-ambient';
  ambientHost.setAttribute('aria-hidden', 'true');
  root.insertBefore(ambientHost, surface);
  ambientHost.innerHTML = `<div class="neos-ambient-mesh"></div><div class="neos-ambient-grid"></div><div class="neos-ambient-beam"></div><div class="neos-ambient-aurora"></div><div class="neos-ambient-noise"></div>
  <svg class="neos-ambient-orbits" viewBox="0 0 1440 800" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="neos-v045-orbit"><stop stop-color="#36d5fb" stop-opacity="0"/><stop offset=".48" stop-color="#42b7ff" stop-opacity=".14"/><stop offset="1" stop-color="#9084ff" stop-opacity="0"/></linearGradient></defs><g fill="none" stroke="url(#neos-v045-orbit)" stroke-width=".85"><ellipse cx="1075" cy="265" rx="440" ry="200" transform="rotate(-17 1075 265)"/><ellipse cx="1075" cy="265" rx="575" ry="280" transform="rotate(-17 1075 265)"/><ellipse cx="1075" cy="265" rx="710" ry="360" transform="rotate(-17 1075 265)"/></g></svg>`;


  // Low-cost, local data-field animation. It is visual only, never reads files or user data.
  const dataCanvas = document.createElement('canvas');
  dataCanvas.className = 'neos-datafield';
  dataCanvas.setAttribute('aria-hidden', 'true');
  ambientHost.appendChild(dataCanvas);
  function launchDatafield(){
    const ctx=dataCanvas.getContext('2d',{alpha:true}); if(!ctx)return;
    let width=0,height=0,dpr=1,last=0,frame=0;
    const pointer={x:.5,y:.48,targetX:.5,targetY:.48};
    const resize=()=>{
      width=Math.max(320,root.clientWidth||window.innerWidth);
      height=Math.max(400,root.clientHeight||window.innerHeight);
      dpr=Math.min(1.5,window.devicePixelRatio||1);
      dataCanvas.width=Math.round(width*dpr);dataCanvas.height=Math.round(height*dpr);
      ctx.setTransform(dpr,0,0,dpr,0,0);
    };
    const draw=now=>{
      ctx.clearRect(0,0,width,height);
      const t=now*.00015, mobile=width<760, rows=mobile?7:11;
      pointer.x+=(pointer.targetX-pointer.x)*.045;
      pointer.y+=(pointer.targetY-pointer.y)*.045;
      const horizon=height*(.52+(.5-pointer.y)*.055);
      for(let j=0;j<rows;j++){
        const base=horizon+j*(mobile?22:26), amp=(mobile?11:18)*(1+j*.025);
        const g=ctx.createLinearGradient(0,base,width,base);
        g.addColorStop(0,'rgba(42,156,240,0)');
        g.addColorStop(.25,'rgba(55,155,240,.06)');
        g.addColorStop(.58,j%4===0?'rgba(144,113,249,.115)':'rgba(49,203,250,.115)');
        g.addColorStop(1,'rgba(45,164,255,0)');
        ctx.strokeStyle=g;ctx.lineWidth=.65;ctx.beginPath();
        for(let i=0;i<=56;i++){
          const x=width*i/56;
          const y=base + amp*Math.sin(i*.23+t*4+j*.18+pointer.x*.8) + amp*.32*Math.cos(i*.37-t*3+j*.45);
          i?ctx.lineTo(x,y):ctx.moveTo(x,y);
        }
        ctx.stroke();
      }
      const count=mobile?24:54;
      for(let i=0;i<count;i++){
        const fx=((i*137.508+9)%997)/997, fy=((i*91.17+16)%991)/991;
        const x=width*(fx+.01*Math.sin(t*3+i)),y=height*(fy*.79+.12+.01*Math.cos(t*4+i*.31));
        const a=.07+.16*(Math.sin(t*3+i*.7)+1)/2;
        ctx.fillStyle=i%9===0?`rgba(170,144,255,${a})`:`rgba(99,203,250,${a})`;
        ctx.beginPath();ctx.arc(x,y,i%7===0?1.25:.65,0,Math.PI*2);ctx.fill();
      }
      if(!mobile){
        const gx=pointer.x*width,gy=pointer.y*height;
        const halo=ctx.createRadialGradient(gx,gy,0,gx,gy,260);
        halo.addColorStop(0,'rgba(73,157,255,.038)');halo.addColorStop(1,'rgba(73,157,255,0)');
        ctx.fillStyle=halo;ctx.fillRect(gx-260,gy-260,520,520);
      }
    };
    const tick=now=>{
      frame=requestAnimationFrame(tick);
      if(!document.hidden&&motionEnabled()&&now-last>48){last=now;draw(now);}
    };
    root.addEventListener('pointermove',e=>{
      if(e.pointerType!=='mouse')return;
      const r=root.getBoundingClientRect();
      pointer.targetX=Math.max(0,Math.min(1,(e.clientX-r.left)/Math.max(1,r.width)));
      pointer.targetY=Math.max(0,Math.min(1,(e.clientY-r.top)/Math.max(1,r.height)));
    },{passive:true});
    root.addEventListener('pointerleave',()=>{pointer.targetX=.5;pointer.targetY=.48;},{passive:true});
    resize();draw(0);frame=requestAnimationFrame(tick);
    window.addEventListener('resize',resize,{passive:true});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden){resize();last=0;}});
  }

  const demo = window.NOVA_DEMO_DATA && root.dataset.demo === 'true' ? window.NOVA_DEMO_DATA : null;
  const csrfToken = () => document.head?.getAttribute('data-requesttoken') || window.OC?.requestToken || '';

  const icons = {
    sparkles:'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 17 .8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',
    check:'<rect x="3" y="4" width="18" height="17" rx="3"/><path d="m8 12 3 3 5-6"/>',
    storage:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 12h18m-5 4h2"/><circle cx="7" cy="16" r="1"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-6-6L4 21"/>',
    message:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
    settings:'<path d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.8 9A7.5 7.5 0 0 1 19 6l1 1M4 17l1 1a7.5 7.5 0 0 0 13.2-3"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    close:'<path d="M5 5l14 14M19 5 5 19"/>',
    grip:'<circle cx="9" cy="5" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="19" r="1"/>',
    file:'<path d="M6 2h9l5 5v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z"/><path d="M14 2v6h6"/>',
    external:'<path d="M14 4h6v6m-9 3 9-9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
    alert:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3v.1"/>',
    cloud:'<path d="M5 18a4 4 0 0 1-.4-8 7 7 0 0 1 13-1 4.5 4.5 0 0 1 1 9H5Z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7 .2l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7-.2l-3 3a5 5 0 1 0 7.1 7.1l1.7-1.7"/>',
    note:'<path d="M4 3h16v18H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    chart:'<path d="M3 20h18M6 17v-4m6 4V6m6 11v-8"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    minus:'<path d="M4 12h16"/>',
    'chevrons-down':'<path d="m6 7 6 6 6-6m-12 6 6 6 6-6"/>',
    'chevrons-up':'<path d="m6 17 6-6 6 6m-12-6 6-6 6 6"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
    star:'<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.3-5.7-3-5.7 3 1.1-6.3L2.8 9.7l6.4-.9L12 3Z"/>',
    list:'<path d="M9 5h12M9 12h12M9 19h12"/><path d="M3 5h.1M3 12h.1M3 19h.1"/>',
    sort:'<path d="M7 4v16m0 0-4-4m4 4 4-4M17 20V4m0 0-4 4m4-4 4 4"/>',
    arrow:'<path d="M4 12h16m-7-7 7 7-7 7"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
    bolt:'<path d="m13 2-9 12h7l-1 8 10-12h-7l0-8Z"/>',
    home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
    users:'<path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="4"/><path d="M17 11a4 4 0 1 0 0-8m4 18v-2a4 4 0 0 0-3-3.87"/>',
    mail:'<path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><path d="m22 7-10 7L2 7"/>',
    kanban:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16m6-16v9"/>',
    map:'<path d="M9 18 3 20V6l6-2 6 2 6-2v14l-6 2-6-2Z"/><path d="M9 4v14m6-12v14"/>',
    news:'<path d="M4 5h13a2 2 0 0 1 2 2v10H6a2 2 0 0 1-2-2V5Z"/><path d="M19 9h1a2 2 0 0 1 2 2v6H8"/><path d="M8 9h7M8 13h5"/>',
    sheet:'<path d="M4 4h16v16H4z"/><path d="M4 9h16M9 4v16m5-16v16"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    open:'<path d="M7 17 17 7"/><path d="M8 7h9v9"/>',
    back:'<path d="m15 18-6-6 6-6"/>',
    forward:'<path d="m9 18 6-6-6-6"/>',
    more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    download:'<path d="M12 3v12m0 0 5-5m-5 5-5-5M4 17v3h16v-3"/>',
    copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
    upload:'<path d="M12 17V4m0 0 5 5m-5-5-5 5M4 17v3h16v-3"/>',
    filter:'<path d="M4 6h16M7 12h10M10 18h4"/>',
    edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/>',
  };
  const icon = (name, size=18) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name] || icons.file}</svg>`;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeUrl = s => typeof s === 'string' && ((/^\/(?!\/)/.test(s) && !s.includes('\\')) || /^https?:\/\//i.test(s) || (root.dataset.demo === 'true' && /^\.\/novadashboard\/img\/(?:[\w.%-]+\/)*[\w.%-]+$/.test(s))) || (demo && /^data:image\/(?:png|svg\+xml);base64,[A-Za-z0-9+/=]+$/.test(s)) ? esc(s) : '#';
  const safeColor = s => /^#[0-9a-f]{6}$/i.test(String(s)) ? s : '#7f8dff';
  const number = n => Number.isFinite(Number(n)) ? Number(n) : 0;
  const humanSize = b => { if (b == null) return '—'; const n = Math.max(0, number(b)); const p = n ? Math.min(4, Math.floor(Math.log(n)/Math.log(1024))) : 0; return new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(n/Math.pow(1024,p)) + ' ' + ['o','Ko','Mo','Go','To'][p]; };
  const ago = ts => { const d = Math.max(0, Math.round((Date.now()-number(ts)*1000)/86400000)); return d===0?'Aujourd’hui':d===1?'Hier':`Il y a ${d} j`; };
  const fmtTime = iso => { if (!iso) return 'Sans échéance'; const d = new Date(iso); return Number.isNaN(+d) ? 'Date inconnue' : new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(d); };
  const ext = name => String(name || '').split('.').pop().toLowerCase();
  const isImage = e => String(e?.mime || '').startsWith('image/');
  const isPdf = e => String(e?.mime || '') === 'application/pdf' || ext(e?.name) === 'pdf';
  const isCsv = e => ['csv','tsv'].includes(ext(e?.name));
  const isText = e => String(e?.mime || '').startsWith('text/') || ['txt','md','markdown','json','log','ini','yaml','yml','xml','html','css','js','ts','php','sql','csv','tsv'].includes(ext(e?.name));
  const isAudio = e => String(e?.mime||'').startsWith('audio/') || ['mp3','m4a','ogg','opus','flac','wav'].includes(ext(e?.name));
  const isVideo = e => String(e?.mime||'').startsWith('video/') || ['mp4','webm','ogv','mov','m4v'].includes(ext(e?.name));
  const isMarkdown = e => ['md','markdown'].includes(ext(e?.name));
  // Only a small, safe subset of Markdown: all source content is escaped first.
  function markdownHtml(value){
    const lines=String(value||'').slice(0,180000).replace(/\r\n?/g,'\n').split('\n');
    const inline=line=>esc(line).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*\n]+)\*/g,'<em>$1</em>');
    let list=false,code=false;const out=[];
    for(const line of lines){
      if(/^```/.test(line)){if(list){out.push('</ul>');list=false;}out.push(code?'</code></pre>':'<pre><code>');code=!code;continue;}
      if(code){out.push(esc(line)+'\n');continue;}
      const bullet=/^\s*[-*+]\s+(.+)$/.exec(line);
      if(bullet){if(!list){out.push('<ul>');list=true;}out.push('<li>'+inline(bullet[1])+'</li>');continue;}
      if(list){out.push('</ul>');list=false;}
      const heading=/^(#{1,4})\s+(.+)$/.exec(line);
      if(heading){const level=heading[1].length;out.push('<h'+level+'>'+inline(heading[2])+'</h'+level+'>');}
      else if(line.trim())out.push('<p>'+inline(line)+'</p>');
    }
    if(list)out.push('</ul>');if(code)out.push('</code></pre>');
    return out.join('');
  }
  const isOffice = e => ['xlsx','xls','ods','docx','doc','odt','pptx','ppt','odp'].includes(ext(e?.name));

  const widgetLabels = {
    explorer:'Fichiers', storage:'Stockage', shortcuts:'Hub apps', clock:'Horloge', files:'Récents',
    calendar:'Agenda', tasks:'Tâches', summary:'Synthèse', links:'Liens', notes:'Notes', deck:'Deck'
  };
  const widgetIcons = { explorer:'folder', storage:'storage', shortcuts:'grid', clock:'clock', files:'file', calendar:'calendar', tasks:'check', summary:'chart', links:'link', notes:'note', deck:'kanban' };
  const widgetIds = Object.keys(widgetLabels);
  const defaultSizes = { explorer:12, storage:3, shortcuts:6, clock:3, files:6, calendar:6, tasks:6, summary:6, links:6, notes:6, deck:6 };
  const adaptiveSizes = { explorer:8, storage:4, shortcuts:8, clock:4, files:6, calendar:6, tasks:6, summary:4, links:6, notes:6, deck:6 };
  const allowedSizes = [3,4,6,8,9,12];
  const allowedHeights = [0,160,220,300,400,520,680];
  const defaultHeights = Object.fromEntries(widgetIds.map(id=>[id,0]));
  let masonryFrame=0;
  let lastMasonryWidth=0;
  const defaults = () => ({ theme:'dark', density:'comfortable', accent:'cyan', layout:'wide', motion:'full', launcherMode:'topbar', gridMode:'adaptive', order:[...widgetIds], hidden:['links','notes'], sizes:{...defaultSizes}, heights:{...defaultHeights}, links:[], notes:'', pins:[], topApps:['files','calendar','tasks','talk'] });

  let overview = null;
  let settings = null;
  let editing = false;
  let editorOpen = false;
  let dragWidgetId = '';
  let layoutAnnounce = '';
  let saving = false;
  let saveQueued = false;
  let popMode = '';
  let browseGeneration = 0;
  let previewGeneration = 0;
  let hasEntered = false;
  let clockTimer = null;
  const browser = { path:'/', davUrl:'', items:[], total:0, truncated:false, limit:160, filesUrl:'#', loading:true, error:'', query:'', sort:'name', type:'all', view:'list', canCreate:true };
  const fileSelection=new Set();
  const fileClipboard={mode:'', entries:[]};
  let fileAnchorPath='';
  let fileBusy=false;
  let fileDragPaths=[];
  let pickerState=null;
  let pickerGeneration=0;
  const globalSearch={query:'',items:[],loading:false,error:'',truncated:false,visited:0,type:'all',date:'all',size:'all',sort:'recent'};
  let searchPanelTab='search';
  const favoriteState={status:'idle',items:[],error:''};
  const favoritePaths=new Set();
  const recentViewed=[];

  let globalSearchGeneration=0;
  let globalSearchTimer=0;
  const uploadState={active:false,files:[],currentIndex:-1,loaded:0,totalBytes:0,doneBytes:0,xhr:null,cancel:false,finished:false};

  let dropZonePath='';
  const preview = { entry:null, status:'empty', mode:'empty', text:'', rows:[], error:'', title:'' };
  // Topbar navigation changes only this workspace, without a Nextcloud page load.
  let activeWorkspace = 'home';
  let transitionSequence = 0;
  const workspaceScroll = new Map();
  let moduleGeneration = 0;
  const photoState={status:'idle',items:[],partial:false,error:'',selected:-1};
  const notesState={status:'idle',items:[],selected:null, draftTitle:'',draftContent:'',dirty:false,error:'',source:'api',folder:'Notes'};
  const deckState={status:'idle',boards:[],boardId:null,stacks:[],error:''};
  const deckCardEditor={boardId:null,stackId:null,cardId:null,card:null,create:false,draftStackId:null,loading:false,loadFailed:false,saving:false,error:'',dirty:false};
  let deckDrag=null;
  let deckMoveBusy=false;
  // Native CalDAV data. Only the signed-in user's accessible calendars are queried.
  const groupware={status:'idle',calendars:[],events:[],tasks:[],error:'',taskErrors:[],taskSources:0,taskSuccess:0,windowStart:null,windowEnd:null,busy:false,generation:0};
  const planningDeck={status:'idle',cards:[],error:'',updatedAt:0,generation:0};
  let planningRange=30;
  let planningKinds=new Set(['event','task','deck']);
  let calendarView='month';
  let calendarCursor=new Date();calendarCursor.setHours(12,0,0,0);
  let taskView='open';
  let noteView='edit';
  let markdownPreview=false;
  const builtInApps=new Set(['files','photos','calendar','tasks','deck','notes']);

  const history = ['/']; let historyIndex=0; let contextPath=''; let fullPreview=false; let previewBlobUrl=''; let previewError=false;

  const motionEnabled = () => settings && settings.motion !== 'off' && !(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  const motionFactor = () => settings?.motion === 'subtle' ? .7 : 1;

  function toast(message, type='info') {
    const node = document.createElement('div');
    node.className = `neos-toast neos-toast-${type}`;
    node.setAttribute('role','status');
    node.textContent = message;
    toastHost.replaceChildren(node);
    setTimeout(() => node.remove(), 3200);
  }

  async function api(url, options={}) {
    if (demo) throw new Error('Démo');
    const token = csrfToken();
    if (!token) throw new Error('Jeton CSRF manquant');
    const response = await fetch(url, {
      credentials:'same-origin', cache:'no-store', ...options,
      headers:{ Accept:'application/json', requesttoken:token, 'X-Requested-With':'XMLHttpRequest', ...(options.headers || {}) }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  function applyTheme() {
    const pref = settings?.theme || 'system';
    const light = pref === 'light' || (pref === 'system' && window.matchMedia?.('(prefers-color-scheme: light)').matches);
    root.classList.toggle('neos-light', !!light);
    root.classList.toggle('neos-dark', !light);
    root.dataset.accent = settings?.accent || 'indigo';
    root.dataset.density = settings?.density || 'comfortable';
    root.dataset.layout = settings?.layout || 'wide';
    root.dataset.motion = settings?.motion || 'full';
    root.dataset.launcherMode = settings?.launcherMode || 'topbar';
  }

  // Timing, staging and stagger concepts adapted from Anime.js v4 documentation.
  // Uses the native Web Animations API to avoid remote scripts and CSP changes.
  function animateIn(nodes, delay=40, base=0) {
    if (!motionEnabled()) return;
    [...nodes].slice(0,28).forEach((el, i) => {
      if (!el?.animate) return;
      const duration = Math.round(560*motionFactor());
      el.animate([
        { opacity:0, transform:'translate3d(0,22px,0) scale(.982)', filter:'blur(3px)' },
        { opacity:1, transform:'translate3d(0,0,0) scale(1)', filter:'blur(0)' }
      ], { duration, delay:base + i*delay*motionFactor(), easing:'cubic-bezier(.16,1,.3,1)', fill:'backwards' });
    });
  }
  function animatePreview() {
    if (!motionEnabled()) return;
    const content=surface.querySelector('.neos-preview-body');
    content?.animate?.([
      {opacity:.1,transform:'translate3d(10px,0,0)'},
      {opacity:1,transform:'translate3d(0,0,0)'}
    ],{duration:340*motionFactor(),easing:'cubic-bezier(.16,1,.3,1)'});
  }
  function animateRows() {
    animateIn(surface.querySelectorAll('.neos-file-row'),19,0);
  }

  function pulse(el) {
    if (!motionEnabled() || !el?.animate) return;
    el.animate([{transform:'scale(.985)'},{transform:'scale(1.02)'},{transform:'scale(1)'}], { duration:380*motionFactor(), easing:'cubic-bezier(.17,.89,.32,1.27)' });
  }
  function animateLayerOpen(host, panelSelector, axis='x') {
    if (!motionEnabled()) return;
    const overlay = host.firstElementChild; const panel = host.querySelector(panelSelector); const shift = axis === 'y' ? '0,18px,0' : '24px,0,0';
    overlay?.animate?.([{opacity:0},{opacity:1}],{duration:220*motionFactor(),easing:'ease-out'});
    panel?.animate?.([{opacity:0,transform:`translate3d(${shift}) scale(.986)`,filter:'blur(6px)'},{opacity:1,transform:'translate3d(0,0,0) scale(1)',filter:'blur(0)'}],{duration:420*motionFactor(),easing:'cubic-bezier(.16,1,.3,1)'});
  }
  function animateLayerClose(host, panelSelector, done, axis='x') {
    const overlay = host.firstElementChild; const panel = host.querySelector(panelSelector); if (!motionEnabled() || !overlay) { done(); return; }
    const shift = axis === 'y' ? '0,18px,0' : '20px,0,0';
    overlay.animate([{opacity:1},{opacity:0}],{duration:180*motionFactor(),easing:'ease-in'});
    panel?.animate?.([{opacity:1,transform:'translate3d(0,0,0) scale(1)',filter:'blur(0)'},{opacity:0,transform:`translate3d(${shift}) scale(.99)`,filter:'blur(5px)'}],{duration:180*motionFactor(),easing:'cubic-bezier(.4,0,1,1)'});
    setTimeout(done, Math.round(195*motionFactor()));
  }

  function widgetMinHeight(id){
    if(settings?.gridMode!=='manual')return 0;
    const value=Number(settings.heights?.[id]||0);
    return allowedHeights.includes(value)?value:0;
  }
  function widgetSpan(id){
    const requested = Number(settings?.sizes?.[id]);
    return settings?.gridMode==='adaptive' ? (adaptiveSizes[id] || 6) : (allowedSizes.includes(requested) ? requested : defaultSizes[id] || 6);
  }
  function editWidgetTools(id){
    if(!editing||activeWorkspace!=='home')return '';
    const order=settings.order.filter(key=>!settings.hidden.includes(key)&&(key!=='shortcuts'||settings.launcherMode==='widget'));
    const index=order.indexOf(id);const span=widgetSpan(id);const height=widgetMinHeight(id);
    const minHeightLabel=height?`${height} px`:'Auto';
    return `<div class="neos-widget-edit-controls"><button type="button" class="neos-mini-action neos-drag-handle" draggable="true" data-drag-widget="${id}" title="Déplacer par glisser-déposer" aria-label="Déplacer ${esc(widgetLabels[id])} par glisser-déposer">${icon('grip',17)}</button><button type="button" class="neos-mini-action" data-action="widget-move" data-id="${id}" data-step="-1" ${index<=0?'disabled':''} aria-label="Déplacer ${esc(widgetLabels[id])} vers le début">${icon('back',14)}</button><button type="button" class="neos-mini-action" data-action="widget-move" data-id="${id}" data-step="1" ${index>=order.length-1?'disabled':''} aria-label="Déplacer ${esc(widgetLabels[id])} vers la fin">${icon('forward',14)}</button><span class="neos-edit-sep"></span><button type="button" class="neos-mini-action" data-action="widget-resize" data-id="${id}" data-step="-1" ${settings.gridMode==='adaptive'?'disabled':''} title="Réduire la largeur">${icon('minus',13)}</button><span class="neos-widget-span" title="Largeur actuelle">${Math.round(span/12*100)}%</span><button type="button" class="neos-mini-action" data-action="widget-resize" data-id="${id}" data-step="1" ${settings.gridMode==='adaptive'?'disabled':''} title="Agrandir la largeur">${icon('plus',13)}</button><span class="neos-edit-sep"></span><button type="button" class="neos-mini-action" data-action="widget-height" data-id="${id}" data-step="-1" ${settings.gridMode==='adaptive'?'disabled':''} title="Réduire la hauteur minimale">${icon('chevrons-down',15)}</button><span class="neos-widget-span neos-height-indicator" title="Hauteur minimale">${minHeightLabel}</span><button type="button" class="neos-mini-action" data-action="widget-height" data-id="${id}" data-step="1" ${settings.gridMode==='adaptive'?'disabled':''} title="Augmenter la hauteur minimale">${icon('chevrons-up',15)}</button></div>`;
  }
  function box(id, body, sub='', tools='') {
    const size=widgetSpan(id);
    return `<section class="neos-card neos-${id} ${editing&&activeWorkspace==='home'?'neos-editable-card':''}" data-widget="${id}" data-size="${size}" data-min-height="${widgetMinHeight(id)}" draggable="false">
      <header class="neos-card-head"><div class="neos-card-name">${icon(widgetIcons[id],18)}<span>${esc(widgetLabels[id])}</span></div><div class="neos-card-actions">${editing&&activeWorkspace==='home'?editWidgetTools(id):tools}<span class="neos-card-sub">${editing&&activeWorkspace==='home'?'':sub}</span></div></header>
      <div class="neos-card-body">${body}</div>
    </section>`;
  }

  function filesHomeUrl(){ return browser.filesUrl && browser.filesUrl !== '#' ? browser.filesUrl : ((overview?.shortcuts || []).find(x => x.id === 'files')?.url || '/index.php/apps/files/'); }

  function breadcrumb() {
    const names = browser.path.split('/').filter(Boolean);
    const crumbs = [`<button type="button" class="neos-crumb ${names.length ? '' : 'active'}" data-action="browse-path" data-path="/">${icon('home',14)}</button>`];
    let path = '';
    names.forEach((part, idx) => { path += '/' + part; crumbs.push(`${icon('chevron',12)}<button type="button" class="neos-crumb ${idx===names.length-1?'active':''}" data-action="browse-path" data-path="${esc(path)}">${esc(part)}</button>`); });
    return crumbs.join('');
  }

  function appColor(id){return ({files:'#FFBC4B',photos:'#2CC9FC',calendar:'#B480FF',tasks:'#36D6AD',talk:'#F77BAE',contacts:'#58BAFF',mail:'#628FFF',activity:'#FFB14D',deck:'#22CDD7',notes:'#B78AFF',bookmarks:'#FFCF59',news:'#7abfff',maps:'#36d6ad',tables:'#59BAFF',office:'#B480FF'})[id]||'#95a5ff';}
  const appAsset=name=>(demo && window.NEOS_PREVIEW_ASSETS?.[name]) || (demo?'./novadashboard/img/':String(root.dataset.assetBase||'/apps/novadashboard/img/').replace(/\/?$/,'/')) + String(name).split('/').map(encodeURIComponent).join('/');
  const kitFile=path=>appAsset('kit/'+path);
  const flatIconMap={files:'fichiers',photos:'photos',calendar:'agenda',tasks:'taches',talk:'talk',contacts:'contacts',mail:'mail',activity:'activite',deck:'deck',notes:'notes'};
  const flatIconId=id=>flatIconMap[id]||'';
  const flatIconAsset=(kind,id)=>{const mapped=flatIconId(id);return mapped?kitFile(`icons/${kind==='glyphs'?'apps':'tiles'}/${mapped}.svg`):'';};
  const glyphPaths={
    files:'<path d="M3.5 8v10.5a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2V9.5a2 2 0 0 0-2-2h-6l-2.1-2.6H5.5a2 2 0 0 0-2 2V8Z"/>',
    photos:'<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><circle cx="9" cy="9" r="1.5"/><path d="m5 18 5.5-6 3.3 3 2.1-2 3.2 5"/>',
    calendar:'<rect x="3.5" y="5.5" width="17" height="15" rx="3"/><path d="M7.8 3.5v4M16 3.5v4M3.5 10h17"/><path d="M8 14h2m4 0h2m-8 3h2"/>',
    planning:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2"/><circle cx="14" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>',
    tasks:'<rect x="4" y="4" width="16" height="16" rx="4"/><path d="m8 12 2.8 2.8 5.2-5.7"/>',
    talk:'<path d="M20 11.1a7.9 7.9 0 0 1-8.1 7.8c-1.3 0-2.7-.3-3.8-1L4 20l1.2-4.5A7.7 7.7 0 0 1 4 11.1a8 8 0 0 1 16 0Z"/><path d="M8 11.4h.1m3.9 0h.1m3.9 0h.1"/>',
    contacts:'<circle cx="9" cy="8" r="3"/><path d="M3.5 19v-1.4A5.5 5.5 0 0 1 9 12a5.5 5.5 0 0 1 5.5 5.6V19"/><path d="M16 5.5a3 3 0 0 1 0 5.8m1.2 2a5 5 0 0 1 3.3 4.8V19"/>',
    mail:'<rect x="3.5" y="5" width="17" height="14" rx="3"/><path d="m4.5 7 7.5 6 7.5-6"/>',
    activity:'<path d="M2.8 12h4.1l2.5-6.6 4.2 13.2 2.3-6.6h5.3"/>',
    deck:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.5 4v16m5-16v16M5.8 8h1.6m3.6 0h1.6m3.6 0h1.6M5.8 12h1.6"/>',
    notes:'<path d="M6 3.5h9l3 3V20.5H6a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2Z"/><path d="M14 3.5v4h4M8 12h7M8 15.5h5"/>',
    bookmarks:'<path d="M6 3.5h12v17l-6-4-6 4v-17Z"/>',
    maps:'<path d="M4 6l5-2 6 2 5-2v14l-5 2-6-2-5 2V6Zm5-2v14m6-12v14"/>',
    tables:'<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M3.5 10h17m-11-5.5v15m5-15v15"/>',
    office:'<path d="M6 3.5h8l4 4v13H6a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2Z"/><path d="M14 3.5v4h4M8 12h7m-7 3h7"/>',
    news:'<path d="M5 4.5h12v12H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z"/><path d="M17 8h2a2 2 0 0 1 2 2v7a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-2.5M7 9h7M7 12h5"/>'
  };
  const appGlyph=(id,size=23)=>`<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${glyphPaths[id]||icons.grid}</svg>`;
  function topApps(){const allowed=new Set(settings.topApps||[]);const filesInWorkspace=!(settings.hidden||[]).includes('explorer');return (overview?.shortcuts||[]).filter(a=>allowed.has(a.id)&&!(a.id==='files'&&filesInWorkspace)).slice(0,8);}
  function brandMark(){return `<img src="${safeUrl(kitFile('branding/neos-wordmark.svg'))}" alt="" loading="eager">`;}
  function appGlyphMarkup(id,label,size=19){const src=flatIconAsset('glyphs',id);return src?`<img src="${safeUrl(src)}" alt="" loading="lazy" class="neos-glyph-img" width="${size}" height="${size}">`:appGlyph(id,size);}
  function appTileMarkup(id,label){const src=flatIconAsset('tiles',id);return src?`<img src="${safeUrl(src)}" alt="" loading="lazy" class="neos-app-tile">`:`<span class="neos-app-glyph">${appGlyph(id,27)}</span>`;}
  function hubIconMarkup(id,label){
    const mapped=flatIconId(id);
    if(mapped){
      const png=kitFile(`icons/png256/${mapped}.png`);
      return `<img class="neos-hub-icon neos-hub-png256" src="${safeUrl(png)}" alt="" loading="lazy" width="76" height="76">`;
    }
    return appGlyphMarkup(id,label,55);
  }
  function hubGrid(compact=false){
    const installed=availableApps();
    const builtIn=orderedApps.map(id=>({id,label:appName(id),available:id==='planning'||installed.has(id)}));
    const extra=(overview?.shortcuts||[]).filter(a=>!orderedApps.includes(a.id));
    const list=[{id:'home',label:'Accueil',available:true},...builtIn,...extra];
    return `<div class="neos-hub-grid neos-hub-icons ${compact?'is-compact':''}">${list.map(app=>{
      const internal=installedTabs().includes(app.id);
      const src=app.id==='home'?safeUrl(kitFile('icons/ui/accueil.svg')):'';
      const picture=app.id==='home'?`<img class="neos-hub-icon neos-hub-png256" src="${safeUrl(appAsset('neos-home-cyan-v056-256.png'))}" alt="" loading="eager" width="76" height="76">`:hubIconMarkup(app.id,app.label);
      const action=internal?`<button type="button" class="neos-app ${app.available?'':'is-unavailable'}" data-action="workspace" data-workspace="${esc(app.id)}" title="${esc(app.label)}" aria-label="Ouvrir ${esc(app.label)} dans Neos">`:`<a class="neos-app" href="${safeUrl(app.url)}" title="${esc(app.label)}">`;
      return `${action}<span class="neos-app-visual">${picture}</span><span class="neos-app-meta"><span class="neos-app-label">${esc(app.label)}</span>${!app.available&&internal?'<small>À activer</small>':''}</span>${internal?'</button>':'</a>'}`;
    }).join('')}</div>`;
  }

  const appName=id=>({'home':'Accueil','files':'Fichiers','photos':'Photos','calendar':'Agenda','planning':'Planning','tasks':'Tâches','talk':'Talk','contacts':'Contacts','mail':'Mail','activity':'Activité','deck':'Deck','notes':'Notes'})[id]||id;
  const orderedApps=['files','photos','planning','calendar','tasks','talk','contacts','mail','activity','deck','notes'];
  function installedTabs(){
    // Keep the navigation stable even if an app is disabled or its API is temporarily unavailable.
    // The corresponding workspace handles the unavailable state without navigating away.
    return ['home', ...orderedApps];
  }
  const availableApps=()=>new Set((overview?.shortcuts||[]).map(x=>x.id));
  // The home icon remains flat in the tab bar. The enlarged image is used in the hub only.
  function flatTabIcon(id){
    const asset=id==='home'?kitFile('icons/ui/accueil.svg'):flatIconAsset('glyphs',id);
    return asset?`<img class="neos-tab-flat-icon" src="${safeUrl(asset)}" alt="" loading="eager" width="21" height="21">`:`<span class="neos-tab-flat-icon">${appGlyph(id,20)}</span>`;
  }
  function tabBar(){return `<nav class="neos-workspace-tabs" aria-label="Espaces de travail"><span class="neos-tab-slider" aria-hidden="true"></span>${installedTabs().map(id=>`<button type="button" data-action="workspace" data-workspace="${id}" class="neos-workspace-tab ${activeWorkspace===id?'is-active':''}" aria-current="${activeWorkspace===id?'page':'false'}" aria-label="Onglet ${esc(appName(id))}">${flatTabIcon(id)}<span>${esc(appName(id))}</span></button>`).join('')}</nav>`;}
  let pillFrame=0;
  function positionTabSlider(from=null){
    const nav=surface.querySelector('.neos-workspace-tabs');
    const slider=nav?.querySelector('.neos-tab-slider');
    const active=nav?.querySelector('.neos-workspace-tab.is-active');
    if(!nav||!slider||!active)return;
    const x=active.offsetLeft, width=active.offsetWidth;
    const initial=from&&Number.isFinite(from.x)&&from.width>0?from:{x,width};
    slider.style.width=`${initial.width}px`;
    slider.style.transform=`translate3d(${initial.x}px,-50%,0)`;
    if(pillFrame)cancelAnimationFrame(pillFrame);
    const move=()=>{
      // Force the initial layout before toggling the transition on a re-render.
      void slider.offsetWidth;
      const animated=motionEnabled()&&Math.abs(initial.x-x)>1;
      if(animated)slider.classList.add('neos-tab-slider-ready');
      slider.style.width=`${width}px`;
      slider.style.transform=`translate3d(${x}px,-50%,0)`;
      if(!animated)slider.classList.remove('neos-tab-slider-ready');
    };
    pillFrame=requestAnimationFrame(()=>{pillFrame=0;move();});
  }
  function previousTabPosition(){
    const old=surface.querySelector('.neos-workspace-tabs .neos-workspace-tab.is-active');
    return old?{x:old.offsetLeft,width:old.offsetWidth}:null;
  }
  function workspaceHero(){
    const label=activeWorkspace==='home'?'Tableau de bord':activeWorkspace==='files'?'Fichiers':appName(activeWorkspace);
    const count=activeWorkspace==='planning'?'Agenda · Tâches · Deck':activeWorkspace==='home'?'Vue d’ensemble':activeWorkspace==='files'?`${browser.total} éléments`:activeWorkspace==='photos'?`${photoState.items.length} images`:activeWorkspace==='notes'?`${notesState.items.length} notes`:activeWorkspace==='deck'?`${deckState.boards.length} tableaux`:'Nextcloud';
    return `<div class="neos-hero"><div class="neos-hero-motion" aria-hidden="true"><span class="neos-hero-arc neos-hero-arc-one"></span><span class="neos-hero-arc neos-hero-arc-two"></span><span class="neos-hero-diagonal neos-hero-diagonal-one"></span><span class="neos-hero-diagonal neos-hero-diagonal-two"></span><span class="neos-hero-pulse"></span></div><div class="neos-hero-head"><span class="neos-hero-eyebrow">NEOS <span>/</span> ${esc(activeWorkspace.toUpperCase())}</span><h1>${esc(label)}</h1></div><div class="neos-hero-meta"><span class="neos-dot"></span><span>${esc(count)}</span><span class="neos-hero-clock" data-clock>--:--</span></div></div>`;
  }
  function panelHeader(title,subtitle='',actions=''){
    return `<div class="neos-module-header"><div><span class="neos-module-eyebrow">ESPACE INTÉGRÉ</span><h2>${esc(title)}</h2>${subtitle?`<p>${esc(subtitle)}</p>`:''}</div><div class="neos-module-actions">${actions}</div></div>`;
  }
  function emptyModule(text,link='',href='#'){
    return `<div class="neos-module-empty"><span class="neos-module-empty-mark">${icon('grid',30)}</span><strong>${esc(text)}</strong>${link?`<a class="neos-btn" href="${safeUrl(href)}">${esc(link)} ${icon('external',15)}</a>`:''}</div>`;
  }
  const moduleLink=id=>(overview?.shortcuts||[]).find(app=>app.id===id)?.url || `/index.php/apps/${id}/`;
  function photoModule(){
    const body=photoState.status==='loading' ? '<div class="neos-module-loader"><span class="neos-spinner"></span>Chargement des images</div>' :
      photoState.status==='error'?emptyModule(photoState.error||'Photos indisponibles','Ouvrir Photos',moduleLink('photos')) :
      photoState.items.length?`<div class="neos-photo-grid">${photoState.items.map((photo,i)=>`<button type="button" class="neos-photo-item" data-action="photo-open" data-photo-index="${i}" title="${esc(photo.name)}"><img src="${safeUrl(photo.previewUrl||photo.davUrl)}" loading="lazy" alt=""><span>${esc(photo.name)}</span></button>`).join('')}</div>${photoState.partial?'<p class="neos-module-small">Résultats partiels — limite de scan atteinte.</p>':''}`:emptyModule('Aucune image trouvée dans les dossiers accessibles.');
    return `<section class="neos-module neos-photo-module">${panelHeader('Photos','Images de tes fichiers Nextcloud',`<button class="neos-iconbtn" data-action="module-refresh" title="Rafraîchir" aria-label="Rafraîchir">${icon('refresh',17)}</button><a class="neos-btn" href="${safeUrl(moduleLink('photos'))}">${icon('external',15)} Albums natifs</a>`)}<div class="neos-module-body">${body}</div></section>`;
  }
  function noteModule(){
    const list=notesState.items;
    const selected=list.find(n=>String(n.id)===String(notesState.selected));
    const sidebar=notesState.status==='loading'?'<div class="neos-module-loader"><span class="neos-spinner"></span></div>':notesState.status==='error'?`<div class="neos-notes-error">${esc(notesState.error)}</div>`:list.length?list.map(n=>`<button type="button" class="neos-note-row ${String(n.id)===String(notesState.selected)?'is-active':''}" data-action="note-select" data-note-id="${esc(n.id)}"><strong>${esc(n.title||'Sans titre')}</strong><span>${esc(n.category||'Notes')} · ${ago(n.modified)}</span></button>`).join(''):'<div class="neos-module-empty-small">Aucune note.</div>';
    const editor=selected?`<div class="neos-note-editor"><div class="neos-note-titleline"><input data-note-title class="neos-note-title-input" maxlength="180" value="${esc(notesState.draftTitle)}" ${selected.readonly?'readonly':''} aria-label="Titre de la note"><button type="button" class="neos-btn neos-btn-small" data-action="note-preview-toggle" aria-pressed="${noteView==='preview'}">${icon('note',15)} ${noteView==='preview'?'Éditer':'Aperçu'}</button></div>${noteView==='preview'?`<article class="neos-markdown-preview neos-note-rendered">${markdownHtml(notesState.draftContent)}</article>`:`<textarea data-note-content class="neos-note-content-input" spellcheck="true" ${selected.readonly?'readonly':''} aria-label="Contenu de la note">${esc(notesState.draftContent)}</textarea>`}<div class="neos-note-bottom"><span data-note-status>${notesState.dirty?'Modifications non enregistrées':selected.readonly?'Lecture seule':'Enregistré'}</span><span data-note-count>${notesState.draftContent.trim()?notesState.draftContent.trim().split(/\s+/).length:0} mots</span><button class="neos-btn neos-btn-primary" type="button" data-action="note-save" ${selected.readonly?'disabled':''}>${icon('check',16)} Enregistrer</button></div></div>`:emptyModule('Sélectionne une note.');
    return `<section class="neos-module">${panelHeader('Notes',notesState.source==='files'?'Édition des fichiers Markdown Nextcloud (API Notes absente)':'Consultation et édition dans Neos',`<button class="neos-btn neos-btn-primary" data-action="note-new">${icon('plus',16)} Nouvelle note</button>${notesState.source==='api'?`<a class="neos-btn" href="${safeUrl(moduleLink('notes'))}">${icon('external',15)} Notes</a>`:''}`)}<div class="neos-module-body neos-notes-layout"><aside class="neos-notes-sidebar">${sidebar}</aside><div class="neos-notes-main">${editor}</div></div></section>`;
  }
  function deckDueLabel(value){
    if(!value)return '';
    const date=new Date(value);
    if(!Number.isFinite(date.getTime()))return '';
    return new Intl.DateTimeFormat('fr-FR',{day:'2-digit',month:'short'}).format(date);
  }
  function deckModule(){
    const board=deckState.boards.find(b=>String(b.id)===String(deckState.boardId));
    const boardButtons=deckState.boards.map(b=>`<button type="button" class="neos-board-chip ${String(b.id)===String(deckState.boardId)?'is-active':''}" data-action="deck-board" data-board-id="${esc(b.id)}">${esc(b.title)}</button>`).join('');
    const stacks=deckState.stacks.map(stack=>`<section class="neos-stack" data-deck-drop-stack="${esc(stack.id)}"><header><h3>${esc(stack.title)}</h3><span>${(stack.cards||[]).length}</span></header><div class="neos-stack-cards" data-deck-drop-stack="${esc(stack.id)}">${(stack.cards||[]).map(card=>`<button type="button" class="neos-deck-card ${card.done?'is-done':''}" draggable="${!deckMoveBusy}" data-action="deck-card-open" data-stack-id="${esc(stack.id)}" data-card-id="${esc(card.id)}" aria-label="Ouvrir ${esc(card.title||'Carte')} — déplacer par glisser-déposer"><span class="neos-deck-card-title">${card.done?icon('check',14):''}${esc(card.title||'Sans titre')}</span><small>${card.duedate?`Échéance ${esc(deckDueLabel(card.duedate))}`:card.description?'Description disponible':'Déplacer vers une autre colonne'}</small></button>`).join('')}</div><button type="button" class="neos-stack-add" data-action="deck-add" data-stack-id="${esc(stack.id)}">${icon('plus',15)} Ajouter une carte</button></section>`).join('');
    const body=deckState.status==='loading'?'<div class="neos-module-loader"><span class="neos-spinner"></span>Chargement Deck</div>':deckState.status==='error'?emptyModule(deckState.error||'Deck indisponible','Ouvrir Deck',moduleLink('deck')):board?`<div class="neos-board-nav">${boardButtons}</div><p class="neos-deck-instructions">Glisse une carte vers une colonne ou ouvre-la pour changer sa colonne, son échéance ou son état.</p><div class="neos-kanban">${stacks||emptyModule('Aucune colonne sur ce tableau.')}</div>`:emptyModule('Aucun tableau disponible.');
    return `<section class="neos-module">${panelHeader('Deck','Tableaux et cartes de tes projets',`<button class="neos-iconbtn" data-action="module-refresh" title="Rafraîchir" aria-label="Rafraîchir">${icon('refresh',17)}</button><a class="neos-btn" href="${safeUrl(moduleLink('deck'))}">${icon('external',15)} Deck</a>`)}<div class="neos-module-body">${body}</div></section>`;
  }

  // Calendar navigation uses local days to avoid UTC date drift on time-zone boundaries.
  const calDayKey=(date)=>{const d=new Date(date);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const calFromKey=(key)=>{const [y,m,d]=String(key).split('-').map(Number);return new Date(y,m-1,d,12,0,0,0);};
  function calStartOfWeek(date){const d=new Date(date.getFullYear(),date.getMonth(),date.getDate(),12);d.setDate(d.getDate()-(d.getDay()+6)%7);return d;}
  function calFetchWindow(){
    const start=new Date(calendarCursor.getFullYear(),calendarCursor.getMonth()-1,1);
    const end=new Date(calendarCursor.getFullYear(),calendarCursor.getMonth()+3,1);
    if(activeWorkspace==='planning'){
      const needed=new Date();needed.setHours(0,0,0,0);needed.setDate(needed.getDate()+planningRange+1);
      if(needed>end)end.setTime(needed.getTime());
    }
    return {start,end};
  }
  function calVisibleDays(){
    let first,count;
    if(calendarView==='week'){first=calStartOfWeek(calendarCursor);count=7;}
    else {first=calStartOfWeek(new Date(calendarCursor.getFullYear(),calendarCursor.getMonth(),1,12));count=42;}
    return Array.from({length:count},(_,i)=>{const day=new Date(first);day.setDate(first.getDate()+i);return day;});
  }
  function calEventsOn(day){
    const from=new Date(day.getFullYear(),day.getMonth(),day.getDate());const to=new Date(from);to.setDate(to.getDate()+1);
    return groupware.events.filter(event=>{const start=Date.parse(event.start),end=Date.parse(event.end)||start+3600000;return start<to.getTime()&&end>from.getTime();});
  }
  const nativeModuleAvailable=id=>(overview?.shortcuts||[]).some(x=>x.id===id);
  const nativeModuleButton=(id,label='Ouvrir')=>nativeModuleAvailable(id)?`<a class="neos-btn" href="${safeUrl(moduleLink(id))}" target="_blank" rel="noopener noreferrer">${icon('external',14)} ${esc(label)}</a>`:'';
  function calendarWindowReady(){
    const days=calVisibleDays();
    const range=activeWorkspace==='planning'?calFetchWindow():{start:new Date(days[0].getFullYear(),days[0].getMonth(),days[0].getDate()),end:new Date(days[days.length-1].getFullYear(),days[days.length-1].getMonth(),days[days.length-1].getDate()+1)};
    return groupware.windowStart&&groupware.windowEnd&&range.start>=groupware.windowStart&&range.end<=groupware.windowEnd;
  }
  function moveCalendar(step){
    if(step==='today')calendarCursor=new Date();
    else if(calendarView==='week')calendarCursor.setDate(calendarCursor.getDate()+Number(step)*7);
    else calendarCursor.setMonth(calendarCursor.getMonth()+Number(step),1);
    calendarCursor.setHours(12,0,0,0);
    if(!calendarWindowReady()&&!demo)void loadGroupware(true);else render();
  }
  function calendarGrid(){
    const days=calVisibleDays(),now=calDayKey(new Date());
    const monthName=new Intl.DateTimeFormat('fr-FR',{month:'long',year:'numeric'}).format(calendarCursor);
    const from=days[0],to=days[days.length-1];
    const weekName=`${new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short'}).format(from)} – ${new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short',year:'numeric'}).format(to)}`;
    const dayNames=['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
    const headings=dayNames.map(x=>`<div class="neos-cal-weekday">${x}</div>`).join('');
    const dayCells=days.map(day=>{
      const key=calDayKey(day),events=calEventsOn(day),today=key===now,other=calendarView==='month'&&day.getMonth()!==calendarCursor.getMonth();
      return `<div class="neos-cal-day ${today?'is-today':''} ${other?'is-other':''}" data-cal-day="${key}"><button type="button" class="neos-cal-day-number" data-action="cal-day" data-date="${key}" aria-label="Créer un événement le ${esc(new Intl.DateTimeFormat('fr-FR',{dateStyle:'full'}).format(day))}">${day.getDate()}${today?'<span class="neos-cal-today-label">Aujourd’hui</span>':''}</button><div class="neos-cal-events">${events.slice(0,calendarView==='week'?9:3).map(event=>`<button type="button" class="neos-cal-event" data-action="cal-event" data-href="${esc(event.href)}" title="${esc(event.title)}"><span>${esc(event.title)}</span>${calendarView==='week'?`<small>${esc(fmtTime(event.start))}</small>`:''}</button>`).join('')}${events.length>(calendarView==='week'?9:3)?`<span class="neos-cal-more">+${events.length-(calendarView==='week'?9:3)} autres</span>`:''}</div></div>`;
    }).join('');
    const currentTitle=calendarView==='month'?monthName:weekName;
    return `<div class="neos-calendar-workspace"><div class="neos-calendar-toolbar"><div class="neos-calendar-nav"><button type="button" class="neos-iconbtn" data-action="cal-prev" aria-label="Période précédente">${icon('chevron',17)}</button><button type="button" class="neos-btn neos-btn-small" data-action="cal-today">Aujourd’hui</button><button type="button" class="neos-iconbtn" data-action="cal-next" aria-label="Période suivante">${icon('chevron',17)}</button><strong>${esc(currentTitle)}</strong></div><div class="neos-calendar-views"><button type="button" data-action="cal-view" data-view="month" aria-pressed="${calendarView==='month'}" class="${calendarView==='month'?'is-active':''}">Mois</button><button type="button" data-action="cal-view" data-view="week" aria-pressed="${calendarView==='week'}" class="${calendarView==='week'?'is-active':''}">Semaine</button></div></div><div class="neos-calendar-grid ${calendarView==='week'?'is-week':'is-month'}">${headings}${dayCells}</div><p class="neos-gw-hint">Clique sur un jour pour créer un événement, ou sur un événement pour consulter ses détails. Les récurrences complexes restent gérées dans Agenda Nextcloud.</p></div>`;
  }
  function calendarEventDetail(href){
    const event=groupware.events.find(e=>e.href===href);if(!event)return;
    const when=iso=>new Intl.DateTimeFormat('fr-FR',{dateStyle:'full',timeStyle:'short'}).format(new Date(iso));
    popMode='calendar-detail';
    popHost.innerHTML=`<div class="neos-pop-layer" data-action="close-pop"><section class="neos-groupware-dialog neos-framed" role="dialog" aria-modal="true" aria-label="Détails de l’événement"><header><strong>${esc(event.title)}</strong><button type="button" class="neos-iconbtn" data-action="close-pop" aria-label="Fermer">${icon('close',19)}</button></header><div class="neos-cal-detail"><div><span>Début</span><strong>${esc(when(event.start))}</strong></div>${event.end?`<div><span>Fin</span><strong>${esc(when(event.end))}</strong></div>`:''}<div><span>Calendrier</span><strong>${esc(event.calendar)}</strong></div>${event.location?`<div><span>Lieu</span><strong>${esc(event.location)}</strong></div>`:''}${event.description?`<p>${esc(event.description)}</p>`:''}</div><footer><button type="button" class="neos-btn neos-btn-primary" data-action="close-pop">Fermer</button>${nativeModuleButton('calendar','Agenda')}</footer></section></div>`;
    animateLayerOpen(popHost,'.neos-groupware-dialog','y');
  }
  // CalDAV uses the same-origin Nextcloud session; no stored passwords or API tokens.
  const groupwareRoot=()=>`${ncWebroot()}/remote.php/dav/calendars/${encodeURIComponent(root.dataset.currentUid||'')}/`;
  function caldavHref(href){
    try { const result=new URL(String(href||''),window.location.origin);
      if(result.origin!==window.location.origin || !result.pathname.includes('/remote.php/dav/calendars/'))return '';
      return result.href;
    }catch{return '';}
  }
  // Deck exports its boards as virtual read-only VTODO calendars. Their card-X.ics
  // resources can be read via CalDAV but MUST be updated via the Deck API.
  function deckVirtualResource(href){
    try{
      const path=decodeURIComponent(new URL(String(href||''),window.location.origin).pathname);
      const match=/(?:^|\/)app-generated--deck--board-(\d+)\/(?:card-(\d+)\.ics)?$/i.exec(path);
      return match?{boardId:match[1],cardId:match[2]||null}:null;
    }catch{return null;}
  }
  function xmlChildren(node,name){return node?[...node.getElementsByTagName('*')].filter(e=>e.localName===name):[];}
  function xmlText(node,name){return xmlChildren(node,name)[0]?.textContent?.trim()||'';}
  function xmlDocument(text){const dom=new DOMParser().parseFromString(text,'application/xml');if(dom.querySelector('parsererror'))throw Error('Réponse XML CalDAV invalide');return dom;}
  function icsUnfold(raw){return String(raw||'').replace(/\r\n/g,'\n').replace(/\n[ \t]/g,'');}
  function icsSection(raw,type){
    const text=icsUnfold(raw);const start=text.indexOf('BEGIN:'+type+'\n');const end=start<0?-1:text.indexOf('END:'+type,start);
    return start<0||end<0?'':text.slice(start+('BEGIN:'+type+'\n').length,end);
  }
  function icsProperty(section,key){const line=section.split('\n').find(s=>s.toUpperCase().startsWith(key+':')||s.toUpperCase().startsWith(key+';'))||'';return line.slice(line.indexOf(':')+1);}
  function icsUnescape(text){return String(text||'').replace(/\\[nN]/g,'\n').replace(/\\([,;\\])/g,'$1');}
  function icsEscape(text){return String(text||'').replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');}
  function icsTime(value){
    const m=/^(\d{4})(\d\d)(\d\d)(?:T(\d\d)(\d\d)(\d\d)?(Z)?)?/.exec(String(value||''));if(!m)return '';
    const parts=[+m[1],+m[2]-1,+m[3],+(m[4]||0),+(m[5]||0),+(m[6]||0)];
    const d=m[7]?new Date(Date.UTC(...parts)):new Date(...parts);return Number.isFinite(d.getTime())?d.toISOString():'';
  }
  function icsUtc(date){const d=new Date(date);if(!Number.isFinite(d.getTime()))throw Error('Date invalide');return d.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');}
  function icsDateOnly(date){return String(date||'').replace(/-/g,'');}
  function dateInputLocal(value){if(!value)return '';const d=new Date(value);if(!Number.isFinite(d.getTime()))return '';const two=x=>String(x).padStart(2,'0');return `${d.getFullYear()}-${two(d.getMonth()+1)}-${two(d.getDate())}T${two(d.getHours())}:${two(d.getMinutes())}`;}
  function icsFold(text){
    // Enforce RFC 5545 75-octet folding without splitting Unicode code points.
    return String(text).split('\n').map(line=>{let chunk='',bytes=0,parts=[];for(const ch of line){const len=new TextEncoder().encode(ch).length;if(bytes+len>73&&chunk){parts.push(chunk);chunk=' ';bytes=1;}chunk+=ch;bytes+=len;}parts.push(chunk);return parts.join('\r\n');}).join('\r\n')+'\r\n';
  }
  function icsUpdateTodo(raw,updates){
    const lines=icsUnfold(raw).split('\n');let within=false,count=0;const seen=new Set();const next=[];
    for(const line of lines){
      if(line==='BEGIN:VTODO'){within=true;count++;next.push(line);continue;}
      if(within&&line==='END:VTODO'){
        for(const [key,value] of Object.entries(updates))if(value!==null&&!seen.has(key))next.push(`${key==='DUE'?'DUE;VALUE=DATE':key}:${value}`);
        within=false;next.push(line);continue;
      }
      if(within){const match=/^([A-Z-]+)(?:;[^:]*)?:/i.exec(line);if(match&&Object.hasOwn(updates,match[1].toUpperCase())){
        const key=match[1].toUpperCase(),value=updates[key];if(!seen.has(key)&&value!==null)next.push(`${key==='DUE'?'DUE;VALUE=DATE':key}:${value}`);
        seen.add(key);continue;
      }}
      next.push(line);
    }
    if(count!==1||within)throw Error('Tâche CalDAV complexe : édition disponible dans Tâches Nextcloud');
    return icsFold(next.join('\n').replace(/\n+$/,''));
  }
  function parseGroupwareObject(raw,type,href,etag,calendar){
    const section=icsSection(raw,type);if(!section)return null;
    const record={href,etag,raw,calendarUrl:calendar.url,calendar:calendar.name,type,uid:icsProperty(section,'UID'),title:icsUnescape(icsProperty(section,'SUMMARY'))||'Sans titre',description:icsUnescape(icsProperty(section,'DESCRIPTION'))};
    if(type==='VEVENT'){
      record.start=icsTime(icsProperty(section,'DTSTART'));record.end=icsTime(icsProperty(section,'DTEND'));
      record.location=icsUnescape(icsProperty(section,'LOCATION'));
      record.recurrence=Boolean(icsProperty(section,'RRULE'));
    }else{
      const dueRaw=icsProperty(section,'DUE');
      record.dueDate=/^\d{8}$/.test(dueRaw)?`${dueRaw.slice(0,4)}-${dueRaw.slice(4,6)}-${dueRaw.slice(6,8)}`:'';
      record.due=record.dueDate?`${record.dueDate}T12:00:00`:icsTime(dueRaw);
      record.done=icsProperty(section,'STATUS').toUpperCase()==='COMPLETED'||Boolean(icsProperty(section,'COMPLETED'));
    }
    if(type==='VTODO'){
      const deck=deckVirtualResource(href);
      record.source=deck?'deck':'caldav';
      record.deckBoardId=deck?.boardId||null;
      record.deckCardId=deck?.cardId||null;
      record.writable=!deck&&!!calendar.writable;
    }
    return record;
  }
  async function caldavRequest(method,url,body='',headers={}){
    if(!caldavHref(url))throw Error('Adresse CalDAV non autorisée');
    const r=await fetch(url,{method,body:body||undefined,credentials:'same-origin',cache:'no-store',headers:{requesttoken:csrfToken(),'X-Requested-With':'XMLHttpRequest',...headers}});
    if(r.redirected&&!caldavHref(r.url))throw Error('Session Nextcloud redirigée : reconnecte-toi puis réessaie.');
    if(!r.ok){
      const err=new Error(`HTTP ${r.status} (${method} CalDAV)`);
      err.status=r.status;err.method=method;
      console.warn('[Neos] CalDAV',method,r.status,new URL(url,window.location.origin).pathname);
      throw err;
    }
    return r;
  }
  // CalDAV: the resource GET may be redirected to an HTML page or return a
  // representation that is not a VTODO. RFC 4791 calendar-multiget offers an
  // independent, read-only way to obtain the current calendar-data + ETag.
  // No PUT is allowed until we have verified both UID and server ETag.
  const xmlEscape=value=>String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  function todoSnapshot(raw,etag,href,expectedUid){
    const section=icsSection(raw,'VTODO'),uid=icsProperty(section,'UID');
    if(!section||!uid)throw Error('Objet CalDAV illisible (VTODO/UID absent)');
    if(expectedUid&&uid!==expectedUid){const error=Error('Identité de la tâche modifiée : actualise la liste');error.identityMismatch=true;throw error;}
    if(!etag)throw Error('ETag absent : écriture protégée annulée');
    return {href,raw,etag,uid};
  }
  async function multigetTodo(href,expectedUid){
    const resource=caldavHref(href);
    if(!resource)throw Error('Adresse de tâche non autorisée');
    const parsed=new URL(resource),collection=resource.slice(0,resource.lastIndexOf('/')+1);
    const body=`<?xml version="1.0"?><c:calendar-multiget xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:getetag/><c:calendar-data/></d:prop><d:href>${xmlEscape(parsed.pathname)}</d:href></c:calendar-multiget>`;
    // RFC 4791, §7.9: omit Depth for calendar-multiget on a collection.
    const response=await caldavRequest('REPORT',collection,body,{'Content-Type':'application/xml; charset=utf-8','Accept':'application/xml'});
    const xml=xmlDocument(await response.text());
    const matching=xmlChildren(xml.documentElement,'response').find(entry=>{
      const candidate=caldavHref(xmlText(entry,'href'));
      return candidate&&new URL(candidate).pathname===parsed.pathname;
    });
    if(!matching)throw Error('REPORT multiget : aucune réponse pour cette tâche');
    for(const propstat of xmlChildren(matching,'propstat')){
      if(!/\b200\b/.test(xmlText(propstat,'status')))continue;
      const props=xmlChildren(propstat,'prop')[0];
      const raw=xmlText(props,'calendar-data'),etag=xmlText(props,'getetag');
      if(raw)return todoSnapshot(raw,etag,resource,expectedUid);
    }
    const statuses=xmlChildren(matching,'status').map(node=>node.textContent||'');
    if(statuses.some(status=>/\b404\b/.test(status))){const error=Error('Objet absent dans REPORT multiget (404)');error.status=404;throw error;}
    throw Error('REPORT multiget : données VTODO/ETag absentes');
  }
  // If GET fails or returns HTML, transparently try calendar-multiget.
  // A stale href is resolved by UID only if exactly one matching task exists.
  async function freshTodo(record){
    async function readAt(href){
      let getFailure;
      try{
        const response=await caldavRequest('GET',href,'',{'Accept':'text/calendar'});
        const raw=await response.text(),etag=response.headers.get('ETag');
        getFailure=Error(`GET ${response.status} : ${response.headers.get('Content-Type')||'type inconnu'}, VTODO/ETag non vérifiable`);
        return todoSnapshot(raw,etag,href,record.uid);
      }catch(error){
        if(error.identityMismatch)throw error;
        getFailure=error;
      }
      try{return await multigetTodo(href,record.uid);}catch(error){
        if(error.identityMismatch)throw error;
        const detail=`Lecture CalDAV impossible (GET : ${getFailure.message} ; REPORT multiget : ${error.message})`;
        const failure=Error(detail);
        if(error.status===404||getFailure.status===404)failure.status=404;
        throw failure;
      }
    }
    try{return await readAt(record.href);}catch(error){
      if(error.status!==404||!record.uid)throw error;
      const matches=[];
      for(const calendar of groupware.calendars.filter(c=>c.tasks).slice(0,16)){
        try{
          for(const candidate of await queryCalDav(calendar,'VTODO')){
            if(candidate.uid===record.uid&&!matches.some(x=>x.href===candidate.href))matches.push(candidate);
          }
        }catch(e){console.warn('[Neos] Recherche UID CalDAV',calendar.name,e.message);}
      }
      if(matches.length!==1)throw Error('Tâche déplacée ou introuvable : recherche par UID non concluante. Actualise Tâches. ('+error.message+')');
      return readAt(matches[0].href);
    }
  }
  async function updateExistingTodo(record,updates){
    if(record.source==='deck'||deckVirtualResource(record.href))throw Error('Ce VTODO provient de Deck : modification CalDAV interdite. Utilise l’API Deck.');
    if(record.writable===false)throw Error('Cette liste CalDAV est en lecture seule.');
    const latest=await freshTodo(record);
    try{
      await caldavRequest('PUT',latest.href,icsUpdateTodo(latest.raw,updates),{'Content-Type':'text/calendar; charset=utf-8','If-Match':latest.etag});
    }catch(error){
      if(error.status===404)throw Error('PUT CalDAV 404 : ressource disparue ou collection non modifiable. Actualise les listes ; pour Deck, utilise l’API Deck.');
      if(error.status===412)throw Error('La tâche a changé ailleurs (HTTP 412). Actualise Tâches puis réessaie.');
      throw error;
    }
    // Verify the persisted state, including removals (e.g. clearing DUE).
    try{
      const check=await freshTodo({...record,href:latest.href});
      const section=icsSection(check.raw,'VTODO');
      for(const [key,value] of Object.entries(updates)){
        if(icsProperty(section,key)!==(value??''))throw Error('Écriture non confirmée par Nextcloud : recharge la tâche et vérifie son état');
      }
    }catch(error){throw Error('Écriture envoyée mais vérification impossible : '+error.message);}
  }
  async function listCalDavCalendars(){
    const body='<?xml version="1.0"?><d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:displayname/><d:resourcetype/><d:current-user-privilege-set/><c:supported-calendar-component-set/></d:prop></d:propfind>';
    const xml=xmlDocument(await (await caldavRequest('PROPFIND',groupwareRoot(),body,{'Depth':'1','Content-Type':'application/xml; charset=utf-8'})).text());
    const calendars=[];
    for(const item of xmlChildren(xml.documentElement,'response')){
      const href=caldavHref(xmlText(item,'href'));
      const props=xmlChildren(item,'prop').find(p=>xmlChildren(p,'calendar').length)||null;
      if(!href||!props)continue;
      const supports=xmlChildren(props,'supported-calendar-component-set');
      const components=supports.length?xmlChildren(supports[0],'comp').map(e=>e.getAttribute('name')||''):['VEVENT','VTODO'];
      const privileges=xmlChildren(props,'current-user-privilege-set');
      const writable=!privileges.length||xmlChildren(privileges[0],'write-content').length>0||xmlChildren(privileges[0],'write').length>0;
      calendars.push({url:href.endsWith('/')?href:href+'/',name:xmlText(props,'displayname')||decodeURIComponent(href.split('/').filter(Boolean).pop()||'Calendrier'),events:components.includes('VEVENT'),tasks:components.includes('VTODO'),writable:writable&&!deckVirtualResource(href.endsWith('/')?href:href+'/'),source:deckVirtualResource(href.endsWith('/')?href:href+'/')?'deck':'caldav'});
    }
    return calendars.slice(0,16);
  }
  async function queryCalDav(calendar,type){
    const window=calFetchWindow();
    const span=type==='VEVENT'?`<c:time-range start="${icsUtc(window.start)}" end="${icsUtc(window.end)}"/>`:'';
    const body=`<?xml version="1.0"?><c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:getetag/><c:calendar-data/></d:prop><c:filter><c:comp-filter name="VCALENDAR"><c:comp-filter name="${type}">${span}</c:comp-filter></c:comp-filter></c:filter></c:calendar-query>`;
    const xml=xmlDocument(await (await caldavRequest('REPORT',calendar.url,body,{'Depth':'1','Content-Type':'application/xml; charset=utf-8'})).text());
    const result=[];
    for(const entry of xmlChildren(xml.documentElement,'response').slice(0,200)){
      const href=caldavHref(xmlText(entry,'href')),raw=xmlText(entry,'calendar-data');
      if(!href||!raw)continue;
      const item=parseGroupwareObject(raw,type,href,xmlText(entry,'getetag'),calendar);if(item)result.push(item);
    }
    return result;
  }
  async function loadGroupware(force=false){
    if(!force&&(groupware.status==='loading'||groupware.status==='ready'))return;
    const gen=++groupware.generation;groupware.status='loading';groupware.error='';render();
    try{
      if(demo){
        groupware.calendars=[{url:'demo://personal/',name:'Personnel',events:true,tasks:true,writable:true,source:'caldav'}];
        groupware.events=(overview?.calendar||[]).map((e,i)=>({href:'demo-event-'+i,calendar:'Personnel',calendarUrl:'demo://personal/',title:e.title,start:e.start,end:new Date(new Date(e.start).getTime()+3600000).toISOString(),description:'',location:''}));
        groupware.tasks=(overview?.tasks||[]).map((t,i)=>({href:'demo-task-'+i,calendar:t.source==='deck'?'Deck : Projet Neos':'Personnel',calendarUrl:'demo://personal/',title:t.title,due:t.due||'',description:'',done:!!t.done,raw:'',source:t.source||'caldav',deckBoardId:t.deckBoardId||null,deckCardId:t.deckCardId||null,writable:t.source!=='deck'}));
        groupware.taskSources=1;groupware.taskSuccess=1;groupware.taskErrors=[];const range=calFetchWindow();groupware.windowStart=range.start;groupware.windowEnd=range.end;
      }else{
        const calendars=await listCalDavCalendars();if(gen!==groupware.generation)return;
        const events=[],tasks=[],taskErrors=[];let taskSources=0,taskSuccess=0;
        for(const cal of calendars){
          if(cal.events){try{events.push(...await queryCalDav(cal,'VEVENT'));}catch(error){console.warn('[Neos] événements CalDAV',error);}}
          if(cal.tasks){taskSources++;try{tasks.push(...await queryCalDav(cal,'VTODO'));taskSuccess++;}catch(error){taskErrors.push({calendar:cal.name,message:String(error.message||'Erreur')});console.warn('[Neos] tâches CalDAV',error);}}
          if(gen!==groupware.generation)return;
        }
        groupware.calendars=calendars;
        groupware.events=events.filter(x=>x.start).sort((a,b)=>new Date(a.start)-new Date(b.start)).slice(0,350);
        groupware.tasks=tasks.sort((a,b)=>Number(a.done)-Number(b.done)||(a.due||'9999').localeCompare(b.due||'9999')).slice(0,150);
        groupware.taskErrors=taskErrors;groupware.taskSources=taskSources;groupware.taskSuccess=taskSuccess;
        const range=calFetchWindow();groupware.windowStart=range.start;groupware.windowEnd=range.end;
      }
      groupware.status='ready';groupware.error='';if(gen===groupware.generation)render();
    }catch(error){if(gen!==groupware.generation)return;groupware.status='error';groupware.error='CalDAV indisponible ('+String(error.message||'erreur')+'). Ouvre Agenda ou Tâches pour vérifier la configuration.';console.warn('[Neos] CalDAV',error);render();}
  }
  function groupwareModule(type){
    const calendar=type==='calendar',isReady=groupware.status==='ready';
    const records=calendar?groupware.events:groupware.tasks;
    const title=calendar?'Agenda':'Tâches';
    const filteredTasks=records.filter(t=>taskView==='all'||(taskView==='done'?t.done:!t.done));
    const taskRows=filteredTasks.map(t=>{const isDeck=t.source==='deck';const canToggle=t.writable!==false||isDeck&&!!t.deckCardId&&availableApps().has('deck');const canEdit=t.writable!==false||isDeck&&!!t.deckCardId&&availableApps().has('deck');return `<div class="neos-gw-entry ${t.done?'neos-gw-done':''}"><button type="button" class="neos-gw-check" data-action="gw-toggle-done" data-href="${esc(t.href)}" aria-label="${t.done?'Rouvrir':'Terminer'} ${esc(t.title)}" title="${isDeck?'Modifier via Deck':canToggle?'Modifier via CalDAV':'Liste en lecture seule'}" ${groupware.busy||!canToggle?'disabled':''}>${icon(t.done?'check':'plus',15)}</button><div class="neos-gw-detail"><strong>${esc(t.title)}</strong><small>${isDeck?'<span class="neos-source neos-source-deck">Deck</span> ':''}${esc(t.calendar)}${t.due?' · '+esc(fmtTime(t.due)):''}${!canToggle?' · Lecture seule':''}</small></div><button type="button" class="neos-mini-action" data-action="gw-edit-task" data-href="${esc(t.href)}" title="${isDeck?'Ouvrir dans Deck':'Modifier'}" ${groupware.busy||!canEdit?'disabled':''}>${icon(isDeck?'kanban':'settings',16)}</button></div>`;}).join('');
    const hasNative=nativeModuleAvailable(calendar?'calendar':'tasks');
    const toolbar=`<button type="button" class="neos-iconbtn" data-action="gw-refresh" title="Actualiser" aria-label="Actualiser">${icon('refresh',16)}</button><button type="button" class="neos-btn neos-btn-primary" data-action="gw-new" data-gw-type="${calendar?'event':'task'}" ${!isReady||(!calendar&&groupware.taskSuccess===0)||!groupware.calendars.some(c=>c.writable&&(calendar?c.events:c.tasks))?'disabled':''}>${icon('plus',15)} ${calendar?'Événement':'Tâche'}</button>${nativeModuleButton(calendar?'calendar':'tasks','Ouvrir')}`;
    let content;
    if(groupware.status==='loading')content='<div class="neos-module-loader"><span class="neos-spinner"></span>Chargement CalDAV…</div>';
    else if(groupware.status==='error')content=emptyModule(groupware.error);
    else if(!groupware.calendars.length)content=emptyModule('Aucun calendrier accessible. Vérifie tes calendriers Nextcloud.');
    else if(calendar)content=calendarGrid();
    else if(groupware.taskSources===0)content=`<div class="neos-gw-info"><strong>Aucune liste de tâches CalDAV</strong><p>Ton Agenda fonctionne, mais aucun calendrier compatible VTODO n’est disponible. Crée une liste de tâches dans Nextcloud, ou active l’application Tâches si elle n’est pas installée.</p></div>`;
    else if(groupware.taskSuccess===0&&groupware.taskErrors.length)content=`<div class="neos-gw-info"><strong>Impossible de lire les listes de tâches</strong><p>${esc(groupware.taskErrors.map(e=>`${e.calendar} : ${e.message}`).join(' · '))}</p><p>L’Agenda peut continuer à fonctionner normalement. Vérifie le code HTTP de la requête REPORT CalDAV dans F12 → Réseau.</p></div>`;
    else content=`<div class="neos-task-filters">${[['open','À faire'],['done','Terminées'],['all','Toutes']].map(([id,label])=>`<button type="button" data-action="task-view" data-view="${id}" class="${taskView===id?'is-active':''}" aria-pressed="${taskView===id}">${label}</button>`).join('')}</div>${!hasNative?'<div class="neos-gw-info neos-gw-info-inline">Le module Tâches de Neos reste accessible via CalDAV. Le raccourci vers l’application Tâches native est masqué si elle n’est pas activée.</div>':''}${groupware.taskErrors.length?`<p class="neos-gw-warning">Certaines listes n’ont pas pu être chargées : ${esc(groupware.taskErrors.map(e=>`${e.calendar} (${e.message})`).join(', '))}</p>`:''}${taskRows?`<div class="neos-gw-list">${taskRows}</div>`:'<div class="neos-empty">Aucune tâche dans ce filtre.</div>'}`;
    return `<section class="neos-module">${panelHeader(title,calendar?'Calendrier mensuel et hebdomadaire':'Tâches CalDAV synchronisées avec Nextcloud',toolbar)}<div class="neos-module-body">${content}</div></section>`;
  }
  function groupwareEditor(type,record=null,prefillDay=null){
    if(record?.source==='deck'){
      if(record.deckBoardId&&record.deckCardId&&availableApps().has('deck'))void openDeckFromVirtual(record);
      else toast('Carte Deck en lecture seule : ouvre Deck pour la modifier.','error');
      return;
    }
    if(record?.writable===false){toast('Liste CalDAV en lecture seule','error');return;}
    const calendar=type==='event';const candidates=groupware.calendars.filter(c=>c.writable&&(calendar?c.events:c.tasks));
    if(!candidates.length){toast('Aucun calendrier autorisant les modifications','error');return;}
    const first=candidates.find(c=>c.url===record?.calendarUrl)||candidates[0];
    const now=new Date();now.setMinutes(0,0,0);now.setHours(now.getHours()+1);
    if(prefillDay){const picked=calFromKey(prefillDay);picked.setHours(now.getHours(),0,0,0);now.setTime(picked.getTime());}
    const start=dateInputLocal(now.toISOString()),end=dateInputLocal(new Date(now.getTime()+3600000).toISOString());
    popMode='groupware-edit';
    popHost.innerHTML=`<div class="neos-pop-layer" data-action="close-pop"><div class="neos-groupware-dialog neos-framed" role="dialog" aria-modal="true" aria-label="${calendar?'Nouvel événement':record?'Modifier la tâche':'Nouvelle tâche'}"><header><strong>${calendar?'Nouvel événement':record?'Modifier la tâche':'Nouvelle tâche'}</strong><button type="button" class="neos-iconbtn" data-action="close-pop" aria-label="Fermer">${icon('close',19)}</button></header><div class="neos-gw-form"><label>Titre<input data-gw-title maxlength="180" required value="${esc(record?.title||'')}" placeholder="${calendar?'Rendez-vous, réunion…':'À faire…'}"></label><label>Calendrier<select data-gw-calendar ${record?'disabled':''}>${candidates.map(c=>`<option value="${esc(c.url)}" ${c.url===first.url?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>${calendar?`<div class="neos-gw-form-grid"><label>Début<input data-gw-start type="datetime-local" value="${esc(start)}" required></label><label>Fin<input data-gw-end type="datetime-local" value="${esc(end)}" required></label></div><label>Lieu<input data-gw-location maxlength="180" placeholder="Facultatif"></label>`:`<label>Échéance<input data-gw-due type="date" value="${esc(record?.dueDate||record?.due?.slice(0,10)||'')}"></label><label class="neos-gw-checkline"><input type="checkbox" data-gw-done ${record?.done?'checked':''}> Tâche terminée</label>`}<label>Description<textarea data-gw-description rows="4" maxlength="12000" placeholder="Détails facultatifs">${esc(record?.description||'')}</textarea></label><p class="neos-gw-status" data-gw-error></p></div><footer><button type="button" class="neos-btn" data-action="close-pop">Annuler</button><button type="button" class="neos-btn neos-btn-primary" data-action="gw-save" ${groupware.busy?'disabled':''}>${icon('check',16)} Enregistrer</button></footer></div></div>`;
    popHost.dataset.gwType=type;popHost.dataset.gwRecord=record?.href||'';
    popHost.querySelector('[data-gw-title]')?.focus();animateLayerOpen(popHost,'.neos-groupware-dialog','y');
  }
  function gwReadForm(){
    const get=q=>popHost.querySelector(q);const type=popHost.dataset.gwType,href=popHost.dataset.gwRecord;
    return {type,href,title:get('[data-gw-title]')?.value?.trim()||'',calendarUrl:get('[data-gw-calendar]')?.value||'',start:get('[data-gw-start]')?.value||'',end:get('[data-gw-end]')?.value||'',due:get('[data-gw-due]')?.value||'',location:get('[data-gw-location]')?.value?.trim()||'',description:get('[data-gw-description]')?.value?.trim()||'',done:!!get('[data-gw-done]')?.checked};
  }
  function createIcs(fields,uid){
    const stamp=icsUtc(new Date()),common=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Neos//Nextcloud Workspace//FR',`BEGIN:${fields.type==='event'?'VEVENT':'VTODO'}`,`UID:${uid}`,`DTSTAMP:${stamp}`,`SUMMARY:${icsEscape(fields.title)}`];
    if(fields.type==='event')common.push(`DTSTART:${icsUtc(new Date(fields.start))}`,`DTEND:${icsUtc(new Date(fields.end))}`,...(fields.location?[`LOCATION:${icsEscape(fields.location)}`]:[]));
    else common.push(`STATUS:${fields.done?'COMPLETED':'NEEDS-ACTION'}`,...(fields.done?[`COMPLETED:${stamp}`,'PERCENT-COMPLETE:100']:[]),...(fields.due?[`DUE;VALUE=DATE:${icsDateOnly(fields.due)}`]:[]));
    if(fields.description)common.push(`DESCRIPTION:${icsEscape(fields.description)}`);
    common.push(`END:${fields.type==='event'?'VEVENT':'VTODO'}`,'END:VCALENDAR');return icsFold(common.join('\n'));
  }
  function taskIcsUpdates(fields){return {'SUMMARY':icsEscape(fields.title),'DESCRIPTION':fields.description?icsEscape(fields.description):null,'DUE':fields.due?icsDateOnly(fields.due):null,'STATUS':fields.done?'COMPLETED':'NEEDS-ACTION','COMPLETED':fields.done?icsUtc(new Date()):null,'PERCENT-COMPLETE':fields.done?'100':null};}
  async function saveGroupware(){
    if(groupware.busy)return;
    const fields=gwReadForm();const error=popHost.querySelector('[data-gw-error]');const fail=msg=>{if(error)error.textContent=msg;};
    if(!fields.title||fields.title.length>180){fail('Indique un titre (180 caractères maximum).');return;}
    if(fields.type==='event'&&(!fields.start||!fields.end||new Date(fields.end)<=new Date(fields.start))){fail('La fin doit être après le début.');return;}
    const selected=groupware.calendars.find(c=>c.url===fields.calendarUrl);
    const record=groupware.tasks.find(x=>x.href===fields.href);
    if(!record&&(!selected||!selected.writable)){fail('Choisis un calendrier modifiable.');return;}
    groupware.busy=true;const btn=popHost.querySelector('[data-action="gw-save"]');if(btn)btn.disabled=true;
    try{
      if(demo){
        if(record)Object.assign(record,{title:fields.title,description:fields.description,due:fields.due?new Date(fields.due+'T00:00:00').toISOString():'',done:fields.done});
        else if(fields.type==='event')groupware.events.push({href:'demo-'+Date.now(),title:fields.title,start:new Date(fields.start).toISOString(),end:new Date(fields.end).toISOString(),calendar:selected.name,calendarUrl:selected.url,location:fields.location,description:fields.description});
        else groupware.tasks.unshift({href:'demo-'+Date.now(),title:fields.title,due:fields.due?new Date(fields.due+'T00:00:00').toISOString():'',done:fields.done,calendar:selected.name,calendarUrl:selected.url,description:fields.description});
      }else if(record){
        await updateExistingTodo(record,taskIcsUpdates(fields));
      }else{
        const uuid=globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}`;
        const href=selected.url+encodeURIComponent(uuid)+'.ics';
        await caldavRequest('PUT',href,createIcs(fields,uuid+'@neos.local'),{'Content-Type':'text/calendar; charset=utf-8','If-None-Match':'*'});
      }
      groupware.busy=false;popMode='';popHost.replaceChildren();
      if(!demo)await loadGroupware(true);else render();
      toast('Enregistré dans Nextcloud','success');
      if(fields.type==='task'&&!demo)void load(true);
    }catch(e){groupware.busy=false;if(btn)btn.disabled=false;fail('Échec de l’enregistrement ('+e.message+'). Un conflit peut nécessiter une actualisation.');}
  }
  async function openDeckFromVirtual(record){
    const boardId=record.deckBoardId,cardId=record.deckCardId;
    try{
      await chooseWorkspace('deck');
      if(deckState.status!=='ready')await loadDeck(true);
      if(String(deckState.boardId)!==String(boardId)||deckState.status!=='ready')await loadDeckStacks(boardId);
      const stack=deckState.stacks.find(st=>(st.cards||[]).some(c=>String(c.id)===String(cardId)));
      if(!stack)throw Error('Carte introuvable dans les colonnes du tableau');
      await openDeckCard(stack.id,cardId);
    }catch(error){toast('Ouverture Deck impossible : '+error.message,'error');}
  }
  // Read FULL card details before PUT: Deck's update endpoint can reset omitted
  // description / dates. Verify the persisted `done` state with a fresh GET.
  async function writeDeckDone(boardId,cardId,wantDone,stackHint=null){
    if(demo){const card=(demo.deckStacks?.[boardId]||[]).flatMap(s=>s.cards||[]).find(c=>String(c.id)===String(cardId));if(!card)throw Error('Carte Deck démo introuvable');card.done=wantDone?new Date().toISOString():null;return card;}
    let stackId=stackHint;
    if(!stackId){
      const stacks=await deckRequest(`/boards/${encodeURIComponent(boardId)}/stacks`);
      const match=(Array.isArray(stacks)?stacks:[]).find(st=>(st.cards||[]).some(c=>String(c.id)===String(cardId)));
      if(!match)throw Error('Carte Deck introuvable dans le tableau. Actualise Tâches.');
      stackId=match.id;
    }
    const path=deckCardApiPath(boardId,stackId,cardId);
    const old=await deckRequest(path);
    if(String(old.id)!==String(cardId))throw Error('Identité de la carte Deck non confirmée');
    const desired=wantDone?new Date().toISOString():null;
    const payload=deckCardPayload(old,{title:old.title,description:old.description||'',duedate:old.duedate||null,done:desired,order:old.order});
    await deckRequest(path,{method:'PUT',body:JSON.stringify(payload)});
    const verified=await deckRequest(path);
    if(!!verified.done!==wantDone)throw Error('État Deck non confirmé après écriture : actualise la page.');
    return verified;
  }
  async function togglePlanningDeckDone(boardId,stackId,cardId){
    if(groupware.busy)return;
    const card=planningDeck.cards.find(c=>String(c.boardId)===String(boardId)&&String(c.cardId)===String(cardId));
    if(!card)return;
    groupware.busy=true;
    try{
      await writeDeckDone(boardId,cardId,!card.done,stackId);
      card.done=!card.done;
      render();toast(card.done?'Carte Deck terminée':'Carte Deck rouverte','success');
      if(!demo){void loadPlanningDeck(true);void loadGroupware(true);}
    }catch(error){toast('Modification Deck impossible : '+error.message,'error');}
    finally{groupware.busy=false;render();}
  }
  async function toggleTaskDone(href){
    if(groupware.busy)return;
    const record=groupware.tasks.find(x=>x.href===href);if(!record)return;
    if(record.writable===false&&record.source!=='deck'){toast('Cette liste CalDAV est en lecture seule.','error');return;}
    if(record.source==='deck'&&!record.deckCardId){toast('Impossible d’identifier la carte Deck : ouvre-la depuis Deck.','error');return;}
    groupware.busy=true;
    try{
      if(record.source==='deck'){
        await writeDeckDone(record.deckBoardId,record.deckCardId,!record.done);
        record.done=!record.done;groupware.busy=false;render();toast(record.done?'Carte Deck terminée':'Carte Deck rouverte','success');
        if(!demo){void loadGroupware(true);void loadPlanningDeck(true);}
        return;
      }
      if(demo){record.done=!record.done;groupware.busy=false;render();toast(record.done?'Tâche terminée':'Tâche rouverte','success');return;}
      await updateExistingTodo(record,{'STATUS':record.done?'NEEDS-ACTION':'COMPLETED','COMPLETED':record.done?null:icsUtc(new Date()),'PERCENT-COMPLETE':record.done?null:'100'});
      groupware.busy=false;await loadGroupware(true);toast('Tâche synchronisée','success');void load(true);
    }catch(error){groupware.busy=false;toast('Impossible de modifier cette tâche : '+error.message,'error');void loadGroupware(true);}
  }
  function planningItems(){
    const start=new Date();start.setHours(0,0,0,0);const end=new Date(start);end.setDate(end.getDate()+planningRange);
    const items=[];
    for(const event of groupware.events){
      const date=new Date(event.start);if(!Number.isFinite(date.getTime())||date<start||date>=end)continue;
      items.push({kind:'event',date,title:event.title,subtitle:event.calendar,href:event.href});
    }
    for(const task of groupware.tasks){
      if(task.source==='deck'||task.done||!task.due)continue;
      const date=new Date(task.due);if(!Number.isFinite(date.getTime())||date>=end)continue;
      // Include overdue tasks in the first day; never silently discard them.
      items.push({kind:'task',date:date<start?start:date,overdue:date<start,title:task.title,subtitle:task.calendar,href:task.href});
    }
    for(const card of planningDeck.cards){
      if(card.done||!card.due)continue;
      const date=new Date(card.due);if(!Number.isFinite(date.getTime())||date>=end)continue;
      items.push({kind:'deck',date:date<start?start:date,overdue:date<start,title:card.title,subtitle:card.boardTitle+' · '+card.stackTitle,boardId:card.boardId,stackId:card.stackId,cardId:card.cardId});
    }
    return items.filter(item=>planningKinds.has(item.kind)).sort((a,b)=>a.date-b.date).slice(0,200);
  }
  function planningModule(){
    const current=new Date();current.setHours(0,0,0,0);
    const activeTasks=groupware.tasks.filter(t=>t.source!=='deck'&&!t.done);
    const undatedTasks=activeTasks.filter(t=>!t.due);
    const overdueTasks=activeTasks.filter(t=>t.due&&new Date(t.due)<current);
    const activeDeck=planningDeck.cards.filter(c=>!c.done);
    const undatedDeck=activeDeck.filter(c=>!c.due);
    const overdueDeck=activeDeck.filter(c=>c.due&&new Date(c.due)<current);
    const counts={event:groupware.events.length,task:activeTasks.length,deck:activeDeck.length};
    const kindNames={event:'Agenda',task:'Tâche',deck:'Deck'};
    const entries=planningItems();let prev='';
    const timeline=entries.map(item=>{
      const key=calDayKey(item.date);const title=new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long'}).format(item.date);
      const header=key===prev?'':`<h3 class="neos-plan-day">${esc(title)}</h3>`;prev=key;
      const typeLabel=kindNames[item.kind];const action=item.kind==='event'?'plan-event':item.kind==='task'?'plan-task':'plan-deck';
      const attrs=item.kind==='deck'?`data-board-id="${esc(item.boardId)}" data-stack-id="${esc(item.stackId)}" data-card-id="${esc(item.cardId)}"`:`data-href="${esc(item.href)}"`;
      const hour=item.kind==='event'?new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(item.date):'Échéance';
      return `${header}<button type="button" class="neos-plan-item neos-plan-${item.kind}" data-action="${action}" ${attrs}><span class="neos-plan-kind">${icon(item.kind==='event'?'calendar':item.kind==='task'?'check':'kanban',18)}</span><span class="neos-plan-item-info"><strong>${esc(item.title)}</strong><small>${esc(item.subtitle||'')} · ${esc(typeLabel)}${item.overdue?' · En retard':''}</small></span><span class="neos-plan-time">${esc(hour)} ${icon('chevron',13)}</span></button>`;
    }).join('');
    const rangeButtons=[7,30,90].map(days=>`<button type="button" class="${planningRange===days?'is-active':''}" data-action="plan-range" data-days="${days}" aria-pressed="${planningRange===days}">${days} jours</button>`).join('');
    const kinds=['event','task','deck'].map(k=>`<button type="button" class="${planningKinds.has(k)?'is-active':''}" data-action="plan-kind" data-kind="${k}" aria-pressed="${planningKinds.has(k)}">${esc(kindNames[k])} <span>${counts[k]}</span></button>`).join('');
    const loading=groupware.status==='loading'||planningDeck.status==='loading';
    const warnings=[];
    if(groupware.status==='error')warnings.push(groupware.error);
    if(groupware.taskErrors.length)warnings.push('Certaines listes Tâches indisponibles.');
    if(planningDeck.status==='error')warnings.push('Deck : '+planningDeck.error);
    if(planningRange===90)warnings.push('Agenda : la vue 90 jours peut nécessiter une nouvelle synchronisation.');
    const actions=`<button type="button" class="neos-iconbtn" title="Actualiser le planning" data-action="plan-refresh">${icon('refresh',16)}</button><button type="button" class="neos-btn neos-btn-primary" data-action="workspace" data-workspace="calendar">${icon('calendar',16)} Agenda</button>`;
    const undatedTaskRows=planningKinds.has('task')?undatedTasks.slice(0,30).map(task=>`<div class="neos-plan-undated-row"><button type="button" class="neos-gw-check" data-action="gw-toggle-done" data-href="${esc(task.href)}" aria-label="Terminer ${esc(task.title)}" ${groupware.busy||task.writable===false?'disabled':''}>${icon('plus',15)}</button><button type="button" class="neos-plan-undated-open" data-action="plan-task" data-href="${esc(task.href)}"><strong>${esc(task.title)}</strong><small>${esc(task.calendar)} · CalDAV</small>${icon('chevron',14)}</button></div>`).join(''):'';
    const undatedDeckRows=planningKinds.has('deck')?undatedDeck.slice(0,30).map(card=>`<div class="neos-plan-undated-row neos-plan-undated-deck"><button type="button" class="neos-gw-check" data-action="plan-deck-toggle" data-board-id="${esc(card.boardId)}" data-stack-id="${esc(card.stackId)}" data-card-id="${esc(card.cardId)}" aria-label="Terminer la carte ${esc(card.title)}" ${groupware.busy?'disabled':''}>${icon('plus',15)}</button><button type="button" class="neos-plan-undated-open" data-action="plan-deck" data-board-id="${esc(card.boardId)}" data-stack-id="${esc(card.stackId)}" data-card-id="${esc(card.cardId)}"><strong>${esc(card.title)}</strong><small><span class="neos-source neos-source-deck">Deck</span> ${esc(card.boardTitle)} · ${esc(card.stackTitle)}</small>${icon('chevron',14)}</button></div>`).join(''):'';
    const noDue=undatedTaskRows||undatedDeckRows?`<section class="neos-plan-undated"><header><div><strong>Sans échéance</strong><span>${(planningKinds.has('task')?undatedTasks.length:0)+(planningKinds.has('deck')?undatedDeck.length:0)} éléments à organiser</span></div><button type="button" class="neos-btn neos-btn-small" data-action="workspace" data-workspace="tasks">Voir les tâches</button></header><div class="neos-plan-undated-list">${undatedTaskRows}${undatedDeckRows}</div>${undatedTasks.length>30||undatedDeck.length>30?'<small class="neos-gw-hint">D’autres éléments sont disponibles dans Tâches ou Deck.</small>':''}</section>`:'';
    const summary=`<div class="neos-plan-summary" aria-label="État du planning"><span>${icon('check',16)} <strong>${planningKinds.has('task')?activeTasks.length:0}</strong> tâches à faire</span><span>${icon('kanban',16)} <strong>${planningKinds.has('deck')?activeDeck.length:0}</strong> cartes Deck</span><span class="${overdueTasks.length+overdueDeck.length?'is-alert':''}">${icon('alert',16)} <strong>${(planningKinds.has('task')?overdueTasks.length:0)+(planningKinds.has('deck')?overdueDeck.length:0)}</strong> en retard</span><span>${icon('clock',16)} <strong>${(planningKinds.has('task')?undatedTasks.length:0)+(planningKinds.has('deck')?undatedDeck.length:0)}</strong> sans échéance</span></div>`;
    const body=`<div class="neos-plan-container"><div class="neos-plan-toolbar"><div class="neos-calendar-views">${rangeButtons}</div><div class="neos-calendar-views">${kinds}</div></div>${summary}${warnings.length?`<div class="neos-gw-warning">${esc(warnings.join(' '))}</div>`:''}${loading?'<p class="neos-plan-loading">Synchronisation en cours…</p>':''}${timeline?`<div class="neos-plan-timeline">${timeline}</div>`:'<div class="neos-empty">Aucun événement ni échéance datée dans cette période.</div>'}${noDue}<p class="neos-gw-hint">Données CalDAV accessibles au compte et échéances Deck de 8 tableaux maximum · événements récurrents complexes gérés dans Agenda.</p></div>`;
    return `<section class="neos-module neos-plan-module">${panelHeader('Planning','Une chronologie pour Agenda, Tâches et Deck',actions)}<div class="neos-module-body">${body}</div></section>`;
  }
  async function loadPlanningDeck(force=false){
    if(!force&&(planningDeck.status==='loading'||(planningDeck.status==='ready'&&Date.now()-planningDeck.updatedAt<300000)))return;
    if(!demo&&!availableApps().has('deck')){planningDeck.status='ready';planningDeck.cards=[];planningDeck.updatedAt=Date.now();return;}
    const gen=++planningDeck.generation;planningDeck.status='loading';planningDeck.error='';if(activeWorkspace==='planning')render();
    try{
      let raw=demo?demo.deckBoards:await deckRequest('/boards');if(raw?.ocs?.data)raw=raw.ocs.data;
      const boards=(Array.isArray(raw)?raw:[]).slice(0,8);const cards=[];
      for(const board of boards){
        let stacks=demo?(demo.deckStacks?.[board.id]||[]):await deckRequest(`/boards/${encodeURIComponent(board.id)}/stacks`);
        if(stacks?.ocs?.data)stacks=stacks.ocs.data;
        for(const stack of (Array.isArray(stacks)?stacks:[]))for(const card of (stack.cards||[])){
          cards.push({kind:'deck',title:card.title||'Sans titre',due:card.duedate||'',done:!!card.done,boardId:board.id,boardTitle:board.title||'Deck',stackId:stack.id,stackTitle:stack.title||'Colonne',cardId:card.id});
        }
        if(gen!==planningDeck.generation)return;
      }
      if(gen!==planningDeck.generation)return;
      planningDeck.cards=cards.slice(0,300);planningDeck.status='ready';planningDeck.updatedAt=Date.now();
    }catch(error){if(gen!==planningDeck.generation)return;planningDeck.status='error';planningDeck.error=error.message||'Indisponible';}
    if(activeWorkspace==='planning')render();
  }
  async function planningDeckOpen(boardId,stackId,cardId){
    await chooseWorkspace('deck');
    if(String(deckState.boardId)!==String(boardId)||deckState.status!=='ready')await loadDeckStacks(boardId);
    if(deckState.status==='ready')await openDeckCard(stackId,cardId);
  }
  function liteModule(id){
    if(id==='calendar')return groupwareModule('calendar');
    if(id==='tasks')return groupwareModule('tasks');
    if(id==='planning')return planningModule();
    return `<section class="neos-module">${panelHeader(appName(id),'Application externe',`<a class="neos-btn neos-btn-primary" href="${safeUrl(moduleLink(id))}">${icon('external',16)} Ouvrir ${esc(appName(id))}</a>`)}<div class="neos-module-body">${emptyModule('Module natif non intégré dans cette version.')}</div></section>`;
  }
  function currentModule(){switch(activeWorkspace){case 'photos':return photoModule();case 'notes':return noteModule();case 'deck':return deckModule();default:return liteModule(activeWorkspace);}}
  function moduleRequest(url,options={}){
    const token=csrfToken(); const headers={Accept:'application/json','OCS-APIRequest':'true','X-Requested-With':'XMLHttpRequest',...(token?{requesttoken:token}:{}),...(options.headers||{})};
    return fetch(url,{credentials:'same-origin',cache:'no-store',...options,headers}).then(async response=>{
      if(!response.ok)throw new Error(`HTTP ${response.status}`);
      return response.json();
    });
  }
  const notesUrl=()=>`${ncWebroot()}/index.php/apps/notes/api/v1/notes`;
  const deckUrl=()=>`${ncWebroot()}/index.php/apps/deck/api/v1.0`;
  function deckApiBases(){
    const generated=window.OC?.generateUrl?.('/apps/deck/api/v1.0');
    return [...new Set([
      ...(generated?[String(generated).replace(/\/$/,'')]:[]),
      deckUrl(),
      `${ncWebroot()}/ocs/v2.php/apps/deck/api/v1.0`,
    ])];
  }
  let deckResolvedBase='';
  async function deckRequest(path,options={}){
    if(demo)return null;
    const bases=deckResolvedBase?[deckResolvedBase]:deckApiBases();
    let last=null;
    for(const base of bases){
      try{
        const data=await moduleRequest(base+path,{
          ...options,
          headers:{'Content-Type':'application/json',...(options.headers||{})},
        });
        if(data?.ocs?.meta?.statuscode && ![100,200].includes(Number(data.ocs.meta.statuscode))){
          throw new Error(`HTTP ${data.ocs.meta.statuscode}`);
        }
        deckResolvedBase=base;
        return data?.ocs?.data??data;
      }catch(error){
        last=error;
        // A forbidden request or a server failure must not be masked by another route.
        if(!/HTTP 404(?:\D|$)/.test(String(error.message)))throw error;
      }
    }
    throw last||new Error('HTTP 404');
  }
  function deckUnavailableMessage(error){
    if(!availableApps().has('deck'))return 'Deck n’est pas activé pour cet utilisateur. Vérifie les applications installées dans Nextcloud.';
    if(/404/.test(String(error.message)))return 'API Deck introuvable (404). Vérifie la version de Deck et son activation dans Nextcloud. Les autres modules Neos restent disponibles.';
    return `Connexion à Deck impossible (${error.message}).`;
  }

  async function loadPhotos(force=false){
    if(!force&&photoState.status==='ready')return;
    const gen=++moduleGeneration;photoState.status='loading';render();
    try{const result=demo?demo.gallery:await api(root.dataset.galleryUrl);if(gen!==moduleGeneration)return;
      photoState.items=Array.isArray(result?.items)?result.items:[];photoState.partial=!!result?.partial;photoState.status='ready';photoState.error='';
    }catch(error){if(gen!==moduleGeneration)return;photoState.error=`Photos indisponibles (${error.message}).`;photoState.status='error';}
    if(activeWorkspace==='photos')render();
  }
  async function loadNotes(force=false){
    if(!force&&notesState.status==='ready')return;
    const gen=++moduleGeneration;notesState.status='loading';notesState.error='';render();
    try{
      let data;
      if(demo){data=demo.notes;notesState.source='demo';}
      else if(availableApps().has('notes')){
        try{data=await moduleRequest(notesUrl());notesState.source='api';}
        catch(error){
          if(!/HTTP 404(?:\D|$)/.test(String(error.message)))throw error;
          const result=await api(root.dataset.localNotesUrl);
          data=result.items;notesState.source='files';notesState.folder=result.folder||'Notes';
        }
      }else{
        const result=await api(root.dataset.localNotesUrl);
        data=result.items;notesState.source='files';notesState.folder=result.folder||'Notes';
      }
      if(gen!==moduleGeneration)return;
      notesState.items=Array.isArray(data)?data:[];notesState.status='ready';notesState.error='';
      if(notesState.items.length){const selected=notesState.items.find(n=>String(n.id)===String(notesState.selected))||notesState.items[0];notesState.selected=selected.id;notesState.draftTitle=selected.title||'';notesState.draftContent=selected.content||'';notesState.dirty=false;}
      else {notesState.selected=null;notesState.draftTitle='';notesState.draftContent='';notesState.dirty=false;}
    }catch(error){if(gen!==moduleGeneration)return;notesState.status='error';notesState.error=`Notes indisponibles (${error.message}). Vérifie le dossier Notes et ses permissions.`;}
    if(activeWorkspace==='notes')render();
  }
  async function loadDeck(force=false){
    if(!force&&deckState.status==='ready')return;
    if(force)deckResolvedBase='';
    if(!demo && !availableApps().has('deck')){deckState.status='error';deckState.error='Deck n’est pas activé pour cet utilisateur. Vérifie les applications Nextcloud.';if(activeWorkspace==='deck'||(activeWorkspace==='home'&&!settings.hidden.includes('deck')))render();return;}
    const gen=++moduleGeneration;deckState.status='loading';if(activeWorkspace==='deck'||(activeWorkspace==='home'&&!settings.hidden.includes('deck')))render();
    try{let data=demo?demo.deckBoards:await deckRequest('/boards');if(gen!==moduleGeneration)return;
      if(data?.ocs?.data)data=data.ocs.data;deckState.boards=Array.isArray(data)?data:[];
      deckState.boardId=deckState.boards.some(b=>String(b.id)===String(deckState.boardId))?deckState.boardId:deckState.boards[0]?.id||null;
      deckState.status='ready';deckState.error='';
      if(deckState.boardId){await loadDeckStacks(deckState.boardId,gen);return;}
    }catch(error){if(gen!==moduleGeneration)return;deckState.status='error';deckState.error=deckUnavailableMessage(error);} if(activeWorkspace==='deck'||(activeWorkspace==='home'&&!settings.hidden.includes('deck')))render();
  }
  async function loadDeckStacks(id, gen=++moduleGeneration){
    deckState.boardId=id;deckState.status='loading';if(activeWorkspace==='deck'||(activeWorkspace==='home'&&!settings.hidden.includes('deck')))render();
    try{let data=demo?(demo.deckStacks?.[id]||[]):await deckRequest(`/boards/${encodeURIComponent(id)}/stacks`);
      if(gen!==moduleGeneration)return;if(data?.ocs?.data)data=data.ocs.data;deckState.stacks=(Array.isArray(data)?data:[]).sort((a,b)=>Number(a.order||0)-Number(b.order||0));deckState.status='ready';deckState.error='';
    }catch(error){if(gen!==moduleGeneration)return;deckState.status='error';deckState.error=deckUnavailableMessage(error);} if(activeWorkspace==='deck'||(activeWorkspace==='home'&&!settings.hidden.includes('deck')))render();
  }
  function noteSelect(id){
    if(notesState.dirty&&!window.confirm('Abandonner les modifications non enregistrées ?'))return;
    const n=notesState.items.find(n=>String(n.id)===String(id));if(!n)return;
    notesState.selected=n.id;notesState.draftTitle=n.title||'';notesState.draftContent=n.content||'';notesState.dirty=false;noteView='edit';render();
  }
  async function noteCreate(){
    if(notesState.dirty&&!window.confirm('Abandonner les modifications non enregistrées ?'))return;
    const title=window.prompt('Titre de la nouvelle note','Nouvelle note');if(title===null||!title.trim())return;
    try{const n=demo?{id:Date.now(),title:title.trim(),content:'',category:'',etag:'demo',modified:Date.now()/1000}:
      notesState.source==='files' ? await api(root.dataset.createLocalNoteUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({title:title.trim(),content:''}).toString()}) :
      await moduleRequest(notesUrl(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.trim(),content:''})});
      notesState.items.unshift(n);notesState.selected=n.id;notesState.draftTitle=n.title||'';notesState.draftContent=n.content||'';notesState.dirty=false;notesState.status='ready';render();toast('Note créée','success');
    }catch(error){toast(`Création de note impossible : ${error.message}`,'error');}
  }
  async function noteSave(){
    const n=notesState.items.find(n=>String(n.id)===String(notesState.selected));if(!n||n.readonly)return;
    if(!notesState.draftTitle.trim()){toast('Titre requis','error');return;}
    try{const result=demo?{...n,title:notesState.draftTitle,content:notesState.draftContent,etag:'demo2'}:
      notesState.source==='files' ? await api(root.dataset.saveLocalNoteUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({id:String(n.id),title:notesState.draftTitle,content:notesState.draftContent,etag:n.etag||''}).toString()}) :
      await moduleRequest(notesUrl()+`/${encodeURIComponent(n.id)}`,{method:'PUT',headers:{'Content-Type':'application/json',...(n.etag?{'If-Match':n.etag}:{})},body:JSON.stringify({title:notesState.draftTitle,content:notesState.draftContent})});
      Object.assign(n,result);notesState.draftTitle=n.title||'';notesState.draftContent=n.content||'';notesState.dirty=false;render();toast('Note enregistrée','success');
    }catch(error){toast(error.message.includes('412')?'La note a changé ailleurs. Copie ton texte avant de recharger.':`Enregistrement impossible : ${error.message}`,'error');}
  }
  function deckDateFromInput(input,previous){
    if(!input)return null;
    if(previous&&String(previous).slice(0,10)===input)return previous;
    const date=new Date(`${input}T12:00:00`);
    if(!Number.isFinite(date.getTime()))throw new Error('Date invalide');
    return date.toISOString();
  }
  function deckCardPayload(card,{title,description,duedate,done,order}){
    return {
      title,description,type:card?.type||'plain',owner:card?.owner||root.dataset.currentUid||'',
      order:Number.isFinite(Number(order))?Number(order):999,
      duedate:duedate||null,archived:!!card?.archived,done:done||null,
    };
  }
  function deckNextOrder(stack){
    return Math.max(0,...(stack?.cards||[]).map(card=>Number(card.order)||0))+1;
  }
  function deckCardApiPath(boardId,stackId,cardId){
    return `/boards/${encodeURIComponent(boardId)}/stacks/${encodeURIComponent(stackId)}/cards/${encodeURIComponent(cardId)}`;
  }
  function deckCardPath(){
    return deckCardApiPath(deckCardEditor.boardId,deckCardEditor.stackId,deckCardEditor.cardId);
  }
  function deckCreateCard(stackId){
    if(deckMoveBusy||!deckState.boardId)return;
    Object.assign(deckCardEditor,{boardId:deckState.boardId,stackId,cardId:null,card:{title:'',description:'',duedate:null,done:null,type:'plain'},create:true,draftStackId:String(stackId),loading:false,loadFailed:false,saving:false,error:'',dirty:false});
    popMode='deck-card';renderDeckCardEditor();
  }
  async function openDeckCard(stackId,cardId){
    if(deckMoveBusy)return;
    const stack=deckState.stacks.find(x=>String(x.id)===String(stackId));
    const summary=stack?.cards?.find(x=>String(x.id)===String(cardId));if(!summary)return;
    Object.assign(deckCardEditor,{boardId:deckState.boardId,stackId,cardId,card:{...summary},create:false,draftStackId:String(stackId),loading:!demo,loadFailed:false,saving:false,error:'',dirty:false});
    popMode='deck-card';renderDeckCardEditor();
    if(demo)return;
    try{
      const details=await deckRequest(deckCardPath());
      if(popMode!=='deck-card'||String(deckCardEditor.cardId)!==String(cardId))return;
      deckCardEditor.card={...summary,...details};deckCardEditor.loading=false;renderDeckCardEditor();
    }catch(e){if(popMode!=='deck-card')return;deckCardEditor.loading=false;deckCardEditor.loadFailed=true;deckCardEditor.error=`Détails indisponibles (${e.message}). Pour protéger les autres champs, l'édition est bloquée.`;renderDeckCardEditor();}
  }
  function renderDeckCardEditor(){
    if(popMode!=='deck-card')return;
    const card=deckCardEditor.card||{};
    const busy=deckCardEditor.loading||deckCardEditor.saving||deckCardEditor.loadFailed;
    const isCreate=deckCardEditor.create;
    const stackOptions=deckState.stacks.map(stack=>`<option value="${esc(stack.id)}" ${String(stack.id)===String(deckCardEditor.draftStackId||deckCardEditor.stackId)?'selected':''}>${esc(stack.title)}</option>`).join('');
    const dateValue=card.duedate?String(card.duedate).slice(0,10):'';
    popHost.innerHTML=`<div class="neos-pop-layer" data-action="close-pop"><section class="neos-deck-dialog neos-framed" role="dialog" aria-modal="true" aria-label="${isCreate?'Créer une carte Deck':'Modifier une carte Deck'}"><header><div><small>DECK · ${isCreate?'NOUVELLE CARTE':'CARTE'}</small><h2>${isCreate?'Créer une carte':'Éditer la carte'}</h2></div><button type="button" class="neos-iconbtn" data-action="deck-card-close" aria-label="Fermer">${icon('close',18)}</button></header>${deckCardEditor.loading?'<div class="neos-module-loader"><span class="neos-spinner"></span>Chargement des détails…</div>':`<div class="neos-deck-fields">${deckCardEditor.error?`<p class="neos-deck-error" role="alert">${esc(deckCardEditor.error)}</p>`:''}<label>Titre<input data-deck-title maxlength="255" value="${esc(card.title||'')}" ${busy?'disabled':''} placeholder="Titre de la carte"></label><label>Colonne<select data-deck-stack ${busy?'disabled':''}>${stackOptions}</select></label><label>Description (Markdown)<textarea data-deck-description rows="6" maxlength="30000" ${busy?'disabled':''} placeholder="Détails, liens, étapes…">${esc(card.description||'')}</textarea></label><label>Échéance (facultative)<input data-deck-duedate type="date" value="${esc(dateValue)}" ${busy?'disabled':''}></label>${!isCreate?`<label class="neos-deck-check"><input data-deck-done type="checkbox" ${card.done?'checked':''} ${busy?'disabled':''}><span>Carte terminée</span></label>`:''}<small>Les changements sont enregistrés dans Deck. Les déplacements sont vérifiés après synchronisation.</small></div>`}<footer><button type="button" class="neos-btn" data-action="deck-card-close">Annuler</button><button type="button" class="neos-btn neos-btn-primary" data-action="deck-card-save" ${busy?'disabled':''}>${icon('check',16)} ${deckCardEditor.saving?'Enregistrement…':isCreate?'Créer la carte':'Enregistrer'}</button></footer></section></div>`;
    if(!busy)popHost.querySelector('[data-deck-title]')?.focus();
  }
  async function deckCheckStack(boardId,cardId,targetStackId){
    await loadDeckStacks(boardId);
    return !!deckState.stacks.find(stack=>String(stack.id)===String(targetStackId))?.cards?.some(card=>String(card.id)===String(cardId));
  }
  async function deckPersistMove({boardId,sourceStackId,targetStackId,cardId,details,payload}){
    // Deck API versions differ in how they handle the stackId in the route.
    // Never report a move as successful without refetching the target stack.
    const targetPath=deckCardApiPath(boardId,targetStackId,cardId);
    let firstError=null;
    try{
      await deckRequest(targetPath,{method:'PUT',body:JSON.stringify(payload)});
      if(await deckCheckStack(boardId,cardId,targetStackId))return;
    }catch(e){firstError=e;}
    // Fallback: documented reorder route using the *target* in both route/body.
    try{
      await deckRequest(`${targetPath}/reorder`,{method:'PUT',body:JSON.stringify({order:payload.order,stackId:Number(targetStackId)})});
      if(await deckCheckStack(boardId,cardId,targetStackId))return;
    }catch(e){firstError=e;}
    await loadDeckStacks(boardId);
    throw new Error(`déplacement non confirmé${firstError?` (${firstError.message})`:''}. Essaie depuis Deck natif.`);
  }
  async function moveDeckCard(sourceStackId,cardId,targetStackId){
    if(deckMoveBusy||String(sourceStackId)===String(targetStackId))return;
    const boardId=deckState.boardId;
    const source=deckState.stacks.find(x=>String(x.id)===String(sourceStackId));
    const target=deckState.stacks.find(x=>String(x.id)===String(targetStackId));
    const card=source?.cards?.find(x=>String(x.id)===String(cardId));
    if(!source||!target||!card||!boardId)return;
    deckMoveBusy=true;
    try{
      if(demo){source.cards=source.cards.filter(x=>String(x.id)!==String(cardId));target.cards.push({...card,stackId:target.id});render();}
      else{
        const details=await deckRequest(deckCardApiPath(boardId,sourceStackId,cardId));
        const payload=deckCardPayload(details,{title:details.title,description:details.description||'',duedate:details.duedate,done:details.done,order:deckNextOrder(target)});
        await deckPersistMove({boardId,sourceStackId,targetStackId,cardId,details,payload});
      }
      if(planningDeck.status!=='idle')void loadPlanningDeck(true);
      toast(`Carte déplacée vers « ${target.title} »`,'success');
    }catch(e){toast(`Déplacement impossible : ${e.message}`,'error');if(!demo)void loadDeckStacks(boardId);}
    finally{deckMoveBusy=false;deckDrag=null;}
  }
  async function saveDeckCard(){
    if(deckCardEditor.loading||deckCardEditor.saving||deckCardEditor.loadFailed)return;
    const title=popHost.querySelector('[data-deck-title]')?.value.trim()||'';
    const description=popHost.querySelector('[data-deck-description]')?.value||'';
    const targetStackId=popHost.querySelector('[data-deck-stack]')?.value||String(deckCardEditor.stackId);
    const duedateInput=popHost.querySelector('[data-deck-duedate]')?.value||'';
    const doneInput=popHost.querySelector('[data-deck-done]')?.checked||false;
    if(!title){toast('Titre requis','error');return;}
    const target=deckState.stacks.find(x=>String(x.id)===String(targetStackId));
    if(!target){toast('Colonne introuvable','error');return;}
    const original=deckCardEditor.card||{};
    const isCreate=deckCardEditor.create;
    const boardId=deckCardEditor.boardId;
    const sourceStackId=deckCardEditor.stackId;
    deckCardEditor.saving=true;deckCardEditor.error='';
    try{
      const duedate=deckDateFromInput(duedateInput,original.duedate);
      const done=isCreate?null:doneInput?(original.done||new Date().toISOString()):null;
      const moved=!isCreate&&String(sourceStackId)!==String(targetStackId);
      const payload=deckCardPayload(original,{title,description,duedate,done,order:moved?deckNextOrder(target):original.order||999});
      if(isCreate){
        if(demo){const card={id:Date.now(),...payload,stackId:Number(targetStackId)};target.cards.push(card);}
        else await deckRequest(`/boards/${encodeURIComponent(boardId)}/stacks/${encodeURIComponent(targetStackId)}/cards`,{method:'POST',body:JSON.stringify({title,description,type:'plain',order:deckNextOrder(target),duedate})});
      }else if(moved){
        if(demo){const source=deckState.stacks.find(x=>String(x.id)===String(sourceStackId));source.cards=source.cards.filter(x=>String(x.id)!==String(deckCardEditor.cardId));target.cards.push({...original,...payload,stackId:Number(targetStackId)});}
        else await deckPersistMove({boardId,sourceStackId,targetStackId,cardId:deckCardEditor.cardId,details:original,payload});
      }else{
        if(!demo)await deckRequest(deckCardPath(),{method:'PUT',body:JSON.stringify(payload)});
        const stack=deckState.stacks.find(x=>String(x.id)===String(sourceStackId));
        const card=stack?.cards?.find(x=>String(x.id)===String(deckCardEditor.cardId));if(card)Object.assign(card,payload);
      }
      deckCardEditor.saving=false;popMode='';popHost.replaceChildren();
      if(!demo)await loadDeckStacks(boardId);else render();
      if(planningDeck.status!=='idle')void loadPlanningDeck(true);
      toast(isCreate?'Carte créée':moved?'Carte déplacée':'Carte mise à jour','success');
    }catch(e){
      deckCardEditor.saving=false;deckCardEditor.draftStackId=String(targetStackId);
      deckCardEditor.card={...original,title,description,duedate:duedateInput?deckDateFromInput(duedateInput,original.duedate):null,done:doneInput?(original.done||new Date().toISOString()):null};
      deckCardEditor.error=`Enregistrement refusé (${e.message}). Vérifie les permissions Deck.`;renderDeckCardEditor();
    }
  }

  async function chooseWorkspace(id){
    if(!installedTabs().includes(id))return;
    if(id===activeWorkspace)return;
    if(notesState.dirty&&activeWorkspace==='notes'&&!window.confirm('Abandonner les modifications non enregistrées ?'))return;
    const old=activeWorkspace;
    const sequence=++transitionSequence;
    const direction=installedTabs().indexOf(id)>=installedTabs().indexOf(old)?1:-1;
    const stage=surface.querySelector('#neos-workspace-stage');
    workspaceScroll.set(old,root.scrollTop);
    if(motionEnabled()&&stage?.animate){
      try{
        const exit=stage.animate([{opacity:1,transform:'translate3d(0,0,0)',filter:'blur(0)'},{opacity:.07,transform:`translate3d(${-direction*24}px,0,0)`,filter:'blur(2px)'}],{duration:Math.round(160*motionFactor()),easing:'cubic-bezier(.4,0,1,1)',fill:'forwards'});
        await exit.finished;
      }catch(error){ /* interrupted by a newer navigation */ }
    }
    if(sequence!==transitionSequence)return;
    ++moduleGeneration;
    activeWorkspace=id;
    render();
    root.scrollTop=workspaceScroll.get(id)||0;
    surface.querySelectorAll('[data-action="workspace"]').forEach(el=>{
      if(el.dataset.workspace===id)el.setAttribute('aria-current','page');
    });
    if(motionEnabled()){
      const incoming=surface.querySelector('#neos-workspace-stage');
      incoming?.animate?.([{opacity:0,transform:`translate3d(${direction*28}px,0,0)`,filter:'blur(3px)'},{opacity:1,transform:'translate3d(0,0,0)',filter:'blur(0)'}],{duration:Math.round(410*motionFactor()),easing:'cubic-bezier(.16,1,.3,1)'});
      animateIn(surface.querySelectorAll('#neos-workspace-stage .neos-card, #neos-workspace-stage .neos-module'),40,65);
    }
    if(id==='photos'&&photoState.status==='idle')void loadPhotos();
    if(id==='notes'&&notesState.status==='idle')void loadNotes();
    if(id==='deck'&&deckState.status==='idle')void loadDeck();
    if((id==='calendar'||id==='tasks'||id==='planning')&&groupware.status==='idle')void loadGroupware();
    if(id==='planning')void loadPlanningDeck();
  }
  function photoLightbox(index){
    const img=photoState.items[index];if(!img)return;
    popMode='photo';popHost.innerHTML=`<div class="neos-fullscreen-overlay" data-action="close-pop"><div class="neos-photo-lightbox"><header><strong>${esc(img.name)}</strong><button class="neos-iconbtn" data-action="close-pop" aria-label="Fermer">${icon('close',18)}</button></header><div><img src="${safeUrl(img.previewUrl||img.davUrl)}" alt="${esc(img.name)}"></div><footer><span>${esc(img.folder||'')}</span><a href="${safeUrl(img.url||moduleLink('photos'))}" class="neos-btn">${icon('external',15)} Fichiers</a></footer></div></div>`;
    animateLayerOpen(popHost,'.neos-photo-lightbox','y');
  }

  function summaryWidget() {
    const countFiles = number(browser.items.filter(x => x.kind === 'file').length);
    const countFolders = number(browser.items.filter(x => x.kind === 'folder').length);
    const appCount = number((overview?.shortcuts || []).length);
    return box('summary', `<div class="neos-metric-grid"><div class="neos-metric"><strong>${countFiles}</strong><span>fichiers</span></div><div class="neos-metric"><strong>${countFolders}</strong><span>dossiers</span></div><div class="neos-metric"><strong>${appCount}</strong><span>apps</span></div></div>`, `${browser.path}`);
  }

  function homeExplorerWidget(){
    const recent=(overview?.files||[]).slice(0,5);
    const pins=(settings.pins||[]).slice(0,4);
    const content=`<div class="neos-home-files-head"><div class="neos-home-file-stats"><strong>${number(browser.total)}</strong><span>éléments dans ${esc(browser.path)}</span></div><button type="button" class="neos-btn neos-btn-primary" data-action="workspace" data-workspace="files">${icon('arrow',16)} Ouvrir Fichiers</button></div>${pins.length?`<div class="neos-home-pins">${pins.map(path=>`<button type="button" data-action="home-open-folder" data-path="${esc(path)}">${icon('folder',15)} ${esc(path.split('/').pop())}</button>`).join('')}</div>`:''}<div class="neos-home-files-list">${recent.length?recent.map(f=>`<button type="button" class="neos-home-file" data-action="home-open-recent" data-folder="${esc(f.folder||'/')}" data-name="${esc(f.name)}"><span>${icon(String(f.mime||'').startsWith('image/')?'image':'file',17)}</span><strong title="${esc(f.name)}">${esc(f.name)}</strong><small>${humanSize(f.size)}</small>${icon('chevron',14)}</button>`).join(''):'<div class="neos-empty">Aucun fichier récent.</div>'}</div>`;
    return box('explorer',content,'Raccourcis');
  }

  function storageWidget(){
    const data=overview?.storage||{};
    const knownQuota=data.total!=null && number(data.total)>0;
    const pct=knownQuota?Math.max(0,Math.min(100,number(data.percent))):null;
    const ringProgress=pct==null?58:pct;
    const used=humanSize(data.used);
    return box('storage', `<div class="neos-storage-console">
      <div class="neos-storage-values"><span class="neos-data-label">ESPACE UTILISÉ</span><div class="neos-stat-main">${used}</div><p class="neos-subtle">${knownQuota?`Sur ${humanSize(data.total)}`:'Quota illimité'}</p></div>
      <div class="neos-storage-orb" role="img" aria-label="${knownQuota?`${pct}% du quota utilisé`:'Espace sans limite définie'}"><svg viewBox="0 0 116 116" aria-hidden="true"><circle cx="58" cy="58" r="43" class="neos-orb-track"/><circle cx="58" cy="58" r="43" class="neos-orb-progress" style="--neos-circle-progress:${ringProgress};"/><circle cx="58" cy="58" r="28" class="neos-orb-inner"/><g class="neos-orb-dots"><circle cx="58" cy="10" r="2.2"/><circle cx="106" cy="58" r="2.2"/><circle cx="58" cy="106" r="2.2"/><circle cx="10" cy="58" r="2.2"/></g></svg><span class="neos-orb-value">${pct==null?'∞':`${Math.round(pct)}%`}</span></div>
    </div><div class="neos-storage-track"><div class="neos-meter ${pct==null?'neos-meter-unlimited':''}" role="progressbar" aria-label="Stockage utilisé" ${knownQuota?`aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"`:''}><span style="width:${pct==null?100:pct}%"></span></div><span class="neos-storage-track-hint">${knownQuota?'QUOTA':'SANS LIMITE'}</span></div>${data.volume&&number(data.volume.total)>0?`<div class="neos-storage-volume" title="${esc(data.volume.note||'Capacité du système de fichiers, pas capacité physique brute du NAS')}"><div class="neos-volume-heading"><strong>Volume de données</strong><span>${humanSize(data.volume.free)} libres</span></div><div class="neos-volume-progress" role="progressbar" aria-label="Occupation du volume Nextcloud" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.max(0,Math.min(100,number(data.volume.percent)))}"><span style="width:${Math.max(0,Math.min(100,number(data.volume.percent)))}%"></span></div><small>${humanSize(data.volume.used)} utilisés / ${humanSize(data.volume.total)} · système de fichiers</small></div>`:''}`);
  }
  function shortcutsWidget(){
    return box('shortcuts',hubGrid(true));
  }
  function clockWidget(){
    const tickMarks=Array.from({length:12},(_,i)=>`<line x1="62" y1="10" x2="62" y2="${i%3===0?18:15}" transform="rotate(${i*30} 62 62)"/>`).join('');
    return box('clock', `<div class="neos-holo-clock"><div class="neos-clock-details"><span class="neos-data-label"><i class="neos-clock-live"></i> HEURE LOCALE</span><div class="neos-clock" data-clock>--:--</div><div class="neos-subtle" data-clock-date>—</div></div><div class="neos-clock-dial"><div class="neos-clock-orbit"></div><svg viewBox="0 0 124 124" aria-hidden="true"><circle cx="62" cy="62" r="52" class="neos-dial-track"/><circle cx="62" cy="62" r="42" class="neos-dial-grid"/><g class="neos-dial-ticks">${tickMarks}</g><line class="neos-clock-hour-hand" data-holo-hour x1="62" y1="62" x2="62" y2="37"/><line class="neos-clock-minute-hand" data-holo-minute x1="62" y1="62" x2="62" y2="24"/><circle cx="62" cy="62" r="4" class="neos-clock-center"/></svg><span class="neos-clock-orbit-dot"></span></div></div>`);
  }
  function recentWidget(){
    const list = overview?.files || [];
    return box('files', list.length ? `<div class="neos-list">${list.map(f => `<button type="button" class="neos-item" data-action="preview-dav" data-url="${safeUrl(f.davUrl || '')}" data-name="${esc(f.name)}" data-mime="${esc(f.mime || '')}" data-size="${Number(f.size)||0}" data-path="${esc(f.path||'')}"><span class="neos-item-icon">${icon(String(f.mime||'').startsWith('image/') ? 'image' : 'file',16)}</span><span class="neos-item-title"><strong>${esc(f.name)}</strong><small>${esc(f.folder)} · ${ago(f.mtime)}</small></span><span class="neos-item-meta">${humanSize(f.size)}</span></button>`).join('')}</div>` : '<div class="neos-empty">Aucun fichier récent.</div>');
  }
  function calendarWidget(){
    const list = overview?.calendar || [];
    return box('calendar', list.length ? `<div class="neos-list">${list.map(x => `<div class="neos-item"><span class="neos-event-bar" style="background:${safeColor(x.color)}"></span><span class="neos-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.calendar)}</small></span><span class="neos-item-meta">${fmtTime(x.start)}</span></div>`).join('')}</div>` : '<div class="neos-empty">Aucun événement.</div>', '30 j');
  }
  function tasksWidget(){
    const list = overview?.tasks || [];
    return box('tasks', list.length ? `<div class="neos-list">${list.map(x => `<div class="neos-item"><span class="neos-item-icon">${icon('check',16)}</span><span class="neos-item-title"><strong>${esc(x.title)}</strong><small>${x.due ? fmtTime(x.due) : 'Sans échéance'}</small></span></div>`).join('')}</div>` : '<div class="neos-empty">Aucune tâche ouverte.</div>');
  }
  function linksWidget(){
    const list = settings.links || [];
    return box('links', list.length ? `<div class="neos-link-grid">${list.map(x => `<a href="${safeUrl(x.url)}" class="neos-link-card">${icon('link',15)}<span>${esc(x.title)}</span>${icon('open',14)}</a>`).join('')}</div>` : '<div class="neos-empty">Aucun lien.</div>');
  }
  function deckWidget(){
    let content='';
    const installed=availableApps().has('deck');
    if(!installed){content=`<div class="neos-widget-state">${icon('kanban',24)}<span>Deck n'est pas activé pour ce compte.</span></div>`;}
    else if(deckState.status==='idle'||deckState.status==='loading'){
      content='<div class="neos-widget-state"><span class="neos-spinner"></span><span>Chargement des tableaux…</span></div>';
    }else if(deckState.status==='error'){
      content=`<div class="neos-widget-state">${icon('alert',21)}<span>${esc(deckState.error||'Deck indisponible')}</span></div>`;
    }else{
      const boards=(deckState.boards||[]);
      content=boards.length?`<div class="neos-deck-widget-boards">${boards.slice(0,6).map((b,i)=>`<button type="button" class="neos-deck-board-row" data-action="deck-widget-open" data-board-id="${esc(b.id)}"><span class="neos-deck-board-symbol" style="--board-color:${['#39c9ff','#b88dff','#33dbb5','#f4b85b'][i%4]}">${icon('kanban',18)}</span><strong>${esc(b.title||'Tableau')}</strong><span>${icon('chevron',15)}</span></button>`).join('')}</div>`:'<div class="neos-widget-state">Aucun tableau disponible.</div>';
    }
    return box('deck',`${content}<div class="neos-deck-widget-footer"><button type="button" class="neos-btn" data-action="workspace" data-workspace="deck">${icon('arrow',16)} Ouvrir Deck</button></div>`,`${(deckState.boards||[]).length} tableaux`);
  }

  function notesWidget(){
    return box('notes', `<textarea id="neos-note" class="neos-note" placeholder="" spellcheck="false">${esc(settings.notes || '')}</textarea><div class="neos-note-tools"><button type="button" data-action="save-note" class="neos-btn">${icon('check',16)} Enregistrer</button></div>`);
  }

  function visibleFileEntries(){
    const term=browser.query.trim().toLocaleLowerCase('fr-FR');
    let items=browser.items.filter(x=>(browser.type==='all'||x.kind===browser.type)&&(!term||String(x.name).toLocaleLowerCase('fr-FR').includes(term)));
    if(browser.sort==='recent')items=[...items].sort((a,b)=>number(b.mtime)-number(a.mtime));
    else if(browser.sort==='size')items=[...items].sort((a,b)=>number(b.size)-number(a.size));
    else items=[...items].sort((a,b)=>(a.kind==='folder'?0:1)-(b.kind==='folder'?0:1)||String(a.name).localeCompare(String(b.name),'fr',{numeric:true}));
    return items;
  }
  function selectedEntries(){return browser.items.filter(item=>fileSelection.has(item.path));}
  function selectionToolbar(){
    const count=fileSelection.size;
    const all=visibleFileEntries();
    const clipboardCount=fileClipboard.entries.length;
    const currentClip=clipboardCount&&fileClipboard.mode==='cut'?'déplacer':'copier';
    return `<div class="neos-files-selectionbar ${count?'has-selection':''} ${fileBusy?'is-busy':''}" role="toolbar" aria-label="Actions groupées sur les fichiers">
      <div class="neos-selection-count"><span class="neos-selection-dot"></span><strong>${fileBusy?'Opération en cours…':count?`${count} sélectionné${count>1?'s':''}`:'Sélection multiple'}</strong><small>${browser.truncated?'Dossier partiellement affiché':`${all.length} éléments visibles`}</small></div>
      <div class="neos-selection-actions">
        <button type="button" class="neos-btn neos-btn-small" data-action="files-select-all" ${!all.length||fileBusy?'disabled':''}>${icon('check',15)} ${count?(all.every(x=>fileSelection.has(x.path))?'Tout désélectionner':'Tout sélectionner'):'Sélectionner'}</button>
        ${count?`<button type="button" class="neos-btn neos-btn-small" data-action="files-copy" ${fileBusy?'disabled':''}>${icon('copy',15)} Copier</button><button type="button" class="neos-btn neos-btn-small" data-action="files-cut" ${fileBusy?'disabled':''}>${icon('arrow',15)} Déplacer</button><button type="button" class="neos-btn neos-btn-small" data-action="files-duplicate" ${fileBusy?'disabled':''}>${icon('copy',15)} Dupliquer</button><button type="button" class="neos-btn neos-btn-small neos-target-action" data-action="files-copy-to" ${fileBusy?'disabled':''}>${icon('folder',15)} Copier vers…</button><button type="button" class="neos-btn neos-btn-small neos-target-action" data-action="files-move-to" ${fileBusy?'disabled':''}>${icon('arrow',15)} Déplacer vers…</button><button type="button" class="neos-btn neos-btn-small neos-danger-soft" data-action="files-delete" ${fileBusy?'disabled':''}>${icon('trash',15)} Supprimer</button><button type="button" class="neos-iconbtn" data-action="files-clear" title="Désélectionner" aria-label="Désélectionner">${icon('close',16)}</button>`:''}
        ${clipboardCount?`<button type="button" class="neos-btn neos-btn-small neos-clipboard-paste" data-action="files-paste" ${fileBusy?'disabled':''}>${icon('check',15)} Coller (${clipboardCount} · ${currentClip})</button><button type="button" class="neos-iconbtn" data-action="files-cancel-paste" title="Vider le presse-papiers Neos" aria-label="Vider le presse-papiers">${icon('close',16)}</button>`:''}
      </div>
    </div>`;
  }
  function refreshSelectionDisplay(){
    const results=surface.querySelector('#neos-file-results');
    if(results)results.innerHTML=browserItems();
    const toolbar=surface.querySelector('[data-selection-toolbar]');
    if(toolbar)toolbar.innerHTML=selectionToolbar();
  }
  function toggleFileSelection(path,shift=false,force=null){
    if(fileBusy)return;
    const entries=visibleFileEntries(), current=entries.findIndex(x=>x.path===path);
    if(current<0)return;
    if(shift&&fileAnchorPath){
      const anchor=entries.findIndex(x=>x.path===fileAnchorPath);
      if(anchor>=0){const a=Math.min(anchor,current),b=Math.max(anchor,current);entries.slice(a,b+1).forEach(x=>fileSelection.add(x.path));}
      else fileSelection.add(path);
    }else{
      if(force===true)fileSelection.add(path);
      else if(force===false)fileSelection.delete(path);
      else if(fileSelection.has(path))fileSelection.delete(path);
      else fileSelection.add(path);
    }
    fileAnchorPath=path;
    refreshSelectionDisplay();
  }
  function selectAllFiles(){
    if(fileBusy)return;
    const entries=visibleFileEntries();
    const allSelected=entries.every(x=>fileSelection.has(x.path));
    entries.forEach(x=>allSelected?fileSelection.delete(x.path):fileSelection.add(x.path));
    fileAnchorPath=entries.at(-1)?.path||'';
    refreshSelectionDisplay();
  }
  function browserItems() {
    if(browser.loading)return '<div class="neos-browser-state"><span class="neos-spinner"></span></div>';
    if(browser.error)return `<div class="neos-browser-state is-error">${icon('alert',20)}<strong>${esc(browser.error)}</strong></div>`;
    const items=visibleFileEntries();
    if(!items.length)return '<div class="neos-browser-state neos-drop-zone" data-drop-folder="'+esc(browser.path)+'">Aucun élément dans ce dossier · dépose des fichiers ici</div>';
    return `<div class="neos-file-list ${browser.view==='grid'?'is-grid':''}">${items.map(item=>{
      const pinned=(settings.pins||[]).includes(item.path);
      const active=preview.entry?.path===item.path;
      const selected=fileSelection.has(item.path);
      const title=item.kind==='folder'?`Ouvrir ${item.name}`:`Prévisualiser ${item.name}`;
      const action=item.kind==='folder'?'browse-path':'select-entry';
      const thumb=item.kind==='file'&&isImage(item)&&item.previewUrl?`<img class="neos-thumb" loading="lazy" alt="" src="${safeUrl(item.previewUrl)}">`:'';
      return `<div class="neos-file-row ${active?'is-active':''} ${selected?'is-selected':''} ${item.kind==='folder'?'is-folder':'is-file'}" draggable="${!fileBusy}" data-file-row="${esc(item.path)}" ${item.kind==='folder'?`data-drop-folder="${esc(item.path)}"`:''}>
        <label class="neos-file-select" title="Sélectionner ${esc(item.name)}"><input type="checkbox" data-file-checkbox data-path="${esc(item.path)}" aria-label="Sélectionner ${esc(item.name)}" ${selected?'checked':''} ${fileBusy?'disabled':''}><span></span></label>
        <button type="button" class="neos-file-main" data-action="${action}" data-path="${esc(item.path)}" title="${esc(title)}">
          <span class="neos-file-symbol">${thumb||icon(item.kind==='folder'?'folder':isImage(item)?'image':isPdf(item)?'file':isOffice(item)?'sheet':'file',18)}</span>
          <span class="neos-file-label"><strong>${esc(item.name)}</strong><small>${item.kind==='folder'?'Dossier':esc(item.mime||'Fichier')} · ${ago(item.mtime)}</small></span>
          <span class="neos-file-size">${item.kind==='folder'?'—':humanSize(item.size)}</span>
        </button>
        <div class="neos-file-actions">
          <button type="button" class="neos-iconbtn neos-favorite-toggle ${favoritePaths.has(item.path)?'is-on':''}" data-action="toggle-favorite" data-path="${esc(item.path)}" aria-pressed="${favoritePaths.has(item.path)}" title="${favoritePaths.has(item.path)?'Retirer des favoris Nextcloud':'Ajouter aux favoris Nextcloud'}" aria-label="${favoritePaths.has(item.path)?'Retirer des favoris':'Ajouter aux favoris'} : ${esc(item.name)}">${icon('star',15)}</button>
          ${item.kind==='folder'?`<button type="button" class="neos-iconbtn ${pinned?'is-on':''}" data-action="pin-folder" data-path="${esc(item.path)}" title="${pinned?'Retirer du raccourci Accueil':'Épingler à l’Accueil'}" aria-label="${pinned?'Retirer de l’Accueil':'Épingler à l’Accueil'} : ${esc(item.name)}">${icon('home',15)}</button>`:''}
          <button type="button" class="neos-iconbtn" data-action="file-menu" data-path="${esc(item.path)}" title="Actions" aria-label="Actions sur ${esc(item.name)}">${icon('more',16)}</button>
        </div>
      </div>`;
    }).join('')}</div>`;
  }

  function inlinePdfUrl(entry){
    if(!entry?.path||!root.dataset.inlinePdfUrl)return '';
    const url=new URL(root.dataset.inlinePdfUrl,window.location.href);
    url.searchParams.set('path',entry.path);
    return url.pathname+url.search;
  }
  function previewPane() {
    const entry=preview.entry;
    const hasFile=entry?.kind==='file';
    const actions=entry?`<div class="neos-preview-actions">
      ${hasFile&&entry.davUrl?`<button type="button" class="neos-iconbtn" data-action="download-selected" title="Télécharger" aria-label="Télécharger">${icon('download',16)}</button><button type="button" class="neos-iconbtn" data-action="share-selected" title="Créer un lien public" aria-label="Créer un lien public">${icon('link',16)}</button><button type="button" class="neos-iconbtn" data-action="copy-selected-link" title="Copier le lien interne" aria-label="Copier le lien interne">${icon('copy',16)}</button>`:''}
      ${hasFile&&isMarkdown(entry)?`<button type="button" class="neos-iconbtn" data-action="preview-markdown" title="${markdownPreview?'Voir le code Markdown':'Voir le rendu Markdown'}" aria-label="Changer la vue Markdown">${icon('note',16)}</button>`:''}
      ${hasFile?`<button type="button" class="neos-iconbtn" data-action="expand-preview" title="Agrandir" aria-label="Agrandir l'aperçu">${icon('expand',16)}</button>`:''}
      ${entry.url?`<a class="neos-iconbtn" href="${safeUrl(entry.url)}" title="Ouvrir dans Fichiers">${icon('external',16)}</a>`:''}
    </div>`:'';
    const head=entry?`<div class="neos-preview-head"><div class="neos-preview-title"><small>APERÇU</small><strong title="${esc(entry.name)}">${esc(entry.name)}</strong><span>${esc(entry.mime||'Fichier')} ${entry.kind==='file'?'· '+humanSize(entry.size):''}</span></div>${actions}</div>`:`<div class="neos-preview-head"><div class="neos-preview-title"><small>APERÇU</small><strong>—</strong></div></div>`;
    let body=`<div class="neos-preview-empty"><span class="neos-empty-symbol">${icon('file',32)}</span><span>Aperçu du fichier</span><small>Sélectionner un élément dans la liste</small></div>`;
    if(preview.status==='loading')body=`<div class="neos-preview-loading"><span class="neos-spinner"></span></div>`;
    else if(preview.status==='error')body=`<div class="neos-preview-empty">${icon('alert',22)}<span>${esc(preview.error||'Prévisualisation indisponible')}</span></div>`;
    else if(entry){
      if(entry.kind==='folder')body=`<div class="neos-folder-preview"><div class="neos-folder-emblem">${icon('folder',42)}</div><div class="neos-preview-meta"><span>Chemin</span><code>${esc(entry.path)}</code></div></div>`;
      else if(preview.mode==='image')body=`<div class="neos-image-preview"><img src="${safeUrl(entry.previewUrl||entry.davUrl||'')}" alt="${esc(entry.name)}" loading="eager" data-dav-fallback="${safeUrl(entry.davUrl||'')}"></div>`;
      else if(preview.mode==='text')body=isMarkdown(entry)&&markdownPreview?`<article class="neos-markdown-preview">${markdownHtml(preview.text)}</article>`:`<pre class="neos-text-preview">${esc(preview.text)}</pre>`;
      else if(preview.mode==='audio')body=`<div class="neos-media-preview"><span class="neos-media-emblem">${icon('play',38)}</span><strong>${esc(entry.name)}</strong><audio controls preload="metadata" src="${safeUrl(entry.davUrl)}">Ton navigateur ne peut pas lire ce fichier audio.</audio><small>La lecture dépend du format et du navigateur.</small></div>`;
      else if(preview.mode==='video')body=`<div class="neos-media-preview neos-video-preview"><video controls playsinline preload="metadata" src="${safeUrl(entry.davUrl)}">Ton navigateur ne peut pas lire cette vidéo.</video><small>Lecture intégrée si le codec est pris en charge.</small></div>`;
      else if(preview.mode==='table')body=`<div class="neos-table-preview"><table>${preview.rows.map((row,i)=>`<tr>${row.map(cell=>i===0?`<th>${esc(cell)}</th>`:`<td>${esc(cell)}</td>`).join('')}</tr>`).join('')}</table></div>`;
      else if(preview.mode==='pdf'){
        const src=inlinePdfUrl(entry);
        body=src?`<div class="neos-pdf-container"><iframe class="neos-pdf-preview" title="PDF ${esc(entry.name)}" referrerpolicy="same-origin" loading="lazy" src="${safeUrl(src)}"></iframe><div class="neos-pdf-fallback"><span>Si l’aperçu ne charge pas :</span><a href="${safeUrl(src)}" target="_blank" rel="noopener noreferrer">Ouvrir le PDF</a>${entry.url?`<a href="${safeUrl(entry.url)}">Ouvrir dans Fichiers</a>`:''}</div></div>`:
          `<div class="neos-preview-empty">Aperçu PDF indisponible dans cette vue. Ouvre le fichier depuis l'explorateur.</div>`;
      }
      else if(preview.mode==='office')body=`<div class="neos-office-preview"><div class="neos-office-illustration">${icon('sheet',42)}</div><strong>${esc(entry.name)}</strong><span>Document Office</span>${entry.previewUrl?`<img loading="lazy" src="${safeUrl(entry.previewUrl)}" alt="Aperçu si disponible" class="neos-office-thumb" data-hide-on-error="1">`:''}<a href="${safeUrl(entry.url)}" class="neos-btn neos-btn-primary">${icon('external',15)} Ouvrir dans Office</a></div>`;
      else body=`<div class="neos-preview-empty">${icon('file',28)}<span>Pas d'aperçu pour ce format</span></div>`;
    }
    return `<aside class="neos-preview" data-preview-pane>${head}<div class="neos-preview-body">${body}</div><div class="neos-preview-foot"><span>${entry?esc(entry.path||'/'):'Lecture seule'}</span><span>${hasFile?'↑ Aperçu':'Fichiers / Neos'}</span></div></aside>`;
  }
  function renderPreview() {
    const node=surface.querySelector('[data-preview-pane]');
    if(node){node.outerHTML=previewPane();animatePreview();}
    surface.querySelectorAll('.neos-file-row').forEach(el=>{
      const path=el.querySelector('[data-path]')?.dataset.path;
      el.classList.toggle('is-active',Boolean(path&&path===preview.entry?.path));
    });
    if(fullPreview)renderFullPreview();
  }

  function explorerWidget() {
    const pins = (settings.pins || []).slice(0, 12);
    return box('explorer', `<div class="neos-browser-shell">
      <div class="neos-browser-tools">
        <div class="neos-breadcrumb"><button class="neos-iconbtn neos-nav-btn" data-action="history-back" title="Retour" aria-label="Retour" ${historyIndex===0?'disabled':''}>${icon('back',16)}</button><button class="neos-iconbtn neos-nav-btn" data-action="history-forward" title="Suivant" aria-label="Suivant" ${historyIndex>=history.length-1?'disabled':''}>${icon('forward',16)}</button><span class="neos-breadcrumb-items" data-drop-folder="${esc(browser.path)}" title="Déposer dans ce dossier">${breadcrumb()}</span><span class="neos-browser-total">${browser.loading?'…':browser.total+' élément'+(browser.total>1?'s':'')}</span></div>
        <div class="neos-browser-actions">
          ${pins.length ? `<div class="neos-pins">${pins.map(p => `<button type="button" class="neos-pin" data-action="browse-path" data-path="${esc(p)}">${icon('folder',13)} ${esc(p.split('/').pop())}</button>`).join('')}</div>` : ''}
          <label class="neos-search">${icon('search',16)}<input type="search" data-browser-search value="${esc(browser.query)}" placeholder="Rechercher dans ce dossier" aria-label="Rechercher dans ce dossier"><kbd>/</kbd></label>
          <button type="button" class="neos-btn neos-global-search-trigger" data-action="global-search" data-tab="search" title="Rechercher dans tous mes dossiers">${icon('search',15)} Partout</button>
          <button type="button" class="neos-btn neos-quick-trigger" data-action="global-search" data-tab="favorites">${icon('star',15)} Favoris</button>
          <button type="button" class="neos-btn neos-quick-trigger" data-action="global-search" data-tab="recent">${icon('clock',15)} Consultés</button>
          <select data-browser-type><option value="all" ${browser.type==='all'?'selected':''}>Tout</option><option value="folder" ${browser.type==='folder'?'selected':''}>Dossiers</option><option value="file" ${browser.type==='file'?'selected':''}>Fichiers</option></select>
          <select data-browser-sort><option value="name" ${browser.sort==='name'?'selected':''}>Nom</option><option value="recent" ${browser.sort==='recent'?'selected':''}>Récents</option><option value="size" ${browser.sort==='size'?'selected':''}>Taille</option></select>
          <button type="button" class="neos-btn" data-action="new-folder">${icon('folder',15)} Nouveau dossier</button>
          <button type="button" class="neos-btn" data-action="upload-trigger">${icon('upload',15)} Téléverser</button>
          <button type="button" class="neos-iconbtn" data-action="toggle-view" title="Changer la vue">${icon(browser.view === 'grid' ? 'list' : 'grid',16)}</button>
          <button type="button" class="neos-iconbtn" data-action="reload-folder" title="Recharger ce dossier">${icon('refresh',16)}</button>
          <a class="neos-btn" href="${safeUrl(filesHomeUrl())}">${icon('external',15)} Fichiers</a>
          <input type="file" data-upload-input hidden multiple>
        </div>
      </div>
      <div data-selection-toolbar>${selectionToolbar()}</div>
      <div class="neos-browser-main"><div class="neos-browser-list-wrap neos-drop-zone" data-drop-folder="${esc(browser.path)}"><div class="neos-list-caption"><span>Nom</span><span>Modifié</span><span>Taille</span></div><div id="neos-file-results">${browserItems()}</div>${browser.truncated?`<div class="neos-truncated">Premiers ${browser.limit} éléments sur ${browser.total} · <a href="${safeUrl(filesHomeUrl())}">Tout afficher</a></div>`:''}</div>${previewPane()}</div>
    </div>`, browser.path);
  }

  function filesWorkspace(){
    return `<div class="neos-files-workspace">${explorerWidget()}</div>`;
  }
  function homeWorkspace(widgets){
    const visible=settings.order.filter(id=>!settings.hidden.includes(id)&&(id!=='shortcuts'||settings.launcherMode==='widget'));
    const homeWidgets={...widgets,explorer:homeExplorerWidget};
    return `${editing?`<div class="neos-editbar neos-layout-toolbar"><div class="neos-layout-toolbar-heading"><span class="neos-layout-pulse"></span><strong>Mode disposition</strong><small>Déplace, redimensionne et remplis les espaces</small></div><div class="neos-layout-toolbar-actions"><button type="button" class="neos-layout-toggle ${settings.gridMode==='adaptive'?'is-active':''}" data-action="grid-mode" data-mode="adaptive">Adaptatif</button><button type="button" class="neos-layout-toggle ${settings.gridMode==='manual'?'is-active':''}" data-action="grid-mode" data-mode="manual">Libre</button><button type="button" class="neos-btn neos-btn-primary" data-action="finish-arrange">${icon('check',16)} Terminer</button></div></div>`:''}${editing?`<div class="neos-grid-legend" aria-hidden="true"><span class="neos-grid-legend-dot"></span> GRILLE 12 COLONNES <span class="neos-grid-legend-divider"></span> DÉPOSE SUR UNE CARTE POUR RÉORGANISER <span class="neos-grid-legend-flex"></span> ${settings.gridMode==='manual'?'DIMENSIONS LIBRES':'TAILLES ADAPTATIVES'}</div>`:''}<div class="neos-grid-cards neos-home-grid ${editing?'neos-arranging':''}" data-grid-mode="${esc(settings.gridMode||'adaptive')}">${visible.map(id=>homeWidgets[id]?homeWidgets[id]():'').join('')}</div>${editing?`<div class="neos-layout-announce" role="status" aria-live="polite">${esc(layoutAnnounce||'Déplacement et tailles enregistrés automatiquement.')}</div>`:''}`;
  }

  // Dense 12-column grid. The cards are measured by their content and assigned
  // short implicit rows, so a tall widget no longer stretches an entire row.
  function scheduleMasonry(){
    if(masonryFrame)cancelAnimationFrame(masonryFrame);
    masonryFrame=requestAnimationFrame(()=>{masonryFrame=0;layoutMasonry();});
  }
  function layoutMasonry(){
    const grid=surface.querySelector('.neos-home-grid');if(!grid)return;
    const cards=[...grid.querySelectorAll(':scope > .neos-card')];
    const narrow=window.matchMedia('(max-width:700px)').matches;
    if(narrow){
      cards.forEach(card=>{card.style.gridRowEnd='auto';card.style.minHeight='';});
      return;
    }
    const style=getComputedStyle(grid);const rowHeight=Number.parseFloat(style.gridAutoRows)||8;
    const rowGap=Number.parseFloat(style.rowGap)||14;
    const pxPerRow=rowHeight+rowGap;
    for(const card of cards){
      // Measure content rather than the stretched grid slot.
      card.style.gridRowEnd='span 1';
      card.style.minHeight='';
      const head=card.querySelector(':scope > .neos-card-head');
      const body=card.querySelector(':scope > .neos-card-body');
      const cs=getComputedStyle(card);
      const marginHead=head?Number.parseFloat(getComputedStyle(head).marginBottom)||0:0;
      const natural=(head?.scrollHeight||0)+(body?.scrollHeight||0)+marginHead+
        (Number.parseFloat(cs.paddingTop)||0)+(Number.parseFloat(cs.paddingBottom)||0)+2;
      const chosen=widgetMinHeight(card.dataset.widget);
      const height=Math.max(natural, chosen, 112);
      const rows=Math.max(1,Math.ceil((height+rowGap)/pxPerRow));
      card.style.gridRowEnd=`span ${rows}`;
      card.style.minHeight=`${height}px`;
    }
  }
  window.addEventListener('resize',()=>{if(activeWorkspace==='home')scheduleMasonry();positionTabSlider();},{passive:true});

  function render() {
    const pillFrom=previousTabPosition();
    applyTheme();
    const warnings=overview?.warnings||[];
    const activeTopApps=settings.launcherMode==='topbar' ? topApps() : [];
    const widgets={explorer:explorerWidget,storage:storageWidget,shortcuts:shortcutsWidget,clock:clockWidget,files:recentWidget,calendar:calendarWidget,tasks:tasksWidget,summary:summaryWidget,links:linksWidget,notes:notesWidget,deck:deckWidget};
    // One launcher placement at a time: topbar OR widget. The Apps button opens the full catalogue.
    const visible = settings.order.filter(id=>!settings.hidden.includes(id) && (id!=='shortcuts'||settings.launcherMode==='widget'));
    surface.innerHTML=`<main class="neos-shell"><div class="neos-layout">
      <header class="neos-topbar">
        <div class="neos-brand"><span class="neos-brand-mark">${brandMark()}</span></div>
        <button type="button" class="neos-topsearch" data-action="global-search" title="Rechercher dans tous mes dossiers"><span>${icon('search',16)}</span><span>Recherche · Favoris · Récents</span><kbd>Ctrl K</kbd></button>
        <div class="neos-top-actions"><span class="neos-header-readout" data-clock>--:--</span><button type="button" class="neos-btn neos-hub-trigger" data-action="toggle-hub" title="Applications">${icon('grid',17)}<span>Applications</span></button><button type="button" class="neos-iconbtn" data-action="refresh" title="Actualiser" aria-label="Actualiser">${icon('refresh',17)}</button><button type="button" class="neos-btn neos-btn-primary" data-action="customize" aria-label="${editing ? 'Terminer' : 'Personnaliser'}">${icon(editing?'check':'settings',17)}<span>${editing?'Terminer':'Personnaliser'}</span></button></div>
      </header>
      ${tabBar()}
      <div id="neos-workspace-stage" class="neos-workspace-stage" data-active-workspace="${esc(activeWorkspace)}">
        ${workspaceHero()}
        ${(activeWorkspace==='files'||activeWorkspace==='home')&&warnings.length?`<div class="neos-warning">${icon('info',16)} ${esc(warnings[0])}</div>`:''}
        ${activeWorkspace==='home'?homeWorkspace(widgets):activeWorkspace==='files'?filesWorkspace():currentModule()}
      </div>
      <footer class="neos-footer"><span>NEOS 0.6.7</span><span>Nextcloud 35</span></footer>
    </div></main>`;
    updateClock();
    positionTabSlider(pillFrom);
    if(activeWorkspace==='home')scheduleMasonry();
    if(!hasEntered){hasEntered=true;animateIn(surface.querySelectorAll('.neos-topbar,.neos-card'),42,35);}
  }

  function updateClock() {
    const date = new Date();
    surface.querySelectorAll('[data-clock]').forEach(el => el.textContent = new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(date));
    surface.querySelectorAll('[data-clock-date]').forEach(el => el.textContent = new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(date));
    const minuteAngle=(date.getMinutes()+date.getSeconds()/60)*6;
    const hourAngle=(date.getHours()%12+date.getMinutes()/60)*30;
    surface.querySelectorAll('[data-holo-minute]').forEach(el=>el.style.transform=`rotate(${minuteAngle}deg)`);
    surface.querySelectorAll('[data-holo-hour]').forEach(el=>el.style.transform=`rotate(${hourAngle}deg)`);
  }

  function choosePreviewCandidate() {
    const current = preview.entry?.path && browser.items.find(x => x.path === preview.entry.path);
    if (current) return current;
    return browser.items.find(x => x.kind === 'file') || browser.items[0] || null;
  }

  async function browse(path, resetQuery=true, recordHistory=true) {
    if (!path || !path.startsWith('/') || path.includes('\\') || path.split('/').slice(1).some(x=>x==='..'||x==='.')) return;
    ++previewGeneration;
    preview.entry=null;preview.status='empty';preview.mode='empty';
    if(recordHistory&&path!==history[historyIndex]){
      history.splice(historyIndex+1);
      history.push(path);
      if(history.length>25)history.shift();
      historyIndex=history.length-1;
    }
    if(path!==browser.path){fileSelection.clear();fileAnchorPath='';}
    browser.path = path;
    if (resetQuery) browser.query = '';
    browser.loading = true;
    browser.error = '';
    render();
    const g = ++browseGeneration;
    try {
      let data;
      if (demo) data = demo.browse?.[path] || { path, davUrl:'', items:[], total:0, truncated:false, limit:160, filesUrl:'#' };
      else { const url = new URL(root.dataset.filesUrl, window.location.href); url.searchParams.set('path', path); data = await api(url.toString()); }
      if (g !== browseGeneration) return;
      browser.path = data.path || path;
      browser.davUrl = data.davUrl || '';
      browser.items = Array.isArray(data.items) ? data.items : [];
      browser.canCreate = data.canCreate !== false;
      for(const path of [...fileSelection])if(!browser.items.some(item=>item.path===path))fileSelection.delete(path);
      browser.total = number(data.total);
      browser.truncated = Boolean(data.truncated);
      browser.limit = number(data.limit) || 160;
      browser.filesUrl = data.filesUrl || '#';
      browser.loading = false;
      browser.error = '';
      render();
      const candidate = choosePreviewCandidate();
      if (candidate?.kind === 'file') void selectEntry(candidate.path, true);
      else if(candidate){preview.entry=candidate;preview.mode='folder';preview.status='ready';renderPreview();}
      animateRows();
      if(favoriteState.status==='idle')void loadFavorites();
    } catch (error) {
      if (g !== browseGeneration) return;
      console.error('[Neos] dossier indisponible', error);
      browser.loading = false;
      browser.error = 'Impossible de charger ce dossier.';
      render();
    }
  }

  async function previewFromDav(url,name,mime,size=0,path=''){
    if(!url||!(/^\/(?!\/)/.test(url)))return;
    ++previewGeneration;
    preview.entry={name,mime,kind:'file',davUrl:url,url:filesHomeUrl(),size,path};
    if(path)recordRecent(preview.entry);
    preview.mode=isPdf({name,mime})?'pdf':isImage({mime})?'image':isVideo({name,mime})?'video':isAudio({name,mime})?'audio':'meta';preview.status='ready';preview.error='';
    renderPreview();
    if(isText({name,mime})&&!isCsv({name,mime})&&size<=2*1024*1024){
      preview.status='loading';renderPreview();const g=++previewGeneration;
      try{
        const r=await fetch(url,{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
        const value=await r.text();if(g!==previewGeneration)return;
        preview.text=value.slice(0,160000);preview.mode='text';preview.status='ready';
      }catch(e){if(g!==previewGeneration)return;preview.status='error';preview.error='Lecture impossible';}renderPreview();
    }
  }
  function parseDelimited(text,delimiter){
    const rows=[];let row=[],cell='',quoted=false;
    for(let i=0;i<text.length&&rows.length<60;i++){
      const c=text[i];
      if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}
      else if(c===delimiter&&!quoted){row.push(cell);cell='';}
      else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);rows.push(row.slice(0,20));row=[];cell='';}
      else cell+=c;
    }
    if(row.length||cell){row.push(cell);rows.push(row.slice(0,20));}
    return rows.slice(0,60);
  }
  async function selectEntry(path, silent=false){
    const entry=browser.items.find(x=>x.path===path);if(!entry)return;
    if(entry.kind==='file'&&!silent)recordRecent(entry);
    const g=++previewGeneration;
    preview.entry=entry;preview.text='';preview.rows=[];preview.error='';
    if(entry.kind==='folder'){preview.mode='folder';preview.status='ready';renderPreview();return;}
    preview.status='loading';preview.mode='meta';renderPreview();
    try{
      if(isImage(entry)){preview.status='ready';preview.mode='image';}
      else if(isVideo(entry)){preview.status='ready';preview.mode='video';}
      else if(isAudio(entry)){preview.status='ready';preview.mode='audio';}
      else if(isPdf(entry)){preview.status='ready';preview.mode='pdf';}
      else if(isOffice(entry)){preview.status='ready';preview.mode='office';}
      else if(isText(entry)){
        if(number(entry.size)>2*1024*1024){preview.status='error';preview.error='Fichier trop volumineux pour un aperçu texte';}
        else{
          const r=await fetch(entry.davUrl,{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
          const value=(await r.text()).slice(0,180000);if(g!==previewGeneration)return;
          if(isCsv(entry)){
            const delimiter=ext(entry.name)==='tsv'?'\t':((value.match(/;/g)||[]).length>(value.match(/,/g)||[]).length?';':',');
            preview.rows=parseDelimited(value,delimiter);preview.mode='table';
          }else{preview.text=value;preview.mode='text';}
          preview.status='ready';
        }
      }else{preview.status='ready';preview.mode='meta';}
    }catch(error){if(g!==previewGeneration)return;console.error('[Neos] aperçu indisponible',error);preview.status='error';preview.error='Aperçu indisponible';}
    if(g===previewGeneration)renderPreview();
  }
  function openInFiles(entry){if(entry?.url)window.location.assign(entry.url);}
  async function copyCurrentLink(entry){
    if(!entry?.url)return;
    try{await navigator.clipboard.writeText(new URL(entry.url,window.location.href).href);toast('Lien copié','success');}
    catch(e){toast('Copie impossible','error');}
  }
  function downloadCurrent(entry){
    if(!entry?.davUrl)return;
    const anchor=document.createElement('a');anchor.href=entry.davUrl;anchor.download=entry.name||'';anchor.rel='noreferrer';
    document.body.appendChild(anchor);anchor.click();anchor.remove();
  }
  const ncWebroot=()=>window.OC?.getRootPath?.()||'';
  const davJoin=(base,name)=>`${String(base||'').replace(/\/+$/,'')}/${String(name||'').split('/').map(part=>encodeURIComponent(part)).join('/')}`;
  async function davRequest(method,url,{headers={},body}={}){
    const response=await fetch(url,{method,body,credentials:'same-origin',headers:{requesttoken:csrfToken(),'X-Requested-With':'XMLHttpRequest',...headers}});
    if(!response.ok&&![201,204,207].includes(response.status))throw new Error(`HTTP ${response.status}`);
    return response;
  }
  // File Manager Pro — native Nextcloud WebDAV operations. Mutations are always
  // non-overwriting; the server decides whether the user has sufficient rights.
  function davRoot(){
    if(!browser.davUrl)return '';
    try{
      const current=new URL(browser.davUrl,window.location.href);
      if(current.origin!==window.location.origin)return '';
      const marker='/remote.php/dav/files/';
      const i=current.pathname.indexOf(marker);
      if(i<0)return '';
      const rest=current.pathname.slice(i+marker.length),uid=rest.split('/')[0];
      return uid?current.origin+current.pathname.slice(0,i+marker.length)+uid:'';
    }catch{return '';}
  }
  function validFileFolderPath(path){
    return typeof path==='string'&&path.startsWith('/')&&path.length<=1024&&(path==='/'||(!path.includes('\\')&&
      !/[\x00-\x1f\x7f]/.test(path)&&!path.split('/').some((p,i)=>i>0&&(p==='.'||p==='..'||p===''))));
  }
  function davFolderUrl(path){
    if(!validFileFolderPath(path))return '';
    const base=davRoot();if(!base)return '';
    return base+(path==='/'?'':path.split('/').slice(1).map(encodeURIComponent).reduce((a,b)=>a+'/'+b,''));
  }
  function sameOrChild(candidate,parent){return candidate===parent||candidate.startsWith(parent+'/');}
  function filenameCopyName(name,number){
    const i=name.lastIndexOf('.');
    const stem=i>0?name.slice(0,i):name,extension=i>0?name.slice(i):'';
    return `${stem} (copie${number>1?' '+number:''})${extension}`;
  }
  function rememberFiles(mode,entries){
    if(fileBusy||!entries.length)return;
    fileClipboard.mode=mode;
    fileClipboard.entries=entries.map(x=>({path:x.path,name:x.name,kind:x.kind,davUrl:x.davUrl}));
    fileSelection.clear();fileAnchorPath='';refreshSelectionDisplay();
    toast(`${entries.length} élément${entries.length>1?'s':''} à ${mode==='cut'?'déplacer':'copier'} — ouvre le dossier cible puis clique Coller`,'success');
  }
  function copyOrCutFiles(mode,entries=selectedEntries()){rememberFiles(mode,entries);}
  function busyFiles(active){fileBusy=active;const toolbar=surface.querySelector('[data-selection-toolbar]');if(toolbar)toolbar.innerHTML=selectionToolbar();}
  function summarizeFiles(operation,done,conflicts,errors){
    const parts=[`${operation} : ${done} réussi${done>1?'s':''}`];
    if(conflicts)parts.push(`${conflicts} conflit${conflicts>1?'s':''} (non remplacé${conflicts>1?'s':''})`);
    if(errors)parts.push(`${errors} erreur${errors>1?'s':''}`);
    toast(parts.join(' · '),conflicts||errors?'error':'success');
  }
  async function transferFiles(entries,targetFolder,mode){
    if(fileBusy||!entries?.length)return;
    if(demo){toast('Opération désactivée dans l’aperçu','error');return;}
    const targetBase=davFolderUrl(targetFolder);
    if(!targetBase){toast('Dossier de destination inaccessible','error');return;}
    const operations=entries.filter(x=>x&&x.davUrl&&x.path&&x.name);
    if(!operations.length)return;
    // Prevent drag/move of a folder into itself or a descendant, and do not
    // silently turn a no-op move to the same folder into a destructive action.
    if(operations.some(x=>x.kind==='folder'&&sameOrChild(targetFolder,x.path))){toast('Impossible de déplacer/copier un dossier dans lui-même ou un sous-dossier','error');return;}
    const moving=mode==='cut',method=moving?'MOVE':'COPY';
    busyFiles(true);let done=0,conflicts=0,errors=0;
    const failed=[];
    for(const entry of operations){
      const sourceFolder=entry.path.slice(0,entry.path.lastIndexOf('/'))||'/';
      if(moving&&sourceFolder===targetFolder){done++;continue;}
      let success=false,conflict=false;
      for(let attempt=0;attempt<(moving?1:30);attempt++){
        // Copying in the same folder must use a new name; for other folders,
        // try original first, then auto-rename if a non-overwrite conflict occurs.
        const name=attempt===0&&sourceFolder!==targetFolder?entry.name:filenameCopyName(entry.name,sourceFolder===targetFolder?attempt+1:attempt);
        const destination=new URL(davJoin(targetBase,name),window.location.href);
        if(destination.origin!==window.location.origin){errors++;break;}
        try{
          await davRequest(method,entry.davUrl,{headers:{Destination:destination.href,Overwrite:'F'}});
          done++;success=true;break;
        }catch(error){
          const isConflict=/HTTP (409|412)/.test(String(error));
          if(isConflict){conflict=true;if(!moving&&attempt<29)continue;conflicts++;}
          else errors++;
          console.warn('[Neos] transfert refusé',method,entry.name,error);
          break;
        }
      }
      if(!success)failed.push(entry);
    }
    if(moving&&fileClipboard.mode==='cut'){
      fileClipboard.entries=failed;
      if(!failed.length)fileClipboard.mode='';
    }
    busyFiles(false);fileSelection.clear();fileAnchorPath='';
    summarizeFiles(moving?'Déplacement':'Copie',done,conflicts,errors);
    await browse(browser.path,false,false);
    refreshSelectionDisplay();
  }
  // Destination chooser: calls the existing Neos directory endpoint, which enforces
  // user access through Nextcloud. No extra server route or privileged token.
  function renderFolderPicker(){
    if(popMode!=='destination'||!pickerState)return;
    const p=pickerState;
    const parts=p.path.split('/').filter(Boolean);
    const title=p.mode==='cut'?'Déplacer vers…':'Copier vers…';
    const destinations=p.folders.filter(x=>x.name.toLocaleLowerCase('fr').includes(p.search.toLocaleLowerCase('fr')));
    popHost.innerHTML=`<div class="neos-pop-layer neos-destination-layer" data-action="close-pop"><section class="neos-destination-dialog neos-framed" role="dialog" aria-modal="true" aria-labelledby="neos-destination-heading"><header class="neos-destination-header"><div><small>GESTIONNAIRE DE FICHIERS</small><h2 id="neos-destination-heading">${title}</h2><span>${p.entries.length} élément${p.entries.length>1?'s':''} sélectionné${p.entries.length>1?'s':''}</span></div><button type="button" class="neos-iconbtn" data-action="destination-close" aria-label="Fermer">${icon('close',18)}</button></header><div class="neos-destination-body"><div class="neos-destination-path"><button type="button" class="neos-iconbtn" data-action="destination-up" ${p.path==='/'?'disabled':''} title="Remonter d’un dossier">${icon('back',16)}</button><button type="button" class="neos-path-root" data-action="destination-browse" data-path="/">${icon('home',15)}</button>${parts.map((part,i)=>`<span class="neos-path-separator">/</span><button type="button" class="neos-path-part" data-action="destination-browse" data-path="/${esc(parts.slice(0,i+1).join('/'))}">${esc(part)}</button>`).join('')}</div><label class="neos-destination-search">${icon('search',16)}<input type="search" data-destination-search placeholder="Filtrer les dossiers" value="${esc(p.search)}" autocomplete="off"></label><div class="neos-destination-list" data-destination-results>${p.loading?'<div class="neos-destination-empty"><span class="neos-spinner"></span></div>':p.error?`<div class="neos-destination-empty neos-destination-error">${icon('alert',18)} ${esc(p.error)}</div>`:destinations.length?destinations.map(f=>`<button type="button" class="neos-destination-folder" data-action="destination-browse" data-path="${esc(f.path)}">${icon('folder',19)}<span>${esc(f.name)}</span>${icon('chevron',16)}</button>`).join(''):'<div class="neos-destination-empty">Aucun sous-dossier</div>'}</div></div><footer class="neos-destination-footer"><div class="neos-destination-current"><span>Destination</span><strong title="${esc(p.path)}">${esc(p.path)}</strong></div><button type="button" class="neos-btn" data-action="destination-close">Annuler</button><button type="button" class="neos-btn neos-btn-primary" data-action="destination-confirm" ${p.loading||p.error||fileBusy?'disabled':''}>${icon(p.mode==='cut'?'arrow':'copy',16)} ${p.mode==='cut'?'Déplacer ici':'Copier ici'}</button></footer></section></div>`;
  }
  async function browseDestination(path){
    if(!pickerState||!validFileFolderPath(path))return;
    pickerState.path=path;pickerState.loading=true;pickerState.error='';pickerState.search='';
    renderFolderPicker();
    const generation=++pickerGeneration;
    try{
      let data;
      if(demo){data=demo.browse?.[path]||{items:[]};}
      else{
        const query=new URL(root.dataset.filesUrl,window.location.href);
        query.searchParams.set('path',path);
        data=await api(query.toString());
      }
      if(generation!==pickerGeneration||!pickerState)return;
      pickerState.folders=(Array.isArray(data.items)?data.items:[]).filter(x=>x.kind==='folder');
      pickerState.loading=false;
    }catch(error){
      if(generation!==pickerGeneration||!pickerState)return;
      console.warn('[Neos] destination inaccessible',error);
      pickerState.loading=false;pickerState.error='Dossier inaccessible ou non autorisé';
    }
    renderFolderPicker();
  }
  function openDestinationPicker(mode,entries=selectedEntries()){
    if(fileBusy||!Array.isArray(entries)||!entries.length)return;
    if(!['cut','copy'].includes(mode))return;
    const snapshot=entries.filter(e=>e?.path&&e?.davUrl&&e?.name).map(e=>({...e}));
    if(!snapshot.length)return;
    pickerState={mode,entries:snapshot,path:browser.path,folders:[],loading:true,error:'',search:''};
    popMode='destination';renderFolderPicker();
    animateLayerOpen(popHost,'.neos-destination-dialog','y');
    void browseDestination(browser.path);
  }
  function destinationConfirm(){
    if(!pickerState||pickerState.loading||pickerState.error||fileBusy)return;
    const {entries,mode,path}=pickerState;
    if(entries.some(entry=>entry.kind==='folder'&&sameOrChild(path,entry.path))){toast('Impossible de placer un dossier dans lui-même','error');return;}
    pickerGeneration++;pickerState=null;popMode='';popHost.replaceChildren();
    void transferFiles(entries,path,mode);
  }
  async function pasteFiles(folder=browser.path){
    if(!fileClipboard.entries.length)return;
    const snap=[...fileClipboard.entries];
    await transferFiles(snap,folder,fileClipboard.mode);
  }
  async function duplicateFiles(entries=selectedEntries()){
    if(!entries.length)return;
    await transferFiles(entries,browser.path,'copy');
  }
  async function deleteFiles(entries=selectedEntries()){
    if(fileBusy||!entries.length)return;
    if(demo){toast('Suppression désactivée dans l’aperçu','error');return;}
    const folderCount=entries.filter(x=>x.kind==='folder').length;
    const text=`Supprimer ${entries.length} élément${entries.length>1?'s':''}${folderCount?` (dont ${folderCount} dossier${folderCount>1?'s':''} et leur contenu)`:''} ? La récupération dépend de la corbeille Nextcloud.`;
    if(!window.confirm(text))return;
    busyFiles(true);let done=0,errors=0;
    for(const entry of entries){
      try{await davRequest('DELETE',entry.davUrl);done++;if(preview.entry?.path===entry.path){preview.entry=null;preview.status='empty';preview.mode='empty';}}
      catch(error){errors++;console.warn('[Neos] suppression refusée',entry.name,error);}
    }
    busyFiles(false);fileSelection.clear();fileAnchorPath='';
    summarizeFiles('Suppression',done,0,errors);
    await browse(browser.path,false,false);
  }

  async function ocsRequest(path,{method='GET',headers={},body}={}){
    const response=await fetch(`${ncWebroot()}/ocs/v2.php${path}${path.includes('?')?'&':'?'}format=json`,{method,body,credentials:'same-origin',headers:{Accept:'application/json','OCS-APIRequest':'true',requesttoken:csrfToken(),'X-Requested-With':'XMLHttpRequest',...headers}});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    const data=await response.json();
    const status=Number(data?.ocs?.meta?.statuscode||0);
    if(status&&status!==100&&status!==200)throw new Error(data?.ocs?.meta?.message||'OCS');
    return data?.ocs?.data;
  }
  function namePrompt(message,placeholder=''){
    const value=window.prompt(message,placeholder);
    if(value==null)return '';
    return value.trim().replace(/[\\/]/g,'').slice(0,180);
  }
  async function createFolder(){
    if(!browser.davUrl)return toast('Dossier courant indisponible','error');
    const name=namePrompt('Nom du nouveau dossier','Nouveau dossier');
    if(!name)return;
    try{await davRequest('MKCOL',davJoin(browser.davUrl,name));toast('Dossier créé','success');await browse(browser.path,false,false);}catch(error){console.error(error);toast('Création impossible','error');}
  }
  // XHR is used only for PUT: it exposes upload byte progress and allows abort.
  function uploadProgressUi(){
    if(!uploadState.active&&!uploadState.finished){uploadHost.replaceChildren();return;}
    const state=uploadState;
    const total=state.totalBytes, loaded=state.doneBytes+state.loaded;
    const percent=total?Math.min(100,Math.round(loaded/total*100)):(state.finished?100:0);
    const current=state.files[state.currentIndex];
    uploadHost.innerHTML=`<section class="neos-upload-panel" role="status" aria-live="off"><header><span class="neos-upload-indicator">${icon('upload',16)}</span><div><strong>${state.active?'Téléversement en cours':state.cancel?'Téléversement interrompu':'Téléversement terminé'}</strong><small>${state.files.filter(f=>f.status==='done').length} / ${state.files.length} fichier(s) transmis</small></div><button type="button" class="neos-iconbtn" data-upload-action="${state.active?'cancel':'dismiss'}" title="${state.active?'Annuler les téléversements':'Fermer'}" aria-label="${state.active?'Annuler les téléversements':'Fermer'}">${icon('close',16)}</button></header><div class="neos-upload-meter"><div style="width:${percent}%"></div></div><div class="neos-upload-totals"><span>${humanSize(loaded)} / ${humanSize(total)}</span><strong>${percent}%</strong></div><div class="neos-upload-current">${current?`${esc(current.name)} <small>${current.status==='sending'?'Envoi…':current.status==='done'?'Terminé':current.status==='conflict'?'Nom déjà utilisé':current.status==='error'?'Échec':current.status==='cancelled'?'Annulé':'En attente'}</small>`:'—'}</div></section>`;
  }
  function uploadPut(file,url,progress){
    return new Promise((resolve,reject)=>{
      const xhr=new XMLHttpRequest();uploadState.xhr=xhr;
      xhr.open('PUT',url,true);xhr.withCredentials=true;
      const token=csrfToken();if(token)xhr.setRequestHeader('requesttoken',token);
      xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
      xhr.setRequestHeader('Content-Type',file.type||'application/octet-stream');
      xhr.setRequestHeader('If-None-Match','*');
      xhr.upload.addEventListener('progress',event=>{if(event.lengthComputable)progress(event.loaded);});
      xhr.addEventListener('load',()=>{uploadState.xhr=null;if(xhr.status>=200&&xhr.status<300)resolve();else reject(new Error('HTTP '+xhr.status));});
      xhr.addEventListener('error',()=>{uploadState.xhr=null;reject(new Error('Erreur réseau'));});
      xhr.addEventListener('abort',()=>{uploadState.xhr=null;reject(new DOMException('Téléversement annulé','AbortError'));});
      xhr.send(file);
    });
  }
  async function uploadSelection(files,targetFolder=browser.path){
    const list=[...(files||[])].filter(file=>file instanceof File);
    if(!list.length)return;
    if(fileBusy)return toast('Une opération est déjà en cours','error');
    if(demo)return toast('Téléversement désactivé dans l’aperçu','error');
    const target=davFolderUrl(targetFolder);
    if(!target)return toast('Dossier de destination indisponible','error');
    uploadState.active=true;uploadState.finished=false;uploadState.cancel=false;uploadState.files=list.map(file=>({name:file.name,size:file.size,status:'pending'}));
    uploadState.totalBytes=list.reduce((acc,file)=>acc+file.size,0);uploadState.doneBytes=0;uploadState.loaded=0;uploadState.currentIndex=-1;
    busyFiles(true);uploadProgressUi();
    let uploaded=0,conflicts=0,errors=0;
    for(let i=0;i<list.length;i++){
      if(uploadState.cancel)break;
      const file=list[i],row=uploadState.files[i];
      uploadState.currentIndex=i;uploadState.loaded=0;row.status='sending';uploadProgressUi();
      if(!file.name||file.name.includes('/')||file.name.includes('\\')){errors++;row.status='error';uploadState.doneBytes+=file.size;continue;}
      try{
        await uploadPut(file,davJoin(target,file.name),loaded=>{uploadState.loaded=loaded;uploadProgressUi();});
        row.status='done';uploaded++;
      }catch(error){
        if(error?.name==='AbortError'){row.status='cancelled';uploadState.cancel=true;break;}
        if(/HTTP (409|412)/.test(String(error))){conflicts++;row.status='conflict';}
        else{errors++;row.status='error';}
        console.warn('[Neos] téléversement refusé',file.name,error);
      }
      uploadState.doneBytes+=file.size;uploadState.loaded=0;uploadProgressUi();
    }
    uploadState.active=false;uploadState.finished=true;uploadState.loaded=0;uploadState.xhr=null;
    if(uploadState.cancel)uploadState.files.filter(f=>f.status==='pending').forEach(f=>f.status='cancelled');
    busyFiles(false);uploadProgressUi();
    summarizeFiles('Téléversement',uploaded,conflicts,errors);
    if(uploaded)await browse(browser.path,false,false);
  }

  async function renameEntry(entry){
    if(!entry?.path||!entry?.name||!browser.davUrl)return;
    const name=namePrompt('Nouveau nom',entry.name); if(!name||name===entry.name)return;
    try{await davRequest('MOVE',entry.davUrl,{headers:{Destination:new URL(davJoin(browser.davUrl,name),window.location.origin).href,Overwrite:'F'}});toast('Élément renommé','success');await browse(browser.path,false,false);}catch(error){console.error(error);toast('Renommage impossible','error');}
  }
  async function deleteEntry(entry){
    if(!entry?.davUrl)return;
    if(!window.confirm(`Supprimer « ${entry.name} » ? La récupération dépend de la configuration de la corbeille Nextcloud.`))return;
    try{await davRequest('DELETE',entry.davUrl);toast('Élément supprimé','success');if(preview.entry?.path===entry.path){preview.entry=null;preview.status='empty';preview.mode='empty';}await browse(browser.path,false,false);}catch(error){console.error(error);toast('Suppression impossible','error');}
  }
  async function shareEntry(entry){
    if(!entry?.path)return;
    if(!window.confirm(`Créer un lien public accessible aux personnes qui le possèdent pour « ${entry.name} » ?`))return;
    try{
      const data=await ocsRequest('/apps/files_sharing/api/v1/shares',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({path:entry.path,shareType:'3'}).toString()});
      const url=data?.url||'';
      if(url&&navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);toast('Lien public copié','success');}
      else if(url){window.prompt('Lien public',url);toast('Lien public créé','success');}
      else toast('Lien public créé','success');
    }catch(error){console.error(error);toast('Partage indisponible','error');}
  }
  function renderFullPreview(){
    if(!fullPreview){if(popMode!=='hub'&&popMode!=='context')popHost.replaceChildren();return;}
    popHost.innerHTML=`<div class="neos-fullscreen-overlay" data-action="close-full-preview"><div class="neos-fullscreen-panel" role="dialog" aria-modal="true" aria-label="Aperçu de fichier"><header><strong>${esc(preview.entry?.name||'Aperçu')}</strong><div><button type="button" class="neos-iconbtn" data-action="download-selected" title="Télécharger">${icon('download',17)}</button><button type="button" class="neos-iconbtn" data-action="close-full-preview" title="Fermer">${icon('close',18)}</button></div></header><div class="neos-fullscreen-content">${previewPane()}</div></div></div>`;
    animateLayerOpen(popHost,'.neos-fullscreen-panel','y');
  }
  function renderContextMenu(){
    if(popMode!=='context')return;
    const entry=browser.items.find(x=>x.path===contextPath);if(!entry){popMode='';popHost.replaceChildren();return;}
    popHost.innerHTML=`<div class="neos-pop-layer neos-context-overlay" data-action="close-pop"><div class="neos-context-menu" role="menu"><div class="neos-context-title">${esc(entry.name)}</div>${entry.kind==='file'?`<button role="menuitem" data-action="menu-preview">${icon('expand',16)} Aperçu</button><button role="menuitem" data-action="menu-download">${icon('download',16)} Télécharger</button>`:`<button role="menuitem" data-action="menu-open-folder">${icon('folder',16)} Ouvrir le dossier</button>`}<button role="menuitem" data-action="menu-favorite">${icon('star',16)} ${favoritePaths.has(entry.path)?'Retirer des favoris':'Ajouter aux favoris'}</button><button role="menuitem" data-action="menu-share">${icon('link',16)} Créer un lien public</button><button role="menuitem" data-action="menu-rename">${icon('edit',16)} Renommer</button><button role="menuitem" data-action="menu-duplicate">${icon('copy',16)} Dupliquer ici</button><button role="menuitem" data-action="menu-move-to">${icon('arrow',16)} Déplacer vers…</button><button role="menuitem" data-action="menu-copy-to">${icon('copy',16)} Copier vers…</button><button role="menuitem" class="is-danger" data-action="menu-delete">${icon('trash',16)} Supprimer</button><button role="menuitem" data-action="menu-copy">${icon('copy',16)} Copier le lien interne</button><a href="${safeUrl(entry.url)}" role="menuitem">${icon('external',16)} Ouvrir dans Fichiers</a></div></div>`;
    animateLayerOpen(popHost,'.neos-context-menu','y');
  }

  function encodeSettings() {
    const form = new URLSearchParams();
    const put = (key, value) => form.append(`settings[${key}]`, String(value));
    ['theme','density','accent','layout','motion','launcherMode','gridMode','notes'].forEach(key => put(key, settings[key] || ''));
    settings.order.forEach((v,i) => form.append(`settings[order][${i}]`, v));
    settings.hidden.forEach((v,i) => form.append(`settings[hidden][${i}]`, v));
    Object.entries(settings.sizes || {}).forEach(([id,v]) => form.append(`settings[sizes][${id}]`, String(v)));
    Object.entries(settings.heights || {}).forEach(([id,v]) => form.append(`settings[heights][${id}]`, String(v)));
    (settings.links || []).forEach((l,i) => { form.append(`settings[links][${i}][title]`, l.title); form.append(`settings[links][${i}][url]`, l.url); });
    (settings.pins || []).forEach((p,i) => form.append(`settings[pins][${i}]`, p));
    (settings.topApps || []).forEach((id,i) => form.append(`settings[topApps][${i}]`, id));
    return form;
  }

  async function save() {
    if (saving) return;
    saving = true;
    while (saveQueued) {
      saveQueued = false;
      updateSaveIndicator('Enregistrement…');
      try {
        await api(root.dataset.settingsUrl, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:encodeSettings().toString() });
        updateSaveIndicator('Enregistré');
      } catch (error) {
        console.error('[Neos] sauvegarde impossible', error);
        updateSaveIndicator('Erreur');
        toast('Impossible d’enregistrer.', 'error');
        break;
      }
    }
    saving = false;
  }

  function queueSave() { if(demo){ updateSaveIndicator('Démo — réglages temporaires'); return; } saveQueued = true; if (!saving) void save(); }

  function radio(name, choices) {
    return `<div class="neos-choice-set">${choices.map(([value,label]) => `<label class="neos-choice"><input type="radio" name="${name}" value="${value}" ${settings[name]===value?'checked':''}><span>${label}</span></label>`).join('')}</div>`;
  }

  function renderEditor() {
    if (!editorOpen) { editorHost.replaceChildren(); return; }
    const appChoices = (overview?.shortcuts || []).map(app => `<label class="neos-check"><input type="checkbox" data-topapp="${esc(app.id)}" ${settings.topApps.includes(app.id)?'checked':''}><span>${esc(app.label)}</span></label>`).join('');
    editorHost.innerHTML = `<div class="neos-overlay" data-action="editor-backdrop"><aside class="neos-editor" role="dialog" aria-modal="true" aria-labelledby="neos-editor-title">
      <header class="neos-editor-head"><h2 id="neos-editor-title">Neos</h2><button type="button" class="neos-iconbtn" data-action="close-editor">${icon('close',18)}</button></header>
      <div class="neos-editor-body">
        <section><h3>Apparence</h3>${radio('theme',[['system','Auto'],['dark','Sombre'],['light','Clair']])}${radio('accent',[['cyan','Cyan'],['indigo','Indigo'],['rose','Violet/Rose'],['emerald','Turquoise'],['amber','Ambre']])}${radio('density',[['comfortable','Aérée'],['compact','Compacte']])}${radio('layout',[['wide','Pleine largeur'],['focused','Centrée']])}${radio('motion',[['full','Animé'],['subtle','Discret'],['off','Off']])}</section>
        <section><h3>Disposition de l'accueil</h3><div class="neos-pref-hint">Choisis « Libre » pour régler largeur et hauteur minimale. La grille compacte automatiquement les espaces entre les cartes.</div>${radio('gridMode',[['adaptive','Adaptatif'],['manual','Libre']])}<div class="neos-pref-list">${settings.order.filter(id=>id!=='shortcuts').map((id,i)=>`<div class="neos-pref-row"><label class="neos-check"><input type="checkbox" data-toggle="${id}" ${settings.hidden.includes(id)?'':'checked'}><span>${esc(widgetLabels[id])}</span></label><div class="neos-pref-tools"><select data-size="${id}" ${settings.gridMode==='adaptive'?'disabled':''}>${[[3,'25%'],[4,'33%'],[6,'50%'],[8,'67%'],[9,'75%'],[12,'100%']].map(([size,label])=>`<option value="${size}" ${Number(settings.sizes[id])===size?'selected':''}>${label}</option>`).join('')}</select><select data-height="${id}" ${settings.gridMode==='adaptive'?'disabled':''} aria-label="Hauteur minimale de ${esc(widgetLabels[id])}">${[[0,'Auto'],[160,'160 px'],[220,'220 px'],[300,'300 px'],[400,'400 px'],[520,'520 px'],[680,'680 px']].map(([h,label])=>`<option value="${h}" ${widgetMinHeight(id)===h?'selected':''}>${label}</option>`).join('')}</select><button type="button" class="neos-iconbtn" data-action="move-up" data-id="${id}" ${settings.order.indexOf(id)===0?'disabled':''} aria-label="Monter ${esc(widgetLabels[id])}">↑</button><button type="button" class="neos-iconbtn" data-action="move-down" data-id="${id}" ${settings.order.indexOf(id)===settings.order.length-1?'disabled':''} aria-label="Descendre ${esc(widgetLabels[id])}">↓</button></div></div>`).join('')}</div></section>
        <section><h3>Position du lanceur</h3>${radio('launcherMode',[['topbar','Barre supérieure'],['widget','Widget']])}<div class="neos-app-picks">${settings.launcherMode==='topbar' ? appChoices : ''}</div></section>
        <section><h3>Liens</h3><div class="neos-custom-links">${(settings.links || []).map((entry, i) => `<div class="neos-link-edit"><input data-link-title="${i}" value="${esc(entry.title)}" maxlength="80"><input data-link-url="${i}" value="${esc(entry.url)}" maxlength="600"><button type="button" class="neos-iconbtn" data-action="remove-link" data-index="${i}">${icon('trash',15)}</button></div>`).join('')}</div><button type="button" class="neos-btn" data-action="add-link">${icon('plus',15)} Ajouter</button></section>
      </div>
      <footer class="neos-editor-foot"><span data-save-indicator>Préférences individuelles</span><div><button type="button" class="neos-btn" data-action="arrange">Réorganiser</button><button type="button" class="neos-btn neos-btn-primary" data-action="close-editor">Terminer</button></div></footer>
    </aside></div>`;
    animateLayerOpen(editorHost,'.neos-editor','x');
  }
  function updateSaveIndicator(text){ const el = editorHost.querySelector('[data-save-indicator]'); if (el) el.textContent = text; }
  function openEditor(){ editing=true;editorOpen=true;render();renderEditor();surface.inert=true; }
  function closeEditor(keepEditing=false){
    harvestLinks(); queueSave();
    const finish = () => { editorOpen=false;editing=keepEditing;surface.inert=false;renderEditor();render();surface.querySelector('[data-action=customize]')?.focus(); };
    if(editorHost.firstElementChild) animateLayerClose(editorHost,'.neos-editor',finish,'x'); else finish();
  }
  function harvestLinks(){ editorHost.querySelectorAll('[data-link-title]').forEach(input => { const i = Number(input.dataset.linkTitle); if (settings.links[i]) settings.links[i].title = input.value.trim().slice(0,80); }); editorHost.querySelectorAll('[data-link-url]').forEach(input => { const i = Number(input.dataset.linkUrl); if (settings.links[i]) settings.links[i].url = input.value.trim().slice(0,600); }); }

  // Favorite state is stored by Nextcloud via WebDAV oc:favorite (not in Neos
  // preferences). Recently opened paths are only stored locally in this browser
  // under a per-user key; no file content is retained.
  function recentStorageKey(){
    const uid=root.dataset.currentUid||'demo';
    return `neos-v060-recent:${uid}`;
  }
  function readRecent(){
    recentViewed.splice(0);
    try{
      const value=JSON.parse(localStorage.getItem(recentStorageKey())||'[]');
      if(Array.isArray(value))for(const item of value.slice(0,24)){
        if(validFileFolderPath(item?.path)&&item.path!=='/'&&typeof item.name==='string'&&item.name.length<300){
          recentViewed.push({name:item.name,path:item.path,parent:item.path.slice(0,item.path.lastIndexOf('/'))||'/',kind:'file',size:number(item.size),mime:String(item.mime||''),mtime:number(item.mtime),openedAt:number(item.openedAt)});
        }
      }
    }catch{/* Storage may be blocked by the browser */}
  }
  function recordRecent(entry){
    if(!entry?.path||entry.kind!=='file'||!validFileFolderPath(entry.path))return;
    const current={name:entry.name,path:entry.path,parent:entry.path.slice(0,entry.path.lastIndexOf('/'))||'/',kind:'file',size:number(entry.size),mime:String(entry.mime||''),mtime:number(entry.mtime),openedAt:Date.now()};
    const idx=recentViewed.findIndex(item=>item.path===entry.path);
    if(idx!==-1)recentViewed.splice(idx,1);
    recentViewed.unshift(current);recentViewed.length=Math.min(recentViewed.length,24);
    try{localStorage.setItem(recentStorageKey(),JSON.stringify(recentViewed));}catch{/* History remains available for this page */}
  }
  function favoriteDavRoot(){
    const uid=root.dataset.currentUid;
    if(uid){
      // The webroot is supplied by Nextcloud itself. Never derive it from
      // the overview route: pretty routes do not contain '/index.php/'.
      const webroot=String(root.dataset.webroot ?? window.OC?.getRootPath?.() ?? '');
      if(webroot&&!webroot.startsWith('/'))return '';
      return window.location.origin+webroot.replace(/\/+$/,'')+'/remote.php/dav/files/'+encodeURIComponent(uid);
    }
    return davRoot();
  }
  function favoriteDavUrl(path){
    if(!validFileFolderPath(path)||path==='/')return '';
    const base=favoriteDavRoot();
    return base?base+path.split('/').slice(1).map(encodeURIComponent).reduce((a,b)=>a+'/'+b,''):'';
  }
  function xmlNodeValue(node,namespace,name){
    return node?.getElementsByTagNameNS(namespace,name)?.[0]?.textContent||'';
  }
  function parseFavoriteXml(xml,base){
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    if(doc.getElementsByTagName('parsererror').length)throw Error('Réponse WebDAV invalide');
    const rootPath=new URL(base,window.location.href).pathname.replace(/\/+$/,'');
    const results=[];
    for(const entry of doc.getElementsByTagNameNS('DAV:','response')){
      const href=xmlNodeValue(entry,'DAV:','href');if(!href)continue;
      const url=new URL(href,window.location.origin);
      const pathname=url.pathname.replace(/\/+$/,'');
      if(url.origin!==window.location.origin||!pathname.startsWith(rootPath+'/'))continue;
      const segments=pathname.slice(rootPath.length+1).split('/').map(x=>decodeURIComponent(x));
      const path='/'+segments.join('/');
      if(!validFileFolderPath(path))continue;
      const collection=entry.getElementsByTagNameNS('DAV:','collection').length>0;
      const name=segments.at(-1);
      const mime=collection?'httpd/unix-directory':xmlNodeValue(entry,'DAV:','getcontenttype');
      const mtime=Math.floor(Date.parse(xmlNodeValue(entry,'DAV:','getlastmodified'))/1000)||0;
      const size=Number(xmlNodeValue(entry,'DAV:','getcontentlength')||xmlNodeValue(entry,'http://owncloud.org/ns','size'))||0;
      results.push({name,path,parent:path.slice(0,path.lastIndexOf('/'))||'/',kind:collection?'folder':'file',mime,size:collection?null:size,mtime,davUrl:url.pathname});
    }
    return results.slice(0,100);
  }
  async function loadFavorites(){
    if(favoriteState.status==='loading')return;
    favoriteState.status='loading';favoriteState.error='';renderGlobalSearchResults();
    try{
      let entries;
      if(demo){
        const browseItems=Object.values(demo.browse||{}).flatMap(x=>x.items||[]);
        entries=browseItems.filter(x=>favoritePaths.has(x.path)).map(x=>({...x,parent:x.path.slice(0,x.path.lastIndexOf('/'))||'/'}));
      }else{
        const base=favoriteDavRoot();if(!base)throw Error('Racine WebDAV inconnue');
        const body='<?xml version="1.0"?><oc:filter-files xmlns:oc="http://owncloud.org/ns" xmlns:d="DAV:"><oc:filter-rules><oc:favorite>1</oc:favorite></oc:filter-rules><d:prop><d:resourcetype/><d:getcontenttype/><d:getlastmodified/><d:getcontentlength/><oc:size/><oc:favorite/></d:prop></oc:filter-files>';
        const response=await fetch(base,{method:'REPORT',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/xml;charset=UTF-8',requesttoken:csrfToken()},body});
        if(!response.ok)throw Error('HTTP '+response.status);
        entries=parseFavoriteXml(await response.text(),base);
      }
      favoriteState.items=entries;favoritePaths.clear();for(const entry of entries)favoritePaths.add(entry.path);
      favoriteState.status='ready';favoriteState.error='';
      if(activeWorkspace==='files'){
        const list=surface.querySelector('#neos-file-results');if(list)list.innerHTML=browserItems();
      }
    }catch(error){console.error('[Neos] favoris Nextcloud',error);favoriteState.status='error';favoriteState.error='Favoris indisponibles : vérifier WebDAV et les permissions.';}
    renderGlobalSearchResults();
  }
  async function toggleFavorite(entry){
    if(!entry?.path||!validFileFolderPath(entry.path))return;
    const enabled=!favoritePaths.has(entry.path);
    if(demo){enabled?favoritePaths.add(entry.path):favoritePaths.delete(entry.path);favoriteState.status='idle';await loadFavorites();return;}
    const url=favoriteDavUrl(entry.path);if(!url){toast('Chemin de favori invalide','error');return;}
    const body=`<?xml version="1.0"?><d:propertyupdate xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns"><d:set><d:prop><oc:favorite>${enabled?1:0}</oc:favorite></d:prop></d:set></d:propertyupdate>`;
    try{
      const response=await fetch(url,{method:'PROPPATCH',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/xml;charset=UTF-8',requesttoken:csrfToken()},body});
      if(!response.ok)throw Error('HTTP '+response.status);
      const reply=await response.text();
      if(/<\?xml|multistatus/i.test(reply)&&!/HTTP\/\d(?:\.\d)? 200 /i.test(reply))throw Error('Favori refusé par WebDAV');
      enabled?favoritePaths.add(entry.path):favoritePaths.delete(entry.path);
      toast(enabled?'Ajouté aux favoris Nextcloud':'Retiré des favoris','success');
      favoriteState.status='idle';await loadFavorites();
    }catch(error){console.error('[Neos] modification favori',error);toast('Favori non enregistré sur Nextcloud','error');}
  }

  // Filename search is bounded and permission-aware on the server. This is not
  // an unrestricted NAS filesystem crawler and does not search file contents.
  function searchFilterSelect(name,label,options){
    return `<label class="neos-search-filter"><span>${label}</span><select data-global-filter="${name}">${options.map(([value,text])=>`<option value="${value}" ${globalSearch[name]===value?'selected':''}>${text}</option>`).join('')}</select></label>`;
  }
  function renderGlobalSearch(){
    if(popMode!=='global-search')return;
    const search=searchPanelTab==='search';
    popHost.innerHTML=`<div class="neos-pop-layer" data-action="close-pop"><section class="neos-search-dialog neos-search-v060" role="dialog" aria-modal="true" aria-label="Recherche, favoris et fichiers récents"><header><div><strong>Accès aux fichiers</strong><p>Recherche, favoris Nextcloud et fichiers consultés</p></div><button type="button" class="neos-iconbtn" data-action="close-pop" aria-label="Fermer">${icon('close',18)}</button></header><nav class="neos-search-tabs" role="tablist" aria-label="Type de fichiers"><button type="button" role="tab" aria-selected="${search}" class="${search?'is-active':''}" data-action="search-tab" data-tab="search">${icon('search',16)} Recherche</button><button type="button" role="tab" aria-selected="${searchPanelTab==='favorites'}" class="${searchPanelTab==='favorites'?'is-active':''}" data-action="search-tab" data-tab="favorites">${icon('star',16)} Favoris</button><button type="button" role="tab" aria-selected="${searchPanelTab==='recent'}" class="${searchPanelTab==='recent'?'is-active':''}" data-action="search-tab" data-tab="recent">${icon('clock',16)} Consultés</button></nav>${search?`<label class="neos-search-dialog-input">${icon('search',19)}<input data-global-search type="search" autocomplete="off" spellcheck="false" placeholder="Nom du fichier ou dossier (2 caractères min.)" value="${esc(globalSearch.query)}"></label><div class="neos-search-filter-grid">${searchFilterSelect('type','Type',[['all','Tous'],['folder','Dossiers'],['image','Images'],['document','Documents'],['video','Vidéos'],['audio','Audio'],['other','Autres fichiers']])}${searchFilterSelect('date','Modifié',[['all','Toutes dates'],['7','7 derniers jours'],['30','30 derniers jours'],['365','12 derniers mois']])}${searchFilterSelect('size','Taille',[['all','Toutes tailles'],['small','Moins de 1 Mo'],['medium','1 à 10 Mo'],['large','10 à 100 Mo'],['huge','Plus de 100 Mo']])}${searchFilterSelect('sort','Tri',[['recent','Dernière modification'],['name','Nom'],['size','Taille décroissante']])}</div>`:''}<div class="neos-search-dialog-results" data-global-search-results role="tabpanel"></div><footer>${search?'Recherche par nom, limitée à 2 500 éléments et 6 niveaux de dossiers.':searchPanelTab==='recent'?'<span>Historique propre à ce navigateur et à ce compte.</span><button type="button" class="neos-search-clear" data-action="recent-clear">Effacer l’historique</button>':'Favoris synchronisés avec Nextcloud (WebDAV).'}</footer></section></div>`;
    renderGlobalSearchResults();
  }
  function quickResultRow(item,tab){
    const isFolder=item.kind==='folder';
    return `<div class="neos-search-quick-row"><button type="button" class="neos-search-result" data-action="search-open" data-path="${esc(item.path)}" data-parent="${esc(item.parent||'/')}"><span class="neos-search-result-icon">${icon(isFolder?'folder':String(item.mime||'').startsWith('image/')?'image':'file',19)}</span><span class="neos-search-result-name"><strong>${esc(item.name)}</strong><small>${esc(item.parent||'/')} · ${isFolder?'Dossier':humanSize(item.size)}${tab==='recent'?' · Consulté '+new Intl.DateTimeFormat('fr-FR',{day:'2-digit',month:'short'}).format(new Date(item.openedAt||Date.now())):''}</small></span>${icon('chevron',16)}</button><div class="neos-quick-actions">${!isFolder?`<button type="button" class="neos-iconbtn" data-action="quick-preview" data-path="${esc(item.path)}" title="Aperçu intégré" aria-label="Aperçu de ${esc(item.name)}">${icon('expand',16)}</button>`:''}<button type="button" class="neos-iconbtn" data-action="quick-parent" data-path="${esc(item.path)}" title="Ouvrir le dossier" aria-label="Ouvrir le dossier de ${esc(item.name)}">${icon('folder',16)}</button><button type="button" class="neos-iconbtn neos-favorite-toggle ${favoritePaths.has(item.path)?'is-on':''}" data-action="quick-favorite" data-path="${esc(item.path)}" title="${favoritePaths.has(item.path)?'Retirer des favoris':'Ajouter aux favoris'}" aria-label="${favoritePaths.has(item.path)?'Retirer des favoris':'Ajouter aux favoris'} : ${esc(item.name)}">${icon('star',16)}</button></div></div>`;
  }
  function renderGlobalSearchResults(){
    const node=popHost.querySelector('[data-global-search-results]');if(!node)return;
    if(searchPanelTab==='favorites'){
      if(favoriteState.status==='loading'){node.innerHTML='<div class="neos-search-status"><span class="neos-spinner"></span> Chargement des favoris Nextcloud…</div>';return;}
      if(favoriteState.status==='error'){node.innerHTML=`<div class="neos-search-status">${icon('alert',18)} ${esc(favoriteState.error)}</div>`;return;}
      node.innerHTML=favoriteState.items.length?`<div class="neos-search-results-list">${favoriteState.items.map(x=>quickResultRow(x,'favorites')).join('')}</div>`:'<div class="neos-search-status">Aucun favori Nextcloud. Utilise l’étoile dans Fichiers.</div>';
      return;
    }
    if(searchPanelTab==='recent'){
      node.innerHTML=recentViewed.length?`<div class="neos-search-results-list">${recentViewed.map(x=>quickResultRow(x,'recent')).join('')}</div>`:'<div class="neos-search-status">Aucun fichier consulté dans Neos avec ce navigateur.</div>';
      return;
    }
    if(globalSearch.loading){node.innerHTML='<div class="neos-search-status"><span class="neos-spinner"></span> Recherche en cours…</div>';return;}
    if(globalSearch.error){node.innerHTML=`<div class="neos-search-status">${icon('alert',18)} ${esc(globalSearch.error)}</div>`;return;}
    if(globalSearch.query.trim().length<2){node.innerHTML='<div class="neos-search-status">Saisis au moins deux caractères pour lancer la recherche.</div>';return;}
    if(!globalSearch.items.length){node.innerHTML='<div class="neos-search-status">Aucun résultat ne correspond aux filtres dans les dossiers parcourus.</div>';return;}
    node.innerHTML=`<div class="neos-search-results-list">${globalSearch.items.map(x=>quickResultRow(x,'search')).join('')}</div>${globalSearch.truncated?'<div class="neos-search-limited">Résultats partiels : limite de recherche atteinte.</div>':''}`;
  }
  async function executeGlobalSearch(){
    const requestId=++globalSearchGeneration;
    const q=globalSearch.query.trim();
    if(q.length<2){globalSearch.loading=false;globalSearch.items=[];globalSearch.error='';renderGlobalSearchResults();return;}
    globalSearch.loading=true;globalSearch.error='';renderGlobalSearchResults();
    try{
      let result;
      if(demo){
        const browses=Object.values(demo.browse||{});
        const cutoff=globalSearch.date==='all'?0:Date.now()/1000-Number(globalSearch.date)*86400;
        const mi=1024*1024;
        let items=browses.flatMap(x=>x.items||[]).filter(x=>x.name.toLocaleLowerCase('fr').includes(q.toLocaleLowerCase('fr'))).filter(x=>{
          if(number(x.mtime)<cutoff)return false;
          if(globalSearch.type==='folder')return x.kind==='folder'&&globalSearch.size==='all';
          if(globalSearch.type!=='all'){
            if(x.kind==='folder')return false;
            const mime=String(x.mime||'').toLowerCase(),extension=ext(x.name);
            const image=mime.startsWith('image/'),audio=mime.startsWith('audio/'),video=mime.startsWith('video/'),doc=mime.startsWith('text/')||['pdf','doc','docx','odt','xls','xlsx','ods','ppt','pptx','odp','txt','md','csv','rtf'].includes(extension);
            if(!({image,video,audio,document:doc,other:!image&&!video&&!audio&&!doc}[globalSearch.type]))return false;
          }
          if(globalSearch.size!=='all'){
            if(x.kind==='folder')return false;
            const z=number(x.size);
            if(globalSearch.size==='small'&&z>=mi)return false;
            if(globalSearch.size==='medium'&&(z<mi||z>=mi*10))return false;
            if(globalSearch.size==='large'&&(z<mi*10||z>=mi*100))return false;
            if(globalSearch.size==='huge'&&z<mi*100)return false;
          }
          return true;
        });
        if(globalSearch.sort==='name')items.sort((a,b)=>a.name.localeCompare(b.name,'fr'));
        else if(globalSearch.sort==='size')items.sort((a,b)=>number(b.size)-number(a.size));
        else items.sort((a,b)=>number(b.mtime)-number(a.mtime));
        result={items:items.slice(0,40).map(x=>({...x,parent:x.path?.slice(0,x.path.lastIndexOf('/'))||'/'})),truncated:items.length>40,visited:items.length};
      }else{
        const url=new URL(root.dataset.searchUrl,window.location.href);
        url.searchParams.set('q',q);
        for(const field of ['type','date','size','sort'])url.searchParams.set(field,globalSearch[field]);
        result=await api(url.toString());
      }
      if(requestId!==globalSearchGeneration||popMode!=='global-search')return;
      globalSearch.items=Array.isArray(result.items)?result.items:[];
      globalSearch.truncated=Boolean(result.truncated);globalSearch.visited=number(result.visited);
      globalSearch.loading=false;renderGlobalSearchResults();
    }catch(error){
      if(requestId!==globalSearchGeneration||popMode!=='global-search')return;
      console.error('[Neos] recherche multi-dossiers',error);
      globalSearch.loading=false;globalSearch.error='Recherche indisponible. Vérifie la mise à jour de Neos.';renderGlobalSearchResults();
    }
  }
  function openGlobalSearch(tab='search'){
    popMode='global-search';searchPanelTab=['search','favorites','recent'].includes(tab)?tab:'search';
    globalSearchGeneration++;
    renderGlobalSearch();animateLayerOpen(popHost,'.neos-search-dialog','y');
    if(searchPanelTab==='search'){
      const input=popHost.querySelector('[data-global-search]');input?.focus();input?.select();
      if(globalSearch.query.length>=2)void executeGlobalSearch();
    }else if(searchPanelTab==='favorites')void loadFavorites();
  }

  function renderHubPanel() {
    if(popMode==='destination'){renderFolderPicker();return;}
    if(popMode==='context'){renderContextMenu();return;}
    if(popMode!=='hub'){if(!fullPreview)popHost.replaceChildren();return;}
    popHost.innerHTML = `<div class="neos-pop-layer" data-action="close-pop"><div class="neos-hub-pop neos-framed" role="dialog" aria-modal="true" aria-label="Applications"><header><div class="neos-hub-header-title"><strong>Applications</strong><span>${(overview?.shortcuts || []).length} disponibles</span></div><button type="button" class="neos-iconbtn" data-action="close-pop" title="Fermer">${icon('close',18)}</button></header><div class="neos-hub-shell"><div class="neos-hub-main">${hubGrid(false)}${settings.links?.length ? `<div class="neos-hub-links">${settings.links.map(x => `<a href="${safeUrl(x.url)}" class="neos-link-card">${icon('link',14)}<span>${esc(x.title)}</span></a>`).join('')}</div>` : ''}</div></div></div></div>`;
    animateLayerOpen(popHost,'.neos-hub-pop','y');
  }

  function hidePop(){
    const finish = () => { popMode=''; fullPreview=false;pickerState=null;pickerGeneration++; popHost.replaceChildren(); };
    if(popHost.firstElementChild) animateLayerClose(popHost,'.neos-hub-pop, .neos-context-menu, .neos-fullscreen-panel, .neos-destination-dialog, .neos-search-dialog, .neos-groupware-dialog',finish,'y'); else finish();
  }

  async function load(silent=false) {
    try {
      const data = demo ? demo.overview : await api(root.dataset.overviewUrl);
      if (!data.overview || !data.settings) throw new Error('Réponse API inattendue');
      overview = data.overview;
      if (!settings || !silent) settings = { ...defaults(), ...data.settings, sizes:{...defaultSizes,...(data.settings.sizes||{})},heights:{...defaultHeights,...(data.settings.heights||{})}, topApps:data.settings.topApps || ['files','calendar','tasks','talk'], launcherMode:data.settings.launcherMode || 'topbar', gridMode:data.settings.gridMode || 'manual', accent: data.settings.accent === 'copper' ? 'cyan' : (data.settings.accent || 'cyan') };
      settings.order=[...new Set([...(Array.isArray(settings.order)?settings.order:[]),...widgetIds])];
      if(!Array.isArray(settings.hidden))settings.hidden=[];
      settings.heights={...defaultHeights,...(settings.heights||{})};
      root.dataset.displayName = data.user?.name || 'toi';
      if(root.dataset.currentUid!==String(data.user?.uid||'demo')){
        root.dataset.currentUid=String(data.user?.uid||'demo');
        readRecent();favoriteState.status='idle';favoriteState.items=[];favoritePaths.clear();
      }
      render();
      if (browser.loading || (!browser.items.length && !browser.error)) void browse(browser.path, false);
      if (activeWorkspace==='home' && !settings.hidden.includes('deck') && deckState.status==='idle') void loadDeck();
      if ((activeWorkspace==='calendar'||activeWorkspace==='tasks'||activeWorkspace==='planning') && groupware.status==='idle')void loadGroupware();
      if(activeWorkspace==='planning'&&planningDeck.status==='idle')void loadPlanningDeck();
      if (silent) toast('Actualisé','success');
    } catch (error) {
      console.error('[Neos] chargement impossible', error);
      surface.innerHTML = `<div class="neos-fatal">${icon('alert',28)}<strong>Chargement impossible</strong><button type="button" class="neos-btn" data-action="refresh">Réessayer</button></div>`;
    }
  }

  surface.addEventListener('click',event=>{
    const input=event.target.closest('input[data-file-checkbox]');
    if(!input)return;
    event.stopPropagation();
    if(fileBusy){event.preventDefault();return;}
    toggleFileSelection(input.dataset.path||'',event.shiftKey);
  });
  surface.addEventListener('click', event => {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    if (action === 'refresh') { void load(true); if(activeWorkspace==='files')void browse(browser.path,false); else if(activeWorkspace==='photos')void loadPhotos(true); else if(activeWorkspace==='deck')void loadDeck(true); else if(activeWorkspace==='notes')void loadNotes(true); else if(activeWorkspace==='calendar'||activeWorkspace==='tasks'||activeWorkspace==='planning'){void loadGroupware(true);if(activeWorkspace==='planning')void loadPlanningDeck(true);} }
    else if (action === 'customize') { if (editorOpen) closeEditor(); else openEditor(); }
    else if(action==='workspace'){if(popMode)hidePop();void chooseWorkspace(target.dataset.workspace);}
    else if(action==='global-search'){openGlobalSearch(target.dataset.tab||'search');}
    else if(action==='toggle-favorite'){const entry=browser.items.find(x=>x.path===target.dataset.path);if(entry)void toggleFavorite(entry);}
    else if(action==='home-open-folder'){const path=target.dataset.path||'/';void chooseWorkspace('files').then(()=>browse(path));}
    else if(action==='home-open-recent'){const folder=target.dataset.folder||'/';const name=target.dataset.name||'';void chooseWorkspace('files').then(async()=>{if(folder!==browser.path)await browse(folder);const entry=browser.items.find(x=>x.name===name);if(entry)void selectEntry(entry.path);});}
    else if(action==='focus-search'){void chooseWorkspace('files').then(()=>surface.querySelector('[data-browser-search]')?.focus());}
    else if(action==='finish-arrange'){editing=false;layoutAnnounce='';render();queueSave();}
    else if(action==='grid-mode'){settings.gridMode=target.dataset.mode==='manual'?'manual':'adaptive';layoutAnnounce=settings.gridMode==='manual'?'Largeurs manuelles activées.':'Mise en page adaptative activée.';queueSave();render();}
    else if(action==='widget-move'){moveWidget(target.dataset.id,Number(target.dataset.step)||0);}
    else if(action==='widget-resize'){resizeWidget(target.dataset.id,Number(target.dataset.step)||0);}
    else if(action==='widget-height'){resizeWidgetHeight(target.dataset.id,Number(target.dataset.step)||0);}
    else if(action==='deck-widget-open'){const boardId=target.dataset.boardId;void chooseWorkspace('deck').then(()=>{if(boardId)void loadDeckStacks(boardId);});}
    else if(action==='module-refresh'){if(activeWorkspace==='photos')void loadPhotos(true);else if(activeWorkspace==='deck')void loadDeck(true);else if(activeWorkspace==='notes')void loadNotes(true);}
    else if(action==='photo-open'){photoLightbox(Number(target.dataset.photoIndex));}
    else if(action==='note-select'){noteSelect(target.dataset.noteId);}
    else if(action==='note-new'){void noteCreate();}
    else if(action==='note-save'){void noteSave();}
    else if(action==='note-preview-toggle'){noteView=noteView==='edit'?'preview':'edit';render();}
    else if(action==='gw-new'){groupwareEditor(target.dataset.gwType||'task');}
    else if(action==='cal-view'){calendarView=target.dataset.view==='week'?'week':'month';render();}
    else if(action==='cal-prev'){moveCalendar(-1);}
    else if(action==='cal-next'){moveCalendar(1);}
    else if(action==='cal-today'){moveCalendar('today');}
    else if(action==='cal-day'){groupwareEditor('event',null,target.dataset.date);}
    else if(action==='cal-event'){calendarEventDetail(target.dataset.href||'');}
    else if(action==='plan-range'){planningRange=[7,30,90].includes(Number(target.dataset.days))?Number(target.dataset.days):30;if(planningRange===90&&!calendarWindowReady()&&!demo)void loadGroupware(true);else render();}
    else if(action==='plan-kind'){const kind=target.dataset.kind;if(['event','task','deck'].includes(kind)){if(planningKinds.has(kind))planningKinds.delete(kind);else planningKinds.add(kind);render();}}
    else if(action==='plan-refresh'){void loadGroupware(true);void loadPlanningDeck(true);}
    else if(action==='plan-event'){calendarEventDetail(target.dataset.href||'');}
    else if(action==='plan-task'){const entry=groupware.tasks.find(t=>t.href===target.dataset.href);if(entry)groupwareEditor('task',entry);}
    else if(action==='plan-deck'){void planningDeckOpen(target.dataset.boardId,target.dataset.stackId,target.dataset.cardId);}
    else if(action==='plan-deck-toggle'){void togglePlanningDeckDone(target.dataset.boardId,target.dataset.stackId,target.dataset.cardId);}
    else if(action==='task-view'){taskView=['open','done','all'].includes(target.dataset.view)?target.dataset.view:'open';render();}
    else if(action==='gw-refresh'){void loadGroupware(true);}
    else if(action==='gw-toggle-done'){void toggleTaskDone(target.dataset.href);}
    else if(action==='gw-edit-task'){const record=groupware.tasks.find(t=>t.href===target.dataset.href);if(record)groupwareEditor('task',record);}
    else if(action==='deck-board'){if(deckMoveBusy){toast('Déplacement en cours…');return;}void loadDeckStacks(Number(target.dataset.boardId));}
    else if(action==='deck-add'){deckCreateCard(target.dataset.stackId);}
    else if(action==='deck-card-open'){void openDeckCard(target.dataset.stackId,target.dataset.cardId);}
    else if (action === 'toggle-hub') { if(popMode === 'hub') hidePop(); else {popMode = 'hub'; renderHubPanel();} }
    else if(action==='history-back'&&historyIndex>0){historyIndex--;void browse(history[historyIndex],true,false);}
    else if(action==='history-forward'&&historyIndex<history.length-1){historyIndex++;void browse(history[historyIndex],true,false);}
    else if (action === 'browse-path') { if((event.ctrlKey||event.metaKey||event.shiftKey)&&target.closest('[data-file-row]'))toggleFileSelection(target.dataset.path||'',event.shiftKey);else void browse(target.dataset.path || '/'); }
    else if (action === 'reload-folder') { void browse(browser.path, false); }
    else if (action === 'toggle-view') { browser.view = browser.view === 'grid' ? 'list' : 'grid'; render(); }
    else if (action === 'pin-folder') {
      const path = target.dataset.path; if (!path) return;
      const current = settings.pins || [];
      settings.pins = current.includes(path) ? current.filter(x => x !== path) : [...current, path].slice(0,12);
      queueSave(); render();
    }
    else if (action === 'select-entry') { if(event.ctrlKey||event.metaKey||event.shiftKey)toggleFileSelection(target.dataset.path||'',event.shiftKey);else void selectEntry(target.dataset.path || ''); }
    else if(action==='file-menu'){contextPath=target.dataset.path||'';popMode='context';renderContextMenu();}
    else if(action==='files-select-all'){selectAllFiles();}
    else if(action==='files-clear'){fileSelection.clear();fileAnchorPath='';refreshSelectionDisplay();}
    else if(action==='files-copy'){copyOrCutFiles('copy');}
    else if(action==='files-cut'){copyOrCutFiles('cut');}
    else if(action==='files-delete'){void deleteFiles();}
    else if(action==='files-paste'){void pasteFiles();}
    else if(action==='files-cancel-paste'){fileClipboard.mode='';fileClipboard.entries=[];refreshSelectionDisplay();}
    else if(action==='files-duplicate'){void duplicateFiles();}
    else if(action==='files-copy-to'){openDestinationPicker('copy');}
    else if(action==='files-move-to'){openDestinationPicker('cut');}
    else if(action==='copy-selected-link'){void copyCurrentLink(preview.entry);}
    else if(action==='download-selected'){downloadCurrent(preview.entry);}
    else if(action==='share-selected'){void shareEntry(preview.entry);}
    else if(action==='expand-preview'){fullPreview=true;renderFullPreview();}
    else if(action==='preview-markdown'){markdownPreview=!markdownPreview;renderPreview();}
    else if(action==='new-folder'){void createFolder();}
    else if(action==='upload-trigger'){surface.querySelector('[data-upload-input]')?.click();}
    else if (action === 'open-file') { const entry = browser.items.find(x => x.path === target.dataset.path); if (entry?.url) window.location.assign(entry.url); }
    else if (action === 'save-note') { settings.notes = surface.querySelector('#neos-note')?.value || ''; queueSave(); toast('Note enregistrée', 'success'); }
    else if (action === 'preview-dav') { void previewFromDav(target.dataset.url || '', target.dataset.name || '', target.dataset.mime || '', Number(target.dataset.size)||0, target.dataset.path||''); }
    pulse(target);
  });

  surface.addEventListener('input', event => {
    const el = event.target;
    if(el.matches('[data-browser-search]')){ browser.query=el.value; const results=surface.querySelector('#neos-file-results');if(results)results.innerHTML=browserItems();const tb=surface.querySelector('[data-selection-toolbar]');if(tb)tb.innerHTML=selectionToolbar(); } 
    if (el.matches('#neos-note')) settings.notes = el.value;
    if(el.matches('[data-note-title]')){notesState.draftTitle=el.value;notesState.dirty=true;surface.querySelector('[data-note-status]')?.replaceChildren(document.createTextNode('Modifications non enregistrées'));}
    if(el.matches('[data-note-content]')){notesState.draftContent=el.value;notesState.dirty=true;surface.querySelector('[data-note-status]')?.replaceChildren(document.createTextNode('Modifications non enregistrées'));const count=surface.querySelector('[data-note-count]');if(count)count.textContent=(el.value.trim()?el.value.trim().split(/\s+/).length:0)+' mots';}
  });
  surface.addEventListener('change', event => {
    const uploadEl = event.target;
    if(uploadEl.matches('[data-upload-input]')){ const files=uploadEl.files; void uploadSelection(files); uploadEl.value=''; }
  });
  surface.addEventListener('change', event => {
    const el = event.target;
    if(el.matches('[data-browser-sort]')){ browser.sort=el.value; const results=surface.querySelector('#neos-file-results');if(results)results.innerHTML=browserItems();const tb=surface.querySelector('[data-selection-toolbar]');if(tb)tb.innerHTML=selectionToolbar();animateRows(); }
    if(el.matches('[data-browser-type]')){ browser.type=el.value; const results=surface.querySelector('#neos-file-results');if(results)results.innerHTML=browserItems();const tb=surface.querySelector('[data-selection-toolbar]');if(tb)tb.innerHTML=selectionToolbar();animateRows(); }
  });

  popHost.addEventListener('change',event=>{
    const select=event.target.closest('[data-global-filter]');if(!select)return;
    globalSearch[select.dataset.globalFilter]=select.value;
    globalSearchGeneration++;clearTimeout(globalSearchTimer);
    if(globalSearch.query.trim().length>=2)void executeGlobalSearch();else renderGlobalSearchResults();
  });
  popHost.addEventListener('input',event=>{
    if(!event.target.matches('[data-global-search]'))return;
    globalSearch.query=event.target.value.slice(0,100);
    globalSearchGeneration++;
    globalSearch.items=[];globalSearch.error='';
    clearTimeout(globalSearchTimer);
    if(globalSearch.query.trim().length<2){globalSearch.loading=false;renderGlobalSearchResults();return;}
    globalSearch.loading=true;renderGlobalSearchResults();
    globalSearchTimer=setTimeout(()=>void executeGlobalSearch(),340);
  });
  popHost.addEventListener('input',event=>{
    if(!event.target.matches('[data-destination-search]')||!pickerState)return;
    pickerState.search=event.target.value;
    const target=popHost.querySelector('[data-destination-results]');
    if(target){const q=pickerState.search.toLocaleLowerCase('fr');const found=pickerState.folders.filter(f=>f.name.toLocaleLowerCase('fr').includes(q));
      target.innerHTML=found.map(f=>`<button type="button" class="neos-destination-folder" data-action="destination-browse" data-path="${esc(f.path)}">${icon('folder',19)}<span>${esc(f.name)}</span>${icon('chevron',16)}</button>`).join('')||'<div class="neos-destination-empty">Aucun dossier correspondant</div>';
    }
  });
  uploadHost.addEventListener('click',event=>{
    const btn=event.target.closest('[data-upload-action]');if(!btn)return;
    if(btn.dataset.uploadAction==='cancel'&&uploadState.active){uploadState.cancel=true;uploadState.xhr?.abort();uploadProgressUi();}
    else if(btn.dataset.uploadAction==='dismiss'&&!uploadState.active){uploadState.finished=false;uploadProgressUi();}
  });

  editorHost.addEventListener('click', event => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    const action = actionEl.dataset.action;
    if (action === 'editor-backdrop' && event.target === actionEl) { closeEditor(); return; }
    if (action === 'close-editor') { closeEditor(); return; }
    if (action === 'arrange') { closeEditor(true); return; }
    if (action === 'add-link') { harvestLinks(); if ((settings.links || []).length < 12) settings.links.push({title:'Lien', url:'/'}); queueSave(); renderEditor(); render(); }
    if (action === 'remove-link') { harvestLinks(); settings.links.splice(Number(actionEl.dataset.index), 1); queueSave(); renderEditor(); render(); }
    if (action === 'move-up' || action === 'move-down') {
      const id = actionEl.dataset.id; const idx = settings.order.indexOf(id); const next = idx + (action === 'move-up' ? -1 : 1); if (idx < 0 || next < 0 || next >= settings.order.length) return;
      [settings.order[idx], settings.order[next]] = [settings.order[next], settings.order[idx]]; queueSave(); renderEditor(); render();
    }
  });
  editorHost.addEventListener('change', event => {
    const el = event.target;
    if (el.matches('input[type="radio"]')) {
      settings[el.name] = el.value;
      if (el.name === 'launcherMode' && el.value === 'widget') settings.hidden = settings.hidden.filter(id=>id!=='shortcuts');
      queueSave(); render();
      if (el.name === 'launcherMode' || el.name === 'gridMode') renderEditor();
    }
    else if (el.matches('[data-toggle]')) { const id = el.dataset.toggle; settings.hidden = el.checked ? settings.hidden.filter(x => x !== id) : [...settings.hidden, id]; queueSave(); render(); if(id==='deck'&&el.checked&&deckState.status==='idle')void loadDeck(); }
    else if (el.matches('[data-size]')) { settings.sizes[el.dataset.size] = Number(el.value); queueSave(); render(); }
    else if (el.matches('[data-height]')) { settings.heights[el.dataset.height] = Number(el.value); queueSave(); render(); }
    else if (el.matches('[data-topapp]')) {
      const id = el.dataset.topapp;
      settings.topApps = el.checked ? [...new Set([...(settings.topApps || []), id])] : (settings.topApps || []).filter(x => x !== id);
      queueSave(); render();
    }
    else if (el.matches('[data-link-title],[data-link-url]')) { harvestLinks(); queueSave(); }
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (editorOpen) { event.preventDefault(); closeEditor(); }
      else if (popMode || fullPreview) { event.preventDefault(); hidePop(); }
    }
    if(popMode==='deck-card'&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();void saveDeckCard();return;}
    if(!editorOpen&&!popMode&&!fullPreview&&activeWorkspace==='notes'&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();void noteSave();return;}
    if(!editorOpen&&!popMode&&!fullPreview&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();openGlobalSearch();return;}
    if(!editorOpen&&!popMode&&!fullPreview&&activeWorkspace==='files'&& !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||'')){
      const key=event.key.toLowerCase();
      if((event.ctrlKey||event.metaKey)&&key==='a'){event.preventDefault();selectAllFiles();}
      else if((event.ctrlKey||event.metaKey)&&key==='c'&&fileSelection.size){event.preventDefault();copyOrCutFiles('copy');}
      else if((event.ctrlKey||event.metaKey)&&key==='x'&&fileSelection.size){event.preventDefault();copyOrCutFiles('cut');}
      else if((event.ctrlKey||event.metaKey)&&key==='v'&&fileClipboard.entries.length){event.preventDefault();void pasteFiles();}
      else if(event.key==='Delete'&&fileSelection.size){event.preventDefault();void deleteFiles();}
    }
    if(!editorOpen&&!popMode&&!fullPreview&&event.key==='/'&&!/INPUT|TEXTAREA/.test(document.activeElement?.tagName||'')){event.preventDefault();if(activeWorkspace!=='files')void chooseWorkspace('files').then(()=>surface.querySelector('[data-browser-search]')?.focus());else surface.querySelector('[data-browser-search]')?.focus();}
  }, true);
  popHost.addEventListener('click', event => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    const action=actionEl.dataset.action;
    if(action==='workspace') { const id=actionEl.dataset.workspace; hidePop(); void chooseWorkspace(id); return; }
    if(action==='gw-save'){void saveGroupware();return;}
    if(action==='deck-card-close'){hidePop();return;}
    if(action==='deck-card-save'){void saveDeckCard();return;}
    if(action==='search-tab'){
      searchPanelTab=actionEl.dataset.tab||'search';renderGlobalSearch();
      if(searchPanelTab==='favorites')void loadFavorites();
      if(searchPanelTab==='search'){popHost.querySelector('[data-global-search]')?.focus();}
      return;
    }
    if(action==='recent-clear'){
      recentViewed.splice(0);
      try{localStorage.removeItem(recentStorageKey());}catch{/* No local persistence */}
      renderGlobalSearchResults();toast('Historique local effacé','success');return;
    }
    if(action==='quick-favorite'){
      const path=actionEl.dataset.path;
      const entry=[...favoriteState.items,...recentViewed,...globalSearch.items].find(x=>x.path===path);
      if(entry)void toggleFavorite(entry);
      return;
    }
    if(action==='quick-preview'||action==='quick-parent'){
      const path=actionEl.dataset.path||'';
      const target=[...globalSearch.items,...favoriteState.items,...recentViewed].find(x=>x.path===path);
      if(!target)return;
      globalSearchGeneration++;clearTimeout(globalSearchTimer);popMode='';popHost.replaceChildren();
      void (async()=>{
        await chooseWorkspace('files');
        await browse(target.parent||target.path.slice(0,target.path.lastIndexOf('/'))||'/',true);
        if(action==='quick-preview'&&target.kind==='file'){await selectEntry(target.path);fullPreview=true;renderFullPreview();}
      })();
      return;
    }
    if(action==='search-open'){
      const path=actionEl.dataset.path||'';
      const parent=actionEl.dataset.parent||'/';
      const target=[...globalSearch.items,...favoriteState.items,...recentViewed].find(x=>x.path===path);
      if(!target)return;
      globalSearchGeneration++;clearTimeout(globalSearchTimer);
      hidePop();
      void (async()=>{
        await chooseWorkspace('files');
        await browse(target.kind==='folder'?path:parent,true);
        if(target.kind==='file')await selectEntry(path);
      })();
      return;
    }
    if(action==='close-full-preview'){if(event.target===actionEl||actionEl.tagName==='BUTTON'){hidePop();}return;}
    if(action==='download-selected'){downloadCurrent(preview.entry);return;}
    if(action==='preview-markdown'){markdownPreview=!markdownPreview;renderFullPreview();return;}
    if(action==='destination-close'){pickerGeneration++;pickerState=null;hidePop();return;}
    if(action==='destination-up'){const parts=pickerState?.path.split('/').filter(Boolean)||[];parts.pop();void browseDestination('/'+parts.join('/'));return;}
    if(action==='destination-browse'){void browseDestination(actionEl.dataset.path||'/');return;}
    if(action==='destination-confirm'){destinationConfirm();return;}
    if(action==='menu-copy-to'||action==='menu-move-to'){
      const entry=browser.items.find(x=>x.path===contextPath);
      if(entry)openDestinationPicker(action==='menu-move-to'?'cut':'copy',[entry]);
      return;
    }
    if(['menu-preview','menu-download','menu-copy','menu-share','menu-rename','menu-delete','menu-open-folder','menu-duplicate','menu-cut','menu-copy-file','menu-favorite'].includes(action)){const entry=browser.items.find(x=>x.path===contextPath);if(!entry)return;hidePop();if(action==='menu-preview')void selectEntry(contextPath);else if(action==='menu-download')downloadCurrent(entry);else if(action==='menu-favorite')void toggleFavorite(entry);else if(action==='menu-copy')void copyCurrentLink(entry);else if(action==='menu-share')void shareEntry(entry);else if(action==='menu-rename')void renameEntry(entry);else if(action==='menu-delete')void deleteEntry(entry);else if(action==='menu-open-folder')void browse(entry.path);else if(action==='menu-duplicate')void duplicateFiles([entry]);else if(action==='menu-cut')copyOrCutFiles('cut',[entry]);else if(action==='menu-copy-file')copyOrCutFiles('copy',[entry]);return;}
    if(action==='close-pop'){if(event.target===actionEl||actionEl.tagName==='BUTTON'){hidePop();}}
  });

  function flashLayoutOrder(changedId){
    const cards=[...surface.querySelectorAll('.neos-home-grid [data-widget]')];
    if(motionEnabled()){
      cards.slice(0,12).forEach((el,i)=>el.animate?.([{opacity:.75,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}],{duration:320*motionFactor(),delay:i*18*motionFactor(),easing:'cubic-bezier(.16,1,.3,1)'}));
    }
    const moved=surface.querySelector(`.neos-home-grid [data-widget="${changedId}"]`);
    moved?.classList.add('neos-just-moved');
    setTimeout(()=>moved?.classList.remove('neos-just-moved'),750);
  }
  function reorderWidget(id,targetId,after=false){
    if(!editing||activeWorkspace!=='home'||!widgetIds.includes(id)||!widgetIds.includes(targetId)||id===targetId)return;
    const next=[...settings.order];const from=next.indexOf(id);if(from<0)return;
    next.splice(from,1);
    let at=next.indexOf(targetId);if(at<0)return;
    if(after)at++;
    next.splice(at,0,id);
    settings.order=next;
    layoutAnnounce=`${widgetLabels[id]} déplacé.`;
    queueSave();render();flashLayoutOrder(id);
  }
  function moveWidget(id,delta){
    const visible=settings.order.filter(key=>!settings.hidden.includes(key)&&(key!=='shortcuts'||settings.launcherMode==='widget'));
    const i=visible.indexOf(id);const to=visible[i+delta];if(!to)return;
    reorderWidget(id,to,delta>0);
  }
  function resizeWidget(id,delta){
    if(settings.gridMode!=='manual')return;
    const current=widgetSpan(id);const idx=allowedSizes.indexOf(current);
    const next=allowedSizes[Math.max(0,Math.min(allowedSizes.length-1,idx+delta))];
    if(next===current)return;
    settings.sizes[id]=next;layoutAnnounce=`${widgetLabels[id]} : ${Math.round(next/12*100)} % de largeur.`;
    queueSave();render();flashLayoutOrder(id);
  }
  function resizeWidgetHeight(id,delta){
    if(settings.gridMode!=='manual')return;
    const current=widgetMinHeight(id);const i=allowedHeights.indexOf(current);
    let next=allowedHeights[Math.max(0,Math.min(allowedHeights.length-1,i+delta))];
    if(delta>0&&current===0){
      const card=surface.querySelector(`.neos-home-grid [data-widget="${id}"]`);
      const naturalHeight=Math.ceil((card?.getBoundingClientRect().height||160)+20);
      next=allowedHeights.find(h=>h>=naturalHeight)||allowedHeights[allowedHeights.length-1];
    }
    if(next===current)return;
    settings.heights[id]=next;
    layoutAnnounce=`${widgetLabels[id]} : hauteur ${next?next+' pixels':'automatique'}.`;
    queueSave();render();flashLayoutOrder(id);
  }
  function clearDropGuide(){surface.querySelectorAll('.neos-drop-before,.neos-drop-after,.neos-is-dragging').forEach(el=>el.classList.remove('neos-drop-before','neos-drop-after','neos-is-dragging'));}
  function clearDeckDropGuide(){surface.querySelectorAll('.neos-deck-drop-target,.neos-deck-dragging').forEach(el=>el.classList.remove('neos-deck-drop-target','neos-deck-dragging'));}
  surface.addEventListener('dragstart',event=>{
    if(activeWorkspace!=='deck'||deckMoveBusy||deckState.status!=='ready')return;
    const card=event.target.closest('.neos-deck-card[data-card-id]');if(!card)return;
    deckDrag={boardId:String(deckState.boardId),cardId:card.dataset.cardId,stackId:card.dataset.stackId};
    if(event.dataTransfer){event.dataTransfer.setData('application/x-neos-deck-card',JSON.stringify(deckDrag));event.dataTransfer.effectAllowed='move';}
    card.classList.add('neos-deck-dragging');
  });
  surface.addEventListener('dragover',event=>{
    if(activeWorkspace!=='deck'||!deckDrag||deckMoveBusy)return;
    const stack=event.target.closest('[data-deck-drop-stack]');if(!stack)return;
    event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect='move';
    clearDeckDropGuide();stack.closest('.neos-stack')?.classList.add('neos-deck-drop-target');
  });
  surface.addEventListener('drop',event=>{
    if(activeWorkspace!=='deck'||!deckDrag)return;
    const stack=event.target.closest('[data-deck-drop-stack]');
    if(!stack)return;
    event.preventDefault();
    const source=deckDrag;deckDrag=null;clearDeckDropGuide();
    if(String(source.boardId)!==String(deckState.boardId))return;
    void moveDeckCard(source.stackId,source.cardId,stack.dataset.deckDropStack);
  });
  surface.addEventListener('dragend',()=>{deckDrag=null;clearDeckDropGuide();});

  // File rows may be dragged to another directory. OS file drops upload to
  // that directory. Modifier Ctrl/Cmd on drop means COPY; otherwise MOVE.
  function dropFolderForEvent(event){
    const target=event.target.closest('[data-drop-folder]');
    return target?.dataset.dropFolder||browser.path;
  }
  function clearFileDropGuide(){surface.querySelectorAll('.neos-file-drop-target').forEach(el=>el.classList.remove('neos-file-drop-target'));}
  surface.addEventListener('dragstart',event=>{
    if(activeWorkspace!=='files'||fileBusy)return;
    const row=event.target.closest('[data-file-row]');if(!row)return;
    const path=row.dataset.fileRow;
    if(!fileSelection.has(path)){fileSelection.clear();fileSelection.add(path);fileAnchorPath=path;}
    fileDragPaths=[...fileSelection];
    event.dataTransfer?.setData('application/x-neos-files+json',JSON.stringify(fileDragPaths));
    if(event.dataTransfer)event.dataTransfer.effectAllowed='copyMove';
    row.classList.add('neos-file-dragging');
    const toolbar=surface.querySelector('[data-selection-toolbar]');if(toolbar)toolbar.innerHTML=selectionToolbar();
  });
  surface.addEventListener('dragover',event=>{
    if(activeWorkspace!=='files'||fileBusy)return;
    const types=[...(event.dataTransfer?.types||[])];
    if(!types.includes('Files')&&!types.includes('application/x-neos-files+json'))return;
    event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect=types.includes('Files')?'copy':event.ctrlKey||event.metaKey?'copy':'move';
    clearFileDropGuide();
    const target=event.target.closest('[data-drop-folder]');
    if(target){target.classList.add('neos-file-drop-target');dropZonePath=target.dataset.dropFolder||browser.path;}
  });
  surface.addEventListener('dragleave',event=>{
    if(activeWorkspace!=='files')return;
    if(!event.relatedTarget?.closest?.('[data-drop-folder]'))clearFileDropGuide();
  });
  surface.addEventListener('drop',event=>{
    if(activeWorkspace!=='files'||fileBusy)return;
    const types=[...(event.dataTransfer?.types||[])];
    if(!types.includes('Files')&&!types.includes('application/x-neos-files+json'))return;
    event.preventDefault();
    const targetFolder=dropFolderForEvent(event);
    clearFileDropGuide();dropZonePath='';
    if(types.includes('Files')){
      const list=event.dataTransfer?.files;
      if(list?.length)void uploadSelection(list,targetFolder);
      return;
    }
    const raw=event.dataTransfer?.getData('application/x-neos-files+json')||'[]';
    let paths=[];try{paths=JSON.parse(raw);}catch{return;}
    if(!Array.isArray(paths)||!paths.every(p=>typeof p==='string'))return;
    const entries=browser.items.filter(x=>paths.includes(x.path));
    if(!entries.length)return;
    const mode=(event.ctrlKey||event.metaKey)?'copy':'cut';
    if(mode==='cut'&&!window.confirm(`Déplacer ${entries.length} élément${entries.length>1?'s':''} vers ${targetFolder} ?`))return;
    void transferFiles(entries,targetFolder,mode);
  });
  surface.addEventListener('dragend',()=>{fileDragPaths=[];clearFileDropGuide();surface.querySelectorAll('.neos-file-dragging').forEach(el=>el.classList.remove('neos-file-dragging'));});

  surface.addEventListener('dragstart',event=>{
    if(!editing||activeWorkspace!=='home')return;
    const handle=event.target.closest('[data-drag-widget]');
    const id=handle?.dataset.dragWidget;if(!id)return;
    dragWidgetId=id;
    event.dataTransfer?.setData('text/plain',id);
    if(event.dataTransfer)event.dataTransfer.effectAllowed='move';
    surface.querySelector(`.neos-home-grid [data-widget="${id}"]`)?.classList.add('neos-is-dragging');
  });
  surface.addEventListener('dragover',event=>{
    if(!editing||!dragWidgetId)return;
    const target=event.target.closest('.neos-home-grid [data-widget]');if(!target||target.dataset.widget===dragWidgetId)return;
    event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect='move';
    clearDropGuide();
    const bounds=target.getBoundingClientRect();
    const midpoint=bounds.left+bounds.width/2;
    const after=Math.abs(event.clientX-midpoint)<14 ? settings.order.indexOf(dragWidgetId)<settings.order.indexOf(target.dataset.widget) : event.clientX>midpoint;
    target.classList.add(after?'neos-drop-after':'neos-drop-before');
    surface.querySelector(`.neos-home-grid [data-widget="${dragWidgetId}"]`)?.classList.add('neos-is-dragging');
  });
  surface.addEventListener('drop',event=>{
    if(!editing||!dragWidgetId)return;
    const target=event.target.closest('.neos-home-grid [data-widget]');
    if(!target){clearDropGuide();dragWidgetId='';return;}
    event.preventDefault();
    const rect=target.getBoundingClientRect();const midpoint=rect.left+rect.width/2;
    const after=Math.abs(event.clientX-midpoint)<14 ? settings.order.indexOf(dragWidgetId)<settings.order.indexOf(target.dataset.widget) : event.clientX>midpoint;
    const from=dragWidgetId;dragWidgetId='';clearDropGuide();reorderWidget(from,target.dataset.widget,after);
  });
  surface.addEventListener('dragend',()=>{dragWidgetId='';clearDropGuide();});

  surface.addEventListener('pointermove', event => {
    if (!motionEnabled() || event.pointerType === 'touch') return;
    const card = event.target.closest('.neos-card'); if (!card) return;
    const rect = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${event.clientX - rect.left}px`); card.style.setProperty('--my', `${event.clientY - rect.top}px`);
  }, { passive:true });

  window.matchMedia?.('(prefers-color-scheme: light)').addEventListener?.('change',()=>{if(settings?.theme==='system')applyTheme();});
  root.addEventListener('error',event=>{
    const img=event.target;
    if(!(img instanceof HTMLImageElement))return;
    if(img.dataset.davFallback && img.dataset.davFallback!=='#' && !img.dataset.fallbackUsed){
      img.dataset.fallbackUsed='1';img.src=img.dataset.davFallback;return;
    }
    if(img.matches('.neos-thumb,.neos-office-thumb') || img.dataset.fallbackUsed){img.style.display='none';}
  },true);
  clockTimer = setInterval(updateClock, 30000);
  void load();
  launchDatafield();
})();
