# Neos v0.6.7 — Installation OMV / Nextcloud 35

Cette version conserve le design **Flat Cyber** et la même application `novadashboard`. **Aucune modification du proxy, de la politique CSP, des volumes Docker ou de la base de données** n'est nécessaire. Sauvegarde préalable obligatoire.

## Ce qui est corrigé

Le diagnostic sur le NAS montre que `GET card-1.ics` répond **200**, que le `REPORT` est accepté (**207**), mais que l'écriture `PUT` du calendrier virtuel `app-generated--deck--board-1` répond **404**. Il s'agit d'un calendrier exporté par **Deck en lecture seule**. Neos 0.6.7 détecte ces objets et redirige leur modification vers l'**API REST Deck**, puis vérifie l'état sauvegardé. Il refuse d'écrire sur les calendriers Deck virtuels. Les vraies tâches CalDAV continuent d'utiliser GET/REPORT/PUT protégé par UID et ETag.

## Nouveautés Planning

Les cartes Deck **sans échéance** sont incluses dans la section correspondante, avec un bouton de validation rapide via l'API Deck. Les compteurs distinguent tâches et cartes ; les doublons entre Deck et ses calendriers virtuels ne sont plus intégrés dans la chronologie. Le Planning est actualisé après les modifications Deck.

**Limites :** tests de code et tests Chromium sur aperçu **simulé** ; nous ne disposons pas d'accès à ton NAS, donc la correction reste à valider sur Nextcloud 35 réel. Si tu n'as pas le droit de modifier un tableau Deck, Neos ne peut pas contourner cette restriction.

## A. Sur Windows — PowerShell, une commande à la fois

Enregistre `neos-nextcloud35-v0.6.7.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.7.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## B. Sur OMV — contrôles et sauvegarde

Exécute **séparément** chaque commande. Avant d'installer, vérifie `maintenance: false` et `needsDbUpgrade: false` :

```bash
sudo docker exec nextcloud occ status
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé : $APP_PATH"
```

**STOP** si la ligne « Neos trouvé » n'est pas affichée.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v067.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v067.tar.gz
```

**STOP** si l'archive de sauvegarde n'existe pas.

## C. Sur OMV — installation

```bash
mkdir -p /tmp/neos-v067
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.7.zip /tmp/neos-v067
```

```bash
test -f /tmp/neos-v067/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**STOP** si « Archive prête » ne s'affiche pas.

```bash
sudo docker cp /tmp/neos-v067/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Attendu : `novadashboard: 0.6.7` (le format exact dépend de la version `occ`). Dans le navigateur : **Ctrl + F5**.

## D. Tests après mise à jour

1. Dans **Tâches**, retrouve une carte qui provient d'un tableau Deck. Une étiquette **Deck** apparaît. Coche-la, recharge la page, vérifie qu'elle reste terminée ; teste aussi la réouverture.
2. Dans **F12 → Réseau**, confirme que cette action utilise `/apps/deck/api/v1.0/boards/.../cards/...` pour écrire, **sans `PUT` vers `app-generated--deck--board-1/card-1.ics`**.
3. Teste une vraie tâche CalDAV, créée dans une liste modifiable ; sa validation doit toujours fonctionner.
4. Dans **Planning**, teste le bouton Terminer d'une carte sans échéance et vérifie les compteurs, puis ouvre une carte Deck depuis la chronologie.
5. Vérifie Agenda Mois/Semaine, Explorateur, Notes, Deck et aperçu PDF comme régression de base.

**Confidentialité :** dans F12, masque les cookies de session, `requesttoken` et URL personnelles avant de partager une capture.

## E. Retour à la v0.6.6 si nécessaire

Exécute les deux commandes suivantes sur le NAS (dans **la même session SSH** où `APP_PATH` a été défini). Elles remplacent les fichiers de la v0.6.7 par la sauvegarde précédente :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v067.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Actualise ensuite le navigateur avec **Ctrl + F5**.

## Aperçu et captures

L'archive inclut `APERCU-Neos-v0.6.7.html` et le dossier `CAPTURES/` avec les captures d'un **aperçu à données simulées**. Ces captures ne sont pas des images de ton instance Nextcloud réelle.
