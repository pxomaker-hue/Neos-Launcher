## 0.6.4 — Agenda mois/semaine et correctif Tâches

- Agenda : vues mensuelle et hebdomadaire, navigation par période, sélection de date et détails événementiels.
- Recherche CalDAV recalée sur la période consultée, et rechargement si nécessaire.
- Tâches : ne plus afficher de lien vers l’application native non installée, évitant une cause possible de 404.
- Diagnostics VTODO explicites (aucune liste, erreur 404 ou permission) sans bloquer Agenda.
- Filtres de tâches À faire / Terminées / Toutes.
- Aucune modification de la configuration de sécurité Nextcloud ou du design général.

## 0.6.3

- Agenda CalDAV : découverte des calendriers accessibles, événements des 60 prochains jours, création avec date, durée, lieu et description.
- Tâches CalDAV : liste, création, édition titre/description/échéance, marquage terminé et réouverture.
- Requêtes CalDAV avec session Nextcloud, If-None-Match pour les créations et If-Match/ETag pour les modifications.
- Design Flat Cyber inchangé et modules mobiles.
- Aucun changement de données ni migration de base de données.

## 0.6.2 — 11 novembre 2026

- Deck : dialogue de création avec description Markdown et échéance.
- Deck : édition de la colonne, de l’échéance et de l’état terminé.
- Deck : glisser-déposer entre les colonnes, avec vérification de la position après écriture pour éviter les faux succès de certaines versions de Deck.
- Conservation du correctif PDF et favoris WebDAV de v0.6.1.1.
- Compatibilité Nextcloud 35 et identifiant `novadashboard` conservés.

## 0.6.1

- Aperçu PDF : liens de repli vers le PDF authentifié et l’app Fichiers lorsqu’un navigateur refuse l’iframe. Pas de modification de la politique de sécurité.

- Lecteurs multimédias audio/vidéo intégrés à l’explorateur, sous réserve des codecs navigateur.
- Aperçu Markdown sûr (texte brut / rendu), sans HTML exécutable.
- Recherche : actions rapides aperçu, ouvrir le dossier, favoris.
- Notes : aperçu Markdown, compteur de mots, Ctrl+S.
- Deck : affichage et édition du titre/de la description des cartes via API Deck, en préservant les autres champs.
- Sans changement des données, de la base ni du chemin `/data`.

## v0.6.0 — Recherche filtrée, favoris Nextcloud et fichiers consultés (2026-11-10)

- Recherche globale : filtres par catégorie (documents, images, audio, vidéo, dossiers), date de modification et tranches de taille, tri par nom, taille ou date. Les restrictions de visite et de permissions sont conservées.
- Favoris natifs Nextcloud : étoiler/désétoiler fichiers et dossiers avec PROPPATCH WebDAV ; liste des favoris du compte avec REPORT WebDAV. Distinct des raccourcis de dossiers de l’accueil.
- Fichiers récemment consultés dans Neos : liste de 24 chemins par compte, enregistrée uniquement dans le navigateur local (sans contenu de fichiers). Les entrées disparues ne sont pas réouvertes sans recontrôle Nextcloud.
- Palette Ctrl+K à trois vues : Recherche / Favoris / Consultés ; accès rapide depuis Fichiers.
- Style Flat Cyber v0.5.9 préservé ; pas de changement de configuration serveur ni de migrations SQL.

## 0.5.9 — Volume et recherche multi-dossiers
- Affichage admin uniquement de la capacité du système de fichiers contenant le répertoire de données Nextcloud, séparée du quota utilisateur.
- Recherche de fichiers et dossiers par nom dans plusieurs dossiers, authentifiée et limitée à 2 500 entrées et 6 niveaux.
- Palette de recherche avec raccourci Ctrl+K, résultats cliquables et indication des résultats partiels.
- Conservation des fonctionnalités et animations de la v0.5.8.

## 0.5.8 — File Manager Productivity + Animated Header

- Sélecteur de destination pour copier ou déplacer les éléments sélectionnés sans ouvrir manuellement le dossier cible ; navigation par dossiers, fil d’Ariane et filtre local.
- Actions contextuelles « Copier vers… » et « Déplacer vers… » reliées au sélecteur.
- Téléversements avec progression réelle en octets via XMLHttpRequest, affichage d’état et annulation de la requête active.
- Conservation des protections WebDAV (`Overwrite: F`, `If-None-Match: *`) et des droits Nextcloud ; aucun écrasement automatique.
- Animations de la bannière : arcs orbitaux, traces diagonales et indicateur lumineux, réglables par les préférences de mouvement.
- Identité Flat Cyber, widgets et explorateur de la v0.5.7 préservés.

## 0.5.7 — File Manager Pro

- Sélection multiple par cases à cocher, Maj+clic et Ctrl/Cmd+clic.
- Commandes de sélection globale et raccourcis Ctrl/Cmd+A, C, X, V, Suppr dans l’onglet Fichiers.
- Presse-papiers interne Neos pour copier et déplacer entre dossiers, sans navigation hors du dashboard.
- Duplication avec suffixes « copie », « copie 2 »… en cas de conflit.
- Glisser-déposer d’éléments dans les dossiers (déplacer ; Ctrl/Cmd pour copier) et de fichiers du PC pour téléverser.
- Actions groupées : copier, déplacer, dupliquer, supprimer avec confirmation.
- WebDAV MOVE/COPY sans écrasement (`Overwrite: F`) et téléversement conditionnel (`If-None-Match: *`).
- Conservation de l’identité Flat Cyber, des fonds et des widgets holographiques de la v0.5.6.

## 0.5.6 — Widget motion / uniform design

- Horloge holographique à aiguilles synchronisées à l’heure locale.
- Visualisation de stockage animée, avec quota illimité clairement indiqué.
- Suppression des traits animés placés en haut des widgets.
- Uniformisation visuelle des modules Notes, Deck, Photos, Agenda, Tâches et Fichiers.
- Icône Accueil du hub chargée via un nouveau nom de fichier pour éviter les anciens caches.
- Animations décoratives intégrées au contenu, désactivables via les préférences de mouvement.

## 0.5.5 — Sliding Tabs / Layout Sandbox
- Nouvelle icône Accueil fournie par l’utilisateur, recadrée et optimisée en PNG transparent pour le hub.
- Retour aux pictogrammes SVG plats en topbar ; hub et topbar utilisent deux présentations distinctes.
- Véritable curseur d’onglet actif mobile : capsule glissante avec largeur animée et déplacement selon les positions réelles.
- Grille de placement 12 colonnes visible en mode réorganisation et zones de dépôt plus lisibles.
- Microanimations locales : signal de widget, jauge de stockage, icône horloge et listes Deck.
- Réduction des animations : préférences de mouvement et `prefers-reduced-motion` respectées.
- Aucune modification des routes d’API ou du stockage Nextcloud.

## 0.5.4 — Compact Workspace
- Widget Deck présent sur l’accueil et lié aux tableaux Nextcloud.
- Grille dense avec rangées de hauteur calculée pour réduire les vides entre widgets.
- Hauteur minimale réglable en mode Libre, sauvegardée par utilisateur.
- Nouvelles icônes Accueil fournies pour le hub et la navigation.
- Icônes topbar harmonisées avec le hub, transitions et ambiance améliorées.

## 0.5.3 — Notes & PDF / PNG256 hub
- Privilégie les 10 images PNG 256 du kit pour le hub des applications, sans encarts.
- Aperçu PDF via une route Nextcloud authentifiée en `Content-Disposition: inline` : sélection ≠ téléchargement.
- Une demande de téléchargement reste explicite via l'icône Télécharger.
- Module Notes : utilise l'API Notes si disponible, et sinon les notes Markdown/TXT du dossier Notes de l'utilisateur via le stockage Nextcloud.
- Contrôle de taille, permissions et ETag sur les modifications des notes en mode fichiers.
- Compatibilité conservée avec Nextcloud 35 et l'ID d'application `novadashboard`.

# Neos — Changelog

## 0.5.2 — Disposition adaptative

- Accueil à grille de 12 colonnes avec mode automatique et mode libre.
- Redimensionnement par widget (3, 4, 6, 8, 9, 12 colonnes) avec sauvegarde.
- Réorganisation interactive avec poignée, zone cible et contrôles au clavier.
- Maintien des préférences d’affichage des versions antérieures.
- API Deck : routes REST documentées et repli OCS en cas de 404 ; diagnostic d’app absente.
- Réintégration des assets SVG du NEOS UI Kit fourni, et monogramme de navigation.

## 0.5.1 — Accueil et Fichiers

- Séparation Accueil/Fichiers, onglets, Deck/Notes visibles, animations de transition, défilement vertical.
