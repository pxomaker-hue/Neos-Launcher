# Neos v0.6.4 — Installation Nextcloud 35 / OpenMediaVault

Cette version conserve l'identifiant technique `novadashboard` et toutes les fonctions précédentes. Elle ajoute le calendrier mensuel/hebdomadaire et améliore le diagnostic des tâches CalDAV. Le code de Neos est modifié, **pas les montages Docker**, ni le volume `/data` sur `sdb1`, ni la base MariaDB.

## 1. Envoyer le ZIP depuis Windows PowerShell

**Une commande par ligne**, puis Entrée :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.4.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier Nextcloud et sauvegarder Neos

```bash
sudo docker exec nextcloud occ status
```

Vérifier **35.x**, `maintenance: false`, `needsDbUpgrade: false` avant de poursuivre.

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
echo "$APP_PATH"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouve"
```

Si le message n'apparaît pas, ne pas continuer.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v064.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v064.tar.gz
```

## 3. Installer le code

```bash
mkdir -p /tmp/neos-v064
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.4.zip /tmp/neos-v064
```

```bash
test -f /tmp/neos-v064/novadashboard/appinfo/info.xml && echo "Archive valide"
```

```bash
sudo docker cp /tmp/neos-v064/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.4`. Recharger le navigateur avec **Ctrl+F5**. Ne pas lancer `occ upgrade` si Nextcloud ne l'exige pas.

## 4. Tester Agenda et le 404 des Tâches

1. **Agenda :** basculer de Mois à Semaine, faire Précédent/Suivant, cliquer sur un événement et sur un jour. Créer un événement temporaire et vérifier sa synchronisation dans Agenda Nextcloud.
2. **Tâches :** cliquer sur les filtres À faire / Terminées / Toutes, créer une tâche temporaire si une liste VTODO modifiable existe, puis la cocher.
3. Si l'ancien **lien Ouvrir Tâches** provoquait une 404 : la v0.6.4 le masque quand l'app native `tasks` n'est pas activée. Le module Tâches intégré peut toujours fonctionner via CalDAV.
4. Si la 404 persiste **dans le contenu Neos**, ouvrir F12 > Réseau et relever la **méthode, le code HTTP et le type de chemin** de la requête en échec (sans jeton d'authentification). Pour un chemin `remote.php/dav/calendars/...`, il s'agit d'un problème CalDAV distinct du lien vers l'application native.

Pour vérifier si l'application native Tâches est activée :

```bash
sudo docker exec nextcloud occ app:list --enabled | grep -i 'tasks:'
```

Si aucun résultat, l'application native n'est pas activée. Elle peut être installée ou activée via **Applications** dans Nextcloud ; cela n'empêche pas le fonctionnement des calendriers CalDAV déjà existants. Ne pas installer ni activer une application à l'aveugle pendant une mise à jour.

## 5. Restaurer la version précédente de Neos

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v064.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

Puis **Ctrl+F5**. Cette restauration concerne uniquement le code Neos, pas les événements ou tâches enregistrés depuis la mise à jour.

## Validation et limites

Syntaxe PHP/JS, XML, ZIP, tests Chromium ordinateur/mobile et tests CalDAV simulés vérifiés. **Non testé sur le NAS réel.** Les récurrences complexes, tâches avec plusieurs composants VTODO et synchronisations CalDAV propres à l'instance doivent rester gérées dans les applications natives si nécessaire. Le modèle CalDAV conserve l'usage d'ETag/If-Match pour les modifications et d'If-None-Match pour les créations.
