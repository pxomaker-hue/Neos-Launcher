# Neos 0.6.14 — Mail : boîtes de réception, diagnostics

- Corrige les identifiants de boîtes (`databaseId`) et le rôle `specialRole`.
- Corrige les identifiants des messages (`databaseId`) pour la lecture.
- Sélecteur des boîtes de réception (plusieurs comptes Mail).
- Affiche les anomalies par compte au lieu de présenter une boîte vide silencieusement.
- Aucun changement des autres modules ni des paramètres de sécurité du NAS.

L’intégration Mail reste dépendante de la version de l’application Mail du serveur ; à confirmer par essai réel sur Nextcloud 35.
