# Neos v0.6.14 — Installation sur OpenMediaVault (Nextcloud 35)

## Nouveautés

- Mail : correction de la reconnaissance des dossiers `databaseId` / `specialRole`.
- Mail : lecture des messages avec identifiant `databaseId`, prise en charge de plusieurs comptes et sélection de la boîte de réception.
- Mail : message explicite si aucun dossier Réception n'est identifié ou si le chargement échoue (au lieu d'afficher silencieusement zéro courriel).
- Conservation du design Flat Cyber, de la topbar personnalisable, de Talk, Activité, Contacts, Tâches, Deck, Planning, Explorateur et Notes.

> Cette version a été contrôlée par tests unitaires simulés, contrôle de syntaxe et intégrité ZIP. Les tests réels sur le NAS restent à confirmer. Ne pas partager les contenus privés des réponses `accounts`, `mailboxes` ou `messages`.

## Étape 1 — Transfert depuis PowerShell (Windows)

Place `neos-nextcloud35-v0.6.14.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.14.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## Étape 2 — Vérifications et sauvegarde sur le NAS (SSH)

Exécute **chaque commande séparément** et arrête-toi en cas d'erreur.

```bash
sudo docker exec nextcloud occ status
```

Vérifie `maintenance: false` et `needsDbUpgrade: false`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.14.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0614.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0614.tar.gz
```

## Étape 3 — Mise à jour

```bash
mkdir -p /tmp/neos-v0614
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.14.zip /tmp/neos-v0614
```

```bash
test -f /tmp/neos-v0614/novadashboard/appinfo/info.xml && echo "Archive prête"
```

```bash
sudo docker cp /tmp/neos-v0614/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.14`. Dans Chrome ou Edge, fais **Ctrl + F5**.

## Étape 4 — Tests à faire

1. Dans **Mail** de Neos, vérifie que la liste s'affiche et que le sélecteur « Boîte » est présent.
2. Ouvre le même compte dans **Mail natif** et compare les derniers messages de la boîte de réception.
3. Ouvre un message dans Neos ; le contenu texte doit apparaître, sans HTML actif.
4. Si aucune liste n'apparaît, vérifie dans **F12 → Réseau** qu'une requête `api/messages?mailboxId=…` est bien lancée. Tu peux me communiquer **uniquement l'URL sans paramètres sensibles et le statut HTTP**, pas le JSON, les cookies, ni les en-têtes d'authentification.
5. Vérifie que les modules Talk, Contacts, Planning, Tâches et la topbar fonctionnent toujours.

Si tu vois `200` pour `api/messages` mais aucun message, dis-moi si **Mail natif** contient des messages dans **Réception**. L'état de synchronisation peut alors être en cause.

## Retour arrière (si nécessaire)

Les commandes suivantes s'exécutent sur le NAS dans la session SSH et utilisent le `APP_PATH` défini plus haut.

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f /config/neos-backup-avant-v0614.tar.gz && echo "Restauration possible"
```

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0614.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Recharge le navigateur avec Ctrl + F5.
