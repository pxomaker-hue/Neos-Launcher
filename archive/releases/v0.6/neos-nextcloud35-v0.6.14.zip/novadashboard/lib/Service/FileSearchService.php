<?php

declare(strict_types=1);

namespace OCA\NovaDashboard\Service;

use InvalidArgumentException;
use OCP\Constants;
use OCP\Files\File;
use OCP\Files\Folder;
use OCP\Files\IRootFolder;
use OCP\IUser;
use Throwable;

/**
 * Bounded, per-user filename search over the Nextcloud-visible file tree.
 * This is intentionally not a whole-NAS disk scan and never bypasses mounts
 * or file permissions. All limits are hard-coded to protect smaller NASes.
 */
final class FileSearchService {
    private const MAX_VISITED = 2500;
    private const MAX_RESULTS = 40;
    private const MAX_DEPTH = 6;

    public function __construct(private IRootFolder $root) {}

    public function search(IUser $user, string $query, string $type = 'all', string $date = 'all', string $size = 'all', string $sort = 'recent'): array {
        $query = trim($query);
        $queryLength = function_exists('mb_strlen') ? mb_strlen($query, 'UTF-8') : strlen($query);
        if ($queryLength < 2 || $queryLength > 100) {
            throw new InvalidArgumentException('Saisir entre 2 et 100 caractères.');
        }

        if (!in_array($type, ['all', 'folder', 'image', 'document', 'video', 'audio', 'other'], true)
            || !in_array($date, ['all', '7', '30', '365'], true)
            || !in_array($size, ['all', 'small', 'medium', 'large', 'huge'], true)
            || !in_array($sort, ['recent', 'name', 'size'], true)) {
            throw new InvalidArgumentException('Filtres de recherche invalides.');
        }
        $cutoff = $date === 'all' ? 0 : time() - ((int)$date * 86400);
        $home = $this->root->getUserFolder($user->getUID());
        $queue = [[$home, 0]];
        $visited = 0;
        $results = [];
        $truncated = false;

        while ($queue !== []) {
            [$folder, $depth] = array_shift($queue);
            if (($folder->getPermissions() & Constants::PERMISSION_READ) === 0) {
                continue;
            }
            try {
                $entries = $folder->getDirectoryListing();
            } catch (Throwable $error) {
                continue;
            }
            foreach ($entries as $entry) {
                if (++$visited > self::MAX_VISITED) {
                    $truncated = true;
                    break 2;
                }
                if (!($entry instanceof File || $entry instanceof Folder)) {
                    continue;
                }
                if (($entry->getPermissions() & Constants::PERMISSION_READ) === 0) {
                    continue;
                }
                $relativePath = $home->getRelativePath($entry->getPath());
                if (!is_string($relativePath) || $relativePath === '') {
                    continue;
                }
                $path = '/' . ltrim($relativePath, '/');
                if ($entry instanceof Folder && $depth < self::MAX_DEPTH) {
                    $queue[] = [$entry, $depth + 1];
                } elseif ($entry instanceof Folder && $depth >= self::MAX_DEPTH) {
                    $truncated = true;
                }
                $matches = function_exists('mb_stripos')
                    ? mb_stripos($entry->getName(), $query, 0, 'UTF-8') !== false
                    : stripos($entry->getName(), $query) !== false;
                if ($matches && $this->matchesFilters($entry, $type, $cutoff, $size)) {
                    $parent = dirname($path);
                    $results[] = [
                        'name' => $entry->getName(),
                        'path' => $path,
                        'parent' => $parent === '.' ? '/' : $parent,
                        'kind' => $entry instanceof Folder ? 'folder' : 'file',
                        'mtime' => (int)$entry->getMTime(),
                        'size' => $entry instanceof Folder ? null : (int)$entry->getSize(),
                        'mime' => $entry instanceof Folder ? 'httpd/unix-directory' : $entry->getMimetype(),
                    ];
                }
            }
        }
        usort($results, static function (array $a, array $b) use ($sort): int {
            if ($sort === 'name') {
                return strnatcasecmp($a['name'], $b['name']);
            }
            if ($sort === 'size') {
                return ($b['size'] ?? -1) <=> ($a['size'] ?? -1);
            }
            return $b['mtime'] <=> $a['mtime'];
        });
        if (count($results) > self::MAX_RESULTS) {
            $truncated = true;
            $results = array_slice($results, 0, self::MAX_RESULTS);
        }
        return [
            'items' => $results,
            'truncated' => $truncated,
            'visited' => min($visited, self::MAX_VISITED),
            'maxVisited' => self::MAX_VISITED,
            'maxDepth' => self::MAX_DEPTH,
            'filters' => ['type' => $type, 'date' => $date, 'size' => $size, 'sort' => $sort],
        ];
    }

    private function matchesFilters(File|Folder $entry, string $type, int $cutoff, string $size): bool {
        $isFolder = $entry instanceof Folder;
        if ($cutoff > 0 && (int)$entry->getMTime() < $cutoff) {
            return false;
        }
        if ($type === 'folder' && !$isFolder) {
            return false;
        }
        if ($type !== 'all' && $type !== 'folder') {
            if ($isFolder) {
                return false;
            }
            $mime = strtolower((string)$entry->getMimetype());
            $extension = strtolower(pathinfo($entry->getName(), PATHINFO_EXTENSION));
            $isImage = str_starts_with($mime, 'image/');
            $isVideo = str_starts_with($mime, 'video/');
            $isAudio = str_starts_with($mime, 'audio/');
            $isDoc = str_starts_with($mime, 'text/')
                || in_array($extension, ['pdf', 'doc', 'docx', 'odt', 'xls', 'xlsx', 'ods', 'ppt', 'pptx', 'odp', 'txt', 'md', 'csv', 'rtf'], true);
            $accepted = match ($type) {
                'image' => $isImage,
                'video' => $isVideo,
                'audio' => $isAudio,
                'document' => $isDoc,
                'other' => !$isImage && !$isVideo && !$isAudio && !$isDoc,
                default => true,
            };
            if (!$accepted) {
                return false;
            }
        }
        if ($size !== 'all') {
            if ($isFolder) {
                return false;
            }
            $bytes = (int)$entry->getSize();
            $mib = 1024 * 1024;
            return match ($size) {
                'small' => $bytes < $mib,
                'medium' => $bytes >= $mib && $bytes < 10 * $mib,
                'large' => $bytes >= 10 * $mib && $bytes < 100 * $mib,
                'huge' => $bytes >= 100 * $mib,
                default => true,
            };
        }
        return true;
    }
}
