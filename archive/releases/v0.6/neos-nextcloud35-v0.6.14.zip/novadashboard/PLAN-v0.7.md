# Plan Neos jusqu'à la v0.7 (après v0.6.14)

## Validé sur NAS d'après les retours utilisateur

- Tâches CalDAV et cartes Deck : validation et actualisation sans rechargement complet.
- Flat Cyber, hub, icône Planning, ordre personnalisable de la topbar.
- Talk : lecture et envoi de messages.
- Contacts : création, édition de fiches.

## Développé, à valider sur NAS

- Mail v0.6.14 : reconnaissance des dossiers avec `databaseId` + `specialRole`, récupération des messages et lecteur texte.
- Activité : pagination serveur et filtres.

## Priorités restantes avant v0.7

1. Stabiliser Mail à partir du test réel de v0.6.14 : boîte Réception et lecture.
2. Mettre en place un compositeur Mail natif Neos seulement après vérification des API d'envoi et des protections CSRF, avec garde-fous contre les doubles envois.
3. Talk : états non lus et suivi des nouvelles conversations.
4. Contacts : champs multiples, suppression avec confirmation et ETag.
5. Tests de régression et compatibilité mobile sur tous les modules, restauration et fiabilité.
