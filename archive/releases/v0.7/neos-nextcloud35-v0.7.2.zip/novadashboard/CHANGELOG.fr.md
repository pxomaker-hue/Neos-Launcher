## 0.7.2

- Les badges de non-lus de Mail et Talk adoptent un halo cyan diffus et un quadrillage discret, avec libellés comme en mode icônes.

## 0.7.1

- Les onglets Mail et Talk affichent les non-lus, y compris en mode icônes.
- Le compteur Mail couvre les boîtes de réception d’après les statistiques renvoyées par Nextcloud Mail.

## 0.7.0

- La barre de navigation affiche uniquement les icônes sur écran réduit et passe à la ligne selon l’espace disponible.
- La recherche Fichiers interroge l’index Nextcloud et charge les résultats par lots.
- Notes charge les pages de la collection en arrière-plan et préserve le brouillon pendant la recherche.
- Contacts récupère les fiches par lots sans les anciens plafonds par carnet et au total.
- Agenda affiche les occurrences CalDAV et permet de créer des répétitions simples et de modifier les séries et occurrences prises en charge.
- Mail reprend le texte et les pièces jointes d’un brouillon IMAP dans une copie.
