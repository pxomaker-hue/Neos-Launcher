<?php
/** @var array $_ */
?>
<div id="nova-root"
     data-overview-url="<?php p($_['overviewUrl']); ?>"
     data-settings-url="<?php p($_['settingsUrl']); ?>">
    <div class="nova-loading" role="status">Chargement de Nova Dashboard…</div>
</div>
