<?php

declare(strict_types=1);

namespace OCA\NovaDashboard\Service;

use OCP\IConfig;

/**
 * Per-user settings. All submitted values are normalized and size-limited.
 * Previous 0.1.x preferences (theme/order/hidden) are preserved.
 */
final class PreferencesService {
    public const WIDGETS = ['storage', 'shortcuts', 'clock', 'files', 'calendar', 'tasks', 'summary', 'links', 'notes'];
    public const SIZES = [3, 4, 6, 8, 12];
    public const ACCENTS = ['indigo', 'cyan', 'emerald', 'rose', 'amber'];

    private const DEFAULT_SIZES = [
        'storage' => 3, 'shortcuts' => 6, 'clock' => 3, 'files' => 6,
        'calendar' => 6, 'tasks' => 6, 'summary' => 6, 'links' => 6, 'notes' => 6,
    ];

    public function __construct(private IConfig $config) {}

    public function get(string $uid): array {
        $raw = $this->config->getUserValue($uid, 'novadashboard', 'preferences', '');
        $settings = json_decode($raw, true);
        return $this->normalize(is_array($settings) ? $settings : []);
    }

    public function save(string $uid, array $settings): array {
        $value = $this->normalize($settings);
        $this->config->setUserValue($uid, 'novadashboard', 'preferences', json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
        return $value;
    }

    public function normalize(array $data): array {
        $theme = in_array($data['theme'] ?? null, ['system', 'dark', 'light'], true) ? $data['theme'] : 'system';
        $density = in_array($data['density'] ?? null, ['comfortable', 'compact'], true) ? $data['density'] : 'comfortable';
        $accent = in_array($data['accent'] ?? null, self::ACCENTS, true) ? $data['accent'] : 'indigo';
        $layout = in_array($data['layout'] ?? null, ['wide', 'focused'], true) ? $data['layout'] : 'wide';
        $ordered = is_array($data['order'] ?? null) ? $data['order'] : [];
        $order = [];
        foreach ($ordered as $widget) {
            if (is_string($widget) && in_array($widget, self::WIDGETS, true) && !in_array($widget, $order, true)) {
                $order[] = $widget;
            }
        }
        foreach (self::WIDGETS as $widget) {
            if (!in_array($widget, $order, true)) {
                $order[] = $widget;
            }
        }

        $hiddenRequested = is_array($data['hidden'] ?? null) ? $data['hidden'] : [];
        // The new optional widgets are hidden by default when migrating 0.1.x settings.
        $legacy = !isset($data['sizes']) && !isset($data['density']) && !isset($data['accent']);
        if ($legacy) {
            $hiddenRequested = array_merge($hiddenRequested, ['notes', 'links']);
        }
        $hidden = [];
        foreach ($hiddenRequested as $widget) {
            if (is_string($widget) && in_array($widget, self::WIDGETS, true) && !in_array($widget, $hidden, true)) {
                $hidden[] = $widget;
            }
        }

        $submittedSizes = is_array($data['sizes'] ?? null) ? $data['sizes'] : [];
        $sizes = [];
        foreach (self::DEFAULT_SIZES as $widget => $default) {
            $candidate = $submittedSizes[$widget] ?? $default;
            $candidate = is_numeric($candidate) ? (int)$candidate : 0;
            $sizes[$widget] = in_array($candidate, self::SIZES, true) ? $candidate : $default;
        }

        $links = [];
        $requestedLinks = is_array($data['links'] ?? null) ? $data['links'] : [];
        foreach (array_slice($requestedLinks, 0, 12) as $link) {
            if (!is_array($link) || !is_string($link['title'] ?? null) || !is_string($link['url'] ?? null)) {
                continue;
            }
            $title = trim($link['title']);
            $url = trim($link['url']);
            if ($title === '' || strlen($title) > 80 || strlen($url) > 600 || !$this->validUrl($url)) {
                continue;
            }
            $links[] = ['title' => $title, 'url' => $url];
        }

        $notes = is_string($data['notes'] ?? null) ? trim($data['notes']) : '';
        // Byte caps prevent oversized settings on any storage backend.
        if (strlen($notes) > 3000) {
            $notes = substr($notes, 0, 3000);
            while ($notes !== '' && preg_match('//u', $notes) !== 1) {
                $notes = substr($notes, 0, -1);
            }
        }

        return compact('theme', 'density', 'accent', 'layout', 'order', 'hidden', 'sizes', 'links', 'notes');
    }

    private function validUrl(string $url): bool {
        if (str_starts_with($url, '/') && !str_starts_with($url, '//')
            && !str_contains($url, '\\') && preg_match('/[\x00-\x1f]/', $url) !== 1) {
            return true;
        }
        if (filter_var($url, FILTER_VALIDATE_URL) === false) {
            return false;
        }
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true);
    }
}
