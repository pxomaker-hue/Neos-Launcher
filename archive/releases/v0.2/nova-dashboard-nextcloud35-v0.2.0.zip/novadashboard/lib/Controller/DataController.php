<?php

declare(strict_types=1);

namespace OCA\NovaDashboard\Controller;

use OCA\NovaDashboard\Service\OverviewService;
use OCA\NovaDashboard\Service\PreferencesService;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\JSONResponse;
use OCP\IRequest;
use OCP\IUserSession;

final class DataController extends Controller {
    public function __construct(
        IRequest $request,
        private IUserSession $session,
        private OverviewService $overviewService,
        private PreferencesService $preferences,
    ) {
        parent::__construct('novadashboard', $request);
    }

    #[NoAdminRequired]
    public function overview(): JSONResponse {
        $user = $this->session->getUser();
        if ($user === null) {
            return new JSONResponse(['error' => 'Authentification requise'], 401);
        }
        $response = new JSONResponse([
            'user' => ['name' => $user->getDisplayName()],
            'overview' => $this->overviewService->build($user),
            'settings' => $this->preferences->get($user->getUID()),
        ]);
        $response->addHeader('Cache-Control', 'private, no-store');
        return $response;
    }

    #[NoAdminRequired]
    public function saveSettings(): JSONResponse {
        $user = $this->session->getUser();
        if ($user === null) {
            return new JSONResponse(['error' => 'Authentification requise'], 401);
        }

        // The route is intentionally not CSRF-exempt; Nextcloud verifies requesttoken.
        $settings = $this->request->getParam('settings');
        if (!is_array($settings)) {
            return new JSONResponse(['error' => 'Préférences invalides'], 400);
        }
        $value = $this->preferences->save($user->getUID(), $settings);
        $response = new JSONResponse(['settings' => $value]);
        $response->addHeader('Cache-Control', 'private, no-store');
        return $response;
    }
}
