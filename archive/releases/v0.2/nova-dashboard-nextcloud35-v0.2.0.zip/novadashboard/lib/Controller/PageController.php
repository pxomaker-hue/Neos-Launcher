<?php

declare(strict_types=1);

namespace OCA\NovaDashboard\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\IRequest;
use OCP\IURLGenerator;
use OCP\Util;

final class PageController extends Controller {
    public function __construct(
        IRequest $request,
        private IURLGenerator $url,
    ) {
        parent::__construct('novadashboard', $request);
    }

    #[NoAdminRequired]
    #[NoCSRFRequired] // Only for the initial HTML page; login remains required.
    public function index(): TemplateResponse {
        Util::addScript('novadashboard', 'app');
        Util::addStyle('novadashboard', 'app');

        return new TemplateResponse('novadashboard', 'main', [
            'overviewUrl' => $this->url->linkToRoute('novadashboard.data.overview'),
            'settingsUrl' => $this->url->linkToRoute('novadashboard.data.saveSettings'),
        ]);
    }
}
