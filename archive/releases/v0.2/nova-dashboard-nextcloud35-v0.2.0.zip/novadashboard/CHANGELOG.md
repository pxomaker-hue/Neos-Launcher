# Historique

## 0.2.0
- Surface 100% viewport sous la barre Nextcloud, responsive.
- Widgets Horloge, Synthèse, Liens et Notes.
- Thème, densité, accent, disposition, tailles et ordre persistés par utilisateur.
- Migration douce des préférences v0.1.x.
- Reprise des corrections CSRF v0.1.1/0.1.2 avec repli de jeton sans récursion.
- Aucune dépendance JS externe, aucune migration SQL.

## 0.1.2
- Correction du chargement d'API avec jeton CSRF issu de la page Nextcloud.

## 0.1.1
- Exemption CSRF limitée à la page HTML initiale.

## 0.1.0
- Première version : stockage, fichiers, calendrier, tâches, raccourcis, thème et ordre.
