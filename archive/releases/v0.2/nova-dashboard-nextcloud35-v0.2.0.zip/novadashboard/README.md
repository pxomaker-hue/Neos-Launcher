# Nova Dashboard — v0.2.0

Application Nextcloud 35 (PHP ≥8.3) : tableau de bord pleine largeur, données utilisateur réelles et personnalisation.

## Changements v0.2.0

- Surface **plein écran** sans dépendre de la largeur du conteneur `#content` de Nextcloud (conserve l'en-tête Nextcloud).
- Grille responsive 12 colonnes sur grand écran ; 6/12 colonnes sur tablette ; une carte par ligne sur mobile.
- Réglages par utilisateur : thème système/clair/sombre, cinq accents, densité, largeur de contenu, ordre, affichage et largeur des cartes (25, 33, 50, 67, 100 %).
- Nouvelle **horloge locale**, nouvelle **synthèse** (données existantes, recherche des fichiers bornée), **liens personnalisés** et **notes privées**.
- Préférences v0.1.x conservées : thème, ordre, widgets cachés.
- Correctif CSRF des versions 0.1.1/0.1.2 conservé : jeton trouvé dans `head[data-requesttoken]`, avec repli `OC.requestToken`, sans récursion.
- Aucune API externe, aucun secret, aucune modification du cœur de Nextcloud.

## Pré-requis

- Nextcloud **35.x** uniquement, PHP **8.3+**. Ne pas forcer l'installation sur une autre version.
- Dossier `novadashboard` existant dans l'emplacement d'applications persistant, sauf première installation.
- Pour OMV + `ghcr.io/linuxserver/nextcloud` : `/config/www/nextcloud/apps/novadashboard`, propriétaire `abc:abc` et conteneur `nextcloud`.
- Sauvegarde de la configuration, des données et de la base de données Nextcloud avant de mettre à jour un environnement de production.

## Mise à jour depuis la v0.1.x — OMV/LinuxServer.io

Depuis le **PC Windows**, dans PowerShell :

```powershell
scp "X:\Travail\Apprentissage\Codage\nova-dashboard-nextcloud35-v0.2.0.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

Sur le NAS, exécuter les commandes **une par une** :

```bash
sudo docker exec nextcloud occ status
sudo docker inspect nextcloud --format '{{range .Mounts}}{{println .Destination .Source}}{{end}}'
# Version 35.x attendue, /config monté sur un volume persistant.
```

Créer une sauvegarde **persistante du code Nova** avant toute modification :

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v020.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

Extraire et copier le dossier **dans** le dossier existant :

```bash
mkdir -p /tmp/nova-v020
python3 -m zipfile -e /tmp/nova-dashboard-nextcloud35-v0.2.0.zip /tmp/nova-v020
ls /tmp/nova-v020/novadashboard/appinfo/info.xml
sudo docker cp /tmp/nova-v020/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud php -l /config/www/nextcloud/apps/novadashboard/lib/Service/PreferencesService.php
sudo docker exec nextcloud occ status
```

Cette mise à jour n'ajoute aucune table de base de données et ne redémarre pas le conteneur. Si Nextcloud demande explicitement une migration, faire les sauvegardes et suivre sa procédure d'upgrade en utilisant `sudo docker exec nextcloud occ upgrade`. **Ne pas lancer** `occ app:update novadashboard` : cette commande vise les apps publiées sur l'App Store, pas ce paquet local.

Dans le navigateur, ouvrir `/index.php/apps/novadashboard/` et actualiser avec **Ctrl+F5**. Examiner F12 → Réseau → `api/overview` en cas d'erreur ; une réponse 200 indique que l'API JSON est accessible. Ne définir l'accueil par défaut qu'après validation de l'interface.

### Retour arrière

Ne pas effacer les fichiers personnels ni le dossier `/data`.

```bash
# Restaurer seulement les fichiers Nova sauvegardés dans /config
sudo docker exec nextcloud sh -c 'tar -xzf /config/novadashboard-backup-avant-v020.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Le fichier de sauvegarde conserve le code précédemment installé. Les préférences 0.2 restent dans la configuration utilisateur, mais 0.1.x ignore leurs nouveaux champs. Le simple retour au code antérieur ne nécessite pas de restaurer une base de données.

## Installation initiale

Pour une première installation, décompresser `novadashboard/` et copier le dossier à `/config/www/nextcloud/apps/`, puis :

```bash
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ app:enable novadashboard
```

## Fonctionnalités et limites

| Carte | Source | Détails |
|---|---|---|
| Stockage | Dossier personnel Nextcloud | Quota et taille (hors stockage externe) |
| Fichiers récents | Nœuds accessibles via OCP | Maximum 180 nœuds explorés, profondeur limitée |
| Agenda / tâches | Calendrier/CalDAV via OCP | Fenêtre de 30 jours ; lecture seule ; peuvent rester vides |
| Raccourcis | Applications activées pour l'utilisateur | Files, Photos, Calendar, Tasks, Talk si disponibles |
| Horloge | Navigateur | Fuseau et heure du PC, pas du NAS |
| Synthèse | Données des cartes ci-dessus | Compteurs indicatifs, non exhaustifs |
| Mes liens | `IConfig` par utilisateur | URLs HTTP(S) ou locales valides, maximum 12 |
| Mes notes | `IConfig` par utilisateur | Petit bloc-notes texte, 3000 octets max |

Les widgets Notes et Liens sont cachés par défaut mais activables dans Personnaliser. Les compteurs NAS/Docker, la météo, Home Assistant et les intégrations externes **ne sont pas encore inclus** : ils nécessitent une conception d'API ou une authentification distincte. Les notes sont stockées dans les préférences Nextcloud, **pas chiffrées de bout en bout**. Ne pas y conserver de mots de passe.

## Sécurité

- Toutes les routes exigent la session Nextcloud. Seule la page GET HTML dispose de `#[NoCSRFRequired]` ; les routes API continuent d'exiger un jeton CSRF.
- Aucun accès direct à la base de données ni aux chemins hôtes du NAS.
- Sauvegarde et normalisation des préférences côté serveur (widget/tailles/couleurs/thème/URL validés, limites de longueur).
- Contenus de noms de fichiers, notes et liens échappés dans le HTML ; aucune requête réseau vers les URLs des liens personnalisés depuis le serveur.
- Version de développement communautaire **non signée et non certifiée**. Tests PHP/JavaScript unitaires et validation navigateur simulé, mais tests réels sur ton instance restant nécessaires.

## Aperçu sans serveur

Depuis l'archive extraite, ouvrir `nova-dashboard-v0.2-apercu.html` dans un navigateur. L'aperçu se connecte **uniquement à des données de démonstration** et n'accède pas au serveur Nextcloud.
