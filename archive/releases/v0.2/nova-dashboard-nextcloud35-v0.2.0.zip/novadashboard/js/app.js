/** Nova Dashboard 0.2.0 — native Nextcloud app, no external assets. */
(() => {
  'use strict';
  const root = document.getElementById('nova-root');
  if (!root) return;

  // Nextcloud currently injects the CSRF token in the page's head. OC is a
  // compatible fallback; never recurse when the token is absent.
  const csrfToken = () => document.head?.getAttribute('data-requesttoken') || window.OC?.requestToken || '';
  const glyphs = {
    sparkles:'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 17 .8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',
    check:'<rect x="3" y="4" width="18" height="17" rx="3"/><path d="m8 12 3 3 5-6"/>',
    storage:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 12h18m-5 4h2"/><circle cx="7" cy="16" r="1"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-6-6L4 21"/>',
    message:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
    settings:'<path d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    moon:'<path d="M20 14a8.5 8.5 0 0 1-10-10 8.5 8.5 0 1 0 10 10Z"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.8 9A7.5 7.5 0 0 1 19 6l1 1M4 17l1 1a7.5 7.5 0 0 0 13.2-3"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    up:'<path d="m6 15 6-6 6 6"/>', down:'<path d="m6 9 6 6 6-6"/>',
    close:'<path d="M5 5l14 14M19 5 5 19"/>',
    grip:'<circle cx="9" cy="5" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="19" r="1"/>',
    file:'<path d="M6 2h9l5 5v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z"/><path d="M14 2v6h6"/>',
    external:'<path d="M14 4h6v6m-9 3 9-9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
    alert:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3v.1"/>',
    cloud:'<path d="M5 18a4 4 0 0 1-.4-8 7 7 0 0 1 13-1 4.5 4.5 0 0 1 1 9H5Z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7 .2l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7-.2l-3 3a5 5 0 1 0 7.1 7.1l1.7-1.7"/>',
    note:'<path d="M4 3h16v18H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    chart:'<path d="M3 20h18M6 17v-4m6 4V6m6 11v-8"/>',
    plus:'<path d="M12 4v16M4 12h16"/>', trash:'<path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15"/>',
    maximize:'<path d="M8 3H3v5m18 8v5h-5M3 3l7 7m11 11-7-7"/>',
  };
  const icon = (name, size = 19) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${glyphs[name] || glyphs.grid}</svg>`;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeUrl = s => typeof s === 'string' && (/^\/(?!\/)/.test(s) && !s.includes('\\') || /^https?:\/\//i.test(s)) ? esc(s) : '#';
  const safeColor = s => /^#[0-9a-fA-F]{6}$/.test(String(s)) ? s : '#8495ff';
  const number = n => Number.isFinite(Number(n)) ? Number(n) : 0;
  const humanSize = b => { if (b == null) return '—'; const n = Math.max(0, number(b)); const pow = n ? Math.min(4, Math.floor(Math.log(n) / Math.log(1024))) : 0; return new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(n/Math.pow(1024,pow))+' '+['o','Ko','Mo','Go','To'][pow]; };
  const fmtTime = iso => { if(!iso) return 'Sans échéance'; const d=new Date(iso); return isNaN(d.valueOf())?'Date inconnue':new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(d); };
  const ago = ts => { const days=Math.round((Date.now()-number(ts)*1000)/86400000); return days<=0?'Aujourd’hui':days===1?'Hier':`Il y a ${days} j`; };
  const labels={storage:'Stockage',shortcuts:'Accès rapide',clock:'Horloge locale',files:'Fichiers récents',calendar:'Prochains événements',tasks:'Tâches à faire',summary:'En un coup d’œil',links:'Mes liens',notes:'Mes notes'};
  const symbols={storage:'storage',shortcuts:'grid',clock:'clock',files:'folder',calendar:'calendar',tasks:'check',summary:'chart',links:'link',notes:'note'};
  const allWidgets=Object.keys(labels);
  const defaultSizes={storage:3,shortcuts:6,clock:3,files:6,calendar:6,tasks:6,summary:6,links:6,notes:6};
  let overview=null, settings=null, editing=false, activeDialog=false, saveRunning=false, saveQueued=false;
  const defaults=()=>({theme:'system',density:'comfortable',accent:'indigo',layout:'wide',order:[...allWidgets],hidden:['links','notes'],sizes:{...defaultSizes},links:[],notes:''});
  const setTheme=()=>{
    const pref=settings?.theme||'system';
    const light=pref==='light'||(pref==='system'&&window.matchMedia?.('(prefers-color-scheme: light)').matches);
    root.classList.toggle('nova-light',!!light); root.classList.toggle('nova-dark',!light);
    root.dataset.accent=settings?.accent||'indigo'; root.dataset.density=settings?.density||'comfortable'; root.dataset.layout=settings?.layout||'wide';
  };
  if (window.matchMedia) window.matchMedia('(prefers-color-scheme: light)').addEventListener?.('change',()=>{if(settings?.theme==='system')setTheme();});

  function panel(id, content, sub='') {
    const size=Number(settings.sizes?.[id] ?? defaultSizes[id]);
    return `<section class="nova-card nova-${id}" data-widget="${id}" data-size="${[3,4,6,8,12].includes(size)?size:6}" draggable="${editing}" aria-label="${esc(labels[id])}">
       <header class="nova-card-head"><div class="nova-card-name">${icon(symbols[id],18)}<span>${esc(labels[id])}</span></div><span class="nova-card-sub">${editing?icon('grip',17):esc(sub)}</span></header>
       <div class="nova-card-body">${content}</div></section>`;
  }
  function storage() {
    const v=overview.storage||{};
    const progress=Math.max(0,Math.min(100,number(v.percent)));
    return panel('storage',`<div class="nova-stat-main">${humanSize(v.used)}</div><p class="nova-subtle">${v.total==null?'Quota illimité':'sur '+humanSize(v.total)}</p>
      <div class="nova-meter"><span style="width:${progress}%"></span></div><p class="nova-explainer">${v.total==null?'Quota non défini':'Quota utilisé : '+progress.toFixed(1).replace('.',',')+' %'} · Hors volumes externes</p>`);
  }
  function shortcuts() {
    const list=overview.shortcuts||[];
    return panel('shortcuts',list.length?`<div class="nova-shortcut-grid">${list.map(x=>`<a class="nova-shortcut" href="${safeUrl(x.url)}"><span class="nova-shortcut-glyph">${icon(glyphs[x.icon]?x.icon:'grid',22)}</span><span>${esc(x.label)}</span></a>`).join('')}</div>`:'<p class="nova-empty">Aucune application disponible.</p>');
  }
  function clock() {
    return panel('clock',`<div class="nova-clock-time" data-clock>--:--</div><p class="nova-subtle" data-clock-date>Heure de ton appareil</p><div class="nova-tag">${icon('clock',14)} Heure locale</div>`);
  }
  function files() {
    const list=overview.files||[];
    return panel('files',list.length?`<div class="nova-list">${list.map(x=>`<a class="nova-item" href="${safeUrl(x.url)}"><span class="nova-item-icon">${icon('file',17)}</span><span class="nova-item-title"><strong>${esc(x.name)}</strong><small>${esc(x.folder)} · ${ago(x.mtime)}</small></span><span class="nova-item-meta">${humanSize(x.size)}</span>${icon('chevron',13)}</a>`).join('')}</div><p class="nova-explainer">Échantillon des derniers fichiers, recherche bornée.</p>`:'<p class="nova-empty">Aucun fichier dans les dossiers explorés.</p>','8 max');
  }
  function calendar() {
    const list=overview.calendar||[];
    return panel('calendar',list.length?`<div class="nova-list">${list.map(x=>`<div class="nova-item"><span class="nova-event-bar" style="background:${safeColor(x.color)}"></span><span class="nova-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.calendar)}</small></span><span class="nova-item-meta">${fmtTime(x.start)}</span></div>`).join('')}</div>`:'<p class="nova-empty">Aucun événement dans les 30 prochains jours.</p>','30 jours');
  }
  function tasks() {
    const list=overview.tasks||[];
    return panel('tasks',list.length?`<div class="nova-list">${list.map(x=>`<div class="nova-item"><span class="nova-item-icon">${icon('check',16)}</span><span class="nova-item-title"><strong>${esc(x.title)}</strong><small>${fmtTime(x.due)}</small></span></div>`).join('')}</div>`:'<p class="nova-empty">Aucune tâche non terminée trouvée via CalDAV.</p>','CalDAV');
  }
  function summary() {
    const end=new Date();end.setDate(end.getDate()+7);
    const week=(overview.calendar||[]).filter(e=>{const d=new Date(e.start);return !isNaN(d.valueOf())&&d<=end&&d>=new Date();}).length;
    const metrics=[[humanSize(overview.storage?.used),'Fichiers personnels'],[(overview.files||[]).length,'Fichiers repérés'],[week,'Événements sous 7 j'],[(overview.tasks||[]).length,'Tâches trouvées']];
    return panel('summary',`<div class="nova-metrics">${metrics.map(([v,l])=>`<div class="nova-metric"><strong>${esc(v)}</strong><span>${esc(l)}</span></div>`).join('')}</div><p class="nova-explainer">Synthèse des données accessibles, pas une statistique exhaustive.</p>`,'Données Nextcloud');
  }
  function links() {
    const list=settings.links||[];
    return panel('links',`<div class="nova-list">${list.length?list.map(x=>`<a class="nova-item" href="${safeUrl(x.url)}" target="_blank" rel="noopener noreferrer"><span class="nova-item-icon">${icon('link',17)}</span><span class="nova-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.url)}</small></span>${icon('external',14)}</a>`).join(''):'<p class="nova-empty">Ajoute des liens via Personnaliser.</p>'}</div>`,'Privés');
  }
  function notes() {
    return panel('notes',`<label class="nova-note-label" for="nova-note-text">Bloc-notes personnel</label><textarea id="nova-note-text" maxlength="3000" placeholder="Une idée, un rappel, une note…">${esc(settings.notes||'')}</textarea><div class="nova-note-actions"><span>Enregistré dans les préférences Nextcloud de ton compte</span><button type="button" data-action="save-note" class="nova-btn nova-btn-primary">Enregistrer</button></div>`,'Privées');
  }
  const renderWidget={storage,shortcuts,clock,files,calendar,tasks,summary,links,notes};
  const greeting=()=>{const h=new Date().getHours();return h<12?'Bonjour':h<18?'Bon après-midi':'Bonsoir';};
  function render() {
    if(!overview||!settings) return;
    setTheme();
    const warnings=(overview.warnings||[]).map(w=>`<div class="nova-warning">${icon('alert',16)} ${esc(w)}</div>`).join('');
    root.innerHTML=`<main class="nova-app"><div class="nova-container">
      <nav class="nova-top"><div class="nova-brand"><span class="nova-mark">${icon('sparkles',23)}</span><span><strong>NOVA</strong><small>DASHBOARD 0.2</small></span></div>
      <div class="nova-toolbar"><span class="nova-online"><i></i> Mon espace</span><button type="button" data-action="refresh" class="nova-btn nova-btn-icon" title="Actualiser" aria-label="Actualiser">${icon('refresh')}</button>
      <button type="button" data-action="edit" class="nova-btn nova-btn-primary">${icon('settings',17)} ${editing?'Terminer':'Personnaliser'}</button></div></nav>
      <section class="nova-hero"><div><div class="nova-eyebrow"><span></span> TON ESPACE PERSONNEL</div><h1>${greeting()}, <em>${esc(root.dataset.displayName||'bienvenue')}</em><b> ✦</b></h1><p>Fichiers, agenda et outils du quotidien. Un seul tableau de bord.</p></div><div class="nova-date">${icon('calendar',17)} ${new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date())}</div></section>
      ${warnings?`<div class="nova-warning-row">${warnings}</div>`:''}
      ${editing?`<div class="nova-editbar">${icon('grip',17)} <span>Déplace les cartes à la souris ; modifie leur taille et visibilité dans les paramètres.</span><button type="button" data-action="preferences" class="nova-btn nova-btn-primary">Ouvrir les paramètres</button></div>`:''}
      <div class="nova-grid">${settings.order.filter(id=>!settings.hidden.includes(id)).map(id=>renderWidget[id]?.()||'').join('')}</div>
      <footer class="nova-footer"><span>${icon('cloud',15)} Nova Dashboard v0.2.0</span><span>Intégré à Nextcloud · Données propres à ton compte</span></footer>
      </div></main>${editing?dialogMarkup():''}`;
    bind(); updateClock();
  }
  function dialogMarkup() {
    const radio=(name,options)=>`<div class="nova-choices">${options.map(([v,t])=>`<label class="nova-choice"><input type="radio" name="${name}" value="${v}" ${settings[name]===v?'checked':''}><span>${t}</span></label>`).join('')}</div>`;
    return `<dialog id="nova-dialog" class="nova-dialog"><div class="nova-dialog-head"><div><strong>Personnalisation</strong><p>Ton espace, tes réglages</p></div><button type="button" class="nova-btn nova-btn-icon" data-action="close-dialog" aria-label="Fermer">${icon('close')}</button></div>
      <div class="nova-dialog-scroll"><h2>Apparence</h2><label class="nova-form-label">Thème</label>${radio('theme',[['system','Automatique'],['dark','Sombre'],['light','Clair']])}
      <label class="nova-form-label">Couleur</label>${radio('accent',[['indigo','Indigo'],['cyan','Cyan'],['emerald','Émeraude'],['rose','Rose'],['amber','Ambre']])}
      <label class="nova-form-label">Densité</label>${radio('density',[['comfortable','Confortable'],['compact','Compact']])}
      <label class="nova-form-label">Largeur</label>${radio('layout',[['wide','Pleine largeur'],['focused','Centrée']])}
      <h2>Disposition des widgets</h2><p class="nova-help">Afficher, masquer, déplacer et régler la largeur de chaque carte.</p>
      <div class="nova-pref-list">${settings.order.map((id,i)=>`<div class="nova-pref-row"><label><input type="checkbox" data-toggle="${id}" ${settings.hidden.includes(id)?'':'checked'}><span>${esc(labels[id])}</span></label>
        <div class="nova-pref-tools"><select aria-label="Largeur de ${esc(labels[id])}" data-size="${id}">${[[3,'25 %'],[4,'33 %'],[6,'50 %'],[8,'67 %'],[12,'100 %']].map(([s,t])=>`<option value="${s}" ${Number(settings.sizes?.[id])===s?'selected':''}>${t}</option>`).join('')}</select>
        <button type="button" data-move="${id}" data-direction="-1" ${i===0?'disabled':''} aria-label="Monter ${esc(labels[id])}">${icon('up',16)}</button><button type="button" data-move="${id}" data-direction="1" ${i===settings.order.length-1?'disabled':''} aria-label="Descendre ${esc(labels[id])}">${icon('down',16)}</button></div></div>`).join('')}</div>
      <h2>Liens personnels</h2><p class="nova-help">Jusqu’à 12 liens HTTP(S) ou internes commençant par /.</p><div class="nova-custom-links">${(settings.links||[]).map((l,i)=>`<div class="nova-link-editor"><input data-link-title="${i}" aria-label="Titre du lien ${i+1}" maxlength="80" value="${esc(l.title)}" placeholder="Nom"><input data-link-url="${i}" aria-label="URL du lien ${i+1}" maxlength="600" value="${esc(l.url)}" placeholder="https://…"><button type="button" data-remove-link="${i}" title="Supprimer">${icon('trash',15)}</button></div>`).join('')}</div><button type="button" class="nova-btn nova-btn-add" data-action="add-link">${icon('plus',16)} Ajouter un lien</button>
      </div><div class="nova-dialog-footer"><span data-save-status aria-live="polite">Les changements sont enregistrés.</span><button type="button" class="nova-btn nova-btn-primary" data-action="close-dialog">Terminer</button></div></dialog>`;
  }
  function bind() {
    root.querySelector('[data-action="refresh"]')?.addEventListener('click',()=>{void load(true);});
    root.querySelector('[data-action="edit"]')?.addEventListener('click',()=>{editing=!editing;render();});
    root.querySelector('[data-action="preferences"]')?.addEventListener('click',()=>openDialog());
    root.querySelector('[data-action="save-note"]')?.addEventListener('click',()=>{
      settings.notes=root.querySelector('#nova-note-text')?.value||'';queueSave();notice('Note enregistrée dans tes préférences.');
    });
    if(!editing)return;
    root.querySelectorAll('[data-widget]').forEach(card=>{
      card.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',card.dataset.widget);e.dataTransfer.effectAllowed='move';});
      card.addEventListener('dragover',e=>{e.preventDefault();e.dataTransfer.dropEffect='move';});
      card.addEventListener('drop',e=>{e.preventDefault();const from=e.dataTransfer.getData('text/plain'),to=card.dataset.widget;
        if(!allWidgets.includes(from)||!allWidgets.includes(to)||from===to)return;
        const order=[...settings.order];const old=order.indexOf(from);const target=order.indexOf(to);if(old<0||target<0)return;
        order.splice(old,1);order.splice(target,0,from);settings.order=order;queueSave();render();
      });
    });
    const dialog=root.querySelector('#nova-dialog');
    dialog?.addEventListener('close',()=>{activeDialog=false;});
    root.querySelectorAll('[data-action="close-dialog"]').forEach(b=>b.addEventListener('click',()=>dialog?.close()));
    root.querySelectorAll('[name="theme"],[name="density"],[name="accent"],[name="layout"]').forEach(input=>input.addEventListener('change',()=>{
      settings[input.name]=input.value;queueSave();rerenderDialog();
    }));
    root.querySelectorAll('[data-toggle]').forEach(input=>input.addEventListener('change',()=>{
      const id=input.dataset.toggle;settings.hidden=input.checked?settings.hidden.filter(x=>x!==id):[...settings.hidden,id];queueSave();rerenderDialog();
    }));
    root.querySelectorAll('[data-size]').forEach(select=>select.addEventListener('change',()=>{
      settings.sizes[select.dataset.size]=Number(select.value);queueSave();rerenderDialog();
    }));
    root.querySelectorAll('[data-move]').forEach(btn=>btn.addEventListener('click',()=>{
      const i=settings.order.indexOf(btn.dataset.move),j=i+Number(btn.dataset.direction);
      if(i<0||j<0||j>=settings.order.length)return;
      [settings.order[i],settings.order[j]]=[settings.order[j],settings.order[i]];queueSave();rerenderDialog();
    }));
    root.querySelector('[data-action="add-link"]')?.addEventListener('click',()=>{
      harvestLinks();if(settings.links.length>=12){notice('Maximum de 12 liens.');return;}
      settings.links.push({title:'Nouveau lien',url:'/'});rerenderDialog();
    });
    root.querySelectorAll('[data-remove-link]').forEach(btn=>btn.addEventListener('click',()=>{
      harvestLinks();settings.links.splice(Number(btn.dataset.removeLink),1);queueSave();rerenderDialog();
    }));
    root.querySelectorAll('[data-link-title],[data-link-url]').forEach(input=>input.addEventListener('change',()=>{
      harvestLinks();queueSave();
    }));
  }
  function harvestLinks(){
    root.querySelectorAll('[data-link-title]').forEach(input=>{
      const i=Number(input.dataset.linkTitle);if(settings.links[i])settings.links[i].title=input.value.trim().slice(0,80);
    });
    root.querySelectorAll('[data-link-url]').forEach(input=>{
      const i=Number(input.dataset.linkUrl);if(settings.links[i])settings.links[i].url=input.value.trim().slice(0,600);
    });
  }
  function rerenderDialog(){
    const wasOpen=!!root.querySelector('#nova-dialog')?.open;render();if(wasOpen)openDialog();
  }
  function openDialog(){root.querySelector('#nova-dialog')?.showModal();activeDialog=true;}
  function updateClock(){
    const el=root.querySelector('[data-clock]');if(!el)return;
    const now=new Date();el.textContent=new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(now);
    const sub=root.querySelector('[data-clock-date]');if(sub)sub.textContent=new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long'}).format(now);
  }
  setInterval(updateClock,30_000);
  function notice(message){
    document.querySelector('.nova-toast')?.remove();const n=document.createElement('div');n.className='nova-toast';n.setAttribute('role','status');n.textContent=message;document.body.appendChild(n);setTimeout(()=>n.remove(),5000);
  }
  function queueSave(){
    saveQueued=true;if(!saveRunning)void save();
  }
  function encodeSettings(){
    const form=new URLSearchParams();const put=(k,v)=>form.append(`settings[${k}]`,String(v));
    for(const key of ['theme','density','accent','layout','notes'])put(key,settings[key]||'');
    settings.order.forEach((v,i)=>form.append(`settings[order][${i}]`,v));
    settings.hidden.forEach((v,i)=>form.append(`settings[hidden][${i}]`,v));
    Object.entries(settings.sizes||{}).forEach(([id,v])=>form.append(`settings[sizes][${id}]`,String(v)));
    (settings.links||[]).forEach((l,i)=>{form.append(`settings[links][${i}][title]`,l.title);form.append(`settings[links][${i}][url]`,l.url);});
    return form;
  }
  async function save(){
    if(saveRunning)return;
    saveRunning=true;
    while(saveQueued){
      saveQueued=false;
      const token=csrfToken();
      try{
        if(!token)throw new Error('Jeton CSRF manquant');
        const res=await fetch(root.dataset.settingsUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','requesttoken':token,'X-Requested-With':'XMLHttpRequest'},body:encodeSettings().toString()});
        if(!res.ok)throw new Error(`HTTP ${res.status}`);
        // Preserve concurrent local changes; the current UI is authoritative.
      }catch(e){console.error('[Nova] sauvegarde impossible',e);notice('Échec de sauvegarde des préférences (voir F12).');break;}
    }
    saveRunning=false;
  }
  async function load(silent=false){
    try{
      const token=csrfToken();if(!token)throw new Error('Jeton CSRF manquant dans Nextcloud');
      const response=await fetch(root.dataset.overviewUrl,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json','requesttoken':token,'X-Requested-With':'XMLHttpRequest'}});
      if(!response.ok)throw new Error(`HTTP ${response.status}`);
      const data=await response.json();
      if(!data.overview||!data.settings)throw new Error('Réponse API inattendue');
      overview=data.overview;settings={...defaults(),...data.settings,sizes:{...defaultSizes,...(data.settings.sizes||{})}};
      root.dataset.displayName=data.user?.name||'bienvenue';
      render();
    }catch(e){
      console.error('[Nova] chargement impossible',e);
      if(silent&&overview){notice('Échec de l’actualisation.');return;}
      root.innerHTML=`<div class="nova-error" role="alert"><h2>Impossible de charger Nova Dashboard</h2><p>${esc(String(e.message))}. Vérifie ta session et F12 → Réseau.</p><button id="nova-retry" type="button">Réessayer</button></div>`;
      root.querySelector('#nova-retry')?.addEventListener('click',()=>{void load();});
    }
  }
  void load();
})();
