# Guide rapide : mise à jour Nova 0.1.x → 0.2 sur OMV

**Environnement ciblé :** Windows Terminal / NAS 192.168.1.200 / SSH `ssh-pxo` / conteneur Docker `nextcloud` / image `ghcr.io/linuxserver/nextcloud` / dossier `/config/www/nextcloud/apps/novadashboard` / Nextcloud 35.x.

## 1. Sur ton PC Windows : transférer le ZIP

```powershell
scp "X:\Travail\Apprentissage\Codage\nova-dashboard-nextcloud35-v0.2.0.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Sur le NAS en SSH : vérifier et sauvegarder

```bash
sudo docker exec nextcloud occ status
sudo docker exec nextcloud ls -ld /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v020.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

**Arrête-toi si Nextcloud n'est pas en 35.x ou si une des commandes échoue.** Effectue aussi une sauvegarde de ta base et de tes données Nextcloud avant modification.

## 3. Extraire et mettre à jour le code (pas les données)

```bash
mkdir -p /tmp/nova-v020
python3 -m zipfile -e /tmp/nova-dashboard-nextcloud35-v0.2.0.zip /tmp/nova-v020
ls /tmp/nova-v020/novadashboard/appinfo/info.xml
sudo docker cp /tmp/nova-v020/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

## 4. Tester

```bash
sudo docker exec nextcloud php -l /config/www/nextcloud/apps/novadashboard/lib/Service/PreferencesService.php
sudo docker exec nextcloud occ status
```

Ouvre `/index.php/apps/novadashboard/` puis **Ctrl+F5**. Active Personnaliser et teste taille, ordre, notes, liens.

En cas d'erreur, consulte F12 → Réseau → `api/overview` et les journaux Nextcloud. Aucun redémarrage du conteneur n'est requis normalement.

## 5. Annuler la mise à jour

```bash
sudo docker exec nextcloud sh -c 'tar -xzf /config/novadashboard-backup-avant-v020.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

La restauration ne touche pas `/data`, MariaDB ni Redis. La sauvegarde complète (base + fichiers) reste importante avant mise à jour d'une installation utilisée en production.
