# Neos v0.5.8 — Guide d'installation OMV / Nextcloud 35

Identifiant technique : `novadashboard`. Nom visible : **Neos**.

Cette mise à jour reprend la v0.5.7 et ajoute un **sélecteur de dossier** pour les copies/déplacements, un **suivi des téléversements** avec bouton d'annulation, et des animations dans la bannière. Elle ne demande ni réinstallation de Docker ni migration de base de données.

## 1. Transfert depuis Windows PowerShell

Après avoir téléchargé l'archive ZIP dans :

`X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.8.zip`

exécute :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.8.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifications préalables

```bash
sudo docker exec nextcloud occ status
```

N'installe la mise à jour que si la version est toujours **35.x**, avec `maintenance: false` et `needsDbUpgrade: false`, sans mise à jour Nextcloud en cours.

## 3. Sauvegarder l'app actuellement installée

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v058.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v058.tar.gz
```

Cette sauvegarde ne remplace pas une sauvegarde de la base, de la configuration et des fichiers Nextcloud.

## 4. Installer

```bash
mkdir -p /tmp/neos-v058
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.8.zip /tmp/neos-v058
ls -l /tmp/neos-v058/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v058/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Fais ensuite un rechargement complet du navigateur (**Ctrl + F5**).

## 5. Vérifier les nouvelles fonctions (sur des fichiers de test)

1. Dans **Neos → Fichiers**, crée un dossier `Essai destination`.
2. Sélectionne un petit fichier non important, puis clique **Copier vers…**.
3. Choisis `Essai destination` dans la fenêtre ; valide avec **Copier ici**.
4. Vérifie que le fichier apparaît dans le dossier choisi. Recommence pour un déplacement avec un autre fichier de test.
5. Téléverse un petit fichier depuis ton PC. Le panneau de progression doit afficher un pourcentage et le nom du fichier.
6. Pour vérifier **Annuler**, recommence avec un fichier temporaire de taille suffisante, puis clique sur la croix pendant l'envoi.
7. Vérifie enfin le mouvement des arcs de la bannière (réglage **Animations** : complètes, discrètes, désactivées).

**Précautions :** un fichier copié ou déplacé ne remplace pas automatiquement un fichier existant. L'annulation d'un téléversement arrête l'envoi en cours, mais ne révoque pas les fichiers déjà transmis. Le résultat pour les montages externes dépend des permissions et du serveur. Le transfert reste de type WebDAV `PUT` standard : les fichiers très volumineux peuvent nécessiter le client Nextcloud ou son mécanisme de transfert par blocs.

## 6. Retour arrière (code de l'application uniquement)

Si une erreur survient, restaure la sauvegarde de l'étape 3 :

```bash
sudo docker exec nextcloud sh -c 'mv /config/www/nextcloud/apps/novadashboard /config/neos-v058-a-verifier'
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v058.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Si le dossier `/config/neos-v058-a-verifier` existe déjà, utilise un nom différent ; ne l'écrase pas. Le retour arrière du code **ne restaure pas** les fichiers éventuellement modifiés ou déplacés après la mise à jour.

## Validation effectuée

- Vérification PHP, JavaScript, XML et intégrité ZIP.
- Tests Chromium **en démonstration** pour l'ouverture du sélecteur, la navigation et l'annulation de son affichage, sur ordinateur et mobile.
- Test simulé avec `XMLHttpRequest` du pourcentage d'envoi et du bouton Annuler.
- **Pas de test sur le NAS réel** : utiliser d'abord des fichiers non importants.
