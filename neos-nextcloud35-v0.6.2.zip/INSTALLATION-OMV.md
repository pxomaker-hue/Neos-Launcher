# Neos v0.6.2 — Deck enrichi pour Nextcloud 35

App technique : `novadashboard` (inchangé). Les PDF, favoris, fichiers, Notes, widgets et thème existants sont conservés.

## Nouveautés

- Création d'une carte Deck : titre, description Markdown, échéance facultative, choix de colonne.
- Édition d'une carte : titre, description, échéance, état terminé et colonne cible.
- Glisser-déposer d'une carte entre colonnes sur ordinateur ; via la liste « Colonne » dans la fenêtre d'édition sur mobile.
- Contrôle du résultat réel d'un déplacement après rechargement. Certaines versions de Deck renvoient un HTTP 200 sans effectuer le mouvement ; Neos tente alors une route de réorganisation de compatibilité et signale un échec si la carte n'a toujours pas bougé.
- Aucun changement au montage `/data` (sdb1), au montage `/config` (sdc1), à MariaDB ou à `defaultapp`.

## Installation sur OMV, une commande par ligne

Dans PowerShell Windows, après avoir placé l'archive dans le dossier local :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.2.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

Sur OMV, vérifier `maintenance: false`, `needsDbUpgrade: false` et version Nextcloud 35 :

```bash
sudo docker exec nextcloud occ status
```

Trouver le vrai chemin de l'application (ne pas supposer `/config/www/nextcloud` après la migration Docker) :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
echo "$APP_PATH"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

En cas d'échec du test, arrêter la procédure. Sauvegarde :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v062.tar.gz -C "$APP_PATH" .
```

Déploiement :

```bash
mkdir -p /tmp/neos-v062
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.2.zip /tmp/neos-v062
```

```bash
test -f /tmp/neos-v062/novadashboard/appinfo/info.xml && echo "Archive extraite OK"
```

```bash
sudo docker cp /tmp/neos-v062/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Vérifier `novadashboard: 0.6.2`, recharger le navigateur avec `Ctrl + F5`.

## Tests sans risque recommandés sur le NAS

1. Créer une **carte de test** dans un tableau Deck non critique, avec description et échéance.
2. Cocher « Carte terminée », puis rouvrir et vérifier la sauvegarde.
3. Déplacer la carte de test vers une autre colonne avec la liste « Colonne ».
4. Sur ordinateur, tenter un glisser-déposer entre deux colonnes.
5. Si le déplacement échoue, vérifier que la carte est restée dans la bonne colonne et relever le message affiché par Neos ; ne pas toucher aux données de production.
6. Confirmer que les PDF, favoris et Notes fonctionnent toujours.

**Limites :** tests de l'interface et de la compatibilité d'API réalisés en simulation ; aucun test direct sur l'instance de production. La prise en charge exacte de l'API varie avec la version de Deck ; un déplacement n'est jamais annoncé comme réussi sans relecture des colonnes.

## Retour arrière

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v062.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

La sauvegarde ne concerne que le code de l'application. Les données Nextcloud et la base MariaDB restent inchangées par l'installation.
