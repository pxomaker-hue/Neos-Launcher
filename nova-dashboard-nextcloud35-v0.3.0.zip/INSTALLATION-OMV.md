# Installer Nova Dashboard v0.3.0 sur ton NAS OMV

**Configuration connue** : OMV `192.168.1.200`, SSH `ssh-pxo`, conteneur Docker `nextcloud` (`ghcr.io/linuxserver/nextcloud`), Nextcloud 35.0.2, applications dans `/config/www/nextcloud/apps`, propriétaire `abc:abc`. Tu as déjà une v0.2 fonctionnelle.

> Cette version est expérimentale et n'a pas été validée sur ton NAS. Procède quand tu peux interrompre brièvement Nova, avec une **sauvegarde complète** de Nextcloud, sa base de données et ses volumes. Les commandes suivantes n'effacent pas les données Nextcloud.

## 1. Sur Windows : envoyer le paquet

Dans **Windows Terminal → PowerShell** (après avoir téléchargé l'archive dans le dossier indiqué) :

```powershell
scp "X:\Travail\Apprentissage\Codage\nova-dashboard-nextcloud35-v0.3.0.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Sur le NAS : vérifier la maintenance et les montages

```bash
sudo docker exec nextcloud occ status
sudo docker inspect nextcloud --format '{{range .Mounts}}{{println .Destination " <= " .Source}}{{end}}'
```

**Continuer uniquement si** : version 35.x, `installed: true`, `maintenance: false`, `needsDbUpgrade: false`, `/config` persistant. S'il y a une migration ou une maintenance active, ne pas copier les fichiers avant de comprendre pourquoi.

## 3. Faire une sauvegarde persistante de l'application

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v030.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/novadashboard-backup-avant-v030.tar.gz
```

Cette sauvegarde conserve uniquement **le code Nova**, pas la base de données ou les fichiers personnels. Elle ne remplace donc pas une vraie sauvegarde Nextcloud.

## 4. Extraire et copier Nova v0.3

Sur le NAS :

```bash
mkdir -p /tmp/nova-v030
python3 -m zipfile -e /tmp/nova-dashboard-nextcloud35-v0.3.0.zip /tmp/nova-v030
ls /tmp/nova-v030/novadashboard/appinfo/info.xml
sudo docker cp /tmp/nova-v030/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud php -l /config/www/nextcloud/apps/novadashboard/lib/Service/FileBrowserService.php
sudo docker exec nextcloud occ status
```

**Pas de modification du Compose**, pas d'arrêt de `nextcloud`, pas de `docker compose down`, pas de `occ upgrade` automatique. Si `occ status` signale une maintenance ou une mise à jour nécessaire, ne la force pas : relève le message et les logs. Un redéploiement Docker ne devrait pas être nécessaire.

## 5. Dans le navigateur : tests indispensables

Ouvre `/index.php/apps/novadashboard/` et fais **Ctrl+F5**. Vérifie que :

1. La nouvelle interface occupe la largeur disponible.
2. « Mes fichiers » affiche les dossiers et permet de naviguer à la racine et dans un sous-dossier.
3. Le filtre, le tri et le bouton liste/grille fonctionnent ; l'étoile épingle un dossier.
4. « Personnaliser » s'ouvre et se ferme avec **croix**, **Échap**, clic à l'extérieur ou **Terminer**.
5. Les réglages sont conservés après rechargement, et les raccourcis de fichiers ouvrent bien Nextcloud Files.

Le navigateur de fichiers est **en lecture seule** : le bouton « Ouvrir Fichiers » sert pour les opérations de copie, déplacement, partage, édition, chargement ou suppression. Il ne parcourt que les dossiers accessibles avec ta session. La recherche est limitée au dossier affiché et aux 120 éléments récupérés.

## 6. Si tu rencontres une erreur

Ouvre F12 → Réseau (Fetch/XHR) et note les statuts de `/apps/novadashboard/api/overview` et `/apps/novadashboard/api/files`. Pour les logs :

```bash
sudo docker logs --since 10m --tail 100 nextcloud
sudo docker exec nextcloud occ config:system:get logfile
```

Ne partage pas de cookies, jetons CSRF, clés d'application ni URLs de fichiers privés dans un extrait de logs.

## 7. Revenir à la v0.2 (code uniquement)

```bash
sudo docker exec nextcloud sh -c 'tar -xzf /config/novadashboard-backup-avant-v030.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Actualise le navigateur avec **Ctrl+F5**. Le fichier `FileBrowserService.php` supplémentaire peut rester présent mais ne sera plus appelé par les anciennes routes ; si tu veux une restauration strictement identique, retire uniquement ce fichier après avoir vérifié la sauvegarde. Les préférences supplémentaires (`motion`, `pins`) sont ignorées par la v0.2 ; ne restaure pas de base de données uniquement pour cela.

Si Nextcloud se retrouve en maintenance, exécute `sudo docker exec nextcloud occ status` **avant** toute autre action. La désactivation du mode maintenance ne doit être envisagée que si `needsDbUpgrade: false` et si aucune mise à jour n'est en cours.
