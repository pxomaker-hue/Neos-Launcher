# Nova Dashboard v0.3.0 — Nextcloud 35

Application Nextcloud personnalisée, conçue pour **Nextcloud 35.x / PHP 8.3+** et testée en aperçu navigateur simulé. Utilisable avec Docker/LinuxServer.io (`ghcr.io/linuxserver/nextcloud`) sur OpenMediaVault. Le code n'est ni signé ni certifié par l'App Store Nextcloud.

## À quoi sert Nova ?

- **Fichiers d'abord** : explorateur de dossiers en lecture seule, favoris personnels, fil d'Ariane, filtre local sur le dossier affiché, tri (nom / récents / taille), affichage en liste ou grille, miniatures lorsque Nextcloud peut les générer, renvoi dans l'application Fichiers pour modifier, partager ou supprimer.
- Widgets : stockage, fichiers récents, raccourcis applicatifs, horloge, calendrier, tâches, synthèse, notes personnelles et liens.
- Personnalisation : thème sombre / clair / automatique, accent, densité, pleine largeur ou largeur centrée, ordre des cartes, carte visible/cachée, taille des widgets et niveau d'animation.
- Panneau de personnalisation **réellement indépendant du dashboard** : croix, `Échap`, bouton `Terminer`, clic sur le voile ; navigation au clavier (focus piégé tant que le panneau est ouvert).
- Design original « Aurora glass » : halos, lumière localisée au survol, entrées échelonnées, effets de profondeur, bouton à retour élastique, orbites lumineuses.
- Le système d'animation utilise la **Web Animations API native et CSS**, avec les principes `stagger` et easing documentés par Anime.js : aucune bibliothèque Anime.js, aucun code de CodePen et aucun CDN ne sont intégrés, afin d'être autonomes et compatibles avec la CSP de Nextcloud.
- Accessibilité : option Animations « Fluides / Discrètes / Désactivées » et respect de `prefers-reduced-motion` du système.

## Données et sécurité

Les routes exigent une session utilisateur Nextcloud. Le GET initial de page est exempté de CSRF car il charge l'interface ; les routes d'API authentifiées utilisent un jeton CSRF et l'enregistrement des préférences conserve cette protection. Pas d'identifiants tiers ni de requête sortante.

Le navigateur de fichiers est **en lecture seule** et limité à 120 éléments par dossier affiché ; ce n'est **pas** une recherche globale dans toutes les données. Les liens vers les fichiers ouvrent le dossier correspondant dans l'application Fichiers de Nextcloud. Le quota ne comprend pas nécessairement les stockages externes et la liste des « récents » repose sur un échantillon borné. Les widgets Calendrier/Tâches dépendent des applications et calendriers disponibles.

Les préférences et notes sont stockées via `IConfig` pour chaque utilisateur (notes : maximum 3 000 octets, non chiffrées de bout en bout). Ne pas y stocker de secrets ou mots de passe. Les noms de fichiers sont échappés dans le HTML, les chemins validés côté serveur et les permissions Nextcloud contrôlées avant affichage.

## Installation / mise à jour depuis v0.2

Lire **`INSTALLATION-OMV.md`** (dans le ZIP complet) avant copie. **Ne pas supprimer** `nextcloud`, `/config`, `/data`, ni modifier les volumes Docker. Sauvegarder les données Nextcloud, sa base et la configuration avant toute mise à jour. La mise à jour de Nova ne modifie pas directement les fichiers personnels, ni la structure SQL.

## Compatibilité

- Nextcloud **35.x**, PHP **8.3 ou plus**, pas de compatibilité garantie avec Nextcloud 36+.
- Déploiement LinuxServer OMV déjà confirmé : `/config/www/nextcloud/apps/novadashboard`, propriétaire `abc:abc`, conteneur `nextcloud`.
- Peut demander une réinitialisation du cache navigateur (`Ctrl + F5`) ; voir F12 → Réseau pour `/apps/novadashboard/api/overview` et `/api/files` en cas d'erreur.
- La v0.3 a passé une vérification de syntaxe PHP/JS, des tests XML/ZIP, ainsi que des tests **navigateur simulé** de panneau, navigation des dossiers, filtre, tri et responsive. **Elle n'a pas été exécutée sur ton conteneur Nextcloud réel** : la validation de production reste à faire.

## Inspirations (sans réutilisation de code des démos)

- [Anime.js v4 – documentation](https://animejs.com/documentation) : animations stagger, easing, timelines.
- [Anime.js v4 – collection CodePen](https://codepen.io/collection/Poerqa?cursor=eyJwYWdlIjo3fQ==) : expérimentations d'interactions.

Licence du code Nova : AGPL-3.0-or-later (voir `appinfo/info.xml`).
