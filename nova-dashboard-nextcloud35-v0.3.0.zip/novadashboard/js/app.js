/** Nova Dashboard 0.3.0 — Nextcloud 35, no external client dependencies. */
(() => {
  'use strict';
  const root = document.getElementById('nova-root');
  if (!root) return;
  root.innerHTML = '<div id="nova-surface"></div><div id="nova-editor-host"></div><div id="nova-toast-host" aria-live="polite"></div>';
  const surface = root.querySelector('#nova-surface');
  const editorHost = root.querySelector('#nova-editor-host');
  const toastHost = root.querySelector('#nova-toast-host');
  const demo = window.NOVA_DEMO_DATA && root.dataset.demo === 'true' ? window.NOVA_DEMO_DATA : null;
  const csrfToken = () => document.head?.getAttribute('data-requesttoken') || window.OC?.requestToken || '';
  const icons = {
    sparkles:'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 17 .8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',
    check:'<rect x="3" y="4" width="18" height="17" rx="3"/><path d="m8 12 3 3 5-6"/>',
    storage:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 12h18m-5 4h2"/><circle cx="7" cy="16" r="1"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-6-6L4 21"/>',
    message:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
    settings:'<path d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.8 9A7.5 7.5 0 0 1 19 6l1 1M4 17l1 1a7.5 7.5 0 0 0 13.2-3"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>', up:'<path d="m6 15 6-6 6 6"/>', down:'<path d="m6 9 6 6 6-6"/>',
    close:'<path d="M5 5l14 14M19 5 5 19"/>',
    grip:'<circle cx="9" cy="5" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="19" r="1"/>',
    file:'<path d="M6 2h9l5 5v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z"/><path d="M14 2v6h6"/>',
    external:'<path d="M14 4h6v6m-9 3 9-9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
    alert:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3v.1"/>',
    cloud:'<path d="M5 18a4 4 0 0 1-.4-8 7 7 0 0 1 13-1 4.5 4.5 0 0 1 1 9H5Z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7 .2l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7-.2l-3 3a5 5 0 1 0 7.1 7.1l1.7-1.7"/>',
    note:'<path d="M4 3h16v18H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    chart:'<path d="M3 20h18M6 17v-4m6 4V6m6 11v-8"/>',
    plus:'<path d="M12 4v16M4 12h16"/>', trash:'<path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
    star:'<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.3-5.7-3-5.7 3 1.1-6.3L2.8 9.7l6.4-.9L12 3Z"/>',
    list:'<path d="M9 5h12M9 12h12M9 19h12"/><path d="M3 5h.1M3 12h.1M3 19h.1"/>',
    sort:'<path d="M7 4v16m0 0-4-4m4 4 4-4M17 20V4m0 0-4 4m4-4 4 4"/>',
    arrow:'<path d="M4 12h16m-7-7 7 7-7 7"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
    bolt:'<path d="m13 2-9 12h7l-1 8 10-12h-7l0-8Z"/>',
    home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
  };
  const icon=(name,size=18)=>`<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name]||icons.file}</svg>`;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeUrl=s=>typeof s==='string' && ((/^\/(?!\/)/.test(s)&&!s.includes('\\'))||/^https?:\/\//i.test(s))?esc(s):'#';
  const safeColor=s=>/^#[0-9a-f]{6}$/i.test(String(s))?s:'#8495ff';
  const number=n=>Number.isFinite(Number(n))?Number(n):0;
  const humanSize=b=>{if(b==null)return '—';const n=Math.max(0,number(b));const p=n?Math.min(4,Math.floor(Math.log(n)/Math.log(1024))):0;return new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(n/Math.pow(1024,p))+' '+['o','Ko','Mo','Go','To'][p];};
  const fmtTime=iso=>{if(!iso)return 'Sans échéance';const d=new Date(iso);return Number.isNaN(+d)?'Date inconnue':new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(d);};
  const ago=ts=>{const d=Math.max(0,Math.round((Date.now()-number(ts)*1000)/86400000));return d===0?'Aujourd’hui':d===1?'Hier':`Il y a ${d} j`;};
  const labels={explorer:'Mes fichiers',storage:'Stockage',shortcuts:'Accès rapide',clock:'Horloge locale',files:'Fichiers récents',calendar:'Prochains événements',tasks:'Tâches à faire',summary:'En un coup d’œil',links:'Mes liens',notes:'Mes notes'};
  const symbols={explorer:'folder',storage:'storage',shortcuts:'grid',clock:'clock',files:'file',calendar:'calendar',tasks:'check',summary:'chart',links:'link',notes:'note'};
  const allWidgets=Object.keys(labels);
  const defaultSizes={explorer:12,storage:3,shortcuts:6,clock:3,files:6,calendar:6,tasks:6,summary:6,links:6,notes:6};
  const defaults=()=>({theme:'system',density:'comfortable',accent:'indigo',layout:'wide',motion:'full',order:[...allWidgets],hidden:['links','notes'],sizes:{...defaultSizes},links:[],notes:'',pins:[]});
  let overview=null,settings=null,editing=false,editorOpen=false,saving=false,saveQueued=false,editorReturnFocus=null;
  let browseGeneration=0,clockTimer=null,hasEntered=false;
  const browser={path:'/',items:[],total:0,limit:120,truncated:false,filesUrl:'#',loading:true,error:'',query:'',sort:'name',type:'all',view:'list'};

  function applyTheme(){
    const pref=settings?.theme||'system';
    const light=pref==='light'||(pref==='system'&&window.matchMedia?.('(prefers-color-scheme: light)').matches);
    root.classList.toggle('nova-light',!!light);root.classList.toggle('nova-dark',!light);
    root.dataset.accent=settings?.accent||'indigo';root.dataset.density=settings?.density||'comfortable';root.dataset.layout=settings?.layout||'wide';root.dataset.motion=settings?.motion||'full';
  }
  window.matchMedia?.('(prefers-color-scheme: light)').addEventListener?.('change',()=>{if(settings?.theme==='system')applyTheme();});
  // Anime.js-inspired stagger, spring-like easing and visual rhythm implemented
  // with the native Web Animations API: no CDN, remote scripts or CSP exceptions.
  const reducedMotion=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)').matches===true;
  const motionEnabled=()=>!reducedMotion()&&settings?.motion!=='off';
  const motionSpeed=()=>settings?.motion==='subtle'?.58:1;
  function enter(nodes,delay=45,base=0){
    if(!motionEnabled())return;
    [...nodes].slice(0,24).forEach((el,i)=>{
      if(typeof el.animate!=='function')return;
      el.animate([
        {opacity:0,transform:'translate3d(0,16px,0) scale(.985)',filter:'blur(3px)'},
        {opacity:1,transform:'translate3d(0,0,0) scale(1)',filter:'blur(0px)'}
      ],{duration:Math.round(580*motionSpeed()),delay:base+i*delay*motionSpeed(),easing:'cubic-bezier(.16,1,.3,1)',fill:'both'});
    });
  }
  function blink(el){
    if(!motionEnabled()||!el?.animate)return;
    el.animate([{transform:'scale(.96)'},{transform:'scale(1.015)'},{transform:'scale(1)'}],{duration:450*motionSpeed(),easing:'cubic-bezier(.17,.89,.32,1.27)'});
  }
  function toast(message,type='info'){
    const node=document.createElement('div');node.className='nova-toast nova-toast-'+type;node.setAttribute('role','status');node.textContent=message;
    toastHost.replaceChildren(node);setTimeout(()=>{if(node.isConnected)node.remove();},4500);
  }
  async function api(url,options={}){
    if(demo)throw new Error('Aucun accès serveur en démonstration');
    const token=csrfToken();if(!token)throw new Error('Jeton CSRF manquant');
    const response=await fetch(url,{credentials:'same-origin',cache:'no-store',...options,headers:{'Accept':'application/json','requesttoken':token,'X-Requested-With':'XMLHttpRequest',...(options.headers||{})}});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    return response.json();
  }
  function box(id,contents,sub='',tools=''){
    const size=Number(settings.sizes?.[id]??defaultSizes[id]);
    return `<section class="nova-card nova-${id}" data-widget="${id}" data-size="${[3,4,6,8,12].includes(size)?size:6}" draggable="${editing}" aria-label="${esc(labels[id])}">
      <header class="nova-card-head"><div class="nova-card-name">${icon(symbols[id],18)}<span>${esc(labels[id])}</span></div><div class="nova-card-actions">${tools}<span class="nova-card-sub">${editing?icon('grip',16):sub}</span></div></header>
      <div class="nova-card-body">${contents}</div></section>`;
  }
  function fileGlyph(entry){
    if(entry.kind==='folder')return 'folder';
    if((entry.mime||'').startsWith('image/'))return 'image';
    return 'file';
  }
  function breadcrumb(){
    const names=browser.path.split('/').filter(Boolean);
    const crumbs=[`<button type="button" data-action="browse-path" data-path="/" class="nova-crumb ${names.length?'':'active'}">${icon('home',14)} Racine</button>`];
    let path='';names.forEach((part,index)=>{path+='/'+part;crumbs.push(`${icon('chevron',12)}<button type="button" data-action="browse-path" data-path="${esc(path)}" class="nova-crumb ${index===names.length-1?'active':''}" title="${esc(part)}">${esc(part)}</button>`);});
    return crumbs.join('');
  }
  function filesHomeUrl(){return browser.filesUrl&&browser.filesUrl!=='#'?browser.filesUrl:((overview?.shortcuts||[]).find(x=>x.id==='files')?.url||'/index.php/apps/files/');}
  function browserRows(){
    if(browser.loading)return `<div class="nova-browser-state"><span class="nova-spinner"></span> Chargement de ce dossier…</div>`;
    if(browser.error)return `<div class="nova-browser-state nova-browser-failed">${icon('alert',22)}<strong>${esc(browser.error)}</strong><button type="button" class="nova-btn" data-action="reload-folder">Réessayer</button></div>`;
    const term=browser.query.trim().toLocaleLowerCase('fr-FR');
    let items=browser.items.filter(x=>(browser.type==='all'||x.kind===browser.type)&&(!term||String(x.name||'').toLocaleLowerCase('fr-FR').includes(term)));
    if(browser.sort==='recent')items=[...items].sort((a,b)=>number(b.mtime)-number(a.mtime));
    else if(browser.sort==='size')items=[...items].sort((a,b)=>number(b.size)-number(a.size));
    else items=[...items].sort((a,b)=>(a.kind==='folder'?0:1)-(b.kind==='folder'?0:1)||String(a.name).localeCompare(String(b.name),'fr',{numeric:true}));
    const countEl=`${items.length} élément${items.length>1?'s':''}${browser.truncated?' parmi les '+browser.limit+' premiers':''}`;
    if(!items.length)return `<div class="nova-browser-state">${icon('search',26)}<strong>${term?'Aucun résultat dans les éléments affichés':'Ce dossier est vide'}</strong><span>${term?'Essaie un autre terme.':'Choisis un autre dossier ou ouvre l’application Fichiers.'}</span></div>`;
    const entries=items.map(x=>{
      const isFolder=x.kind==='folder';const isPinned=(settings.pins||[]).includes(x.path);
      const primary=isFolder?`<button type="button" class="nova-file-primary" data-action="browse-path" data-path="${esc(x.path)}" aria-label="Ouvrir le dossier ${esc(x.name)}">`:
        `<a class="nova-file-primary" href="${safeUrl(x.url)}" title="Retrouver ce fichier dans Nextcloud Fichiers">`;
      const end=isFolder?'</button>':'</a>';
      const thumb=x.kind==='file'&&String(x.mime||'').startsWith('image/')&&x.id>0&&x.id<1e15
        ?`<img class="nova-file-thumb" loading="lazy" alt="" src="${safeUrl(root.dataset.previewBase||'/index.php/core/preview')}?fileId=${x.id}&amp;x=120&amp;y=120&amp;forceIcon=0" >` : '';
      return `<div class="nova-file-row ${isFolder?'is-folder':'is-file'}" data-file-kind="${x.kind}">${primary}<span class="nova-file-symbol">${thumb}${icon(fileGlyph(x),19)}</span><span class="nova-file-title"><strong title="${esc(x.name)}">${esc(x.name)}</strong><small>${isFolder?'Dossier':esc(x.mime||'Fichier')} · ${ago(x.mtime)}</small></span><span class="nova-file-size">${isFolder?'—':humanSize(x.size)}</span>${icon(isFolder?'chevron':'external',15)}${end}
        ${isFolder?`<button type="button" class="nova-file-pin ${isPinned?'is-pinned':''}" data-action="pin-folder" data-path="${esc(x.path)}" title="${isPinned?'Retirer des favoris':'Épingler ce dossier'}" aria-label="${isPinned?'Retirer des favoris':'Épingler'} ${esc(x.name)}">${icon('star',18)}</button>`:''}</div>`;
    }).join('');
    return `<div class="nova-browser-count" aria-live="polite">${countEl}</div><div class="nova-file-list ${browser.view==='grid'?'nova-file-tiles':''}">${entries}</div>${browser.truncated?`<div class="nova-browser-limit">${icon('info',15)} Dossier volumineux : seuls les ${browser.limit} premiers éléments sont affichés. <a href="${safeUrl(filesHomeUrl())}">Ouvrir dans Fichiers</a> pour tout voir.</div>`:''}`;
  }
  function explorerWidget(){
    const pins=(settings.pins||[]).slice(0,12);
    return box('explorer',`<div class="nova-browser">
        <div class="nova-browser-intro"><div><span class="nova-overline">WORKSPACE / FICHIERS</span><h2>Ton univers, bien rangé<span class="nova-h2-dot">.</span></h2><p>Explore, recherche, épingle tes dossiers et ouvre tes documents dans Nextcloud.</p></div><a class="nova-btn nova-btn-soft" href="${safeUrl(filesHomeUrl())}">${icon('external',16)} Ouvrir Fichiers</a></div>
        ${pins.length?`<div class="nova-pins"><span>${icon('star',14)} Favoris</span>${pins.map(p=>`<button type="button" class="nova-pin-chip" data-action="browse-path" data-path="${esc(p)}" title="${esc(p)}">${icon('folder',14)} ${esc(p.split('/').pop())}</button>`).join('')}</div>`:''}
        <div class="nova-browser-controls"><div class="nova-breadcrumb" aria-label="Chemin du dossier">${breadcrumb()}</div><div class="nova-browser-filters"><label class="nova-search-wrap">${icon('search',17)}<input type="search" data-browser-search aria-label="Rechercher parmi les éléments affichés" placeholder="Filtrer ce dossier…" value="${esc(browser.query)}"></label><select data-browser-type aria-label="Filtrer par type"><option value="all" ${browser.type==='all'?'selected':''}>Tout</option><option value="folder" ${browser.type==='folder'?'selected':''}>Dossiers</option><option value="file" ${browser.type==='file'?'selected':''}>Fichiers</option></select><select data-browser-sort aria-label="Trier les fichiers"><option value="name" ${browser.sort==='name'?'selected':''}>Nom</option><option value="recent" ${browser.sort==='recent'?'selected':''}>Récents</option><option value="size" ${browser.sort==='size'?'selected':''}>Taille</option></select><button type="button" class="nova-btn nova-btn-icon" data-action="toggle-view" title="Changer la vue" aria-label="Changer la vue">${icon(browser.view==='grid'?'list':'grid',17)}</button><button type="button" class="nova-btn nova-btn-icon" data-action="reload-folder" title="Actualiser le dossier" aria-label="Actualiser le dossier">${icon('refresh',17)}</button></div></div>
        <div id="nova-browser-results">${browserRows()}</div><div class="nova-browser-foot">${icon('info',15)} Vue en lecture seule · utilise l'application Fichiers pour modifier, partager ou supprimer.</div>
      </div>`, 'Dossiers & documents');
  }
  function storageWidget(){const v=overview.storage||{};const p=Math.max(0,Math.min(100,number(v.percent)));return box('storage',`<div class="nova-stat-main">${humanSize(v.used)}</div><p class="nova-subtle">${v.total==null?'Quota illimité':'sur '+humanSize(v.total)}</p><div class="nova-meter"><span style="width:${p}%"></span></div><p class="nova-explainer">${v.total==null?'Aucune limite de quota définie':`Quota utilisé : ${p.toFixed(1).replace('.',',')} %`} · Hors stockages externes</p>`);}
  function shortcutWidget(){const list=overview.shortcuts||[];return box('shortcuts',list.length?`<div class="nova-shortcut-grid">${list.map(x=>`<a class="nova-shortcut" href="${safeUrl(x.url)}"><span class="nova-shortcut-glyph">${icon(icons[x.icon]?x.icon:'grid',23)}</span><span>${esc(x.label)}</span>${icon('arrow',13)}</a>`).join('')}</div>`:'<p class="nova-empty">Aucune application disponible.</p>');}
  function clockWidget(){return box('clock',`<div class="nova-clock-time" data-clock>--:--</div><p class="nova-subtle" data-clock-date>Heure locale</p><span class="nova-tag">${icon('clock',14)} Ton fuseau horaire</span>`);}
  function recentWidget(){const list=overview.files||[];return box('files',list.length?`<div class="nova-list">${list.map(x=>`<a class="nova-item" href="${safeUrl(x.url)}"><span class="nova-item-icon">${icon('file',17)}</span><span class="nova-item-title"><strong title="${esc(x.name)}">${esc(x.name)}</strong><small>${esc(x.folder)} · ${ago(x.mtime)}</small></span><span class="nova-item-meta">${humanSize(x.size)}</span>${icon('chevron',13)}</a>`).join('')}</div><p class="nova-explainer">Échantillon récent des dossiers explorés (recherche limitée).</p>`:'<p class="nova-empty">Aucun fichier dans les dossiers explorés.</p>','8 max');}
  function calendarWidget(){const list=overview.calendar||[];return box('calendar',list.length?`<div class="nova-list">${list.map(x=>`<div class="nova-item"><span class="nova-event-bar" style="background:${safeColor(x.color)}"></span><span class="nova-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.calendar)}</small></span><span class="nova-item-meta">${fmtTime(x.start)}</span></div>`).join('')}</div>`:'<p class="nova-empty">Aucun événement dans les 30 prochains jours.</p>','30 jours');}
  function taskWidget(){const list=overview.tasks||[];return box('tasks',list.length?`<div class="nova-list">${list.map(x=>`<div class="nova-item"><span class="nova-item-icon">${icon('check',16)}</span><span class="nova-item-title"><strong>${esc(x.title)}</strong><small>${fmtTime(x.due)}</small></span></div>`).join('')}</div>`:'<p class="nova-empty">Aucune tâche non terminée trouvée via CalDAV.</p>','CalDAV');}
  function summaryWidget(){const end=new Date();end.setDate(end.getDate()+7);const week=(overview.calendar||[]).filter(e=>{const d=new Date(e.start);return !Number.isNaN(+d)&&d<=end&&d>=new Date();}).length;const stats=[[humanSize(overview.storage?.used),'Espace utilisé'],[(overview.files||[]).length,'Fichiers récents repérés'],[week,'Événements sous 7 jours'],[(overview.tasks||[]).length,'Tâches trouvées']];return box('summary',`<div class="nova-metrics">${stats.map(([value,label])=>`<div class="nova-metric"><strong>${esc(value)}</strong><span>${esc(label)}</span></div>`).join('')}</div><p class="nova-explainer">Synthèse des éléments accessibles, non exhaustive.</p>`,'Nextcloud');}
  function linkWidget(){const list=settings.links||[];return box('links',`<div class="nova-list">${list.length?list.map(x=>`<a class="nova-item" href="${safeUrl(x.url)}" target="_blank" rel="noopener noreferrer"><span class="nova-item-icon">${icon('link',17)}</span><span class="nova-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.url)}</small></span>${icon('external',14)}</a>`).join(''):'<p class="nova-empty">Ajoute des liens via Personnaliser.</p>'}</div>`,'Privés');}
  function noteWidget(){return box('notes',`<label class="nova-note-label" for="nova-note-text">Mon bloc-notes privé</label><textarea id="nova-note-text" maxlength="3000" placeholder="Une idée, un rappel, une note…">${esc(settings.notes||'')}</textarea><div class="nova-note-actions"><span>Enregistré dans tes préférences Nextcloud</span><button type="button" data-action="save-note" class="nova-btn nova-btn-primary">${icon('check',16)} Enregistrer</button></div>`,'Personnel');}
  const widgets={explorer:explorerWidget,storage:storageWidget,shortcuts:shortcutWidget,clock:clockWidget,files:recentWidget,calendar:calendarWidget,tasks:taskWidget,summary:summaryWidget,links:linkWidget,notes:noteWidget};
  const greeting=()=>{const h=new Date().getHours();return h<12?'Bonjour':h<18?'Bon après-midi':'Bonsoir';};
  function render(){
    if(!overview||!settings)return;
    applyTheme();
    const warning=(overview.warnings||[]).map(w=>`<span class="nova-warning">${icon('alert',15)} ${esc(w)}</span>`).join('');
    const firstFile=(overview.files||[])[0];
    surface.innerHTML=`<main class="nova-app"><div class="nova-container">
      <nav class="nova-top"><div class="nova-brand"><span class="nova-mark">${icon('sparkles',23)}</span><span><strong>NOVA <i>✦</i></strong><small>TON CLOUD, RÉINVENTÉ</small></span></div><div class="nova-toolbar"><span class="nova-online"><i></i> Ton espace</span><button type="button" data-action="refresh" class="nova-btn nova-btn-icon" title="Actualiser" aria-label="Actualiser">${icon('refresh',18)}</button><button type="button" data-action="customize" class="nova-btn nova-btn-primary">${icon(editing?'check':'settings',17)} ${editing?'Terminer':'Personnaliser'}</button></div></nav>
      <section class="nova-hero"><div class="nova-hero-text"><div class="nova-eyebrow">ESPACE PERSONNEL <span class="nova-line-glow"></span> NOVA 0.3</div><h1>${greeting()}, <em>${esc(root.dataset.displayName||'toi')}</em><span class="nova-star">✦</span></h1><p>Tout ton univers numérique, à portée de main.</p><div class="nova-hero-actions"><button type="button" data-action="jump-files" class="nova-btn nova-btn-cta">${icon('folder',17)} Explorer mes fichiers ${icon('arrow',17)}</button>${firstFile?`<span class="nova-last-file">${icon('clock',15)} Dernière activité : ${esc(firstFile.name)}</span>`:''}</div></div><div class="nova-hero-side"><div class="nova-hero-orb"><span class="nova-orbit nova-orbit-a"></span><span class="nova-orbit nova-orbit-b"></span><span class="nova-orb-core">${icon('cloud',40)}</span></div><span>${new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date())}</span></div></section>
      ${warning?`<div class="nova-warning-row">${warning}</div>`:''}
      ${editing?`<div class="nova-editbar">${icon('grip',18)} <span>Glisse les cartes pour les réorganiser ; change leur taille dans le panneau.</span><button type="button" class="nova-btn" data-action="open-editor">${icon('settings',16)} Paramètres</button></div>`:''}
      <div class="nova-grid">${settings.order.filter(id=>!settings.hidden.includes(id)).map(id=>widgets[id]?.()||'').join('')}</div>
      <footer class="nova-footer"><span>${icon('cloud',15)} Nova Dashboard v0.3.0</span><span>Local · Intégré à Nextcloud · Aucun service tiers requis</span></footer>
      </div></main>`;
    updateClock();
    if(!hasEntered){hasEntered=true;enter(surface.querySelectorAll('.nova-hero-text > *, .nova-card'),43,60);}
  }
  function updateBrowserResults(){const result=surface.querySelector('#nova-browser-results');if(result){result.innerHTML=browserRows();enter(result.querySelectorAll('.nova-file-row'),18,10);}}
  function updateBrowserHeader(){
    const crumbs=surface.querySelector('.nova-breadcrumb');if(crumbs)crumbs.innerHTML=breadcrumb();
    const chips=surface.querySelector('.nova-pins');if(chips){chips.outerHTML=(settings.pins||[]).length?`<div class="nova-pins"><span>${icon('star',14)} Favoris</span>${settings.pins.map(p=>`<button type="button" class="nova-pin-chip" data-action="browse-path" data-path="${esc(p)}" title="${esc(p)}">${icon('folder',14)} ${esc(p.split('/').pop())}</button>`).join('')}</div>`:'';}
    else if((settings.pins||[]).length){render();return;}
    const link=surface.querySelector('.nova-browser-intro>a');if(link)link.href=filesHomeUrl();
  }
  function setFolderError(message){browser.loading=false;browser.error=message;updateBrowserResults();}
  async function browse(path,resetQuery=true){
    if(!path||!path.startsWith('/')||path.includes('\\')||(path!=='/'&&path.split('/').some((x,i)=>i>0&&(x==='..'||x==='.'||x===''))))return;
    browser.path=path;if(resetQuery)browser.query='';browser.loading=true;browser.error='';
    ++browseGeneration;const generation=browseGeneration;
    updateBrowserHeader();render();
    try{
      let data;
      if(demo){data=demo.browse[path]||{path,items:[],total:0,limit:120,truncated:false,filesUrl:'#'};}
      else{const url=new URL(root.dataset.filesUrl,window.location.href);url.searchParams.set('path',path);data=await api(url.toString());}
      if(generation!==browseGeneration)return;
      if(!Array.isArray(data.items))throw new Error('Réponse invalide');
      browser.path=data.path||path;browser.items=data.items;browser.total=number(data.total);browser.truncated=Boolean(data.truncated);browser.limit=number(data.limit)||120;browser.filesUrl=data.filesUrl||'#';
      browser.loading=false;browser.error='';render();enter(surface.querySelectorAll('.nova-file-row'),18,5);
    }catch(error){if(generation!==browseGeneration)return;console.error('[Nova] dossier indisponible',error);setFolderError('Impossible de charger ce dossier.');}
  }
  function editorMarkup(){
    const radio=(name,choices)=>`<div class="nova-choice-set">${choices.map(([value,text])=>`<label class="nova-choice"><input type="radio" name="${name}" value="${value}" ${settings[name]===value?'checked':''}><span>${text}</span></label>`).join('')}</div>`;
    return `<div class="nova-editor-overlay" data-action="editor-backdrop"><aside class="nova-editor" role="dialog" aria-modal="true" aria-labelledby="nova-editor-title" tabindex="-1"><header class="nova-editor-header"><div><span class="nova-overline">MON ESPACE</span><h2 id="nova-editor-title">Personnalisation<span class="nova-h2-dot">.</span></h2><p>Crée une interface qui te ressemble.</p></div><button type="button" data-action="close-editor" class="nova-btn nova-btn-icon nova-editor-close" aria-label="Fermer la personnalisation">${icon('close',21)}</button></header>
       <div class="nova-editor-scroll"><h3>Apparence</h3><div class="nova-editor-setting"><label>Thème</label>${radio('theme',[['system','Auto'],['dark','Sombre'],['light','Clair']])}</div><div class="nova-editor-setting"><label>Accent</label>${radio('accent',[['indigo','Indigo'],['cyan','Cyan'],['emerald','Émeraude'],['rose','Rose'],['amber','Ambre']])}</div><div class="nova-editor-setting"><label>Densité</label>${radio('density',[['comfortable','Aérée'],['compact','Compacte']])}</div><div class="nova-editor-setting"><label>Largeur</label>${radio('layout',[['wide','Pleine largeur'],['focused','Centrée']])}</div><div class="nova-editor-setting"><label>Animations</label>${radio('motion',[['full','Fluides'],['subtle','Discrètes'],['off','Désactivées']])}</div>
       <h3>Mes widgets</h3><p class="nova-editor-hint">Affiche ou masque les cartes, choisis leur largeur et organise-les.</p><div class="nova-pref-list">${settings.order.map((id,i)=>`<div class="nova-pref-row"><label><input type="checkbox" data-toggle="${id}" ${settings.hidden.includes(id)?'':'checked'}><span>${esc(labels[id])}</span></label><div class="nova-pref-tools"><select data-size="${id}" aria-label="Largeur : ${esc(labels[id])}">${[[3,'25 %'],[4,'33 %'],[6,'50 %'],[8,'67 %'],[12,'100 %']].map(([s,t])=>`<option value="${s}" ${Number(settings.sizes[id])===s?'selected':''}>${t}</option>`).join('')}</select><button type="button" data-action="move-up" data-id="${id}" ${i===0?'disabled':''} aria-label="Monter ${esc(labels[id])}">${icon('up',16)}</button><button type="button" data-action="move-down" data-id="${id}" ${i===settings.order.length-1?'disabled':''} aria-label="Descendre ${esc(labels[id])}">${icon('down',16)}</button></div></div>`).join('')}</div>
       <h3>Liens personnels</h3><p class="nova-editor-hint">Jusqu'à 12 liens. Active le widget « Mes liens » pour les voir.</p><div class="nova-custom-links">${(settings.links||[]).map((entry,i)=>`<div class="nova-link-editor"><input data-link-title="${i}" aria-label="Nom du lien ${i+1}" maxlength="80" value="${esc(entry.title)}" placeholder="Titre"><input data-link-url="${i}" aria-label="Adresse du lien ${i+1}" maxlength="600" value="${esc(entry.url)}" placeholder="https://…"><button type="button" data-action="remove-link" data-index="${i}" title="Supprimer">${icon('trash',15)}</button></div>`).join('')}</div><button type="button" data-action="add-link" class="nova-btn nova-btn-add">${icon('plus',16)} Ajouter un lien</button></div>
       <footer class="nova-editor-footer"><span data-save-indicator aria-live="polite">${demo?'Démo — non sauvegardé':saving?'Enregistrement…':'Préférences individuelles'}</span><div class="nova-editor-footer-buttons"><button type="button" data-action="arrange" class="nova-btn">${icon('grip',17)} Réorganiser</button><button type="button" data-action="close-editor" class="nova-btn nova-btn-cta">Terminer ${icon('check',17)}</button></div></footer></aside></div>`;
  }
  function openEditor(){if(!settings||editorOpen)return;editing=true;editorOpen=true;editorReturnFocus=surface.querySelector('[data-action="customize"]');render();editorHost.innerHTML=editorMarkup();root.classList.add('nova-modal-open');surface.inert=true;editorHost.querySelector('.nova-editor-close')?.focus();}
  function harvestLinks(){
    editorHost.querySelectorAll('[data-link-title]').forEach(input=>{const index=Number(input.dataset.linkTitle);if(settings.links[index])settings.links[index].title=input.value.trim().slice(0,80);});
    editorHost.querySelectorAll('[data-link-url]').forEach(input=>{const index=Number(input.dataset.linkUrl);if(settings.links[index])settings.links[index].url=input.value.trim().slice(0,600);});
  }
  function closeEditor(keepEditing=false){
    if(!editorOpen)return;
    harvestLinks();queueSave();editorOpen=false;editorHost.replaceChildren();surface.inert=false;root.classList.remove('nova-modal-open');editing=keepEditing;render();
    surface.querySelector('[data-action="customize"]')?.focus();
  }
  function rerenderEditor(){const sc=editorHost.querySelector('.nova-editor-scroll'),scroll=sc?.scrollTop||0;editorHost.innerHTML=editorMarkup();const next=editorHost.querySelector('.nova-editor-scroll');if(next)next.scrollTop=scroll;}
  function setSaveLabel(message){const el=editorHost.querySelector('[data-save-indicator]');if(el)el.textContent=message;}
  function queueSave(){saveQueued=true;if(demo){saveQueued=false;setSaveLabel('Démo — réglages temporaires');return;}if(!saving)void save();}
  function encodeSettings(){
    const form=new URLSearchParams();const put=(key,v)=>form.append(`settings[${key}]`,String(v));
    for(const key of ['theme','density','accent','layout','motion','notes'])put(key,settings[key]||'');
    settings.order.forEach((v,i)=>form.append(`settings[order][${i}]`,v));
    settings.hidden.forEach((v,i)=>form.append(`settings[hidden][${i}]`,v));
    Object.entries(settings.sizes).forEach(([id,v])=>form.append(`settings[sizes][${id}]`,String(v)));
    (settings.links||[]).forEach((l,i)=>{form.append(`settings[links][${i}][title]`,l.title);form.append(`settings[links][${i}][url]`,l.url);});
    (settings.pins||[]).forEach((p,i)=>form.append(`settings[pins][${i}]`,p));
    return form;
  }
  async function save(){
    if(saving)return;saving=true;
    while(saveQueued){
      saveQueued=false;setSaveLabel('Enregistrement…');
      try{await api(root.dataset.settingsUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:encodeSettings().toString()});setSaveLabel('Modifications enregistrées');}
      catch(error){console.error('[Nova] sauvegarde impossible',error);setSaveLabel('Échec de sauvegarde');toast('Impossible d’enregistrer tes préférences.','error');break;}
    }
    saving=false;
  }
  function updateClock(){const date=new Date();surface.querySelectorAll('[data-clock]').forEach(el=>el.textContent=new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(date));surface.querySelectorAll('[data-clock-date]').forEach(el=>el.textContent=new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long'}).format(date));}
  surface.addEventListener('click',event=>{
    const button=event.target.closest('[data-action]');if(!button||!surface.contains(button))return;
    const action=button.dataset.action;
    if(action==='refresh'){void load(true);void browse(browser.path,false);}
    if(action==='customize'){if(editing){if(editorOpen)closeEditor();else{editing=false;render();}}else openEditor();}
    if(action==='open-editor')openEditor();
    if(action==='jump-files'){surface.querySelector('[data-widget="explorer"]')?.scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});surface.querySelector('[data-browser-search]')?.focus({preventScroll:true});}
    if(action==='browse-path'){void browse(button.dataset.path||'/');}
    if(action==='reload-folder'){void browse(browser.path,false);}
    if(action==='toggle-view'){browser.view=browser.view==='list'?'grid':'list';render();}
    if(action==='pin-folder'){
      const path=button.dataset.path;if(!path||!path.startsWith('/'))return;
      const current=settings.pins||[];
      if(current.includes(path))settings.pins=current.filter(p=>p!==path);
      else if(current.length>=12){toast('Maximum de 12 dossiers épinglés.');return;}
      else settings.pins=[...current,path];
      queueSave();render();
    }
    if(action==='save-note'){settings.notes=surface.querySelector('#nova-note-text')?.value||'';queueSave();toast('Enregistrement de la note demandé.','info');}
  });
  surface.addEventListener('input',event=>{
    if(event.target.matches('[data-browser-search]')){browser.query=event.target.value;updateBrowserResults();}
    if(event.target.matches('#nova-note-text'))settings.notes=event.target.value;
  });
  surface.addEventListener('change',event=>{
    if(event.target.matches('[data-browser-sort]')){browser.sort=event.target.value;updateBrowserResults();}
    if(event.target.matches('[data-browser-type]')){browser.type=event.target.value;updateBrowserResults();}
  });
  surface.addEventListener('dragstart',event=>{
    if(!editing)return;const card=event.target.closest('[data-widget]');if(!card)return;
    event.dataTransfer?.setData('text/plain',card.dataset.widget);if(event.dataTransfer)event.dataTransfer.effectAllowed='move';card.classList.add('is-dragging');
  });
  surface.addEventListener('dragend',event=>event.target.closest('[data-widget]')?.classList.remove('is-dragging'));
  surface.addEventListener('dragover',event=>{if(editing&&event.target.closest('[data-widget]'))event.preventDefault();});
  surface.addEventListener('drop',event=>{
    if(!editing)return;const target=event.target.closest('[data-widget]');if(!target)return;event.preventDefault();
    const from=event.dataTransfer?.getData('text/plain'),to=target.dataset.widget;if(!allWidgets.includes(from)||!allWidgets.includes(to)||from===to)return;
    const order=[...settings.order];const fromIndex=order.indexOf(from),toIndex=order.indexOf(to);if(fromIndex<0||toIndex<0)return;
    order.splice(fromIndex,1);order.splice(toIndex,0,from);settings.order=order;queueSave();render();
  });
  editorHost.addEventListener('click',event=>{
    const actionEl=event.target.closest('[data-action]');if(!actionEl)return;
    const action=actionEl.dataset.action;
    if(action==='editor-backdrop'&&event.target===actionEl){closeEditor();return;}
    if(action==='close-editor'){closeEditor();return;}
    if(action==='arrange'){closeEditor(true);return;}
    if(action==='move-up'||action==='move-down'){
      harvestLinks();const index=settings.order.indexOf(actionEl.dataset.id),next=index+(action==='move-up'?-1:1);
      if(index<0||next<0||next>=settings.order.length)return;
      [settings.order[index],settings.order[next]]=[settings.order[next],settings.order[index]];queueSave();render();rerenderEditor();
    }
    if(action==='add-link'){
      harvestLinks();if(settings.links.length>=12){toast('Maximum de 12 liens.');return;}
      settings.links.push({title:'Nouveau lien',url:'/'});queueSave();render();rerenderEditor();
    }
    if(action==='remove-link'){
      harvestLinks();settings.links.splice(Number(actionEl.dataset.index),1);queueSave();render();rerenderEditor();
    }
  });
  editorHost.addEventListener('change',event=>{
    const input=event.target;
    if(input.matches('input[type="radio"]')){settings[input.name]=input.value;queueSave();render();}
    else if(input.matches('[data-toggle]')){const id=input.dataset.toggle;if(!allWidgets.includes(id))return;settings.hidden=input.checked?settings.hidden.filter(x=>x!==id):[...settings.hidden,id];queueSave();render();}
    else if(input.matches('[data-size]')){settings.sizes[input.dataset.size]=Number(input.value);queueSave();render();}
    else if(input.matches('[data-link-title],[data-link-url]')){harvestLinks();queueSave();render();}
  });
  document.addEventListener('keydown',event=>{
    if(editorOpen&&event.key==='Escape'){event.preventDefault();event.stopPropagation();closeEditor();}
    if(editorOpen&&event.key==='Tab'){
      const tabbable=[...editorHost.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href]')].filter(el=>el.getClientRects().length);
      if(!tabbable.length)return;
      const first=tabbable[0],last=tabbable[tabbable.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  },true);
  async function load(silent=false){
    try{
      const data=demo?demo.overview:await api(root.dataset.overviewUrl);
      if(!data.overview||!data.settings)throw new Error('Réponse API inattendue');
      overview=data.overview;
      if(!settings||!silent)settings={...defaults(),...data.settings,sizes:{...defaultSizes,...(data.settings.sizes||{})},pins:data.settings.pins||[]};
      root.dataset.displayName=data.user?.name||'toi';render();
      if(browser.loading||(!browser.items.length&&!browser.error))void browse(browser.path,false);
      if(silent)toast('Dashboard actualisé.','success');
    }catch(error){
      console.error('[Nova] chargement impossible',error);
      if(silent&&overview){toast('Échec de l’actualisation.','error');return;}
      surface.innerHTML=`<div class="nova-error" role="alert">${icon('alert',24)}<h2>Impossible de charger Nova Dashboard</h2><p>${esc(error.message)}. Vérifie ta session et l’onglet Réseau (F12).</p><button type="button" class="nova-btn" data-action="refresh">Réessayer</button></div>`;
    }
  }
  // Card spotlight follows pointer without rerendering or data access.
  surface.addEventListener('pointermove',event=>{
    if(!motionEnabled()||event.pointerType==='touch')return;
    const card=event.target.closest('.nova-card');if(!card)return;
    const r=card.getBoundingClientRect();card.style.setProperty('--nova-px',`${event.clientX-r.left}px`);card.style.setProperty('--nova-py',`${event.clientY-r.top}px`);
  },{passive:true});
  surface.addEventListener('click',event=>{
    const button=event.target.closest('.nova-btn, .nova-file-pin, .nova-shortcut');if(button)blink(button);
  });
  surface.addEventListener('error',event=>{
    if(event.target.matches?.('.nova-file-thumb'))event.target.remove();
  },true);
  clockTimer=setInterval(updateClock,30000);
  void load();
})();
