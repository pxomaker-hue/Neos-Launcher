<?php
/** @var array $_ */
?>
<div id="nova-root"
     data-overview-url="<?php p($_['overviewUrl']); ?>"
     data-settings-url="<?php p($_['settingsUrl']); ?>"
     data-files-url="<?php p($_['filesUrl']); ?>"
     data-preview-base="<?php p($_['previewBase']); ?>">
    <div class="nova-loading" role="status">Chargement de Nova Dashboard…</div>
</div>
