<?php

declare(strict_types=1);

namespace OCA\NovaDashboard\Service;

use InvalidArgumentException;
use OCP\Constants;
use OCP\Files\File;
use OCP\Files\Folder;
use OCP\Files\IRootFolder;
use OCP\IURLGenerator;
use OCP\IUser;

/**
 * Read-only directory explorer, deliberately limited to a logged-in user's
 * accessible files. It does not write, delete or move files.
 */
final class FileBrowserService {
    private const DISPLAY_LIMIT = 120;

    public function __construct(
        private IRootFolder $root,
        private IURLGenerator $url,
    ) {}

    public function browse(IUser $user, string $path): array {
        $path = self::validatePath($path);
        $home = $this->root->getUserFolder($user->getUID());
        $target = $path === '/' ? $home : $home->get(ltrim($path, '/'));
        if (!($target instanceof Folder)) {
            throw new InvalidArgumentException('Ce chemin ne désigne pas un dossier.');
        }
        if (($target->getPermissions() & Constants::PERMISSION_READ) === 0) {
            throw new \OCP\Files\NotPermittedException('Accès au dossier refusé');
        }
        $nodes = $target->getDirectoryListing();
        $nodes = array_values(array_filter($nodes, static fn($node): bool =>
            ($node instanceof Folder || $node instanceof File)
            && (($node->getPermissions() & Constants::PERMISSION_READ) !== 0)
        ));
        usort($nodes, static function ($a, $b): int {
            if (($a instanceof Folder) !== ($b instanceof Folder)) {
                return $a instanceof Folder ? -1 : 1;
            }
            return strnatcasecmp($a->getName(), $b->getName());
        });
        $total = count($nodes);
        $entries = [];
        $filesBase = $this->url->getWebroot() . '/index.php/apps/files/';
        foreach (array_slice($nodes, 0, self::DISPLAY_LIMIT) as $node) {
            $isFolder = $node instanceof Folder;
            $name = $node->getName();
            $itemPath = rtrim($path, '/') . '/' . $name;
            $entries[] = [
                'id' => (int)$node->getId(),
                'name' => $name,
                'path' => $itemPath,
                'kind' => $isFolder ? 'folder' : 'file',
                'mtime' => (int)$node->getMTime(),
                'size' => $isFolder ? null : (int)$node->getSize(),
                'mime' => $isFolder ? 'httpd/unix-directory' : $node->getMimetype(),
                // Opens the parent folder in Nextcloud Files, where all file
                // operations use native Nextcloud permissions and UI.
                'url' => $filesBase . '?dir=' . rawurlencode($path)
                    . '&scrollto=' . rawurlencode($name),
            ];
        }
        return [
            'path' => $path,
            'items' => $entries,
            'total' => $total,
            'truncated' => $total > self::DISPLAY_LIMIT,
            'limit' => self::DISPLAY_LIMIT,
            'filesUrl' => $filesBase . '?dir=' . rawurlencode($path),
        ];
    }

    public static function validatePath(string $path): string {
        if ($path === '') {
            return '/';
        }
        if (!str_starts_with($path, '/') || strlen($path) > 1024
            || str_contains($path, '\\') || preg_match('/[\x00-\x1f\x7f]/', $path) === 1) {
            throw new InvalidArgumentException('Chemin invalide.');
        }
        $parts = explode('/', trim($path, '/'));
        if ($path === '/') {
            return '/';
        }
        foreach ($parts as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                throw new InvalidArgumentException('Chemin invalide.');
            }
        }
        return '/' . implode('/', $parts);
    }
}
