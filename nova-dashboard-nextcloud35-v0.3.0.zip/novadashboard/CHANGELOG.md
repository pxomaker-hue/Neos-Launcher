# Nova Dashboard — historique

## 0.3.0 (préversion)
- Explorateur de fichiers Nextcloud en lecture seule : navigation par dossiers, tri, filtre local, affichage liste/grille, favoris personnels.
- Nouveau design futuriste : halos lumineux, panneaux de verre, micro-interactions et animation échelonnée (Web Animations API locale, sans CDN).
- Panneau de personnalisation autonome : croix, Échap, Terminer, clic en dehors ; navigation clavier et restitution du focus.
- Réglage des animations par utilisateur : fluides / discrètes / désactivées et prise en charge `prefers-reduced-motion`.
- Conserve les widgets, préférences, corrections CSRF de la v0.2 ; aucune opération d'écriture sur les fichiers.

## 0.2.0
- Pleine largeur, personnalisation individuelle, horloge, synthèse, notes et liens.

## 0.1.2
- Correction de transmission du jeton CSRF côté navigateur.
