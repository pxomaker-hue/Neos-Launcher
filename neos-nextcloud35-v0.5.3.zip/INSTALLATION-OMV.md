# Neos v0.5.3 — mise à jour sur OMV / Nextcloud 35

Le nom visible est **Neos**, mais l'identifiant de l'application reste `novadashboard`.
Cette mise à jour conserve les préférences et ne recrée ni volumes ni conteneurs Docker.

## 1. Copier le ZIP depuis Windows (PowerShell)

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.3.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier le serveur avant de modifier les fichiers

```bash
sudo docker exec nextcloud occ status
```

Vérifier Nextcloud 35.x, `maintenance: false`, `needsDbUpgrade: false` et aucune mise à jour en cours.
Disposer d'une sauvegarde complète et récente du NAS (config, base de données et données).

## 3. Sauvegarder le code Neos existant

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v053.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v053.tar.gz
```

## 4. Installer Neos v0.5.3

```bash
mkdir -p /tmp/neos-v053
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.3.zip /tmp/neos-v053
sudo docker cp /tmp/neos-v053/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Actualiser Neos avec **Ctrl + F5**. Si Nextcloud affiche `needsDbUpgrade: true`, ne pas forcer l'interface web : vérifier l'état et disposer d'une sauvegarde complète avant de décider d'une commande `occ upgrade`.

## 5. Tester les trois points de la mise à jour

**Hub** : ouvrir Applications. Les dix apps du kit utilisent les PNG 256 directement (sans encarts supplémentaires).

**PDF** : ouvrir l'onglet Fichiers, cliquer sur un `.pdf` puis vérifier l'aperçu dans le panneau de droite. Le téléchargement doit rester lié à l'action Télécharger. L'aperçu utilise une route Nextcloud authentifiée avec affichage `inline`. Le navigateur doit disposer d'un lecteur PDF intégré.

**Notes** : ouvrir Notes. Si l'app Notes est activée, Neos utilise son API habituelle ; si elle renvoie 404 ou si Notes n'est pas active, Neos propose la lecture/édition des `.md`/`.txt` dans le dossier Notes du compte via l'API de fichiers Nextcloud. Le dossier Notes est créé au premier ajout de note, jamais simplement en ouvrant l'onglet. Un changement simultané dans deux éditeurs déclenche un conflit plutôt qu'un écrasement silencieux.

L'emplacement Notes peut dépendre du paramètre Nextcloud Notes `defaultFolder`. La solution de secours parcourt uniquement ce dossier, et non tous les sous-dossiers. Les notes très volumineuses ne sont pas chargées automatiquement.

Pour connaître l'état des applications Notes et Deck :

```bash
sudo docker exec nextcloud occ app:list
```

## 6. Retour arrière

Si un problème apparaît, la sauvegarde couvre le dossier applicatif précédent :

```bash
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v053.tar.gz -C /config/www/nextcloud/apps/'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Puis **Ctrl + F5**. Les éventuels fichiers ou notes créés par l'utilisateur pendant la v0.5.3 restent dans les données Nextcloud ; le retour arrière ne les efface pas.
