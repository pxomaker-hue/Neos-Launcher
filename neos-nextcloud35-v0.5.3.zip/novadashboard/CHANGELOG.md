## 0.5.3 — Notes & PDF / PNG256 hub
- Privilégie les 10 images PNG 256 du kit pour le hub des applications, sans encarts.
- Aperçu PDF via une route Nextcloud authentifiée en `Content-Disposition: inline` : sélection ≠ téléchargement.
- Une demande de téléchargement reste explicite via l'icône Télécharger.
- Module Notes : utilise l'API Notes si disponible, et sinon les notes Markdown/TXT du dossier Notes de l'utilisateur via le stockage Nextcloud.
- Contrôle de taille, permissions et ETag sur les modifications des notes en mode fichiers.
- Compatibilité conservée avec Nextcloud 35 et l'ID d'application `novadashboard`.

# Neos — Changelog

## 0.5.2 — Disposition adaptative

- Accueil à grille de 12 colonnes avec mode automatique et mode libre.
- Redimensionnement par widget (3, 4, 6, 8, 9, 12 colonnes) avec sauvegarde.
- Réorganisation interactive avec poignée, zone cible et contrôles au clavier.
- Maintien des préférences d’affichage des versions antérieures.
- API Deck : routes REST documentées et repli OCS en cas de 404 ; diagnostic d’app absente.
- Réintégration des assets SVG du NEOS UI Kit fourni, et monogramme de navigation.

## 0.5.1 — Accueil et Fichiers

- Séparation Accueil/Fichiers, onglets, Deck/Notes visibles, animations de transition, défilement vertical.
