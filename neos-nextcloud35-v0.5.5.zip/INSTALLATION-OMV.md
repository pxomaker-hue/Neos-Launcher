# Neos v0.5.5 — installation sur Nextcloud 35 (OMV / LinuxServer.io)

Neos garde l'identifiant technique `novadashboard`. Cette mise à jour concerne le code et les assets de Neos, **pas** les données utilisateurs ou les services Docker. Elle ne demande **pas** d'exécuter `occ upgrade` par défaut.

## 1. Transférer l'archive depuis Windows PowerShell

Enregistre le ZIP téléchargé dans le dossier ci-dessous, puis lance :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.5.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier que Nextcloud est prêt

```bash
sudo docker exec nextcloud occ status
```

Poursuis seulement si Nextcloud est en version **35.x** et si `maintenance: false` et `needsDbUpgrade: false`. N'interviens pas pendant une migration en cours.

## 3. Sauvegarder l'application existante

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v055.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v055.tar.gz
```

Pour toute opération importante sur Nextcloud, conserver aussi une sauvegarde cohérente des fichiers, de la configuration et de la base de données.

## 4. Décompresser et installer

```bash
mkdir -p /tmp/neos-v055
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.5.zip /tmp/neos-v055
ls -l /tmp/neos-v055/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v055/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Dans le navigateur, recharge avec **Ctrl + F5**.

## 5. Vérifier les changements

1. Ouvre Accueil puis Fichiers : **la capsule cyan doit glisser latéralement** d'un onglet à l'autre et s'adapter à la largeur du libellé.
2. Vérifie les icônes plates dans la topbar et l'icône cyan Accueil dans le hub Applications.
3. Accueil → Personnaliser → Réorganiser : la grille 12 colonnes devient visible. Déplace un widget via sa poignée et dépose-le sur une carte pour changer l'ordre.
4. En mode Libre, règle la largeur et la hauteur minimale des widgets existants.
5. Dans Personnaliser, vérifie que les animations peuvent passer de « Animé » à « Discret » ou « Off ».

**Limite du mode grille :** c'est un guide visuel avec placement dense et accroche sur les autres cartes, pas un bureau à coordonnées libres. Les éléments se rangent dans la grille et évitent de se superposer.

## Retour arrière (code uniquement)

Si tu dois restaurer les fichiers de Neos d'avant la v0.5.5, assure-toi qu'aucune migration n'est en cours et utilise :

```bash
sudo docker exec nextcloud sh -c 'mv /config/www/nextcloud/apps/novadashboard /config/novadashboard-v055-mise-de-cote'
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v055.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Cette restauration concerne uniquement le code de Neos : elle ne restaure pas une base de données qui aurait été modifiée par une autre mise à niveau.

## Tests et compatibilité

Syntaxe JavaScript, syntaxe PHP, structure XML et intégrité ZIP contrôlées hors serveur. Le navigateur de test n'a pas permis de valider le rendu interactif dans cet environnement. La fluidité du slider et du quadrillage doit être confirmée sur ton instance réelle.
