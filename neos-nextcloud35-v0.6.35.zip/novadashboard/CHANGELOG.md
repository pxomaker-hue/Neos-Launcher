## 0.6.35 — Navigation clavier dans les onglets de recherche

- Dans la fenêtre Accès aux fichiers, le focus reste sur l’onglet choisi après un changement entre Recherche, Favoris et Consultés.
- Flèches gauche/droite et touches Début/Fin permettent de parcourir les trois onglets, avec un seul onglet dans l’ordre de tabulation.
- Chaque onglet est relié au panneau qu’il affiche pour les lecteurs d’écran.
- Les recherches, favoris et fichiers récemment consultés conservent leur fonctionnement et leurs données.

## 0.6.34 — Robustesse du widget Tâches

- Deux tâches CalDAV et Deck distinctes restent visibles même si elles portent le même titre et la même échéance.
- Le dédoublonnage par titre et échéance ne concerne que les données provisoires du tableau de bord sans source connue.
- Une erreur de lecture CalDAV est annoncée dans le widget au lieu d’être présentée comme une liste vide ; les tâches déjà disponibles restent affichées.
- Les permissions et les opérations de création CalDAV de la v0.6.32 ainsi que les actions Deck de la v0.6.33 restent inchangées.

## 0.6.33 — Widget accueil Tâches CalDAV + Deck

- Le widget Tâches de l'accueil lit les mêmes données CalDAV / Deck que le module Tâches dès que leur chargement est terminé.
- Cartes Deck visibles dans le widget, avec accès à leur carte d'origine, dédoublonnage par ID de carte, et sélection équilibrée des deux sources.
- Les tâches normales continuent d'être affichées et se créent comme avant via CalDAV. Les actions Deck restent assurées exclusivement par les API natives Deck.
- Rafraîchissement du widget lors du chargement de la page, du retour sur l'accueil et de la commande Actualiser.
- Le correctif v0.6.32 des permissions de création CalDAV est conservé.
- Tests sur navigateur de démonstration et validation ZIP ; vérifier le fonctionnement sur le NAS.

## 0.6.32 — Création de tâches CalDAV

- Le widget d’accueil ouvre directement le module Tâches.
- La création utilise le droit DAV:bind de la liste ; la modification d’une tâche existante utilise DAV:write-content. Les calendriers virtuels Deck restent exclus.
- Un échec de lecture REPORT n’empêche plus la création dans une liste qui autorise DAV:bind. Si aucune liste ne permet l’ajout, l’interface l’explique.
- Vérifications locales uniquement ; aucune donnée du NAS n’a été modifiée.

## 0.6.31 — États d’enregistrement et erreurs accessibles

- Les notifications d'erreur sont annoncées en alerte ; les confirmations restent non intrusives.
- Agenda/Tâches : erreur de formulaire annoncée, état de sauvegarde lisible et protection pendant l'envoi.
- Deck : chargement et sauvegarde identifiés pour les lecteurs d'écran, sans changer les API.
- Contacts : état de vérification/suppression indiqué pendant une suppression CardDAV.
- Recherche globale : annonce concise du chargement et du nombre de résultats, hors de la liste pour éviter une lecture exhaustive.
- La gestion de focus v0.6.30, les titres allégés, la navigation Activité et le thème restent conservés.
- Tests en navigateur de démonstration ; vérification serveur Nextcloud à effectuer sur NAS.

## 0.6.30 — Fenêtres et navigation au clavier

- Piégeage du focus dans les dialogues modaux (Tab/Maj+Tab) et rappel du bouton à la fermeture.
- Fermeture Échap protégée pendant la sauvegarde Deck, Agenda/Tâches et opérations de destination en cours.
- Confirmation de suppression Contacts accessible au clavier avec retour de focus après annulation ou erreur.
- Halo de focus visible renforcé et compatibilité avec le mode animation réduite.
- Aucune modification des API Nextcloud.

# Neos 0.6.29 — Navigation clavier et accessibilité

- Raccourci « / » contextuel : recherche dans le module ouvert (Mail, Talk, Contacts, Activité, Planning ou Fichiers). Ne quitte plus accidentellement le module pour Fichiers.
- Dans Mail, Talk, Contacts et Activité, la touche Échap efface la recherche active sans quitter le module ni toucher aux brouillons.
- Lien « Aller au contenu de Neos » visible au focus pour ignorer la navigation et accéder directement au module.
- Focus clavier maintenu après les filtres Non lues, carnet d’adresses et dossier Mail.
- Indication du raccourci / dans le champ de recherche, accessible aussi aux lecteurs d'écran.
- Interfaces et fonctions IMAP, Talk, CardDAV, Activité, Planning, thème Flat Cyber et topbar conservés.
- Vérifications de régression desktop et mobile en démo ; validation NAS à effectuer.

# Neos 0.6.28 — Compteurs épurés et résultats contextuels

- Mail, Talk, Contacts et Activité : conserver la valeur unique cyan, afficher seulement « élément » / « éléments » dans le petit libellé. Plus de duplication « 40 40 éléments ».
- Recherches : ne montrer « N résultats » que lorsqu'une recherche ou un filtre est réellement actif. Avec les vues par défaut, supprimer la ligne redondante « N résultats » tout en conservant le champ de recherche et tous les contrôles.
- Accessibilité : libellé numérique complet disponible pour les lecteurs d'écran ; gestion correcte de 0, 1 ou plusieurs éléments et résultats.
- Aucune modification des appels API ou données Nextcloud. Pagination Activité v0.6.27, Talk, Mail, CardDAV et design Flat Cyber conservés.
- Tests d'interface Chromium desktop/mobile en démonstration ; à confirmer sur le NAS.

# Neos 0.6.27 — Activité historique & en-têtes harmonisés

- Activité : pagination OCS v2 basée sur le lien HTTP rel="next" et le curseur `X-Activity-Last-Given`. Une page de moins de 30 activités ne bloque plus l’accès aux dates précédentes.
- Activité : bouton unique « Voir les activités plus anciennes », qui affiche les éléments déjà chargés ou récupère la page suivante et révèle immédiatement de nouvelles lignes.
- Activité : contrôles des doublons et des curseurs répétés pour éviter les boucles ; arrêt explicite après plusieurs pages sans nouveaux résultats, plafond mémoire documenté à 300 événements.
- Mail, Talk, Contacts, Activité : suppression du titre répété dans le grand encadré interne ; maintien d’un titre par panneau, d’une description et du compteur compact. Le bandeau stylisé général de Neos est strictement inchangé.
- Vérifications desktop/mobile sur code d’interface réel et données fictives. Mise à jour de l’archive installable et aperçu. La pagination OCS doit encore être confirmée sur NAS.

# Neos 0.6.26 — Activité et grands carnets Contacts

- Activité : plus de plafond artificiel à 70 lignes ; affichage par groupes de 15, même après chargement de pages serveur. Le nombre d’activités chargées est clairement distinct de celui affiché.
- Activité : filtre local sur les 7/30 derniers jours (uniquement parmi les éléments déjà chargés ; pas une recherche serveur exhaustive), avec boutons de source accessibles et indication des filtres.
- Activité : pagination sûre, dédoublonnage des éléments, limite explicite de 300 activités par session ; réponse tardive d’une ancienne synchronisation ignorée ; chargement progressif maintenu.
- Contacts : affichage filtré sans recherches répétitives `indexOf` pour chaque ligne ; optimise les gros carnets sans toucher aux API CardDAV ni aux protections ETag.
- Accessibilité : état des résultats annoncé et focus clavier conservé après l'affichage de résultats supplémentaires ou la sélection d’un filtre Activité ; CSS mobile adapté.
- Mail, Talk, Planning, Deck : API et fonctionnement inchangés ; design Flat Cyber, topbar personnalisable et icône Planning orange conservés.

# Neos 0.6.25 — Contacts : filtres et listes plus grandes

- Contacts : recherche locale étendue aux champs e-mail et téléphone secondaires, à l'organisation et au carnet, sans exposer de données à un service tiers.
- Contacts : sélecteur « Carnet d’adresses » ; la liste affiche uniquement les contacts du carnet choisi. Le choix du carnet et la recherche ne changent pas les contacts sur le serveur.
- Contacts : chargement progressif de l'interface par groupes de 35 fiches ; bouton « Afficher 35 contacts de plus » jusqu’à la fin des résultats chargés.
- Contacts : les requêtes CardDAV consultent jusqu’à 250 fiches par carnet, 400 au total. Les éventuelles limites et carnets indisponibles sont annoncés : pour consulter toutes les fiches au-delà, utiliser Contacts natif.
- Contacts : Échap ferme une confirmation de suppression ouverte sans aucune écriture CardDAV ; les contrôles ETag des éditions et suppressions demeurent inchangés.
- Talk et Mail : aucune modification des API ; scénarios de non-régression réalisés sur l'interface de démonstration.
- Visuels : Flat Cyber, icône Planning orange et topbar personnalisable inchangés ; compteur de version actualisé.

# Neos 0.6.24 — robustesse Talk & Mail

- Talk : les actualisations conservent les messages déjà récupérés, y compris les pages d’historique anciennes, et gardent le curseur de pagination. Une erreur réseau durant le rafraîchissement automatique ne masque plus la conversation en cours.
- Talk : conservation de la position de défilement, et du focus/sélection dans la zone de rédaction lors d’un rafraîchissement ; heure de dernière actualisation affichée.
- Mail : suspendre la synchronisation périodique de la Réception lorsqu'un dossier Brouillons est consulté, afin de ne pas interrompre la lecture de brouillons. Le bouton de synchronisation principale est indisponible pendant une lecture/rédaction ouverte.
- Mail : bouton « Réessayer la lecture » pour les erreurs de lecture de message ou de brouillon IMAP (aucun envoi, déplacement ni suppression).
- Interface : version du pied de page mise à jour (bloquée à 0.6.19 depuis plusieurs versions), continuité Flat Cyber et icône Planning conservées.
- Aucun changement de l’API CardDAV de création/édition/suppression : préserver les fonctions Contacts déjà validées sur le NAS.
- Brouillons : reprise en copie texte uniquement, l'original IMAP reste intact.

# Neos 0.6.23 — correctif brouillons vides

- Mail : après chargement réussi, la reprise en copie autorise les brouillons IMAP sans texte. L’original reste intact.
- Mail : message vide explicitement signalé, champ Message facultatif pour enregistrer un brouillon ; l’envoi exige toujours un corps non vide.
- Talk, Contacts, Planning et autres fonctions conservés de v0.6.22.

# Neos 0.6.22

## Améliorations
- Mail : reprise prudente du texte d’un brouillon IMAP dans un **nouveau message** Neos. L’original IMAP reste intact ; pièces jointes, Cc/Cci et mise en forme ne sont pas copiés. Toute modification directe de l’original continue à se faire dans Mail natif.
- Talk : marqueur de lecture explicite avec confirmation du serveur via `POST /ocs/v2.php/apps/spreed/api/v1/chat/{token}/read`. Relecture périodique des messages lorsque le salon est ouvert, sans interférer avec un message en cours de rédaction.
- CSS : disposition adaptée aux petits écrans pour les nouvelles commandes.
- Maintien du thème Flat Cyber, du hub Planning, de la topbar personnalisable et de l’ensemble des modules de la version 0.6.21.

## Vérification sur NAS
- Valider le bouton « Marquer comme lu » dans Talk.
- Valider la reprise d’un brouillon texte fictif et constater que le brouillon original est toujours présent dans Mail natif.
- Aucun envoi automatique, aucune modification/destruction du brouillon original n’est déclenché par la reprise.

---

# Neos 0.6.21

## Correctifs
- Brouillons IMAP : récupération de l’identifiant `draftsMailboxId` depuis les données complètes du compte Mail (il était supprimé dans le résumé interne), indépendamment du nom du dossier.
- Sélecteur manuel de dossier si le serveur ne fournit pas de rôle IMAP reconnaissable. Affichage du nombre de dossiers détectés et des requêtes réellement exécutées.
- Diagnostic visible en cas de dossier absent, dossier non synchronisé ou réponse en erreur ; pas de faux message « dossier vide ».

## Nouveautés
- Contacts : suppression avec confirmation explicite, contrôle ETag avant requête conditionnelle `DELETE`, puis vérification d’absence. Aucune suppression automatique.
- Thème et fonctionnalités précédentes conservés.

## À valider sur le NAS
- Lecture du dossier Brouillons (Mail 5.13.2) et sélection manuelle au besoin.
- Suppression d'un contact fictif temporaire uniquement.
# Neos 0.6.20

- Mail : consultation des dossiers Brouillons IMAP dans Neos, avec aperçu filtré et lien direct vers l’édition de l’original dans Mail natif. Aucune écriture, suppression ou expédition depuis ce lecteur.
- Contacts : deux courriels et deux téléphones, tout en préservant les autres champs vCard lors des éditions via ETag.
- Conservation du design Flat Cyber, topbar et fonctionnalités des versions précédentes.

# Historique Neos

## 0.6.19 — Brouillons visibles dans Mail natif et Talk filtrable

- Correction de la confirmation trompeuse des brouillons dans la v0.6.18 : `POST /api/drafts` ou `PUT /api/drafts/{id}` crée/met à jour seulement un brouillon local à Nextcloud Mail.
- Après cette première étape, appel explicite à `POST /api/drafts/move/{id}`, qui demande à Nextcloud Mail 5.13.2 de transférer le brouillon dans le dossier IMAP Brouillons. Aucun envoi SMTP n'est effectué.
- Le formulaire est verrouillé après transfert accepté pour éviter de réutiliser un identifiant temporaire supprimé côté serveur ; l'édition/reprise du brouillon transféré s'effectue dans Mail natif. Cette limitation est affichée dans Neos.
- En cas de transfert non confirmé, message explicite avec identifiant local et blocage des essais répétitifs automatiques, pour ne pas créer de doublon. Avant un nouvel essai : examiner Mail natif.
- Filtre « Toutes / Non lues » dans les conversations Talk et actualisation de la liste au retour d'une conversation. Les non-lus proviennent de l'API Talk, sans marquage forcé.
- Conservés : ordre de topbar, icône Planning, Contacts, Agenda, Tâches, Deck, Activité, lecture HTML des mails, envoi, synchronisation des boîtes, suivi Outbox.

# Historique Neos

## 0.6.18 — Brouillons Mail et suivi des envois

- Enregistrer un brouillon dans Nextcloud Mail via POST /api/drafts ; mises à jour via PUT /api/drafts/{id}.
- Suivre les messages en boîte d'envoi via GET /api/outbox ; aucun renvoi automatique.
- Vérification non destructive de l'état d'une référence d'envoi (GET /api/outbox/{id}).
- Brouillons conservés côté serveur, sans stockage local du contenu ; reprise après reconnexion via Mail natif.
- Prévention de la réutilisation accidentelle d'un ancien brouillon comme « nouveau message ».
- Conserve les fonctionnalités v0.6.17 et précédentes.

## 0.6.17 — synchronisation de Mail

- Synchroniser la boîte IMAP avant de lire les messages (API Mail 5.13.2).
- Bouton Synchroniser visible, avec heure de dernière synchronisation réussie.
- Rafraîchissement toutes les 90 s quand l'espace Mail est actif et visible ; contrôle après envoi confirmé.
- Un seul rafraîchissement simultané ; gestion bornée des retours 428 (initialisation), 409 (occupé) et 500 (erreur).
- Conserve les messages précédemment mis en cache en cas d'échec temporaire.

## 0.6.16 — rédaction / envoi / réponse

- Interface de composition texte dans Mail, envoi en deux étapes via Outbox.

