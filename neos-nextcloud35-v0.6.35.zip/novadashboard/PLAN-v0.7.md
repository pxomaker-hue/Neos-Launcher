## Après Neos v0.6.35
- Vérifier au clavier et avec un lecteur d’écran la fenêtre Accès aux fichiers sur le NAS.
- Poursuivre l’audit des autres fenêtres complexes avant v0.7.

## Après Neos v0.6.34
- Confirmer sur NAS les états d’erreur du widget Tâches en cas de liste CalDAV indisponible.
- Poursuivre l’audit d’accessibilité clavier et des boîtes de dialogue complexes avant v0.7.

## Après Neos v0.6.31
- Vérifier les notifications et états asynchrones sur NAS avec vrais appels serveur (Agenda, Deck, CardDAV).
- Continuer l'audit WCAG des widgets, l'ergonomie mobile et les erreurs en v0.6.32.
- Éviter de modifier les pièces jointes IMAP d'origine ; la copie de texte reste volontairement non destructive.

# v0.6.29 : amélioration progressive de l’accessibilité clavier, raccourcis non destructifs et focus conservé. Prochaine étape : stabilisation du focus et des annonces sur les boîtes de dialogue complexes.

# Feuille de route v0.7 — après v0.6.26

| Zone | Acquis | Reste à valider |
| --- | --- | --- |
| Contacts | Deux courriels, deux téléphones, création/édition/suppression ETag validées ; filtre par carnet et liste progressive en v0.6.26 | Tester les grands carnets réels, limites à 250 par carnet / 400 chargées ; rechercher une future pagination distante sans modifier les données |
| Talk | Envoi, lecture, marqueur lu ; actualisation prudente et conservation de l’historique | Vérifier la pagination sur historique long et l'actualisation sur NAS |
| Mail | Brouillons IMAP et reprise texte non destructive, lecture HTML sécurisée, envoi, relecture après erreur | Tester le bouton Réessayer sur NAS ; pièce jointe dans la copie uniquement après API validée |
| Activité | Filtres et pagination OCS | Tester un historique réel volumineux |
| Planning/Deck/Tâches/Agenda | Parcours fonctionnels validés | Audit de régression, échéances et permissions |
| Design | Flat Cyber, icône Planning orange et topbar réorganisable | Affiner l’accessibilité clavier et le mobile |

Toute modification destructive demeure conditionnée à une confirmation et, si applicable, à une vérification ETag. Les ZIP sont publiés sur GitHub et déployés après sauvegarde OMV.

## Priorités après Neos 0.6.28

1. Confirmer l'historique Activité sur NAS jusqu'aux événements antérieurs au 11 novembre 2026 à 15 h 52 et vérifier les filtres « Toutes les dates ».
2. Consolider les cas de gros historiques et les états de chargement (API Nextcloud).
3. Poursuivre l'accessibilité clavier, les tailles mobiles et les contrôles de non-régression avant v0.7.
