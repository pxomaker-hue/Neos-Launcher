# Neos v0.6.1 — installation sur OMV / Nextcloud 35

**Identifiant Nextcloud préservé : `novadashboard`.** Cette version reprend les préférences et widgets précédents ; aucune migration SQL ni modification de `/data` n’est nécessaire. Le stockage Nextcloud demeure sur **sdb1** et `/config` demeure sur **sdc1**.

## Nouveautés

- Aperçus audio/vidéo intégrés dans l’explorateur (formats lisibles par le navigateur).
- Rendu Markdown sûr, activable depuis l’aperçu ; texte brut toujours accessible.
- Recherche globale : boutons **Aperçu**, **Ouvrir le dossier** et **Favoris** directement sur les résultats.
- Notes : aperçu Markdown, compteur de mots, raccourci Ctrl/Cmd+S.
- Deck : ouvrir une carte pour éditer le titre et la description, puis enregistrer via l’API Deck. Les champs annexes (échéance, propriétaire, état) sont préservés dans la requête.
- PDF : liens de repli **Ouvrir le PDF** et **Ouvrir dans Fichiers** si l’affichage intégré échoue. Le diagnostic dépend des en-têtes du serveur et de la réponse de l’API.

## Transfert depuis PowerShell — une commande par ligne

Place `neos-nextcloud35-v0.6.1.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.1.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## Vérification préalable sur OMV

```bash
sudo docker exec nextcloud occ status
```

Ne poursuivre **que si** Nextcloud 35 est installé avec `maintenance: false` et `needsDbUpgrade: false`.

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
echo "$APP_PATH"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Si le dernier contrôle échoue, arrêter l’installation et vérifier le chemin de l’app. Après la recréation Docker, ne pas supposer que le code se trouve encore sous `/config/www/nextcloud`.

## Sauvegarde de l’app actuelle

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v061.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud tar -tzf /config/neos-backup-avant-v061.tar.gz | head
```

## Installation — commandes individuelles

```bash
mkdir -p /tmp/neos-v061
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.1.zip /tmp/neos-v061
```

```bash
test -f /tmp/neos-v061/novadashboard/appinfo/info.xml && echo "Archive extraite"
```

```bash
sudo docker cp /tmp/neos-v061/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.1`. Si Nextcloud maintient l’ancienne version affichée, vérifier l’app et les fichiers : ne pas exécuter `occ upgrade` ni forcer une migration. Actualiser le navigateur avec **Ctrl+F5**.

## Vérifications après installation

1. Tester une note en mode édition puis Aperçu, et Ctrl+S.
2. Dans **Fichiers**, ouvrir un fichier Markdown, audio et vidéo de test.
3. Rechercher un fichier (`Ctrl+K`), utiliser **Aperçu** puis **Ouvrir le dossier**.
4. Modifier le titre d’une carte Deck de test, vérifier le résultat dans l’application Deck officielle.
5. Tester un PDF de petite taille, puis ses deux liens de repli. Les PDF ne sont **pas** modifiés par les aperçus.

## Diagnostiquer l’erreur d’aperçu PDF

Dans Neos, un PDF est lu avec `GET /index.php/apps/novadashboard/api/inline-pdf?path=...` et doit répondre avec `Content-Type: application/pdf`, `Content-Disposition: inline`. La route est authentifiée et restreinte aux fichiers lisibles par l’utilisateur.

1. **Ouvrir le même PDF dans Fichiers Nextcloud.** S’il fonctionne là mais pas dans Neos, le problème est vraisemblablement lié à la route Neos ou à son intégration dans l’iframe. S’il échoue aussi dans Fichiers, investiguer le lecteur navigateur, l’application PDF officielle et le fichier.
2. Dans Neos v0.6.1, cliquer **Ouvrir le PDF** sous l’aperçu. Si le PDF fonctionne dans un onglet mais pas dans l’aperçu intégré, vérifier dans `F12` → Console les erreurs `frame-src`, `frame-ancestors` ou `X-Frame-Options`. Vérifier aussi les en-têtes de la route dans Réseau. **Ne pas désactiver globalement les protections CSP ou X-Frame-Options** : diagnostiquer d’abord la configuration du reverse proxy et les en-têtes doublonnés.
3. Si le PDF ouvert directement renvoie du JSON ou un message d’erreur, dans `F12` → Réseau relever le **code HTTP** de `inline-pdf` : 401/403 (session/permission), 404 (chemin/route), 500 (erreur application/stockage). Ne pas partager d’URL contenant des jetons ou des données privées.
4. Pour confirmer que Neos est bien actif, sur OMV :

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

5. Pour consulter les erreurs Nextcloud après un test échoué :

```bash
sudo docker exec nextcloud sh -c 'tail -n 40 /data/nextcloud.log'
```

Supprimer/masquer les chemins personnels, identifiants de session et autres détails sensibles avant de partager un extrait. Si le fichier est illisible aussi dans Fichiers, comparer avec un deuxième petit PDF connu comme valide. La génération de miniatures PDF peut être désactivée indépendamment du lecteur PDF : **inutile d’activer des générateurs de miniatures risqués uniquement pour résoudre le lecteur intégré**.

## Retour arrière si nécessaire

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v061.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ status
```

Si des fichiers uniquement ajoutés par la nouvelle version restent dans le dossier après restauration, ils peuvent être examinés séparément ; ne jamais effacer le dossier de l’app sans copie de secours et sans vérifier son chemin réel. **Ne pas toucher aux données `/data` ni à MariaDB.**

## Validation

Code PHP/JavaScript sans erreur de syntaxe, ZIP contrôlé, tests Chromium en mode démonstration sur fichiers et cartes fictifs. Les opérations WebDAV, Notes et Deck réelles n’ont pas été exécutées sur le NAS ; vérifier avec des documents de test.
