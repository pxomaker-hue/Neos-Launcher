# Neos — progression vers la v0.7 après la v0.6.19

## Validations NAS déjà reçues

- Nextcloud 35 / Mail 5.13.2 / OMV LinuxServer.io.
- Validation des tâches et cartes Deck ; planning unifié et onglets personnalisables.
- Talk : lecture/envoi. Contacts : création/modification CardDAV.
- Mail : lecture HTML, envoi SMTP après configuration du dossier Envoyés, synchronisation des nouveaux courriels.

## v0.6.18 — Retour du test réel

- `PUT /apps/mail/api/drafts/{id}` → HTTP 202.
- Le brouillon n'est pas visible dans Mail natif → Brouillons.
- Cause retrouvée dans l'API Mail : la création/mise à jour conserve d'abord une entrée locale, et l'écriture IMAP est une étape distincte.

## v0.6.19 — À tester sur NAS

- Transfert IMAP explicite après enregistrement local (`POST /api/drafts/move/{id}`).
- Neos ne déclare plus un succès complet après le seul HTTP 202 de `PUT /api/drafts`.
- Blocage des opérations multiples quand l'état du transfert est incertain.
- Filtre Talk non lus et actualisation de la liste après retour d'une conversation.

## Reste avant la v0.7

1. **Mail** : retrouver/réouvrir un brouillon IMAP dans l'éditeur Neos (avec gestion d'identifiants IMAP), pièces jointes, réponse dans un fil, gestion multi-boîtes ; contrôler les alias.
2. **Talk** : rafraîchissement non intrusif et fiabilité des compteurs non lus ; réponses et pièces jointes plus riches.
3. **Contacts** : champs multiples et suppression protégée avec confirmation et ETag.
4. **Activité** : filtres serveur, pagination et messages d'erreurs affinés.
5. **Tests de stabilisation** : portable/mobile, sécurité et absence de doublons ; retours arrière, mise à jour des API, tests réels avant publication de la 0.7.
