# Rapport de vérification Neos v0.6.19

## Contrôles effectués dans l'environnement local

- Source construite à partir du ZIP v0.6.18 fourni précédemment.
- `node --check` sur le JavaScript Neos : validé.
- Tests de la fonction de brouillon avec réponses API simulées :
  - `POST /api/drafts` puis `POST /api/drafts/move/{id}` → confirmation du transfert, pas d'appel SMTP.
  - Échec HTTP 500 du transfert → état incertain, blocage du renvoi automatique.
  - Perte simulée de réponse réseau → état incertain, blocage du renvoi automatique.
- Aperçu interactif rendu avec Chromium dans un environnement local, sans connexion Nextcloud, sur données fictives.
- Filtre « Non lues » dans Talk : fonctionnement visuel en démonstration.
- Transfert IMAP réel et reprise de brouillons dans Neos : **non testés sur le NAS**. La reprise de brouillons transférés dans Neos n'est pas implémentée ; elle s'effectue via Mail natif.

## Référence fonctionnelle

Mail 5.13.2 : `DraftsController::create` → HTTP 201 ; `DraftsController::update` → HTTP 202 ; `DraftsController::move` → HTTP 202 avec appel `DraftsService::sendMessage()` pour enregistrement IMAP et suppression locale après succès.

## Test demandé sur NAS

1. Préparer un brouillon fictif dans Neos, sans envoi.
2. Vérifier les deux requêtes dans F12 → Réseau.
3. Vérifier le dossier Brouillons de Mail natif.
4. Tester le filtre Talk « Non lues ».
