# Installer Neos v0.6.19 — OpenMediaVault / Nextcloud 35

Cette mise à jour part de Neos **v0.6.18**, conserve le design Flat Cyber et ajoute le transfert des brouillons Mail vers le dossier IMAP et le filtre Talk « Non lues ». **Exécute chaque commande séparément**. Le serveur n'a pas besoin d'une modification de son proxy ou de Docker.

## 1. Windows — PowerShell

Enregistre l'archive dans `X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.19.zip` puis :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.19.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. NAS OMV — Vérifier et sauvegarder la version v0.6.18

```bash
sudo docker exec nextcloud occ status
```

Arrête l'installation si `maintenance: true` ou `needsDbUpgrade: true`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.19.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Continue uniquement si `Neos trouvé` s'affiche.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0619.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0619.tar.gz
```

## 3. Installation

```bash
mkdir -p /tmp/neos-v0619
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.19.zip /tmp/neos-v0619
```

```bash
test -f /tmp/neos-v0619/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**Arrête-toi** si `Archive prête` n'apparaît pas.

```bash
sudo docker cp /tmp/neos-v0619/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.19`. Recharge le navigateur avec **Ctrl + F5**.

## 4. Tester le correctif Brouillons sans envoyer de mail

1. Dans **Neos → Mail → Rédiger**, prépare un petit message fictif avec destinataire, objet et texte. Ne clique pas sur « Envoyer ».
2. Clique **Enregistrer dans Brouillons**. La requête de création/mise à jour (`POST /api/drafts` ou `PUT /api/drafts/{id}`) doit être suivie de **`POST /api/drafts/move/{id}`**.
3. Neos doit afficher **« Transfert du brouillon vers le dossier IMAP accepté »**. Vérifie sa présence dans **Mail natif → Brouillons** (au besoin, synchronise le dossier).
4. La version actuelle fige le compositeur après transfert pour éviter des copies supplémentaires. **Édite le brouillon transféré dans Mail natif**. L'ouverture des brouillons IMAP dans l'éditeur Neos sera développée ultérieurement.
5. Si Neos indique **« Transfert non confirmé »**, ne réessaie pas immédiatement : vérifie les Brouillons dans Mail natif avant toute nouvelle action.
6. Dans **Neos → Talk**, teste le filtre **Non lues**, puis ouvre une conversation et reviens à la liste. Vérifie aussi la synchronisation Mail et l'ordre des onglets.

Cette opération ne déclenche pas d'envoi SMTP. Un brouillon local de la v0.6.18 peut encore exister côté Nextcloud sans être visible dans le dossier IMAP ; la v0.6.19 ne le récupère pas automatiquement.

## 5. Retour arrière si nécessaire

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
sudo docker exec nextcloud test -f /config/neos-backup-avant-v0619.tar.gz && echo "Sauvegarde trouvée"
```

Si la sauvegarde existe :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0619.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.18`. Recharge avec Ctrl + F5. Ce retour arrière n'efface pas les brouillons déjà transférés vers le serveur IMAP.
