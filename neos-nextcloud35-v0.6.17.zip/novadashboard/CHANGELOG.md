# Historique Neos

## 0.6.17 — synchronisation de Mail

- Synchroniser la boîte IMAP avant de lire les messages (API Mail 5.13.2).
- Bouton Synchroniser visible, avec heure de dernière synchronisation réussie.
- Rafraîchissement toutes les 90 s quand l'espace Mail est actif et visible ; contrôle après envoi confirmé.
- Un seul rafraîchissement simultané ; gestion bornée des retours 428 (initialisation), 409 (occupé) et 500 (erreur).
- Conserve les messages précédemment mis en cache en cas d'échec temporaire.

## 0.6.16 — rédaction / envoi / réponse

- Interface de composition texte dans Mail, envoi en deux étapes via Outbox.
