# Neos — Prochaines étapes vers v0.7

**Validé sur NAS :** onglets réorganisables, icône Planning, Tâches + Deck, Talk (lecture/envoi), Contacts (création/édition), Mail (lecture HTML + envoi après configuration du dossier Envoyés).

**v0.6.17 à valider :** synchronisation IMAP directement depuis Neos, rafraîchissement de la boîte et diagnostic des collisions de sync.

**Travaux à terminer avant v0.7 :**

- Mail : brouillons persistants, état d'envoi consultable, réponses fiables, pièces jointes (selon API et tests réels).
- Talk : compteurs de non-lus et confort des conversations.
- Contacts : champs multiples, suppression avec confirmation et contrôle ETag.
- Activité : filtres et pagination à consolider.
- Régression : validation sur desktop/mobile, erreurs réseau, compatibilité Nextcloud 35, sécurité du HTML, sauvegarde/rollback.
