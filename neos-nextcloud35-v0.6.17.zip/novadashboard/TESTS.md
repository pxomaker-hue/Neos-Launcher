# Tests Neos v0.6.17

- Syntaxe JavaScript : `node --check js/app.js` — OK.
- Syntaxe PHP : `php -l appinfo/routes.php` — OK ; validation XML de info.xml — OK.
- Simulation API Mail (Node.js) : 200, 428 initialisation, 409 boîte occupée, 500 erreur serveur — OK ; la requête sync précède toujours le GET des messages ; aucun POST Outbox émis par la synchronisation.
- Chromium : ouverture de Mail, bouton Synchroniser, capture ordinateur et mobile, aucun `pageerror` JavaScript — OK sur données fictives.
- ZIP : à vérifier avant livraison.

**À confirmer sur NAS :** `POST /apps/mail/api/mailboxes/1/sync` et réception d'un nouveau message sans ouvrir Mail natif, puis tests de non-régression.
