# Neos Launcher v0.6.17 — Nextcloud 35

Version fondée sur la v0.6.16, validée sur le NAS (envoi Mail et lecture HTML après configuration du dossier Envoyés).

## Mail — synchronisation IMAP

La lecture `/apps/mail/api/messages` seule ne déclenchait pas l'actualisation du serveur. Neos appelle maintenant `POST /apps/mail/api/mailboxes/{id}/sync` avec une requête JSON avant de lire les messages, à l'ouverture, sur « Synchroniser » et environ toutes les 90 secondes tant que le module Mail est visible. Une réponse 428 déclenche au maximum une initialisation supplémentaire. Une réponse 409, 423 ou 500 est décrite sans masquer les messages déjà disponibles. Le retour à la liste après un envoi réussi recharge également les messages.

La synchronisation n'envoie aucun mail. Les pièces jointes, les brouillons persistants, le S/MIME, les envois différés restent accessibles depuis Mail natif.

Conserve le thème Flat Cyber, la topbar réorganisable, l'icône Planning personnalisée, Planning, Deck, Talk, Activité et Contacts.
