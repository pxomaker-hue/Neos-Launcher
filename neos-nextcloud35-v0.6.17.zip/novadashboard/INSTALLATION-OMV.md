# Neos v0.6.17 — Installation OMV / Nextcloud 35

Cette mise à jour part de la v0.6.16 validée : envoi de Mail opérationnel après configuration du dossier Envoyés. Elle corrige la lecture de la boîte de réception non actualisée dans Neos. La version 5.13.2 de Mail possède une API de synchronisation IMAP que Neos utilise avant de lire `/api/messages`.

**Nouveautés** : synchronisation serveur des boîtes avant lecture, bouton « Synchroniser », passage automatique toutes les 90 secondes lorsque Mail reste visible, synchronisation après un envoi confirmé (au retour à la boîte), diagnostics 409/428/500. Pas de nouvel envoi déclenché par la synchronisation.

## 1. PowerShell — une commande à la fois

Télécharger `neos-nextcloud35-v0.6.17.zip` et le placer dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.17.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Terminal SSH OMV — vérifier et sauvegarder

```bash
sudo docker exec nextcloud occ status
```

**Stop** si `maintenance: true` ou `needsDbUpgrade: true`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.17.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

**Stop** si « Neos trouvé » n'apparaît pas.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0617.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0617.tar.gz
```

## 3. Décompresser et installer

```bash
mkdir -p /tmp/neos-v0617
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.17.zip /tmp/neos-v0617
```

```bash
test -f /tmp/neos-v0617/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**Stop** si « Archive prête » n'apparaît pas.

```bash
sudo docker cp /tmp/neos-v0617/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.17`. Recharger Neos avec **Ctrl + F5**.

## 4. Tests réels sans envoi supplémentaire

1. Déposer un nouveau message de test dans la boîte depuis un autre client ou attendre un mail entrant ; rester dans Neos Mail et vérifier le rafraîchissement après synchronisation.
2. Cliquer sur **Synchroniser** : dans F12 → Réseau, vérifier que `POST /apps/mail/api/mailboxes/{id}/sync` précède `GET /apps/mail/api/messages?...`.
3. Si `409`, le serveur est déjà en train de synchroniser : un message de diagnostic doit apparaître et les anciens courriels restent accessibles.
4. Reprendre une discussion Talk, afficher une fiche Contacts, valider une tâche et vérifier l'ordre de la topbar pour détecter toute régression.

La fréquence automatique est de 90 secondes uniquement lorsque l'onglet Mail de Neos est actif, visible et qu'aucune rédaction/lecture détaillée n'est en cours. Une synchronisation lancée juste avant la réception du nouveau message ne le fera apparaître qu'au passage suivant.

## 5. Retour arrière vers v0.6.16

Une commande à la fois sur OMV :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
sudo docker exec nextcloud test -f /config/neos-backup-avant-v0617.tar.gz && echo "Sauvegarde trouvée"
```

Si la sauvegarde a été trouvée :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0617.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.16`. Recharger avec Ctrl + F5. Ne pas lancer `occ upgrade`, ni modifier le proxy ou le serveur SMTP pour cette mise à jour.
