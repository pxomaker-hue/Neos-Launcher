# Installation — Neos v0.5.2 / Nextcloud 35 / OMV

Le nom affiché est **Neos**. L'ID technique demeure **novadashboard** : aucun nouveau conteneur ou volume n'est nécessaire. Le paquet contient les assets et les préférences compatibles avec les versions précédentes.

## 1. Copier l'archive depuis Windows

Télécharger `neos-nextcloud35-v0.5.2.zip` puis dans PowerShell :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.5.2.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier l'état

Dans SSH :

```bash
sudo docker exec nextcloud occ status
```

Continuer uniquement si Nextcloud est toujours en 35.x, si `maintenance` et `needsDbUpgrade` sont à `false`, et si aucune mise à jour n'est en cours. Prévoir une sauvegarde régulière complète de Nextcloud.

## 3. Sauvegarder le code de la version précédente

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v052.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

Pour vérifier :

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v052.tar.gz
```

## 4. Déployer v0.5.2

```bash
mkdir -p /tmp/neos-v052
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.2.zip /tmp/neos-v052
sudo docker cp /tmp/neos-v052/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Recharger **Neos** avec `Ctrl + F5`.

## 5. Utiliser la nouvelle disposition

Sur **Accueil** → **Personnaliser** → **Disposition de l'accueil**.

- **Adaptatif** : la grille ajuste automatiquement les tailles à l'écran.
- **Libre** : choisir la largeur de chaque widget (25, 33, 50, 67, 75 ou 100 %).
- **Réorganiser** : fermer le panneau en mode disposition, déplacer les cartes par les poignées, ajuster `−` et `+`, puis cliquer **Terminer**.

L'ordre et les largeurs sont enregistrés par utilisateur. Sur téléphone, utiliser les flèches plutôt que le glisser-déposer.

## 6. Diagnostiquer Deck si HTTP 404 persiste

La documentation Deck décrit `GET /index.php/apps/deck/api/v1.0/boards` et requiert `OCS-APIRequest: true`. Neos essaie également le point d'entrée OCS lorsqu'il reçoit un 404.

Dans SSH :

```bash
sudo docker exec nextcloud occ app:list
```

Chercher **deck** sous la section des applications **Enabled**. Si Deck est **Disabled** et déjà installé, vérifier qu'il est compatible avec Nextcloud 35 avant d'utiliser `sudo docker exec nextcloud occ app:enable deck`.

Si Deck est déjà activé, ouvrir **F12 → Réseau → Fetch/XHR** dans le navigateur, cliquer **Deck** dans Neos et examiner la réponse de `boards`. Si elle reste en erreur, consulter les journaux Nextcloud :

```bash
sudo docker exec nextcloud occ log:tail
```

Ne pas lancer `occ upgrade` pour ce seul problème.

## 7. Retour arrière

Si Neos présente un problème après la mise à jour :

```bash
sudo docker exec nextcloud sh -c 'tar -xzf /config/neos-backup-avant-v052.tar.gz -C /config/www/nextcloud/apps/'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Puis `Ctrl + F5`. Pour une restauration *strictement identique*, les nouveaux fichiers éventuellement ajoutés par la v0.5.2 doivent également être retirés après sauvegarde préalable ; ne jamais supprimer tout le volume `/config`.

## Validation hors NAS

Contrôles syntaxe PHP/JS/XML, tests navigateur en simulation desktop/mobile, glisser-déposer, redimensionnement, navigation Deck en simulation (404 REST suivi d'un succès OCS), archive ZIP. **Pas de validation directe sur ton NAS.**
