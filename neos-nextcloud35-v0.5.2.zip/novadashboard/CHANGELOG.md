# Neos — Changelog

## 0.5.2 — Disposition adaptative

- Accueil à grille de 12 colonnes avec mode automatique et mode libre.
- Redimensionnement par widget (3, 4, 6, 8, 9, 12 colonnes) avec sauvegarde.
- Réorganisation interactive avec poignée, zone cible et contrôles au clavier.
- Maintien des préférences d’affichage des versions antérieures.
- API Deck : routes REST documentées et repli OCS en cas de 404 ; diagnostic d’app absente.
- Réintégration des assets SVG du NEOS UI Kit fourni, et monogramme de navigation.

## 0.5.1 — Accueil et Fichiers

- Séparation Accueil/Fichiers, onglets, Deck/Notes visibles, animations de transition, défilement vertical.
