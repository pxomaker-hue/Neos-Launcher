# Neos — v0.5.2

Application personnalisée pour Nextcloud 35. L’identifiant technique reste `novadashboard` pour préserver la page d’accueil et les préférences existantes.

## Changements v0.5.2

- Disposition de l’accueil : **Adaptatif** (tailles calculées) et **Libre** (tailles personnalisables, de 25 % à 100 %).
- Déplacement des widgets directement sur l’accueil via une **poignée de glisser-déposer** avec repère de placement ; commandes de déplacement disponibles également pour mobile et clavier.
- Prévisualisation des réarrangements avec grille cyan, survol lumineux et animation d’atterrissage ; sauvegarde des préférences utilisateur dans Nextcloud.
- Deck : vérification de sa présence parmi les applications activées, essai des routes REST officielles puis OCS en cas de 404 ; messages d’erreur plus détaillés.
- Assets SVG du kit NEOS UI Kit v1 intégrés localement, dont le pictogramme de navigation `img/app.svg`.

## Limites

- L’erreur Deck 404 peut signifier une **application Deck absente/désactivée** ou une route indisponible sur l’instance. Neos ne peut pas activer Deck ni réparer sa configuration serveur.
- La confirmation du correctif Deck doit être faite sur une instance Nextcloud 35 avec Deck installé et actif pour l’utilisateur.
- Seuls les modules réellement implémentés dans Neos prennent en charge les actions intégrées ; les autres applications restent accessibles via leurs liens Nextcloud.
- Les suppressions et partages de fichiers demeurent des actions réelles sur les données Nextcloud : utiliser les confirmations.

## Installation

Consulter `INSTALLATION-OMV.md` à la racine de l’archive.
