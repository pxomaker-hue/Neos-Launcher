# Neos v0.6.10 — Installation sur OMV / Nextcloud 35

**Application :** `novadashboard` · **Environnement :** OpenMediaVault + Docker LinuxServer.io · **Domaine :** configuration Nextcloud existante inchangée.

Cette mise à jour conserve les espaces de la v0.6.9. Elle ajoute la nouvelle icône Planning dans le hub, l'ordre des onglets personnalisable (sauvegardé dans Nextcloud pour chaque utilisateur) et les filtres de l'Activité.

**IMPORTANT : exécuter chaque bloc de commande séparément**, sans coller tous les blocs d'un coup. L'installation remplace uniquement les fichiers de l'application Neos. Elle ne touche ni aux fichiers personnels ni aux configurations du proxy.

## 1. Sur Windows, dans PowerShell

Télécharger `neos-nextcloud35-v0.6.10.zip` et le placer dans :

`X:\Travail\Apprentissage\Codage\Neos Launcher\`

Copier le ZIP :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.10.zip" ssh-pxo@192.168.1.200:/tmp/
```

Se connecter :

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Dans le terminal SSH du NAS

Vérifier le statut (doit montrer `maintenance: false` et `needsDbUpgrade: false`) :

```bash
sudo docker exec nextcloud occ status
```

Vérifier la présence du ZIP :

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.10.zip
```

Lire le chemin réel de l'application :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

Vérifier que c'est bien Neos :

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé : $APP_PATH"
```

**Si aucune confirmation `Neos trouvé` ne s'affiche, ne pas continuer.**

Sauvegarder l'ancienne version (normalement 0.6.9) :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0610.tar.gz -C "$APP_PATH" .
```

Vérifier que l'archive de sauvegarde existe :

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0610.tar.gz
```

Préparer un dossier d'extraction propre :

```bash
mkdir -p /tmp/neos-v0610
```

Décompresser :

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.10.zip /tmp/neos-v0610
```

Vérifier la structure :

```bash
test -f /tmp/neos-v0610/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**Si `Archive prête` s'affiche et que les étapes précédentes ont réussi**, installer :

```bash
sudo docker cp /tmp/neos-v0610/novadashboard/. "nextcloud:$APP_PATH/"
```

Réparer les droits dans le conteneur LinuxServer.io :

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

Vérifier la version :

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Attendu : `novadashboard: 0.6.10`.

Retourner dans le navigateur et faire **Ctrl + F5**.

## 3. Utiliser les nouveaux réglages

1. Dans Neos, cliquer **Personnaliser**.
2. La section **Ordre des onglets**, désormais en haut du volet, permet de déplacer les onglets par glisser-déposer ou via les flèches. **Ordre par défaut** restaure le classement d'origine.
3. Cliquer **Terminer**, ou cliquer **Réorganiser** pour déplacer directement les onglets de la barre supérieure avec la souris.
4. Actualiser la page et vérifier que l'ordre choisi a été conservé ; les préférences sont stockées dans Nextcloud et suivent le compte utilisateur.
5. Ouvrir **Applications** : l'icône orange Planning doit être visible.
6. Ouvrir **Activité** : filtrer par source et afficher la suite des résultats.

**Note :** dans l'aperçu HTML, les réglages restent temporaires ; la synchronisation entre appareils ne peut être validée que sur le NAS.

## 4. Retour à la version sauvegardée

Si l'installation ne fonctionne pas, utiliser ces commandes dans la **même session SSH** (où `APP_PATH` est toujours défini). Sinon, relancer d'abord la commande `APP_PATH=...` ci-dessus.

Restaurer les fichiers précédents :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0610.tar.gz -C "$APP_PATH"
```

Réparer les droits :

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

Vérifier :

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Actualiser le navigateur avec **Ctrl + F5**. Si la restauration n'a pas rétabli la version précédente, arrêter les manipulations et partager l'erreur plutôt que modifier le conteneur.

## 5. Avancement vers Neos v0.7

- Talk : lecture des fils et envoi direct encore à faire.
- Activité : filtres locaux disponibles en v0.6.10 ; pagination serveur à faire.
- Contacts : création, modification, suppression CardDAV sécurisées à faire.
- Mail : lecture complète, composition et envoi dans Neos à faire après validation des APIs de l'app Mail installée.
- Revue des cas de permissions, mobile et des erreurs réseau avant la v0.7.
