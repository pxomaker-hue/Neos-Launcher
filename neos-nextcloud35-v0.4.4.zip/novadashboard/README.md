# Neos v0.4.4

Application intégrée pour **Nextcloud 35** (PHP 8.3+). Identifiant d'application : `novadashboard` pour assurer la compatibilité avec les installations et préférences Nova existantes.

## Fonctions

- accueil plein écran et animations contrôlables (`off`, `subtle`, `full`)
- explorateur intégré en deux colonnes avec navigation arrière/avant, recherche locale, historique, tris, favoris
- aperçus sécurisés : images, fichiers texte, CSV/TSV et PDF selon capacités navigateur
- menu contextuel : aperçu agrandi, téléchargement, lien, ouverture native
- hub d'applications téléchargées activées pour l'utilisateur, topbar configurable
- widgets de stockage, activités récentes, calendrier, tâches, notes, liens et réglages

## Sécurité et limites

- aucune modification des données par les API Neos : seuls les services de lecture des fichiers du compte connecté sont utilisés
- le rendu HTML échappe les noms de fichiers, titres et préférences
- les routes API restent protégées par le jeton CSRF Nextcloud, hormis la page d'accueil HTML
- édition/partage/suppression restent dans l'application Fichiers officielle
- la prise en charge Office complète requiert les applications Office intégrées à Nextcloud
- les aperçus PDF dépendent des politiques du navigateur et du serveur
- pas de script chargé depuis un CDN ; le style animé est inspiré d'Anime.js et implémenté localement

## Icône

`img/app.svg` et `img/neos-mark.svg` contiennent un monogramme local remplaçable par la charte graphique finale.
