# Neos Dashboard 0.5.0

Application Nextcloud 35, personnalisable et pleine largeur, conservant l'ID technique `novadashboard`.

## Modules

- **Fichiers** : recherche dans le dossier courant, navigation, aperçu, téléversement et opérations de base via WebDAV.
- **Photos** : images accessibles au compte courant (recherche bornée à 900 éléments, 120 photos restituées), visionneuse intégrée. Les albums Nextcloud Photos ne sont pas répliqués.
- **Notes** : liste/édition/création via l'API officielle Notes v1. Le conflit d'édition entraîne un message sans écraser la version distante.
- **Deck** : consultation des tableaux/listes/cartes et création de carte via l'API REST Deck v1.0.
- **Agenda et Tâches** : consultation, à partir des données CalDAV existantes.
- **Talk, Mail, Contacts, Activité** : espace interne de repli avec lien explicite vers l'app native. Pas de conversation, de mail ou d'appel interne dans cette version.

## Sécurité et limites

- Les actions serveur sont effectuées uniquement avec la session Nextcloud courante.
- Les opérations sensibles utilisent les protections et permissions de Nextcloud/WebDAV.
- Création de liens publics et suppression demandent une confirmation.
- Import/export/édition Office restent gérés par les apps natives, selon les apps installées.
- Pas de dépendance JavaScript externe ni modification de la base Nextcloud.

## Fichiers importants

- `appinfo/info.xml` : métadonnées et version.
- `appinfo/routes.php` : routes API existantes et galerie.
- `lib/Service/MediaService.php` : découverte d'images autorisées.
- `js/app.js` : vue et navigation internes.
- `css/app.css` : style intégré et thème.
- `img/kit/` : SVG issus du kit fourni par l'utilisateur.
