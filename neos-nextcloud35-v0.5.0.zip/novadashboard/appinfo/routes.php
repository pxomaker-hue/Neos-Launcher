<?php

declare(strict_types=1);

return [
    'routes' => [
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        ['name' => 'data#overview', 'url' => '/api/overview', 'verb' => 'GET'],
        ['name' => 'data#browseFiles', 'url' => '/api/files', 'verb' => 'GET'],
        ['name' => 'data#gallery', 'url' => '/api/gallery', 'verb' => 'GET'],
        ['name' => 'data#saveSettings', 'url' => '/api/settings', 'verb' => 'POST'],
    ],
];
