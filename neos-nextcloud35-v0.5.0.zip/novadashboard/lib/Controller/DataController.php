<?php

declare(strict_types=1);

namespace OCA\NovaDashboard\Controller;

use OCA\NovaDashboard\Service\OverviewService;
use OCA\NovaDashboard\Service\PreferencesService;
use OCA\NovaDashboard\Service\FileBrowserService;
use OCA\NovaDashboard\Service\MediaService;
use OCP\Files\NotFoundException;
use OCP\Files\NotPermittedException;
use InvalidArgumentException;
use Throwable;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\JSONResponse;
use OCP\IRequest;
use OCP\IUserSession;

final class DataController extends Controller {
    public function __construct(
        IRequest $request,
        private IUserSession $session,
        private OverviewService $overviewService,
        private PreferencesService $preferences,
        private FileBrowserService $fileBrowser,
        private MediaService $media,
    ) {
        parent::__construct('novadashboard', $request);
    }

    #[NoAdminRequired]
    public function overview(): JSONResponse {
        $user = $this->session->getUser();
        if ($user === null) {
            return new JSONResponse(['error' => 'Authentification requise'], 401);
        }
        $response = new JSONResponse([
            'user' => ['name' => $user->getDisplayName()],
            'overview' => $this->overviewService->build($user),
            'settings' => $this->preferences->get($user->getUID()),
        ]);
        $response->addHeader('Cache-Control', 'private, no-store');
        return $response;
    }

    #[NoAdminRequired]
    public function browseFiles(): JSONResponse {
        $user = $this->session->getUser();
        if ($user === null) {
            return new JSONResponse(['error' => 'Authentification requise'], 401);
        }
        $path = $this->request->getParam('path', '/');
        if (!is_string($path)) {
            return new JSONResponse(['error' => 'Chemin invalide'], 400);
        }
        try {
            $result = $this->fileBrowser->browse($user, $path);
            $response = new JSONResponse($result);
        } catch (InvalidArgumentException $error) {
            return new JSONResponse(['error' => 'Chemin invalide'], 400);
        } catch (NotFoundException $error) {
            return new JSONResponse(['error' => 'Dossier introuvable'], 404);
        } catch (NotPermittedException $error) {
            return new JSONResponse(['error' => 'Accès au dossier refusé'], 403);
        } catch (Throwable $error) {
            return new JSONResponse(['error' => 'Impossible de lire ce dossier'], 500);
        }
        $response->addHeader('Cache-Control', 'private, no-store');
        return $response;
    }

    #[NoAdminRequired]
    public function gallery(): JSONResponse {
        $user = $this->session->getUser();
        if ($user === null) {
            return new JSONResponse(['error' => 'Authentification requise'], 401);
        }
        try {
            $result = new JSONResponse($this->media->gallery($user));
            $result->addHeader('Cache-Control', 'private, no-store');
            return $result;
        } catch (Throwable $error) {
            return new JSONResponse(['error' => 'Photos momentanément indisponibles'], 500);
        }
    }

    #[NoAdminRequired]
    public function saveSettings(): JSONResponse {
        $user = $this->session->getUser();
        if ($user === null) {
            return new JSONResponse(['error' => 'Authentification requise'], 401);
        }

        // The route is intentionally not CSRF-exempt; Nextcloud verifies requesttoken.
        $settings = $this->request->getParam('settings');
        if (!is_array($settings)) {
            return new JSONResponse(['error' => 'Préférences invalides'], 400);
        }
        $value = $this->preferences->save($user->getUID(), $settings);
        $response = new JSONResponse(['settings' => $value]);
        $response->addHeader('Cache-Control', 'private, no-store');
        return $response;
    }
}
