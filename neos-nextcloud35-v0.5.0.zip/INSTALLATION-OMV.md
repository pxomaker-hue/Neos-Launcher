# Neos 0.5.0 — Installation OMV / Nextcloud 35

Ce paquet est une mise à jour du dossier applicatif **novadashboard**. Il ne crée **aucun conteneur**, ne touche pas aux fichiers de données Nextcloud et ne demande pas de migration SQL.

## Copier depuis Windows PowerShell

Après avoir enregistré le ZIP dans le dossier souhaité (adapter le chemin local si nécessaire) :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.5.0.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 1. Contrôler l'état

```bash
sudo docker exec nextcloud occ status
```

Poursuivre uniquement si Nextcloud est en version 35.x, `maintenance: false`, `needsDbUpgrade: false`, et qu'aucune mise à jour n'est en cours.

## 2. Sauvegarder le code actuel

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v050.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

Cette sauvegarde est **complémentaire** à une sauvegarde de Nextcloud (données, configuration et base de données).

## 3. Décompresser sur le NAS

```bash
mkdir -p /tmp/neos-v050
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.0.zip /tmp/neos-v050
ls -l /tmp/neos-v050/novadashboard/appinfo/info.xml
```

## 4. Installer dans le conteneur LinuxServer

```bash
sudo docker cp /tmp/neos-v050/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

La mise à jour du code est généralement suffisante. **Ne pas exécuter `occ upgrade` automatiquement.** Si Nextcloud active le mode maintenance ou signale une migration, lire les logs et vérifier avant de poursuivre.

Actualiser la page Neos avec `Ctrl + F5`.

## 5. Vérifications après installation

1. Fichiers : liste, aperçu et navigation.
2. Photos : onglet et miniatures.
3. Notes et Deck : onglets présents **seulement si les apps sont activées**. Sinon, aucune intégration factice n'apparaît.
4. Navigation entre modules sans changement de page.
5. Personnalisation : ouverture et fermeture.

Si un module affiche « API indisponible », relever l'onglet **Réseau** des outils développeur et le code HTTP de la requête. L'app Notes peut nécessiter une configuration d'accès API compatible avec la session ; le code est conçu pour conserver l'accès natif en repli.

## Restauration de l'ancienne version

Après confirmation que la sauvegarde existe :

```bash
sudo docker exec nextcloud sh -c 'test -s /config/novadashboard-backup-avant-v050.tar.gz && echo "Sauvegarde présente"'
```

Pour restaurer **uniquement l'application** (pas le conteneur ni les données Nextcloud) :

```bash
sudo docker exec nextcloud sh -c 'rm -rf /config/www/nextcloud/apps/novadashboard && tar -xzf /config/novadashboard-backup-avant-v050.tar.gz -C /config/www/nextcloud/apps/'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Puis `Ctrl + F5` dans le navigateur.

## Fichiers fournis

- `novadashboard/` : application.
- `APERCU-Neos-v0.5.0.html` : démonstration locale, **données fictives**, à ouvrir depuis le dossier extrait.
- `INSTALLATION-OMV.md` : ce guide.

**Important :** la galerie intégrée ne remplace pas encore les albums Photos natifs ; Agenda et Tâches sont en consultation ; les appels Talk et les fonctions avancées d'Office ne sont pas intégrés.
