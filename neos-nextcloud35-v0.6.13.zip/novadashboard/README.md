# Neos Launcher v0.6.13 — Nextcloud 35

Module `novadashboard` pour OMV / LinuxServer.io.

- Mail : ouverture et lecture intégrée en texte via `/api/messages/{id}/body`, avec repli vers Mail natif si indisponible. Aucun HTML de mail n’est exécuté dans Neos.
- Mail : lien direct vers le message via `/open/{id}`, filtre Non lus conservé.
- Contacts création/édition, Talk conversation, Activité pagination, Agenda, Deck, Tâches, Planning et topbar personnalisable conservés.

**Mail rédaction, réponses, pièces jointes et envoi :** restent dans l’application native.

Consultez `INSTALLATION-OMV.md` avant installation. Tests de l’API réelle sur NAS nécessaires.
