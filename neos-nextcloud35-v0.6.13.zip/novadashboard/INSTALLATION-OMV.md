# Neos v0.6.13 — Installation OMV / Nextcloud 35

Application : `novadashboard`. Mise à niveau depuis **v0.6.12**, validée sur le NAS.

**Exécuter les commandes ci-dessous séparément.** N'effectuer aucune modification du proxy, de la CSP ou des fichiers personnels.

## 1. Windows — PowerShell

Télécharge `neos-nextcloud35-v0.6.13.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.13.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. NAS — Vérifications et sauvegarde

```bash
sudo docker exec nextcloud occ status
```

Arrête-toi si `maintenance` est `true` ou `needsDbUpgrade` est `true`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.13.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Arrête-toi si « Neos trouvé » n'apparaît pas.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0613.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0613.tar.gz
```

## 3. Installation

```bash
mkdir -p /tmp/neos-v0613
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.13.zip /tmp/neos-v0613
```

```bash
test -f /tmp/neos-v0613/novadashboard/appinfo/info.xml && echo "Archive prête"
```

```bash
sudo docker cp /tmp/neos-v0613/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.13`. Dans le navigateur, **Ctrl + F5**.

## 4. Tests à effectuer

1. Dans Neos → **Mail**, vérifie que les messages récents s'affichent.
2. Ouvre un message contenant du texte brut et vérifie que son corps apparaît dans Neos.
3. Vérifie le bouton « Boîte de réception » pour revenir à la liste.
4. Vérifie « Ouvrir dans Mail », puis le filtre « Non lus ».
5. Vérifie Contacts, Talk, Planning et que l'ordre de la topbar est conservé.

**Important :** le lecteur affiche le texte seulement, jamais le HTML ni les images distantes. Les messages uniquement HTML ainsi que les réponses, pièces jointes et envois s'ouvrent dans Mail natif. Le point d'API utilisé existe dans les sources de Nextcloud Mail, mais le comportement reste à confirmer sur ta version installée.

## 5. Retour arrière vers la sauvegarde v0.6.12

Exécuter uniquement si nécessaire. Ne pas supprimer les préférences ni les données Nextcloud.

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f /config/neos-backup-avant-v0613.tar.gz && echo "Sauvegarde disponible"
```

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0613.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Terminer par Ctrl + F5. La restauration remet les fichiers de la version sauvegardée ; pour un retour strict, la sauvegarde doit être complète et les anciens fichiers ne doivent pas avoir été renommés/supprimés.
