# Feuille de route Neos vers v0.7 — après v0.6.13

## Déjà développés et validés sur NAS
- Agenda, Tâches, Deck et Planning, incluant validation des cartes Deck.
- Topbar réordonnable avec préférences utilisateur.
- Talk : lecture/envoi de messages.
- Contacts : consultation, création et modification CardDAV.

## Développés, à valider sur NAS
- Mail : filtres, ouverture et lecture sécurisée en texte, sans HTML chargé dans Neos (v0.6.13).
- Activité : pagination et filtrage (tests UI ; tester la pagination réelle si pas encore fait).

## Avant la v0.7
- Mail : compatibilité des API du serveur réel, rédaction, réponse et envoi avec contrôles de sécurité, sous réserve de schéma d'API validé ; sinon repli explicite dans Mail natif.
- Contacts : plusieurs e-mails / numéros et suppression avec confirmation et ETag.
- Talk : gestion des non-lus et conversation améliorée.
- Validation des vues mobiles, des erreurs serveur et des mises à jour sans rafraîchissement intégral.
- Tests de régression et de retour arrière.

Le jalon v0.7 sera considéré atteint après validation des parcours principaux sur le NAS et non sur la seule base des simulations.
