## v0.6.13 — Mail, lecture intégrée

- Nouveau lecteur de courriels en texte brut dans Neos ; appel individuel à l’API Mail seulement après sélection.
- Protection : aucun HTML de courriel injecté, ni image distante chargée ; corps non conservé dans les paramètres.
- Retour vers Mail natif pour rédiger, répondre et gérer les pièces jointes ; erreurs détaillées en cas d’API incompatible.
- Conservation des modules et préférences de la v0.6.12.

# Neos 0.6.12 — Contacts éditables et Mail non lus

- Contacts : création d'une fiche vCard 3.0 via `PUT` CardDAV avec `If-None-Match: *`, choix du carnet, vérification immédiate par GET.
- Contacts : édition directe dans le thème Flat Cyber. Lecture de la version courante, `If-Match` ETag obligatoire, prévention des conflits, relecture après sauvegarde.
- Mise à jour ciblée des champs FN, N (en cas de changement du nom), EMAIL, TEL, ORG ; conservation des autres propriétés et adresses secondaires dans la vCard existante.
- Liste Contacts : conservation des URL individuelles et du carnet d'origine ; aucune écriture hors de l'espace CardDAV de l'utilisateur authentifié.
- Mail : filtre « Tous / Non lus » sur les messages déjà récupérés ; la lecture détaillée et l'envoi restent dans Mail natif, sans stockage de secrets.
- Design Flat Cyber, Topbar personnalisable, Talk, Activité, Planning, Deck et Tâches inchangés ; nouvelles captures ordinateur/mobile et guide OMV.
- Simulations navigateur : créations, modifications et refus des conflits ETag. Non validé sur une instance NAS réelle.

# Neos 0.6.11

- Talk : lecture de l’historique, envoi de messages texte et pagination dans l’espace Neos.
- Activité : récupération réelle des pages suivantes via l’API OCS Activity.
- Contacts : affichage de la fiche contact (nom, courriel, téléphone, organisation, carnet) depuis CardDAV.
- Préservation de la personnalisation Flat Cyber et des fonctionnalités précédentes.

# Neos v0.6.10 — Personnalisation des onglets et Planning

- **Planning :** icône fournie par l’utilisateur, recadrée et exportée pour le hub des applications avec transparence.
- **Topbar :** déplacement des onglets par glisser-déposer lorsque la personnalisation est active ; commandes Monter/Descendre dans les réglages, utilisables au clavier et sur mobile.
- **Sauvegarde :** nouvel attribut `tabOrder` dans les préférences individuelles Nextcloud (validation par liste blanche côté serveur, ajout des futurs onglets absents, réinitialisation possible).
- **Activité :** filtres Toutes / Fichiers / Deck / Talk / Autres et affichage progressif des 50 activités récupérées. Ce n’est pas encore une pagination côté serveur.
- Les espaces Talk, Activité, Contacts, Mail de v0.6.9 sont conservés ; leurs fonctions avancées restent ciblées pour v0.7.
- Design Flat Cyber conservé.

## 0.6.8 — Marquage Deck natif et Planning ciblé
- Cartes Deck virtuelles : utiliser les routes natives `PUT /apps/deck/cards/{cardId}/done` et `/undone` documentées dans le routeur Deck, au lieu de l’API de mise à jour complète qui renvoyait HTTP 400.
- Vérification de l'identité de carte avant mutation et de son état après ; prise en compte du déplacement automatique dans une colonne de fin. Pas d'écriture CalDAV pour les cartes Deck.
- Diagnostic Deck : messages JSON d’erreur courts et contrôlés ; pas d’exposition des cookies.
- Planning : recherche locale par texte (accents ignorés), filtre « En retard », remise à zéro des filtres ; compatible desktop/mobile et design Flat Cyber conservé.
- Tests simulés uniquement ; opération réelle Deck à confirmer sur le NAS.

## 0.6.7 — Tâches Deck et Planning sans échéance
- Correctif du PUT 404 : les calendriers virtuels `app-generated--deck--board-*` exposent des VTODO en lecture seule ; Neos n’envoie plus jamais de PUT CalDAV sur ces objets.
- Identification sécurisée du tableau et de la carte via la ressource `card-<id>.ics`. Les cartes Deck sont distinguées des tâches CalDAV et modifiées via l’API Deck.
- Mise à jour `done` sur Deck en relisant d’abord la carte et en conservant ses champs complets ; vérification par GET après écriture. Si l’API Deck est indisponible, l’erreur reste explicite ; aucune écriture CalDAV de secours.
- Respect du caractère lecture seule des autres listes CalDAV lors de l’édition.
- Planning : cartes Deck sans échéance, marquage terminé directement depuis la liste, compteurs unifiés et suppression des doublons Deck issus de CalDAV virtuel.
- Mise à jour du Planning après modification ou déplacement de cartes dans Deck. Design Flat Cyber, modules précédents et protections Nextcloud conservés.
- Tests unitaires Deck API simulée et tests Chromium desktop/mobile sur l’aperçu fictif ; validation NAS Nextcloud 35 à effectuer.

## 0.6.6 — Fiabilité CalDAV & Planning enrichi
- Modification des tâches : GET vérifié, puis repli via REPORT `calendar-multiget` (RFC 4791) si l’objet reçu est illisible, si le GET échoue ou si l’ETag est absent.
- Un PUT ne peut être envoyé qu’après validation de l’UID et d’un ETag fourni par le serveur ; If-Match obligatoire, vérification après écriture et des champs supprimés.
- Recherche par UID uniquement lorsque la ressource paraît absente, avec refus de toute correspondance ambiguë ; messages d’erreur GET / REPORT / PUT détaillés.
- Tâches datées sans fuseau (DUE;VALUE=DATE) : le jour est conservé pour l’édition et le Planning.
- Planning : indicateurs tâches à faire/en retard/sans échéance, liste indépendante de 30 tâches sans date, édition et validation rapides ; aucune suppression du Planning ni des vues Agenda de v0.6.4.
- Design Flat Cyber, route d’app `novadashboard`, contrôles de sécurité Nextcloud et fonctionnalités existantes conservés.
- Correctif serveur CalDAV non garanti tant que les requêtes réelles du NAS n’ont pas été testées.

## 0.6.5
- Planning intégré regroupant échéances Agenda, tâches VTODO et cartes Deck.
- Vérification du chemin, UID et ETag avant chaque modification de tâche; contrôle après PUT et diagnostics précis du HTTP 404.
- Pas de changement des montages Docker ou des données utilisateur.

## 0.6.4 — Agenda mois/semaine et correctif Tâches

- Agenda : vues mensuelle et hebdomadaire, navigation par période, sélection de date et détails événementiels.
- Recherche CalDAV recalée sur la période consultée, et rechargement si nécessaire.
- Tâches : ne plus afficher de lien vers l’application native non installée, évitant une cause possible de 404.
- Diagnostics VTODO explicites (aucune liste, erreur 404 ou permission) sans bloquer Agenda.
- Filtres de tâches À faire / Terminées / Toutes.
- Aucune modification de la configuration de sécurité Nextcloud ou du design général.

## 0.6.3

- Agenda CalDAV : découverte des calendriers accessibles, événements des 60 prochains jours, création avec date, durée, lieu et description.
- Tâches CalDAV : liste, création, édition titre/description/échéance, marquage terminé et réouverture.
- Requêtes CalDAV avec session Nextcloud, If-None-Match pour les créations et If-Match/ETag pour les modifications.
- Design Flat Cyber inchangé et modules mobiles.
- Aucun changement de données ni migration de base de données.

## 0.6.2 — 11 novembre 2026

- Deck : dialogue de création avec description Markdown et échéance.
- Deck : édition de la colonne, de l’échéance et de l’état terminé.
- Deck : glisser-déposer entre les colonnes, avec vérification de la position après écriture pour éviter les faux succès de certaines versions de Deck.
- Conservation du correctif PDF et favoris WebDAV de v0.6.1.1.
- Compatibilité Nextcloud 35 et identifiant `novadashboard` conservés.

## 0.6.1

- Aperçu PDF : liens de repli vers le PDF authentifié et l’app Fichiers lorsqu’un navigateur refuse l’iframe. Pas de modification de la politique de sécurité.

- Lecteurs multimédias audio/vidéo intégrés à l’explorateur, sous réserve des codecs navigateur.
- Aperçu Markdown sûr (texte brut / rendu), sans HTML exécutable.
- Recherche : actions rapides aperçu, ouvrir le dossier, favoris.
- Notes : aperçu Markdown, compteur de mots, Ctrl+S.
- Deck : affichage et édition du titre/de la description des cartes via API Deck, en préservant les autres champs.
- Sans changement des données, de la base ni du chemin `/data`.

## v0.6.0 — Recherche filtrée, favoris Nextcloud et fichiers consultés (2026-11-10)

- Recherche globale : filtres par catégorie (documents, images, audio, vidéo, dossiers), date de modification et tranches de taille, tri par nom, taille ou date. Les restrictions de visite et de permissions sont conservées.
- Favoris natifs Nextcloud : étoiler/désétoiler fichiers et dossiers avec PROPPATCH WebDAV ; liste des favoris du compte avec REPORT WebDAV. Distinct des raccourcis de dossiers de l’accueil.
- Fichiers récemment consultés dans Neos : liste de 24 chemins par compte, enregistrée uniquement dans le navigateur local (sans contenu de fichiers). Les entrées disparues ne sont pas réouvertes sans recontrôle Nextcloud.
- Palette Ctrl+K à trois vues : Recherche / Favoris / Consultés ; accès rapide depuis Fichiers.
- Style Flat Cyber v0.5.9 préservé ; pas de changement de configuration serveur ni de migrations SQL.

## 0.5.9 — Volume et recherche multi-dossiers
- Affichage admin uniquement de la capacité du système de fichiers contenant le répertoire de données Nextcloud, séparée du quota utilisateur.
- Recherche de fichiers et dossiers par nom dans plusieurs dossiers, authentifiée et limitée à 2 500 entrées et 6 niveaux.
- Palette de recherche avec raccourci Ctrl+K, résultats cliquables et indication des résultats partiels.
- Conservation des fonctionnalités et animations de la v0.5.8.

## 0.5.8 — File Manager Productivity + Animated Header

- Sélecteur de destination pour copier ou déplacer les éléments sélectionnés sans ouvrir manuellement le dossier cible ; navigation par dossiers, fil d’Ariane et filtre local.
- Actions contextuelles « Copier vers… » et « Déplacer vers… » reliées au sélecteur.
- Téléversements avec progression réelle en octets via XMLHttpRequest, affichage d’état et annulation de la requête active.
- Conservation des protections WebDAV (`Overwrite: F`, `If-None-Match: *`) et des droits Nextcloud ; aucun écrasement automatique.
- Animations de la bannière : arcs orbitaux, traces diagonales et indicateur lumineux, réglables par les préférences de mouvement.
- Identité Flat Cyber, widgets et explorateur de la v0.5.7 préservés.

## 0.5.7 — File Manager Pro

- Sélection multiple par cases à cocher, Maj+clic et Ctrl/Cmd+clic.
- Commandes de sélection globale et raccourcis Ctrl/Cmd+A, C, X, V, Suppr dans l’onglet Fichiers.
- Presse-papiers interne Neos pour copier et déplacer entre dossiers, sans navigation hors du dashboard.
- Duplication avec suffixes « copie », « copie 2 »… en cas de conflit.
- Glisser-déposer d’éléments dans les dossiers (déplacer ; Ctrl/Cmd pour copier) et de fichiers du PC pour téléverser.
- Actions groupées : copier, déplacer, dupliquer, supprimer avec confirmation.
- WebDAV MOVE/COPY sans écrasement (`Overwrite: F`) et téléversement conditionnel (`If-None-Match: *`).
- Conservation de l’identité Flat Cyber, des fonds et des widgets holographiques de la v0.5.6.

## 0.5.6 — Widget motion / uniform design

- Horloge holographique à aiguilles synchronisées à l’heure locale.
- Visualisation de stockage animée, avec quota illimité clairement indiqué.
- Suppression des traits animés placés en haut des widgets.
- Uniformisation visuelle des modules Notes, Deck, Photos, Agenda, Tâches et Fichiers.
- Icône Accueil du hub chargée via un nouveau nom de fichier pour éviter les anciens caches.
- Animations décoratives intégrées au contenu, désactivables via les préférences de mouvement.

## 0.5.5 — Sliding Tabs / Layout Sandbox
- Nouvelle icône Accueil fournie par l’utilisateur, recadrée et optimisée en PNG transparent pour le hub.
- Retour aux pictogrammes SVG plats en topbar ; hub et topbar utilisent deux présentations distinctes.
- Véritable curseur d’onglet actif mobile : capsule glissante avec largeur animée et déplacement selon les positions réelles.
- Grille de placement 12 colonnes visible en mode réorganisation et zones de dépôt plus lisibles.
- Microanimations locales : signal de widget, jauge de stockage, icône horloge et listes Deck.
- Réduction des animations : préférences de mouvement et `prefers-reduced-motion` respectées.
- Aucune modification des routes d’API ou du stockage Nextcloud.

## 0.5.4 — Compact Workspace
- Widget Deck présent sur l’accueil et lié aux tableaux Nextcloud.
- Grille dense avec rangées de hauteur calculée pour réduire les vides entre widgets.
- Hauteur minimale réglable en mode Libre, sauvegardée par utilisateur.
- Nouvelles icônes Accueil fournies pour le hub et la navigation.
- Icônes topbar harmonisées avec le hub, transitions et ambiance améliorées.

## 0.5.3 — Notes & PDF / PNG256 hub
- Privilégie les 10 images PNG 256 du kit pour le hub des applications, sans encarts.
- Aperçu PDF via une route Nextcloud authentifiée en `Content-Disposition: inline` : sélection ≠ téléchargement.
- Une demande de téléchargement reste explicite via l'icône Télécharger.
- Module Notes : utilise l'API Notes si disponible, et sinon les notes Markdown/TXT du dossier Notes de l'utilisateur via le stockage Nextcloud.
- Contrôle de taille, permissions et ETag sur les modifications des notes en mode fichiers.
- Compatibilité conservée avec Nextcloud 35 et l'ID d'application `novadashboard`.

# Neos — Changelog

## 0.5.2 — Disposition adaptative

- Accueil à grille de 12 colonnes avec mode automatique et mode libre.
- Redimensionnement par widget (3, 4, 6, 8, 9, 12 colonnes) avec sauvegarde.
- Réorganisation interactive avec poignée, zone cible et contrôles au clavier.
- Maintien des préférences d’affichage des versions antérieures.
- API Deck : routes REST documentées et repli OCS en cas de 404 ; diagnostic d’app absente.
- Réintégration des assets SVG du NEOS UI Kit fourni, et monogramme de navigation.

## 0.5.1 — Accueil et Fichiers

- Séparation Accueil/Fichiers, onglets, Deck/Notes visibles, animations de transition, défilement vertical.

## v0.6.9 — 11 novembre 2026

- Intégration initiale native, en consultation, des espaces **Talk** (API OCS v4), **Activité** (OCS v2), **Contacts** (CardDAV) et **Mail** (API de l'application Mail).
- Listes récentes et recherche locale, accès direct au contenu dans les applications Nextcloud, gestion des fonctionnalités indisponibles sans interrompre Neos.
- Lecture seule intentionnelle : aucun mot de passe stocké par Neos, aucun envoi de mail, aucune édition CardDAV et aucun message Talk émis par cette version.
- Tâches : une modification confirmée actualise immédiatement la vue À faire/Terminées sans recharger l'accueil ; synchronisation CalDAV en arrière-plan.
- Identité graphique Flat Cyber préservée ; affichage responsive et captures de démonstration pour les quatre espaces.
- Les routes internes de Nextcloud Mail peuvent différer selon la version installée. Leur bon fonctionnement reste à valider sur l'instance réelle.
