# Neos v0.5.1 — Mise à jour sur OMV / Nextcloud 35

**Type d'installation :** remplacement du code de l'application existante `novadashboard` dans le conteneur LinuxServer.io `nextcloud`. Ne créez pas de conteneur et ne modifiez pas les volumes de données. Le thème et les réglages précédents restent associés à chaque utilisateur.

## Télécharger / envoyer le ZIP

Depuis **Windows PowerShell**, en adaptant le chemin de téléchargement :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.5.1.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## Contrôle obligatoire

```bash
sudo docker exec nextcloud occ status
```

Ne poursuivez **que si** la version de Nextcloud est toujours 35.x, si `maintenance: false` et `needsDbUpgrade: false`, et si aucune mise à jour n'est en cours.

## Sauvegarder l'ancienne application

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v051.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud sh -c 'test -s /config/novadashboard-backup-avant-v051.tar.gz && echo "Sauvegarde OK"'
```

Il s'agit uniquement d'une sauvegarde du **code de Neos**. Elle ne remplace pas une sauvegarde globale de Nextcloud (données, base de données, configuration).

## Décompresser / installer

```bash
mkdir -p /tmp/neos-v051
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.1.zip /tmp/neos-v051
ls -l /tmp/neos-v051/novadashboard/appinfo/info.xml

sudo docker cp /tmp/neos-v051/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Enfin, dans le navigateur : **Ctrl + F5**.

Ne lancez pas `occ upgrade` automatiquement. Si Nextcloud signale une mise à niveau ou le mode maintenance, examinez l'état et les journaux avant d'effectuer une autre commande.

## Contrôles fonctionnels

1. **Accueil** : widgets visibles, scrollbar verticale et widget Fichiers compact.
2. **Fichiers** : explorateur complet, navigation, recherche, aperçu et actions rapides.
3. **Transitions** : effet slide/fade à chaque changement d'onglet ; désactivable dans Personnaliser → Animations.
4. **Deck / Notes** : onglets visibles même si l'application est absente ; les modules n'utilisent les API réelles que si elles répondent.
5. **Applications** : icônes directes, sans tuiles encadrantes ; clic sur un module intégré sans rechargement.
6. **Mobile** : les onglets restent accessibles horizontalement et la page défile vers le bas.

Les modules Notes et Deck utilisent les API de ces applications : leur disponibilité dépend de leur activation et des autorisations Nextcloud. Les photos intégrées restent une galerie de fichiers accessibles, non une reproduction complète des albums Photos.

## Retour à la version précédente

Vérifiez d'abord que la sauvegarde est présente :

```bash
sudo docker exec nextcloud sh -c 'test -s /config/novadashboard-backup-avant-v051.tar.gz && echo "Sauvegarde présente"'
```

Restaurez **uniquement l'application** :

```bash
sudo docker exec nextcloud sh -c 'rm -rf /config/www/nextcloud/apps/novadashboard && tar -xzf /config/novadashboard-backup-avant-v051.tar.gz -C /config/www/nextcloud/apps/'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Rechargez avec **Ctrl + F5**.

## Contenu de l'archive

- `novadashboard/` : code installable dans Nextcloud.
- `APERCU-Neos-v0.5.1.html` : aperçu autonome avec données **fictives**, sans lien avec les fichiers de votre NAS.
- `INSTALLATION-OMV.md` : ce guide.
