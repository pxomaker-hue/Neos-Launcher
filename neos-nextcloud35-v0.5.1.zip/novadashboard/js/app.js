/** Neos 0.5.1 — separated Home / Files, slide transitions, native animations, no CDN. */
(() => {
  'use strict';
  const root = document.getElementById('nova-root');
  if (!root) return;
  root.innerHTML = '<div id="neos-surface"></div><div id="neos-editor-host"></div><div id="neos-pop-host"></div><div id="neos-toast-host" aria-live="polite"></div>';
  const surface = root.querySelector('#neos-surface');
  const editorHost = root.querySelector('#neos-editor-host');
  const popHost = root.querySelector('#neos-pop-host');
  const toastHost = root.querySelector('#neos-toast-host');
  const ambientHost = document.createElement('div');
  ambientHost.className = 'neos-ambient';
  ambientHost.setAttribute('aria-hidden', 'true');
  root.insertBefore(ambientHost, surface);
  ambientHost.innerHTML = `<div class="neos-ambient-mesh"></div><div class="neos-ambient-grid"></div><div class="neos-ambient-beam"></div><div class="neos-ambient-aurora"></div><div class="neos-ambient-noise"></div>
  <svg class="neos-ambient-orbits" viewBox="0 0 1440 800" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="neos-v045-orbit"><stop stop-color="#36d5fb" stop-opacity="0"/><stop offset=".48" stop-color="#42b7ff" stop-opacity=".14"/><stop offset="1" stop-color="#9084ff" stop-opacity="0"/></linearGradient></defs><g fill="none" stroke="url(#neos-v045-orbit)" stroke-width=".85"><ellipse cx="1075" cy="265" rx="440" ry="200" transform="rotate(-17 1075 265)"/><ellipse cx="1075" cy="265" rx="575" ry="280" transform="rotate(-17 1075 265)"/><ellipse cx="1075" cy="265" rx="710" ry="360" transform="rotate(-17 1075 265)"/></g></svg>`;


  // Low-cost, local data-field animation. It is visual only, never reads files or user data.
  const dataCanvas = document.createElement('canvas');
  dataCanvas.className = 'neos-datafield';
  dataCanvas.setAttribute('aria-hidden', 'true');
  ambientHost.appendChild(dataCanvas);
  function launchDatafield(){
    const ctx=dataCanvas.getContext('2d',{alpha:true}); if(!ctx)return;
    let width=0,height=0,dpr=1,last=0,frame=0;
    const pointer={x:.5,y:.48,targetX:.5,targetY:.48};
    const resize=()=>{
      width=Math.max(320,root.clientWidth||window.innerWidth);
      height=Math.max(400,root.clientHeight||window.innerHeight);
      dpr=Math.min(1.5,window.devicePixelRatio||1);
      dataCanvas.width=Math.round(width*dpr);dataCanvas.height=Math.round(height*dpr);
      ctx.setTransform(dpr,0,0,dpr,0,0);
    };
    const draw=now=>{
      ctx.clearRect(0,0,width,height);
      const t=now*.00015, mobile=width<760, rows=mobile?7:11;
      pointer.x+=(pointer.targetX-pointer.x)*.045;
      pointer.y+=(pointer.targetY-pointer.y)*.045;
      const horizon=height*(.52+(.5-pointer.y)*.055);
      for(let j=0;j<rows;j++){
        const base=horizon+j*(mobile?22:26), amp=(mobile?11:18)*(1+j*.025);
        const g=ctx.createLinearGradient(0,base,width,base);
        g.addColorStop(0,'rgba(42,156,240,0)');
        g.addColorStop(.25,'rgba(55,155,240,.06)');
        g.addColorStop(.58,j%4===0?'rgba(144,113,249,.115)':'rgba(49,203,250,.115)');
        g.addColorStop(1,'rgba(45,164,255,0)');
        ctx.strokeStyle=g;ctx.lineWidth=.65;ctx.beginPath();
        for(let i=0;i<=56;i++){
          const x=width*i/56;
          const y=base + amp*Math.sin(i*.23+t*4+j*.18+pointer.x*.8) + amp*.32*Math.cos(i*.37-t*3+j*.45);
          i?ctx.lineTo(x,y):ctx.moveTo(x,y);
        }
        ctx.stroke();
      }
      const count=mobile?24:54;
      for(let i=0;i<count;i++){
        const fx=((i*137.508+9)%997)/997, fy=((i*91.17+16)%991)/991;
        const x=width*(fx+.01*Math.sin(t*3+i)),y=height*(fy*.79+.12+.01*Math.cos(t*4+i*.31));
        const a=.07+.16*(Math.sin(t*3+i*.7)+1)/2;
        ctx.fillStyle=i%9===0?`rgba(170,144,255,${a})`:`rgba(99,203,250,${a})`;
        ctx.beginPath();ctx.arc(x,y,i%7===0?1.25:.65,0,Math.PI*2);ctx.fill();
      }
      if(!mobile){
        const gx=pointer.x*width,gy=pointer.y*height;
        const halo=ctx.createRadialGradient(gx,gy,0,gx,gy,260);
        halo.addColorStop(0,'rgba(73,157,255,.038)');halo.addColorStop(1,'rgba(73,157,255,0)');
        ctx.fillStyle=halo;ctx.fillRect(gx-260,gy-260,520,520);
      }
    };
    const tick=now=>{
      frame=requestAnimationFrame(tick);
      if(!document.hidden&&motionEnabled()&&now-last>48){last=now;draw(now);}
    };
    root.addEventListener('pointermove',e=>{
      if(e.pointerType!=='mouse')return;
      const r=root.getBoundingClientRect();
      pointer.targetX=Math.max(0,Math.min(1,(e.clientX-r.left)/Math.max(1,r.width)));
      pointer.targetY=Math.max(0,Math.min(1,(e.clientY-r.top)/Math.max(1,r.height)));
    },{passive:true});
    root.addEventListener('pointerleave',()=>{pointer.targetX=.5;pointer.targetY=.48;},{passive:true});
    resize();draw(0);frame=requestAnimationFrame(tick);
    window.addEventListener('resize',resize,{passive:true});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden){resize();last=0;}});
  }

  const demo = window.NOVA_DEMO_DATA && root.dataset.demo === 'true' ? window.NOVA_DEMO_DATA : null;
  const csrfToken = () => document.head?.getAttribute('data-requesttoken') || window.OC?.requestToken || '';

  const icons = {
    sparkles:'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 17 .8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    folder:'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/>',
    check:'<rect x="3" y="4" width="18" height="17" rx="3"/><path d="m8 12 3 3 5-6"/>',
    storage:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 12h18m-5 4h2"/><circle cx="7" cy="16" r="1"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-6-6L4 21"/>',
    message:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
    settings:'<path d="M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/><circle cx="12" cy="12" r="4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.8 9A7.5 7.5 0 0 1 19 6l1 1M4 17l1 1a7.5 7.5 0 0 0 13.2-3"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    close:'<path d="M5 5l14 14M19 5 5 19"/>',
    grip:'<circle cx="9" cy="5" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="19" r="1"/>',
    file:'<path d="M6 2h9l5 5v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z"/><path d="M14 2v6h6"/>',
    external:'<path d="M14 4h6v6m-9 3 9-9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
    alert:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3v.1"/>',
    cloud:'<path d="M5 18a4 4 0 0 1-.4-8 7 7 0 0 1 13-1 4.5 4.5 0 0 1 1 9H5Z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7 .2l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7-.2l-3 3a5 5 0 1 0 7.1 7.1l1.7-1.7"/>',
    note:'<path d="M4 3h16v18H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    chart:'<path d="M3 20h18M6 17v-4m6 4V6m6 11v-8"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
    star:'<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.3-5.7-3-5.7 3 1.1-6.3L2.8 9.7l6.4-.9L12 3Z"/>',
    list:'<path d="M9 5h12M9 12h12M9 19h12"/><path d="M3 5h.1M3 12h.1M3 19h.1"/>',
    sort:'<path d="M7 4v16m0 0-4-4m4 4 4-4M17 20V4m0 0-4 4m4-4 4 4"/>',
    arrow:'<path d="M4 12h16m-7-7 7 7-7 7"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
    bolt:'<path d="m13 2-9 12h7l-1 8 10-12h-7l0-8Z"/>',
    home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
    users:'<path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="4"/><path d="M17 11a4 4 0 1 0 0-8m4 18v-2a4 4 0 0 0-3-3.87"/>',
    mail:'<path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><path d="m22 7-10 7L2 7"/>',
    kanban:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16m6-16v9"/>',
    map:'<path d="M9 18 3 20V6l6-2 6 2 6-2v14l-6 2-6-2Z"/><path d="M9 4v14m6-12v14"/>',
    news:'<path d="M4 5h13a2 2 0 0 1 2 2v10H6a2 2 0 0 1-2-2V5Z"/><path d="M19 9h1a2 2 0 0 1 2 2v6H8"/><path d="M8 9h7M8 13h5"/>',
    sheet:'<path d="M4 4h16v16H4z"/><path d="M4 9h16M9 4v16m5-16v16"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    open:'<path d="M7 17 17 7"/><path d="M8 7h9v9"/>',
    back:'<path d="m15 18-6-6 6-6"/>',
    forward:'<path d="m9 18 6-6-6-6"/>',
    more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    download:'<path d="M12 3v12m0 0 5-5m-5 5-5-5M4 17v3h16v-3"/>',
    copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
    upload:'<path d="M12 17V4m0 0 5 5m-5-5-5 5M4 17v3h16v-3"/>',
    filter:'<path d="M4 6h16M7 12h10M10 18h4"/>',
    edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/>',
  };
  const icon = (name, size=18) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name] || icons.file}</svg>`;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeUrl = s => typeof s === 'string' && ((/^\/(?!\/)/.test(s) && !s.includes('\\')) || /^https?:\/\//i.test(s) || (root.dataset.demo === 'true' && /^\.\/novadashboard\/img\/(?:[\w.%-]+\/)*[\w.%-]+$/.test(s))) ? esc(s) : '#';
  const safeColor = s => /^#[0-9a-f]{6}$/i.test(String(s)) ? s : '#7f8dff';
  const number = n => Number.isFinite(Number(n)) ? Number(n) : 0;
  const humanSize = b => { if (b == null) return '—'; const n = Math.max(0, number(b)); const p = n ? Math.min(4, Math.floor(Math.log(n)/Math.log(1024))) : 0; return new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(n/Math.pow(1024,p)) + ' ' + ['o','Ko','Mo','Go','To'][p]; };
  const ago = ts => { const d = Math.max(0, Math.round((Date.now()-number(ts)*1000)/86400000)); return d===0?'Aujourd’hui':d===1?'Hier':`Il y a ${d} j`; };
  const fmtTime = iso => { if (!iso) return 'Sans échéance'; const d = new Date(iso); return Number.isNaN(+d) ? 'Date inconnue' : new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(d); };
  const ext = name => String(name || '').split('.').pop().toLowerCase();
  const isImage = e => String(e?.mime || '').startsWith('image/');
  const isPdf = e => String(e?.mime || '') === 'application/pdf' || ext(e?.name) === 'pdf';
  const isCsv = e => ['csv','tsv'].includes(ext(e?.name));
  const isText = e => String(e?.mime || '').startsWith('text/') || ['txt','md','markdown','json','log','ini','yaml','yml','xml','html','css','js','ts','php','sql','csv','tsv'].includes(ext(e?.name));
  const isOffice = e => ['xlsx','xls','ods','docx','doc','odt','pptx','ppt','odp'].includes(ext(e?.name));

  const widgetLabels = {
    explorer:'Fichiers', storage:'Stockage', shortcuts:'Hub apps', clock:'Horloge', files:'Récents',
    calendar:'Agenda', tasks:'Tâches', summary:'Synthèse', links:'Liens', notes:'Notes'
  };
  const widgetIcons = { explorer:'folder', storage:'storage', shortcuts:'grid', clock:'clock', files:'file', calendar:'calendar', tasks:'check', summary:'chart', links:'link', notes:'note' };
  const widgetIds = Object.keys(widgetLabels);
  const defaultSizes = { explorer:12, storage:3, shortcuts:6, clock:3, files:6, calendar:6, tasks:6, summary:6, links:6, notes:6 };
  const defaults = () => ({ theme:'dark', density:'comfortable', accent:'cyan', layout:'wide', motion:'full', launcherMode:'topbar', order:[...widgetIds], hidden:['links','notes'], sizes:{...defaultSizes}, links:[], notes:'', pins:[], topApps:['files','calendar','tasks','talk'] });

  let overview = null;
  let settings = null;
  let editing = false;
  let editorOpen = false;
  let saving = false;
  let saveQueued = false;
  let popMode = '';
  let browseGeneration = 0;
  let previewGeneration = 0;
  let hasEntered = false;
  let clockTimer = null;
  const browser = { path:'/', davUrl:'', items:[], total:0, truncated:false, limit:160, filesUrl:'#', loading:true, error:'', query:'', sort:'name', type:'all', view:'list' };
  const preview = { entry:null, status:'empty', mode:'empty', text:'', rows:[], error:'', title:'' };
  // Topbar navigation changes only this workspace, without a Nextcloud page load.
  let activeWorkspace = 'home';
  let transitionSequence = 0;
  const workspaceScroll = new Map();
  let moduleGeneration = 0;
  const photoState={status:'idle',items:[],partial:false,error:'',selected:-1};
  const notesState={status:'idle',items:[],selected:null, draftTitle:'',draftContent:'',dirty:false,error:''};
  const deckState={status:'idle',boards:[],boardId:null,stacks:[],error:''};
  const builtInApps=new Set(['files','photos','calendar','tasks','deck','notes']);

  const history = ['/']; let historyIndex=0; let contextPath=''; let fullPreview=false; let previewBlobUrl=''; let previewError=false;

  const motionEnabled = () => settings && settings.motion !== 'off' && !(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  const motionFactor = () => settings?.motion === 'subtle' ? .7 : 1;

  function toast(message, type='info') {
    const node = document.createElement('div');
    node.className = `neos-toast neos-toast-${type}`;
    node.setAttribute('role','status');
    node.textContent = message;
    toastHost.replaceChildren(node);
    setTimeout(() => node.remove(), 3200);
  }

  async function api(url, options={}) {
    if (demo) throw new Error('Démo');
    const token = csrfToken();
    if (!token) throw new Error('Jeton CSRF manquant');
    const response = await fetch(url, {
      credentials:'same-origin', cache:'no-store', ...options,
      headers:{ Accept:'application/json', requesttoken:token, 'X-Requested-With':'XMLHttpRequest', ...(options.headers || {}) }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  function applyTheme() {
    const pref = settings?.theme || 'system';
    const light = pref === 'light' || (pref === 'system' && window.matchMedia?.('(prefers-color-scheme: light)').matches);
    root.classList.toggle('neos-light', !!light);
    root.classList.toggle('neos-dark', !light);
    root.dataset.accent = settings?.accent || 'indigo';
    root.dataset.density = settings?.density || 'comfortable';
    root.dataset.layout = settings?.layout || 'wide';
    root.dataset.motion = settings?.motion || 'full';
    root.dataset.launcherMode = settings?.launcherMode || 'topbar';
  }

  // Timing, staging and stagger concepts adapted from Anime.js v4 documentation.
  // Uses the native Web Animations API to avoid remote scripts and CSP changes.
  function animateIn(nodes, delay=40, base=0) {
    if (!motionEnabled()) return;
    [...nodes].slice(0,28).forEach((el, i) => {
      if (!el?.animate) return;
      const duration = Math.round(560*motionFactor());
      el.animate([
        { opacity:0, transform:'translate3d(0,22px,0) scale(.982)', filter:'blur(3px)' },
        { opacity:1, transform:'translate3d(0,0,0) scale(1)', filter:'blur(0)' }
      ], { duration, delay:base + i*delay*motionFactor(), easing:'cubic-bezier(.16,1,.3,1)', fill:'backwards' });
    });
  }
  function animatePreview() {
    if (!motionEnabled()) return;
    const content=surface.querySelector('.neos-preview-body');
    content?.animate?.([
      {opacity:.1,transform:'translate3d(10px,0,0)'},
      {opacity:1,transform:'translate3d(0,0,0)'}
    ],{duration:340*motionFactor(),easing:'cubic-bezier(.16,1,.3,1)'});
  }
  function animateRows() {
    animateIn(surface.querySelectorAll('.neos-file-row'),19,0);
  }

  function pulse(el) {
    if (!motionEnabled() || !el?.animate) return;
    el.animate([{transform:'scale(.985)'},{transform:'scale(1.02)'},{transform:'scale(1)'}], { duration:380*motionFactor(), easing:'cubic-bezier(.17,.89,.32,1.27)' });
  }
  function animateLayerOpen(host, panelSelector, axis='x') {
    if (!motionEnabled()) return;
    const overlay = host.firstElementChild; const panel = host.querySelector(panelSelector); const shift = axis === 'y' ? '0,18px,0' : '24px,0,0';
    overlay?.animate?.([{opacity:0},{opacity:1}],{duration:220*motionFactor(),easing:'ease-out'});
    panel?.animate?.([{opacity:0,transform:`translate3d(${shift}) scale(.986)`,filter:'blur(6px)'},{opacity:1,transform:'translate3d(0,0,0) scale(1)',filter:'blur(0)'}],{duration:420*motionFactor(),easing:'cubic-bezier(.16,1,.3,1)'});
  }
  function animateLayerClose(host, panelSelector, done, axis='x') {
    const overlay = host.firstElementChild; const panel = host.querySelector(panelSelector); if (!motionEnabled() || !overlay) { done(); return; }
    const shift = axis === 'y' ? '0,18px,0' : '20px,0,0';
    overlay.animate([{opacity:1},{opacity:0}],{duration:180*motionFactor(),easing:'ease-in'});
    panel?.animate?.([{opacity:1,transform:'translate3d(0,0,0) scale(1)',filter:'blur(0)'},{opacity:0,transform:`translate3d(${shift}) scale(.99)`,filter:'blur(5px)'}],{duration:180*motionFactor(),easing:'cubic-bezier(.4,0,1,1)'});
    setTimeout(done, Math.round(195*motionFactor()));
  }

  function box(id, body, sub='', tools='') {
    const size = [3,4,6,8,12].includes(Number(settings.sizes?.[id])) ? Number(settings.sizes[id]) : 6;
    return `<section class="neos-card neos-${id}" data-widget="${id}" data-size="${size}" draggable="${editing}">
      <header class="neos-card-head"><div class="neos-card-name">${icon(widgetIcons[id],18)}<span>${esc(widgetLabels[id])}</span></div><div class="neos-card-actions">${tools}<span class="neos-card-sub">${editing ? icon('grip',15) : sub}</span></div></header>
      <div class="neos-card-body">${body}</div>
    </section>`;
  }

  function filesHomeUrl(){ return browser.filesUrl && browser.filesUrl !== '#' ? browser.filesUrl : ((overview?.shortcuts || []).find(x => x.id === 'files')?.url || '/index.php/apps/files/'); }

  function breadcrumb() {
    const names = browser.path.split('/').filter(Boolean);
    const crumbs = [`<button type="button" class="neos-crumb ${names.length ? '' : 'active'}" data-action="browse-path" data-path="/">${icon('home',14)}</button>`];
    let path = '';
    names.forEach((part, idx) => { path += '/' + part; crumbs.push(`${icon('chevron',12)}<button type="button" class="neos-crumb ${idx===names.length-1?'active':''}" data-action="browse-path" data-path="${esc(path)}">${esc(part)}</button>`); });
    return crumbs.join('');
  }

  function appColor(id){return ({files:'#FFBC4B',photos:'#2CC9FC',calendar:'#B480FF',tasks:'#36D6AD',talk:'#F77BAE',contacts:'#58BAFF',mail:'#628FFF',activity:'#FFB14D',deck:'#22CDD7',notes:'#B78AFF',bookmarks:'#FFCF59',news:'#7abfff',maps:'#36d6ad',tables:'#59BAFF',office:'#B480FF'})[id]||'#95a5ff';}
  const appAsset=name=>(demo?'./novadashboard/img/':String(root.dataset.assetBase||'/apps/novadashboard/img/').replace(/\/?$/,'/')) + String(name).split('/').map(encodeURIComponent).join('/');
  const kitFile=path=>appAsset('kit/'+path);
  const flatIconMap={files:'fichiers',photos:'photos',calendar:'agenda',tasks:'taches',talk:'talk',contacts:'contacts',mail:'mail',activity:'activite',deck:'deck',notes:'notes'};
  const flatIconId=id=>flatIconMap[id]||'';
  const flatIconAsset=(kind,id)=>{const mapped=flatIconId(id);return mapped?kitFile(`icons/${kind==='glyphs'?'apps':'tiles'}/${mapped}.svg`):'';};
  const glyphPaths={
    files:'<path d="M3.5 8v10.5a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2V9.5a2 2 0 0 0-2-2h-6l-2.1-2.6H5.5a2 2 0 0 0-2 2V8Z"/>',
    photos:'<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><circle cx="9" cy="9" r="1.5"/><path d="m5 18 5.5-6 3.3 3 2.1-2 3.2 5"/>',
    calendar:'<rect x="3.5" y="5.5" width="17" height="15" rx="3"/><path d="M7.8 3.5v4M16 3.5v4M3.5 10h17"/><path d="M8 14h2m4 0h2m-8 3h2"/>',
    tasks:'<rect x="4" y="4" width="16" height="16" rx="4"/><path d="m8 12 2.8 2.8 5.2-5.7"/>',
    talk:'<path d="M20 11.1a7.9 7.9 0 0 1-8.1 7.8c-1.3 0-2.7-.3-3.8-1L4 20l1.2-4.5A7.7 7.7 0 0 1 4 11.1a8 8 0 0 1 16 0Z"/><path d="M8 11.4h.1m3.9 0h.1m3.9 0h.1"/>',
    contacts:'<circle cx="9" cy="8" r="3"/><path d="M3.5 19v-1.4A5.5 5.5 0 0 1 9 12a5.5 5.5 0 0 1 5.5 5.6V19"/><path d="M16 5.5a3 3 0 0 1 0 5.8m1.2 2a5 5 0 0 1 3.3 4.8V19"/>',
    mail:'<rect x="3.5" y="5" width="17" height="14" rx="3"/><path d="m4.5 7 7.5 6 7.5-6"/>',
    activity:'<path d="M2.8 12h4.1l2.5-6.6 4.2 13.2 2.3-6.6h5.3"/>',
    deck:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.5 4v16m5-16v16M5.8 8h1.6m3.6 0h1.6m3.6 0h1.6M5.8 12h1.6"/>',
    notes:'<path d="M6 3.5h9l3 3V20.5H6a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2Z"/><path d="M14 3.5v4h4M8 12h7M8 15.5h5"/>',
    bookmarks:'<path d="M6 3.5h12v17l-6-4-6 4v-17Z"/>',
    maps:'<path d="M4 6l5-2 6 2 5-2v14l-5 2-6-2-5 2V6Zm5-2v14m6-12v14"/>',
    tables:'<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M3.5 10h17m-11-5.5v15m5-15v15"/>',
    office:'<path d="M6 3.5h8l4 4v13H6a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2Z"/><path d="M14 3.5v4h4M8 12h7m-7 3h7"/>',
    news:'<path d="M5 4.5h12v12H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z"/><path d="M17 8h2a2 2 0 0 1 2 2v7a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-2.5M7 9h7M7 12h5"/>'
  };
  const appGlyph=(id,size=23)=>`<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${glyphPaths[id]||icons.grid}</svg>`;
  function topApps(){const allowed=new Set(settings.topApps||[]);const filesInWorkspace=!(settings.hidden||[]).includes('explorer');return (overview?.shortcuts||[]).filter(a=>allowed.has(a.id)&&!(a.id==='files'&&filesInWorkspace)).slice(0,8);}
  function brandMark(){return `<img src="${safeUrl(kitFile('branding/neos-wordmark.svg'))}" alt="" loading="eager">`;}
  function appGlyphMarkup(id,label,size=19){const src=flatIconAsset('glyphs',id);return src?`<img src="${safeUrl(src)}" alt="" loading="lazy" class="neos-glyph-img" width="${size}" height="${size}">`:appGlyph(id,size);}
  function appTileMarkup(id,label){const src=flatIconAsset('tiles',id);return src?`<img src="${safeUrl(src)}" alt="" loading="lazy" class="neos-app-tile">`:`<span class="neos-app-glyph">${appGlyph(id,27)}</span>`;}
  function hubGrid(compact=false){
    const installed=availableApps();
    const builtIn=orderedApps.map(id=>({id,label:appName(id),available:installed.has(id)}));
    const extra=(overview?.shortcuts||[]).filter(a=>!orderedApps.includes(a.id));
    const list=[{id:'home',label:'Accueil',available:true},...builtIn,...extra];
    return `<div class="neos-hub-grid neos-hub-icons ${compact?'is-compact':''}">${list.map(app=>{
      const internal=installedTabs().includes(app.id);
      const src=app.id==='home'?safeUrl(kitFile('icons/ui/accueil.svg')):'';
      const picture=app.id==='home'?`<img class="neos-hub-icon" src="${src}" alt="">`:appGlyphMarkup(app.id,app.label,49);
      const action=internal?`<button type="button" class="neos-app ${app.available?'':'is-unavailable'}" data-action="workspace" data-workspace="${esc(app.id)}" title="${esc(app.label)}" aria-label="Ouvrir ${esc(app.label)} dans Neos">`:`<a class="neos-app" href="${safeUrl(app.url)}" title="${esc(app.label)}">`;
      return `${action}<span class="neos-app-visual">${picture}</span><span class="neos-app-meta"><span class="neos-app-label">${esc(app.label)}</span>${!app.available&&internal?'<small>À activer</small>':''}</span>${internal?'</button>':'</a>'}`;
    }).join('')}</div>`;
  }

  const appName=id=>({'home':'Accueil','files':'Fichiers','photos':'Photos','calendar':'Agenda','tasks':'Tâches','talk':'Talk','contacts':'Contacts','mail':'Mail','activity':'Activité','deck':'Deck','notes':'Notes'})[id]||id;
  const orderedApps=['files','photos','calendar','tasks','talk','contacts','mail','activity','deck','notes'];
  function installedTabs(){
    // Keep the navigation stable even if an app is disabled or its API is temporarily unavailable.
    // The corresponding workspace handles the unavailable state without navigating away.
    return ['home', ...orderedApps];
  }
  const availableApps=()=>new Set((overview?.shortcuts||[]).map(x=>x.id));
  function tabBar(){return `<nav class="neos-workspace-tabs" aria-label="Espaces de travail">${installedTabs().map(id=>`<button type="button" data-action="workspace" data-workspace="${id}" class="neos-workspace-tab ${activeWorkspace===id?'is-active':''}" aria-current="${activeWorkspace===id?'page':'false'}" aria-label="Onglet ${esc(appName(id))}">${id==='home'?icon('home',21):appGlyphMarkup(id,appName(id),21)}<span>${esc(appName(id))}</span></button>`).join('')}</nav>`;}
  function workspaceHero(){
    const label=activeWorkspace==='home'?'Tableau de bord':activeWorkspace==='files'?'Fichiers':appName(activeWorkspace);
    const count=activeWorkspace==='home'?'Vue d’ensemble':activeWorkspace==='files'?`${browser.total} éléments`:activeWorkspace==='photos'?`${photoState.items.length} images`:activeWorkspace==='notes'?`${notesState.items.length} notes`:activeWorkspace==='deck'?`${deckState.boards.length} tableaux`:'Nextcloud';
    return `<div class="neos-hero"><div class="neos-hero-head"><span class="neos-hero-eyebrow">NEOS <span>/</span> ${esc(activeWorkspace.toUpperCase())}</span><h1>${esc(label)}</h1></div><div class="neos-hero-meta"><span class="neos-dot"></span><span>${esc(count)}</span><span class="neos-hero-clock" data-clock>--:--</span></div></div>`;
  }
  function panelHeader(title,subtitle='',actions=''){
    return `<div class="neos-module-header"><div><span class="neos-module-eyebrow">ESPACE INTÉGRÉ</span><h2>${esc(title)}</h2>${subtitle?`<p>${esc(subtitle)}</p>`:''}</div><div class="neos-module-actions">${actions}</div></div>`;
  }
  function emptyModule(text,link='',href='#'){
    return `<div class="neos-module-empty"><span class="neos-module-empty-mark">${icon('grid',30)}</span><strong>${esc(text)}</strong>${link?`<a class="neos-btn" href="${safeUrl(href)}">${esc(link)} ${icon('external',15)}</a>`:''}</div>`;
  }
  const moduleLink=id=>(overview?.shortcuts||[]).find(app=>app.id===id)?.url || `/index.php/apps/${id}/`;
  function photoModule(){
    const body=photoState.status==='loading' ? '<div class="neos-module-loader"><span class="neos-spinner"></span>Chargement des images</div>' :
      photoState.status==='error'?emptyModule(photoState.error||'Photos indisponibles','Ouvrir Photos',moduleLink('photos')) :
      photoState.items.length?`<div class="neos-photo-grid">${photoState.items.map((photo,i)=>`<button type="button" class="neos-photo-item" data-action="photo-open" data-photo-index="${i}" title="${esc(photo.name)}"><img src="${safeUrl(photo.previewUrl||photo.davUrl)}" loading="lazy" alt=""><span>${esc(photo.name)}</span></button>`).join('')}</div>${photoState.partial?'<p class="neos-module-small">Résultats partiels — limite de scan atteinte.</p>':''}`:emptyModule('Aucune image trouvée dans les dossiers accessibles.');
    return `<section class="neos-module neos-photo-module">${panelHeader('Photos','Images de tes fichiers Nextcloud',`<button class="neos-iconbtn" data-action="module-refresh" title="Rafraîchir" aria-label="Rafraîchir">${icon('refresh',17)}</button><a class="neos-btn" href="${safeUrl(moduleLink('photos'))}">${icon('external',15)} Albums natifs</a>`)}<div class="neos-module-body">${body}</div></section>`;
  }
  function noteModule(){
    const list=notesState.items;
    const selected=list.find(n=>String(n.id)===String(notesState.selected));
    const sidebar=notesState.status==='loading'?'<div class="neos-module-loader"><span class="neos-spinner"></span></div>':notesState.status==='error'?`<div class="neos-notes-error">${esc(notesState.error)}</div>`:list.length?list.map(n=>`<button type="button" class="neos-note-row ${String(n.id)===String(notesState.selected)?'is-active':''}" data-action="note-select" data-note-id="${esc(n.id)}"><strong>${esc(n.title||'Sans titre')}</strong><span>${esc(n.category||'Notes')} · ${ago(n.modified)}</span></button>`).join(''):'<div class="neos-module-empty-small">Aucune note.</div>';
    const editor=selected?`<div class="neos-note-editor"><input data-note-title class="neos-note-title-input" maxlength="180" value="${esc(notesState.draftTitle)}" ${selected.readonly?'readonly':''} aria-label="Titre de la note"><textarea data-note-content class="neos-note-content-input" spellcheck="true" ${selected.readonly?'readonly':''} aria-label="Contenu de la note">${esc(notesState.draftContent)}</textarea><div class="neos-note-bottom"><span>${notesState.dirty?'Modifications non enregistrées':selected.readonly?'Lecture seule':'Enregistré'}</span><button class="neos-btn neos-btn-primary" type="button" data-action="note-save" ${selected.readonly?'disabled':''}>${icon('check',16)} Enregistrer</button></div></div>`:emptyModule('Sélectionne une note.');
    return `<section class="neos-module">${panelHeader('Notes','Consultation et édition dans Neos',`<button class="neos-btn neos-btn-primary" data-action="note-new">${icon('plus',16)} Nouvelle note</button><a class="neos-btn" href="${safeUrl(moduleLink('notes'))}">${icon('external',15)} Notes</a>`)}<div class="neos-module-body neos-notes-layout"><aside class="neos-notes-sidebar">${sidebar}</aside><div class="neos-notes-main">${editor}</div></div></section>`;
  }
  function deckModule(){
    const board=deckState.boards.find(b=>String(b.id)===String(deckState.boardId));
    const boardButtons=deckState.boards.map(b=>`<button type="button" class="neos-board-chip ${String(b.id)===String(deckState.boardId)?'is-active':''}" data-action="deck-board" data-board-id="${esc(b.id)}">${esc(b.title)}</button>`).join('');
    const stacks=deckState.stacks.map(stack=>`<section class="neos-stack"><header><h3>${esc(stack.title)}</h3><span>${(stack.cards||[]).length}</span></header><div class="neos-stack-cards">${(stack.cards||[]).map(card=>`<div class="neos-deck-card"><span>${esc(card.title||'Sans titre')}</span>${card.description?'<small>Note jointe</small>':''}</div>`).join('')}</div><button class="neos-stack-add" data-action="deck-add" data-stack-id="${esc(stack.id)}">${icon('plus',15)} Ajouter une carte</button></section>`).join('');
    const body=deckState.status==='loading'?'<div class="neos-module-loader"><span class="neos-spinner"></span>Chargement Deck</div>':deckState.status==='error'?emptyModule(deckState.error||'Deck indisponible','Ouvrir Deck',moduleLink('deck')):board?`<div class="neos-board-nav">${boardButtons}</div><div class="neos-kanban">${stacks||emptyModule('Aucune colonne sur ce tableau.')}</div>`:emptyModule('Aucun tableau disponible.');
    return `<section class="neos-module">${panelHeader('Deck','Tableaux et cartes de tes projets',`<button class="neos-iconbtn" data-action="module-refresh" title="Rafraîchir" aria-label="Rafraîchir">${icon('refresh',17)}</button><a class="neos-btn" href="${safeUrl(moduleLink('deck'))}">${icon('external',15)} Deck</a>`)}<div class="neos-module-body">${body}</div></section>`;
  }
  function liteModule(id){
    if(id==='calendar')return `<section class="neos-module">${panelHeader('Agenda','30 prochains jours',`<a class="neos-btn" href="${safeUrl(moduleLink('calendar'))}">${icon('external',15)} Calendrier complet</a>`)}<div class="neos-module-body neos-lite-list">${(overview?.calendar||[]).length?(overview.calendar.map(e=>`<div class="neos-lite-item"><span class="neos-color-dot" style="background:${safeColor(e.color)}"></span><strong>${esc(e.title)}</strong><span>${fmtTime(e.start)}</span></div>`).join('')):emptyModule('Aucun événement à venir.')}</div></section>`;
    if(id==='tasks')return `<section class="neos-module">${panelHeader('Tâches','Tâches CalDAV en cours',`<a class="neos-btn" href="${safeUrl(moduleLink('tasks'))}">${icon('external',15)} Tâches</a>`)}<div class="neos-module-body neos-lite-list">${(overview?.tasks||[]).length?overview.tasks.map(t=>`<div class="neos-lite-item">${icon('check',16)}<strong>${esc(t.title)}</strong><span>${fmtTime(t.due)}</span></div>`).join(''):emptyModule('Aucune tâche ouverte.')}</div></section>`;
    return `<section class="neos-module">${panelHeader(appName(id),'Application externe',`<a class="neos-btn neos-btn-primary" href="${safeUrl(moduleLink(id))}">${icon('external',16)} Ouvrir ${esc(appName(id))}</a>`)}<div class="neos-module-body">${emptyModule('Module natif non intégré dans cette version.')}</div></section>`;
  }
  function currentModule(){switch(activeWorkspace){case 'photos':return photoModule();case 'notes':return noteModule();case 'deck':return deckModule();default:return liteModule(activeWorkspace);}}
  function moduleRequest(url,options={}){
    const token=csrfToken(); const headers={Accept:'application/json','OCS-APIRequest':'true','X-Requested-With':'XMLHttpRequest',...(token?{requesttoken:token}:{}),...(options.headers||{})};
    return fetch(url,{credentials:'same-origin',cache:'no-store',...options,headers}).then(async response=>{
      if(!response.ok)throw new Error(`HTTP ${response.status}`);
      return response.json();
    });
  }
  const notesUrl=()=>`${ncWebroot()}/index.php/apps/notes/api/v1/notes`;
  const deckUrl=()=>`${ncWebroot()}/index.php/apps/deck/api/v1.0`;
  async function loadPhotos(force=false){
    if(!force&&photoState.status==='ready')return;
    const gen=++moduleGeneration;photoState.status='loading';render();
    try{const result=demo?demo.gallery:await api(root.dataset.galleryUrl);if(gen!==moduleGeneration)return;
      photoState.items=Array.isArray(result?.items)?result.items:[];photoState.partial=!!result?.partial;photoState.status='ready';photoState.error='';
    }catch(error){if(gen!==moduleGeneration)return;photoState.error=`Photos indisponibles (${error.message}).`;photoState.status='error';}
    if(activeWorkspace==='photos')render();
  }
  async function loadNotes(force=false){
    if(!force&&notesState.status==='ready')return;
    const gen=++moduleGeneration;notesState.status='loading';render();
    try{const data=demo?demo.notes:await moduleRequest(notesUrl());if(gen!==moduleGeneration)return;
      notesState.items=Array.isArray(data)?data:[];notesState.status='ready';notesState.error='';
      if(notesState.items.length){const selected=notesState.items.find(n=>String(n.id)===String(notesState.selected))||notesState.items[0];notesState.selected=selected.id;notesState.draftTitle=selected.title||'';notesState.draftContent=selected.content||'';notesState.dirty=false;}
      else notesState.selected=null;
    }catch(error){if(gen!==moduleGeneration)return;notesState.status='error';notesState.error=`API Notes indisponible (${error.message}).`;} if(activeWorkspace==='notes')render();
  }
  async function loadDeck(force=false){
    if(!force&&deckState.status==='ready')return;
    const gen=++moduleGeneration;deckState.status='loading';render();
    try{let data=demo?demo.deckBoards:await moduleRequest(deckUrl()+'/boards');if(gen!==moduleGeneration)return;
      if(data?.ocs?.data)data=data.ocs.data;deckState.boards=Array.isArray(data)?data:[];
      deckState.boardId=deckState.boards.some(b=>String(b.id)===String(deckState.boardId))?deckState.boardId:deckState.boards[0]?.id||null;
      deckState.status='ready';deckState.error='';
      if(deckState.boardId){await loadDeckStacks(deckState.boardId,gen);return;}
    }catch(error){if(gen!==moduleGeneration)return;deckState.status='error';deckState.error=`API Deck indisponible (${error.message}).`;} if(activeWorkspace==='deck')render();
  }
  async function loadDeckStacks(id, gen=++moduleGeneration){
    deckState.boardId=id;deckState.status='loading';if(activeWorkspace==='deck')render();
    try{let data=demo?(demo.deckStacks?.[id]||[]):await moduleRequest(deckUrl()+`/boards/${encodeURIComponent(id)}/stacks`);
      if(gen!==moduleGeneration)return;if(data?.ocs?.data)data=data.ocs.data;deckState.stacks=(Array.isArray(data)?data:[]).sort((a,b)=>Number(a.order||0)-Number(b.order||0));deckState.status='ready';deckState.error='';
    }catch(error){if(gen!==moduleGeneration)return;deckState.status='error';deckState.error=`Colonnes indisponibles (${error.message}).`;} if(activeWorkspace==='deck')render();
  }
  function noteSelect(id){
    if(notesState.dirty&&!window.confirm('Abandonner les modifications non enregistrées ?'))return;
    const n=notesState.items.find(n=>String(n.id)===String(id));if(!n)return;
    notesState.selected=n.id;notesState.draftTitle=n.title||'';notesState.draftContent=n.content||'';notesState.dirty=false;render();
  }
  async function noteCreate(){
    if(notesState.dirty&&!window.confirm('Abandonner les modifications non enregistrées ?'))return;
    const title=window.prompt('Titre de la nouvelle note','Nouvelle note');if(title===null||!title.trim())return;
    try{const n=demo?{id:Date.now(),title:title.trim(),content:'',category:'',etag:'demo',modified:Date.now()/1000}:await moduleRequest(notesUrl(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.trim(),content:''})});
      notesState.items.unshift(n);notesState.selected=n.id;notesState.draftTitle=n.title||'';notesState.draftContent=n.content||'';notesState.dirty=false;notesState.status='ready';render();toast('Note créée','success');
    }catch(error){toast(`Création de note impossible : ${error.message}`,'error');}
  }
  async function noteSave(){
    const n=notesState.items.find(n=>String(n.id)===String(notesState.selected));if(!n||n.readonly)return;
    if(!notesState.draftTitle.trim()){toast('Titre requis','error');return;}
    try{const result=demo?{...n,title:notesState.draftTitle,content:notesState.draftContent,etag:'demo2'}:await moduleRequest(notesUrl()+`/${encodeURIComponent(n.id)}`,{method:'PUT',headers:{'Content-Type':'application/json',...(n.etag?{'If-Match':n.etag}:{})},body:JSON.stringify({title:notesState.draftTitle,content:notesState.draftContent})});
      Object.assign(n,result);notesState.draftTitle=n.title||'';notesState.draftContent=n.content||'';notesState.dirty=false;render();toast('Note enregistrée','success');
    }catch(error){toast(error.message.includes('412')?'La note a changé ailleurs. Copie ton texte avant de recharger.':`Enregistrement impossible : ${error.message}`,'error');}
  }
  async function deckCreateCard(stackId){
    const boardId=deckState.boardId;const title=window.prompt('Titre de la carte','');if(!boardId||!title?.trim())return;
    try{if(demo){const stack=deckState.stacks.find(s=>String(s.id)===String(stackId));stack?.cards?.push({id:Date.now(),title:title.trim()});}
      else await moduleRequest(deckUrl()+`/boards/${encodeURIComponent(boardId)}/stacks/${encodeURIComponent(stackId)}/cards`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.trim(),type:'plain',order:999})});
      toast('Carte ajoutée','success');if(!demo)await loadDeckStacks(boardId);else render();
    }catch(error){toast(`Carte non créée : ${error.message}`,'error');}
  }
  async function chooseWorkspace(id){
    if(!installedTabs().includes(id))return;
    if(id===activeWorkspace)return;
    if(notesState.dirty&&activeWorkspace==='notes'&&!window.confirm('Abandonner les modifications non enregistrées ?'))return;
    const old=activeWorkspace;
    const sequence=++transitionSequence;
    const direction=installedTabs().indexOf(id)>=installedTabs().indexOf(old)?1:-1;
    const stage=surface.querySelector('#neos-workspace-stage');
    workspaceScroll.set(old,root.scrollTop);
    if(motionEnabled()&&stage?.animate){
      try{
        const exit=stage.animate([{opacity:1,transform:'translate3d(0,0,0)',filter:'blur(0)'},{opacity:.07,transform:`translate3d(${-direction*24}px,0,0)`,filter:'blur(2px)'}],{duration:Math.round(160*motionFactor()),easing:'cubic-bezier(.4,0,1,1)',fill:'forwards'});
        await exit.finished;
      }catch(error){ /* interrupted by a newer navigation */ }
    }
    if(sequence!==transitionSequence)return;
    ++moduleGeneration;
    activeWorkspace=id;
    render();
    root.scrollTop=workspaceScroll.get(id)||0;
    surface.querySelectorAll('[data-action="workspace"]').forEach(el=>{
      if(el.dataset.workspace===id)el.setAttribute('aria-current','page');
    });
    if(motionEnabled()){
      const incoming=surface.querySelector('#neos-workspace-stage');
      incoming?.animate?.([{opacity:0,transform:`translate3d(${direction*28}px,0,0)`,filter:'blur(3px)'},{opacity:1,transform:'translate3d(0,0,0)',filter:'blur(0)'}],{duration:Math.round(410*motionFactor()),easing:'cubic-bezier(.16,1,.3,1)'});
      animateIn(surface.querySelectorAll('#neos-workspace-stage .neos-card, #neos-workspace-stage .neos-module'),40,65);
    }
    if(id==='photos'&&photoState.status==='idle')void loadPhotos();
    if(id==='notes'&&notesState.status==='idle')void loadNotes();
    if(id==='deck'&&deckState.status==='idle')void loadDeck();
  }
  function photoLightbox(index){
    const img=photoState.items[index];if(!img)return;
    popMode='photo';popHost.innerHTML=`<div class="neos-fullscreen-overlay" data-action="close-pop"><div class="neos-photo-lightbox"><header><strong>${esc(img.name)}</strong><button class="neos-iconbtn" data-action="close-pop" aria-label="Fermer">${icon('close',18)}</button></header><div><img src="${safeUrl(img.previewUrl||img.davUrl)}" alt="${esc(img.name)}"></div><footer><span>${esc(img.folder||'')}</span><a href="${safeUrl(img.url||moduleLink('photos'))}" class="neos-btn">${icon('external',15)} Fichiers</a></footer></div></div>`;
    animateLayerOpen(popHost,'.neos-photo-lightbox','y');
  }

  function summaryWidget() {
    const countFiles = number(browser.items.filter(x => x.kind === 'file').length);
    const countFolders = number(browser.items.filter(x => x.kind === 'folder').length);
    const appCount = number((overview?.shortcuts || []).length);
    return box('summary', `<div class="neos-metric-grid"><div class="neos-metric"><strong>${countFiles}</strong><span>fichiers</span></div><div class="neos-metric"><strong>${countFolders}</strong><span>dossiers</span></div><div class="neos-metric"><strong>${appCount}</strong><span>apps</span></div></div>`, `${browser.path}`);
  }

  function homeExplorerWidget(){
    const recent=(overview?.files||[]).slice(0,5);
    const pins=(settings.pins||[]).slice(0,4);
    const content=`<div class="neos-home-files-head"><div class="neos-home-file-stats"><strong>${number(browser.total)}</strong><span>éléments dans ${esc(browser.path)}</span></div><button type="button" class="neos-btn neos-btn-primary" data-action="workspace" data-workspace="files">${icon('arrow',16)} Ouvrir Fichiers</button></div>${pins.length?`<div class="neos-home-pins">${pins.map(path=>`<button type="button" data-action="home-open-folder" data-path="${esc(path)}">${icon('folder',15)} ${esc(path.split('/').pop())}</button>`).join('')}</div>`:''}<div class="neos-home-files-list">${recent.length?recent.map(f=>`<button type="button" class="neos-home-file" data-action="home-open-recent" data-folder="${esc(f.folder||'/')}" data-name="${esc(f.name)}"><span>${icon(String(f.mime||'').startsWith('image/')?'image':'file',17)}</span><strong title="${esc(f.name)}">${esc(f.name)}</strong><small>${humanSize(f.size)}</small>${icon('chevron',14)}</button>`).join(''):'<div class="neos-empty">Aucun fichier récent.</div>'}</div>`;
    return box('explorer',content,'Raccourcis');
  }

  function storageWidget(){
    const s = overview?.storage || {}; const p = Math.max(0, Math.min(100, number(s.percent)));
    return box('storage', `<div class="neos-stat-main">${humanSize(s.used)}</div><div class="neos-meter"><span style="width:${p}%"></span></div><p class="neos-subtle">${s.total == null ? 'illimité' : 'sur ' + humanSize(s.total)}</p>`);
  }
  function shortcutsWidget(){
    return box('shortcuts',hubGrid(true));
  }
  function clockWidget(){ return box('clock', `<div class="neos-clock" data-clock>--:--</div><div class="neos-subtle" data-clock-date>—</div>`); }
  function recentWidget(){
    const list = overview?.files || [];
    return box('files', list.length ? `<div class="neos-list">${list.map(f => `<button type="button" class="neos-item" data-action="preview-dav" data-url="${safeUrl(f.davUrl || '')}" data-name="${esc(f.name)}" data-mime="${esc(f.mime || '')}" data-size="${Number(f.size)||0}"><span class="neos-item-icon">${icon(String(f.mime||'').startsWith('image/') ? 'image' : 'file',16)}</span><span class="neos-item-title"><strong>${esc(f.name)}</strong><small>${esc(f.folder)} · ${ago(f.mtime)}</small></span><span class="neos-item-meta">${humanSize(f.size)}</span></button>`).join('')}</div>` : '<div class="neos-empty">Aucun fichier récent.</div>');
  }
  function calendarWidget(){
    const list = overview?.calendar || [];
    return box('calendar', list.length ? `<div class="neos-list">${list.map(x => `<div class="neos-item"><span class="neos-event-bar" style="background:${safeColor(x.color)}"></span><span class="neos-item-title"><strong>${esc(x.title)}</strong><small>${esc(x.calendar)}</small></span><span class="neos-item-meta">${fmtTime(x.start)}</span></div>`).join('')}</div>` : '<div class="neos-empty">Aucun événement.</div>', '30 j');
  }
  function tasksWidget(){
    const list = overview?.tasks || [];
    return box('tasks', list.length ? `<div class="neos-list">${list.map(x => `<div class="neos-item"><span class="neos-item-icon">${icon('check',16)}</span><span class="neos-item-title"><strong>${esc(x.title)}</strong><small>${x.due ? fmtTime(x.due) : 'Sans échéance'}</small></span></div>`).join('')}</div>` : '<div class="neos-empty">Aucune tâche ouverte.</div>');
  }
  function linksWidget(){
    const list = settings.links || [];
    return box('links', list.length ? `<div class="neos-link-grid">${list.map(x => `<a href="${safeUrl(x.url)}" class="neos-link-card">${icon('link',15)}<span>${esc(x.title)}</span>${icon('open',14)}</a>`).join('')}</div>` : '<div class="neos-empty">Aucun lien.</div>');
  }
  function notesWidget(){
    return box('notes', `<textarea id="neos-note" class="neos-note" placeholder="" spellcheck="false">${esc(settings.notes || '')}</textarea><div class="neos-note-tools"><button type="button" data-action="save-note" class="neos-btn">${icon('check',16)} Enregistrer</button></div>`);
  }

  function browserItems() {
    if (browser.loading) return '<div class="neos-browser-state"><span class="neos-spinner"></span></div>';
    if (browser.error) return `<div class="neos-browser-state is-error">${icon('alert',20)}<strong>${esc(browser.error)}</strong></div>`;
    const term = browser.query.trim().toLocaleLowerCase('fr-FR');
    let items = browser.items.filter(x => (browser.type === 'all' || x.kind === browser.type) && (!term || String(x.name).toLocaleLowerCase('fr-FR').includes(term)));
    if (browser.sort === 'recent') items = [...items].sort((a,b) => number(b.mtime) - number(a.mtime));
    else if (browser.sort === 'size') items = [...items].sort((a,b) => number(b.size) - number(a.size));
    else items = [...items].sort((a,b) => (a.kind==='folder'?0:1) - (b.kind==='folder'?0:1) || String(a.name).localeCompare(String(b.name),'fr',{numeric:true}));
    if (!items.length) return '<div class="neos-browser-state">—</div>';

    const rows = items.map(item => {
      const pinned = (settings.pins || []).includes(item.path);
      const active = preview.entry?.path === item.path;
      const title = item.kind === 'folder' ? `Ouvrir ${item.name}` : `Prévisualiser ${item.name}`;
      const action = item.kind === 'folder' ? 'browse-path' : 'select-entry';
      const thumb = item.kind === 'file' && isImage(item) && item.previewUrl ? `<img class="neos-thumb" loading="lazy" alt="" src="${safeUrl(item.previewUrl)}">` : '';
      return `<div class="neos-file-row ${active ? 'is-active' : ''} ${item.kind==='folder' ? 'is-folder' : 'is-file'}">
        <button type="button" class="neos-file-main" data-action="${action}" data-path="${esc(item.path)}" title="${esc(title)}">
          <span class="neos-file-symbol">${thumb || icon(item.kind==='folder' ? 'folder' : isImage(item) ? 'image' : isPdf(item) ? 'file' : isOffice(item) ? 'sheet' : 'file',18)}</span>
          <span class="neos-file-label"><strong>${esc(item.name)}</strong><small>${item.kind==='folder' ? 'Dossier' : esc(item.mime || 'Fichier')} · ${ago(item.mtime)}</small></span>
          <span class="neos-file-size">${item.kind === 'folder' ? '—' : humanSize(item.size)}</span>
        </button>
        <div class="neos-file-actions">
          ${item.kind === 'folder' ? `<button type="button" class="neos-iconbtn ${pinned ? 'is-on' : ''}" data-action="pin-folder" data-path="${esc(item.path)}" title="${pinned ? 'Retirer des favoris' : 'Épingler'}">${icon('star',15)}</button>` : ''}
          <button type="button" class="neos-iconbtn" data-action="file-menu" data-path="${esc(item.path)}" title="Actions" aria-label="Actions sur ${esc(item.name)}">${icon('more',16)}</button>
        </div>
      </div>`;
    }).join('');
    return `<div class="neos-file-list ${browser.view==='grid' ? 'is-grid' : ''}">${rows}</div>`;
  }

  function previewPane() {
    const entry=preview.entry;
    const hasFile=entry?.kind==='file';
    const actions=entry?`<div class="neos-preview-actions">
      ${hasFile&&entry.davUrl?`<button type="button" class="neos-iconbtn" data-action="download-selected" title="Télécharger" aria-label="Télécharger">${icon('download',16)}</button><button type="button" class="neos-iconbtn" data-action="share-selected" title="Créer un lien public" aria-label="Créer un lien public">${icon('link',16)}</button><button type="button" class="neos-iconbtn" data-action="copy-selected-link" title="Copier le lien interne" aria-label="Copier le lien interne">${icon('copy',16)}</button>`:''}
      ${hasFile?`<button type="button" class="neos-iconbtn" data-action="expand-preview" title="Agrandir" aria-label="Agrandir l'aperçu">${icon('expand',16)}</button>`:''}
      ${entry.url?`<a class="neos-iconbtn" href="${safeUrl(entry.url)}" title="Ouvrir dans Fichiers">${icon('external',16)}</a>`:''}
    </div>`:'';
    const head=entry?`<div class="neos-preview-head"><div class="neos-preview-title"><small>APERÇU</small><strong title="${esc(entry.name)}">${esc(entry.name)}</strong><span>${esc(entry.mime||'Fichier')} ${entry.kind==='file'?'· '+humanSize(entry.size):''}</span></div>${actions}</div>`:`<div class="neos-preview-head"><div class="neos-preview-title"><small>APERÇU</small><strong>—</strong></div></div>`;
    let body=`<div class="neos-preview-empty"><span class="neos-empty-symbol">${icon('file',32)}</span><span>Aperçu du fichier</span><small>Sélectionner un élément dans la liste</small></div>`;
    if(preview.status==='loading')body=`<div class="neos-preview-loading"><span class="neos-spinner"></span></div>`;
    else if(preview.status==='error')body=`<div class="neos-preview-empty">${icon('alert',22)}<span>${esc(preview.error||'Prévisualisation indisponible')}</span></div>`;
    else if(entry){
      if(entry.kind==='folder')body=`<div class="neos-folder-preview"><div class="neos-folder-emblem">${icon('folder',42)}</div><div class="neos-preview-meta"><span>Chemin</span><code>${esc(entry.path)}</code></div></div>`;
      else if(preview.mode==='image')body=`<div class="neos-image-preview"><img src="${safeUrl(entry.previewUrl||entry.davUrl||'')}" alt="${esc(entry.name)}" loading="eager" data-dav-fallback="${safeUrl(entry.davUrl||'')}"></div>`;
      else if(preview.mode==='text')body=`<pre class="neos-text-preview">${esc(preview.text)}</pre>`;
      else if(preview.mode==='table')body=`<div class="neos-table-preview"><table>${preview.rows.map((row,i)=>`<tr>${row.map(cell=>i===0?`<th>${esc(cell)}</th>`:`<td>${esc(cell)}</td>`).join('')}</tr>`).join('')}</table></div>`;
      else if(preview.mode==='pdf')body=`<div class="neos-pdf-container"><iframe class="neos-pdf-preview" title="PDF ${esc(entry.name)}" referrerpolicy="same-origin" src="${safeUrl(entry.davUrl||'')}"></iframe></div>`;
      else if(preview.mode==='office')body=`<div class="neos-office-preview"><div class="neos-office-illustration">${icon('sheet',42)}</div><strong>${esc(entry.name)}</strong><span>Document Office</span>${entry.previewUrl?`<img loading="lazy" src="${safeUrl(entry.previewUrl)}" alt="Aperçu si disponible" class="neos-office-thumb" data-hide-on-error="1">`:''}<a href="${safeUrl(entry.url)}" class="neos-btn neos-btn-primary">${icon('external',15)} Ouvrir dans Office</a></div>`;
      else body=`<div class="neos-preview-empty">${icon('file',28)}<span>Pas d'aperçu pour ce format</span></div>`;
    }
    return `<aside class="neos-preview" data-preview-pane>${head}<div class="neos-preview-body">${body}</div><div class="neos-preview-foot"><span>${entry?esc(entry.path||'/'):'Lecture seule'}</span><span>${hasFile?'↑ Aperçu':'Fichiers / Neos'}</span></div></aside>`;
  }
  function renderPreview() {
    const node=surface.querySelector('[data-preview-pane]');
    if(node){node.outerHTML=previewPane();animatePreview();}
    surface.querySelectorAll('.neos-file-row').forEach(el=>{
      const path=el.querySelector('[data-path]')?.dataset.path;
      el.classList.toggle('is-active',Boolean(path&&path===preview.entry?.path));
    });
    if(fullPreview)renderFullPreview();
  }

  function explorerWidget() {
    const pins = (settings.pins || []).slice(0, 12);
    return box('explorer', `<div class="neos-browser-shell">
      <div class="neos-browser-tools">
        <div class="neos-breadcrumb"><button class="neos-iconbtn neos-nav-btn" data-action="history-back" title="Retour" aria-label="Retour" ${historyIndex===0?'disabled':''}>${icon('back',16)}</button><button class="neos-iconbtn neos-nav-btn" data-action="history-forward" title="Suivant" aria-label="Suivant" ${historyIndex>=history.length-1?'disabled':''}>${icon('forward',16)}</button><span class="neos-breadcrumb-items">${breadcrumb()}</span><span class="neos-browser-total">${browser.loading?'…':browser.total+' élément'+(browser.total>1?'s':'')}</span></div>
        <div class="neos-browser-actions">
          ${pins.length ? `<div class="neos-pins">${pins.map(p => `<button type="button" class="neos-pin" data-action="browse-path" data-path="${esc(p)}">${icon('folder',13)} ${esc(p.split('/').pop())}</button>`).join('')}</div>` : ''}
          <label class="neos-search">${icon('search',16)}<input type="search" data-browser-search value="${esc(browser.query)}" placeholder="Rechercher dans ce dossier" aria-label="Rechercher dans ce dossier"><kbd>/</kbd></label>
          <select data-browser-type><option value="all" ${browser.type==='all'?'selected':''}>Tout</option><option value="folder" ${browser.type==='folder'?'selected':''}>Dossiers</option><option value="file" ${browser.type==='file'?'selected':''}>Fichiers</option></select>
          <select data-browser-sort><option value="name" ${browser.sort==='name'?'selected':''}>Nom</option><option value="recent" ${browser.sort==='recent'?'selected':''}>Récents</option><option value="size" ${browser.sort==='size'?'selected':''}>Taille</option></select>
          <button type="button" class="neos-btn" data-action="new-folder">${icon('folder',15)} Nouveau dossier</button>
          <button type="button" class="neos-btn" data-action="upload-trigger">${icon('upload',15)} Téléverser</button>
          <button type="button" class="neos-iconbtn" data-action="toggle-view" title="Changer la vue">${icon(browser.view === 'grid' ? 'list' : 'grid',16)}</button>
          <button type="button" class="neos-iconbtn" data-action="reload-folder" title="Recharger ce dossier">${icon('refresh',16)}</button>
          <a class="neos-btn" href="${safeUrl(filesHomeUrl())}">${icon('external',15)} Fichiers</a>
          <input type="file" data-upload-input hidden multiple>
        </div>
      </div>
      <div class="neos-browser-main"><div class="neos-browser-list-wrap"><div class="neos-list-caption"><span>Nom</span><span>Modifié</span><span>Taille</span></div><div id="neos-file-results">${browserItems()}</div>${browser.truncated?`<div class="neos-truncated">Premiers ${browser.limit} éléments sur ${browser.total} · <a href="${safeUrl(filesHomeUrl())}">Tout afficher</a></div>`:''}</div>${previewPane()}</div>
    </div>`, browser.path);
  }

  function filesWorkspace(){
    return `<div class="neos-files-workspace">${explorerWidget()}</div>`;
  }
  function homeWorkspace(widgets){
    const visible=settings.order.filter(id=>!settings.hidden.includes(id) && (id!=='shortcuts'||settings.launcherMode==='widget'));
    const homeWidgets={...widgets,explorer:homeExplorerWidget};
    return `${editing?`<div class="neos-editbar">${icon('grip',17)} Réorganiser les widgets</div>`:''}<div class="neos-grid-cards neos-home-grid">${visible.map(id=>homeWidgets[id]?homeWidgets[id]():'').join('')}</div>`;
  }

  function render() {
    applyTheme();
    const warnings=overview?.warnings||[];
    const activeTopApps=settings.launcherMode==='topbar' ? topApps() : [];
    const widgets={explorer:explorerWidget,storage:storageWidget,shortcuts:shortcutsWidget,clock:clockWidget,files:recentWidget,calendar:calendarWidget,tasks:tasksWidget,summary:summaryWidget,links:linksWidget,notes:notesWidget};
    // One launcher placement at a time: topbar OR widget. The Apps button opens the full catalogue.
    const visible = settings.order.filter(id=>!settings.hidden.includes(id) && (id!=='shortcuts'||settings.launcherMode==='widget'));
    surface.innerHTML=`<main class="neos-shell"><div class="neos-layout">
      <header class="neos-topbar">
        <div class="neos-brand"><span class="neos-brand-mark">${brandMark()}</span></div>
        <button type="button" class="neos-topsearch" data-action="focus-search" title="Rechercher dans mes fichiers"><span>${icon('search',16)}</span><span>Rechercher dans mes fichiers</span><kbd>/</kbd></button>
        <div class="neos-top-actions"><span class="neos-header-readout" data-clock>--:--</span><button type="button" class="neos-btn neos-hub-trigger" data-action="toggle-hub" title="Applications">${icon('grid',17)}<span>Applications</span></button><button type="button" class="neos-iconbtn" data-action="refresh" title="Actualiser" aria-label="Actualiser">${icon('refresh',17)}</button><button type="button" class="neos-btn neos-btn-primary" data-action="customize" aria-label="${editing ? 'Terminer' : 'Personnaliser'}">${icon(editing?'check':'settings',17)}<span>${editing?'Terminer':'Personnaliser'}</span></button></div>
      </header>
      ${tabBar()}
      <div id="neos-workspace-stage" class="neos-workspace-stage" data-active-workspace="${esc(activeWorkspace)}">
        ${workspaceHero()}
        ${(activeWorkspace==='files'||activeWorkspace==='home')&&warnings.length?`<div class="neos-warning">${icon('info',16)} ${esc(warnings[0])}</div>`:''}
        ${activeWorkspace==='home'?homeWorkspace(widgets):activeWorkspace==='files'?filesWorkspace():currentModule()}
      </div>
      <footer class="neos-footer"><span>NEOS 0.5.1</span><span>Nextcloud 35</span></footer>
    </div></main>`;
    updateClock();
    if(!hasEntered){hasEntered=true;animateIn(surface.querySelectorAll('.neos-topbar,.neos-card'),42,35);}
  }

  function updateClock() {
    const date = new Date();
    surface.querySelectorAll('[data-clock]').forEach(el => el.textContent = new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(date));
    surface.querySelectorAll('[data-clock-date]').forEach(el => el.textContent = new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(date));
  }

  function choosePreviewCandidate() {
    const current = preview.entry?.path && browser.items.find(x => x.path === preview.entry.path);
    if (current) return current;
    return browser.items.find(x => x.kind === 'file') || browser.items[0] || null;
  }

  async function browse(path, resetQuery=true, recordHistory=true) {
    if (!path || !path.startsWith('/') || path.includes('\\') || path.split('/').slice(1).some(x=>x==='..'||x==='.')) return;
    ++previewGeneration;
    preview.entry=null;preview.status='empty';preview.mode='empty';
    if(recordHistory&&path!==history[historyIndex]){
      history.splice(historyIndex+1);
      history.push(path);
      if(history.length>25)history.shift();
      historyIndex=history.length-1;
    }
    browser.path = path;
    if (resetQuery) browser.query = '';
    browser.loading = true;
    browser.error = '';
    render();
    const g = ++browseGeneration;
    try {
      let data;
      if (demo) data = demo.browse?.[path] || { path, davUrl:'', items:[], total:0, truncated:false, limit:160, filesUrl:'#' };
      else { const url = new URL(root.dataset.filesUrl, window.location.href); url.searchParams.set('path', path); data = await api(url.toString()); }
      if (g !== browseGeneration) return;
      browser.path = data.path || path;
      browser.davUrl = data.davUrl || '';
      browser.items = Array.isArray(data.items) ? data.items : [];
      browser.total = number(data.total);
      browser.truncated = Boolean(data.truncated);
      browser.limit = number(data.limit) || 160;
      browser.filesUrl = data.filesUrl || '#';
      browser.loading = false;
      browser.error = '';
      render();
      const candidate = choosePreviewCandidate();
      if (candidate?.kind === 'file') void selectEntry(candidate.path, true);
      else if(candidate){preview.entry=candidate;preview.mode='folder';preview.status='ready';renderPreview();}
      animateRows();
    } catch (error) {
      if (g !== browseGeneration) return;
      console.error('[Neos] dossier indisponible', error);
      browser.loading = false;
      browser.error = 'Impossible de charger ce dossier.';
      render();
    }
  }

  async function previewFromDav(url,name,mime,size=0){
    if(!url||!(/^\/(?!\/)/.test(url)))return;
    ++previewGeneration;
    preview.entry={name,mime,kind:'file',davUrl:url,url:filesHomeUrl(),size:null,path:''};
    preview.mode=isImage({mime})?'image':'meta';preview.status='ready';preview.error='';
    renderPreview();
    if(isText({name,mime})&&!isCsv({name,mime})&&size<=2*1024*1024){
      preview.status='loading';renderPreview();const g=++previewGeneration;
      try{
        const r=await fetch(url,{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
        const value=await r.text();if(g!==previewGeneration)return;
        preview.text=value.slice(0,160000);preview.mode='text';preview.status='ready';
      }catch(e){if(g!==previewGeneration)return;preview.status='error';preview.error='Lecture impossible';}renderPreview();
    }
  }
  function parseDelimited(text,delimiter){
    const rows=[];let row=[],cell='',quoted=false;
    for(let i=0;i<text.length&&rows.length<60;i++){
      const c=text[i];
      if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}
      else if(c===delimiter&&!quoted){row.push(cell);cell='';}
      else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);rows.push(row.slice(0,20));row=[];cell='';}
      else cell+=c;
    }
    if(row.length||cell){row.push(cell);rows.push(row.slice(0,20));}
    return rows.slice(0,60);
  }
  async function selectEntry(path){
    const entry=browser.items.find(x=>x.path===path);if(!entry)return;
    const g=++previewGeneration;
    preview.entry=entry;preview.text='';preview.rows=[];preview.error='';
    if(entry.kind==='folder'){preview.mode='folder';preview.status='ready';renderPreview();return;}
    preview.status='loading';preview.mode='meta';renderPreview();
    try{
      if(isImage(entry)){preview.status='ready';preview.mode='image';}
      else if(isPdf(entry)){preview.status='ready';preview.mode='pdf';}
      else if(isOffice(entry)){preview.status='ready';preview.mode='office';}
      else if(isText(entry)){
        if(number(entry.size)>2*1024*1024){preview.status='error';preview.error='Fichier trop volumineux pour un aperçu texte';}
        else{
          const r=await fetch(entry.davUrl,{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
          const value=(await r.text()).slice(0,180000);if(g!==previewGeneration)return;
          if(isCsv(entry)){
            const delimiter=ext(entry.name)==='tsv'?'\t':((value.match(/;/g)||[]).length>(value.match(/,/g)||[]).length?';':',');
            preview.rows=parseDelimited(value,delimiter);preview.mode='table';
          }else{preview.text=value;preview.mode='text';}
          preview.status='ready';
        }
      }else{preview.status='ready';preview.mode='meta';}
    }catch(error){if(g!==previewGeneration)return;console.error('[Neos] aperçu indisponible',error);preview.status='error';preview.error='Aperçu indisponible';}
    if(g===previewGeneration)renderPreview();
  }
  function openInFiles(entry){if(entry?.url)window.location.assign(entry.url);}
  async function copyCurrentLink(entry){
    if(!entry?.url)return;
    try{await navigator.clipboard.writeText(new URL(entry.url,window.location.href).href);toast('Lien copié','success');}
    catch(e){toast('Copie impossible','error');}
  }
  function downloadCurrent(entry){
    if(!entry?.davUrl)return;
    const anchor=document.createElement('a');anchor.href=entry.davUrl;anchor.download=entry.name||'';anchor.rel='noreferrer';
    document.body.appendChild(anchor);anchor.click();anchor.remove();
  }
  const ncWebroot=()=>window.OC?.getRootPath?.()||'';
  const davJoin=(base,name)=>`${String(base||'').replace(/\/+$/,'')}/${String(name||'').split('/').map(part=>encodeURIComponent(part)).join('/')}`;
  async function davRequest(method,url,{headers={},body}={}){
    const response=await fetch(url,{method,body,credentials:'same-origin',headers:{requesttoken:csrfToken(),'X-Requested-With':'XMLHttpRequest',...headers}});
    if(!response.ok&&![201,204,207].includes(response.status))throw new Error(`HTTP ${response.status}`);
    return response;
  }
  async function ocsRequest(path,{method='GET',headers={},body}={}){
    const response=await fetch(`${ncWebroot()}/ocs/v2.php${path}${path.includes('?')?'&':'?'}format=json`,{method,body,credentials:'same-origin',headers:{Accept:'application/json','OCS-APIRequest':'true',requesttoken:csrfToken(),'X-Requested-With':'XMLHttpRequest',...headers}});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    const data=await response.json();
    const status=Number(data?.ocs?.meta?.statuscode||0);
    if(status&&status!==100&&status!==200)throw new Error(data?.ocs?.meta?.message||'OCS');
    return data?.ocs?.data;
  }
  function namePrompt(message,placeholder=''){
    const value=window.prompt(message,placeholder);
    if(value==null)return '';
    return value.trim().replace(/[\\/]/g,'').slice(0,180);
  }
  async function createFolder(){
    if(!browser.davUrl)return toast('Dossier courant indisponible','error');
    const name=namePrompt('Nom du nouveau dossier','Nouveau dossier');
    if(!name)return;
    try{await davRequest('MKCOL',davJoin(browser.davUrl,name));toast('Dossier créé','success');await browse(browser.path,false,false);}catch(error){console.error(error);toast('Création impossible','error');}
  }
  async function uploadSelection(files){
    const list=[...(files||[])].filter(Boolean); if(!list.length||!browser.davUrl)return;
    let uploaded=0;
    for(const file of list){
      if(browser.items.some(entry=>entry.name===file.name)&&!window.confirm(`« ${file.name} » existe déjà. Le remplacer ?`))continue;
      try{await davRequest('PUT',davJoin(browser.davUrl,file.name),{body:file,headers:{'Content-Type':file.type||'application/octet-stream'}});uploaded++;}
      catch(error){console.error(error);toast(`Échec du téléversement : ${file.name}`,'error');}
    }
    if(uploaded){toast(`${uploaded} fichier${uploaded>1?'s':''} téléversé${uploaded>1?'s':''}`,'success');await browse(browser.path,false,false);}    
  }
  async function renameEntry(entry){
    if(!entry?.path||!entry?.name||!browser.davUrl)return;
    const name=namePrompt('Nouveau nom',entry.name); if(!name||name===entry.name)return;
    try{await davRequest('MOVE',entry.davUrl,{headers:{Destination:new URL(davJoin(browser.davUrl,name),window.location.origin).href,Overwrite:'F'}});toast('Élément renommé','success');await browse(browser.path,false,false);}catch(error){console.error(error);toast('Renommage impossible','error');}
  }
  async function deleteEntry(entry){
    if(!entry?.davUrl)return;
    if(!window.confirm(`Supprimer « ${entry.name} » ? La récupération dépend de la configuration de la corbeille Nextcloud.`))return;
    try{await davRequest('DELETE',entry.davUrl);toast('Élément supprimé','success');if(preview.entry?.path===entry.path){preview.entry=null;preview.status='empty';preview.mode='empty';}await browse(browser.path,false,false);}catch(error){console.error(error);toast('Suppression impossible','error');}
  }
  async function shareEntry(entry){
    if(!entry?.path)return;
    if(!window.confirm(`Créer un lien public accessible aux personnes qui le possèdent pour « ${entry.name} » ?`))return;
    try{
      const data=await ocsRequest('/apps/files_sharing/api/v1/shares',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({path:entry.path,shareType:'3'}).toString()});
      const url=data?.url||'';
      if(url&&navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);toast('Lien public copié','success');}
      else if(url){window.prompt('Lien public',url);toast('Lien public créé','success');}
      else toast('Lien public créé','success');
    }catch(error){console.error(error);toast('Partage indisponible','error');}
  }
  function renderFullPreview(){
    if(!fullPreview){if(popMode!=='hub'&&popMode!=='context')popHost.replaceChildren();return;}
    popHost.innerHTML=`<div class="neos-fullscreen-overlay" data-action="close-full-preview"><div class="neos-fullscreen-panel" role="dialog" aria-modal="true" aria-label="Aperçu de fichier"><header><strong>${esc(preview.entry?.name||'Aperçu')}</strong><div><button type="button" class="neos-iconbtn" data-action="download-selected" title="Télécharger">${icon('download',17)}</button><button type="button" class="neos-iconbtn" data-action="close-full-preview" title="Fermer">${icon('close',18)}</button></div></header><div class="neos-fullscreen-content">${previewPane()}</div></div></div>`;
    animateLayerOpen(popHost,'.neos-fullscreen-panel','y');
  }
  function renderContextMenu(){
    if(popMode!=='context')return;
    const entry=browser.items.find(x=>x.path===contextPath);if(!entry){popMode='';popHost.replaceChildren();return;}
    popHost.innerHTML=`<div class="neos-pop-layer neos-context-overlay" data-action="close-pop"><div class="neos-context-menu" role="menu"><div class="neos-context-title">${esc(entry.name)}</div>${entry.kind==='file'?`<button role="menuitem" data-action="menu-preview">${icon('expand',16)} Aperçu</button><button role="menuitem" data-action="menu-download">${icon('download',16)} Télécharger</button>`:`<button role="menuitem" data-action="menu-open-folder">${icon('folder',16)} Ouvrir le dossier</button>`}<button role="menuitem" data-action="menu-share">${icon('link',16)} Créer un lien public</button><button role="menuitem" data-action="menu-rename">${icon('edit',16)} Renommer</button><button role="menuitem" class="is-danger" data-action="menu-delete">${icon('trash',16)} Supprimer</button><button role="menuitem" data-action="menu-copy">${icon('copy',16)} Copier le lien interne</button><a href="${safeUrl(entry.url)}" role="menuitem">${icon('external',16)} Ouvrir dans Fichiers</a></div></div>`;
    animateLayerOpen(popHost,'.neos-context-menu','y');
  }

  function encodeSettings() {
    const form = new URLSearchParams();
    const put = (key, value) => form.append(`settings[${key}]`, String(value));
    ['theme','density','accent','layout','motion','launcherMode','notes'].forEach(key => put(key, settings[key] || ''));
    settings.order.forEach((v,i) => form.append(`settings[order][${i}]`, v));
    settings.hidden.forEach((v,i) => form.append(`settings[hidden][${i}]`, v));
    Object.entries(settings.sizes || {}).forEach(([id,v]) => form.append(`settings[sizes][${id}]`, String(v)));
    (settings.links || []).forEach((l,i) => { form.append(`settings[links][${i}][title]`, l.title); form.append(`settings[links][${i}][url]`, l.url); });
    (settings.pins || []).forEach((p,i) => form.append(`settings[pins][${i}]`, p));
    (settings.topApps || []).forEach((id,i) => form.append(`settings[topApps][${i}]`, id));
    return form;
  }

  async function save() {
    if (saving) return;
    saving = true;
    while (saveQueued) {
      saveQueued = false;
      updateSaveIndicator('Enregistrement…');
      try {
        await api(root.dataset.settingsUrl, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:encodeSettings().toString() });
        updateSaveIndicator('Enregistré');
      } catch (error) {
        console.error('[Neos] sauvegarde impossible', error);
        updateSaveIndicator('Erreur');
        toast('Impossible d’enregistrer.', 'error');
        break;
      }
    }
    saving = false;
  }

  function queueSave() { if(demo){ updateSaveIndicator('Démo — réglages temporaires'); return; } saveQueued = true; if (!saving) void save(); }

  function radio(name, choices) {
    return `<div class="neos-choice-set">${choices.map(([value,label]) => `<label class="neos-choice"><input type="radio" name="${name}" value="${value}" ${settings[name]===value?'checked':''}><span>${label}</span></label>`).join('')}</div>`;
  }

  function renderEditor() {
    if (!editorOpen) { editorHost.replaceChildren(); return; }
    const appChoices = (overview?.shortcuts || []).map(app => `<label class="neos-check"><input type="checkbox" data-topapp="${esc(app.id)}" ${settings.topApps.includes(app.id)?'checked':''}><span>${esc(app.label)}</span></label>`).join('');
    editorHost.innerHTML = `<div class="neos-overlay" data-action="editor-backdrop"><aside class="neos-editor" role="dialog" aria-modal="true" aria-labelledby="neos-editor-title">
      <header class="neos-editor-head"><h2 id="neos-editor-title">Neos</h2><button type="button" class="neos-iconbtn" data-action="close-editor">${icon('close',18)}</button></header>
      <div class="neos-editor-body">
        <section><h3>Apparence</h3>${radio('theme',[['system','Auto'],['dark','Sombre'],['light','Clair']])}${radio('accent',[['cyan','Cyan'],['indigo','Indigo'],['rose','Violet/Rose'],['emerald','Turquoise'],['amber','Ambre']])}${radio('density',[['comfortable','Aérée'],['compact','Compacte']])}${radio('layout',[['wide','Pleine largeur'],['focused','Centrée']])}${radio('motion',[['full','Animé'],['subtle','Discret'],['off','Off']])}</section>
        <section><h3>Widgets</h3><div class="neos-pref-list">${settings.order.filter(id => id!=='shortcuts').map((id, i) => `<div class="neos-pref-row"><label class="neos-check"><input type="checkbox" data-toggle="${id}" ${settings.hidden.includes(id)?'':'checked'}><span>${esc(widgetLabels[id])}</span></label><div class="neos-pref-tools"><select data-size="${id}">${[[3,'25%'],[4,'33%'],[6,'50%'],[8,'67%'],[12,'100%']].map(([s,t])=>`<option value="${s}" ${Number(settings.sizes[id])===s?'selected':''}>${t}</option>`).join('')}</select><button type="button" class="neos-iconbtn" data-action="move-up" data-id="${id}" ${settings.order.indexOf(id)===0?'disabled':''}>↑</button><button type="button" class="neos-iconbtn" data-action="move-down" data-id="${id}" ${settings.order.indexOf(id)===settings.order.length-1?'disabled':''}>↓</button></div></div>`).join('')}</div></section>
        <section><h3>Position du lanceur</h3>${radio('launcherMode',[['topbar','Barre supérieure'],['widget','Widget']])}<div class="neos-app-picks">${settings.launcherMode==='topbar' ? appChoices : ''}</div></section>
        <section><h3>Liens</h3><div class="neos-custom-links">${(settings.links || []).map((entry, i) => `<div class="neos-link-edit"><input data-link-title="${i}" value="${esc(entry.title)}" maxlength="80"><input data-link-url="${i}" value="${esc(entry.url)}" maxlength="600"><button type="button" class="neos-iconbtn" data-action="remove-link" data-index="${i}">${icon('trash',15)}</button></div>`).join('')}</div><button type="button" class="neos-btn" data-action="add-link">${icon('plus',15)} Ajouter</button></section>
      </div>
      <footer class="neos-editor-foot"><span data-save-indicator>Préférences individuelles</span><div><button type="button" class="neos-btn" data-action="arrange">Réorganiser</button><button type="button" class="neos-btn neos-btn-primary" data-action="close-editor">Terminer</button></div></footer>
    </aside></div>`;
    animateLayerOpen(editorHost,'.neos-editor','x');
  }
  function updateSaveIndicator(text){ const el = editorHost.querySelector('[data-save-indicator]'); if (el) el.textContent = text; }
  function openEditor(){ editing=true;editorOpen=true;render();renderEditor();surface.inert=true; }
  function closeEditor(keepEditing=false){
    harvestLinks(); queueSave();
    const finish = () => { editorOpen=false;editing=keepEditing;surface.inert=false;renderEditor();render();surface.querySelector('[data-action=customize]')?.focus(); };
    if(editorHost.firstElementChild) animateLayerClose(editorHost,'.neos-editor',finish,'x'); else finish();
  }
  function harvestLinks(){ editorHost.querySelectorAll('[data-link-title]').forEach(input => { const i = Number(input.dataset.linkTitle); if (settings.links[i]) settings.links[i].title = input.value.trim().slice(0,80); }); editorHost.querySelectorAll('[data-link-url]').forEach(input => { const i = Number(input.dataset.linkUrl); if (settings.links[i]) settings.links[i].url = input.value.trim().slice(0,600); }); }

  function renderHubPanel() {
    if(popMode==='context'){renderContextMenu();return;}
    if(popMode!=='hub'){if(!fullPreview)popHost.replaceChildren();return;}
    popHost.innerHTML = `<div class="neos-pop-layer" data-action="close-pop"><div class="neos-hub-pop neos-framed" role="dialog" aria-modal="true" aria-label="Applications"><header><div class="neos-hub-header-title"><strong>Applications</strong><span>${(overview?.shortcuts || []).length} disponibles</span></div><button type="button" class="neos-iconbtn" data-action="close-pop" title="Fermer">${icon('close',18)}</button></header><div class="neos-hub-shell"><div class="neos-hub-main">${hubGrid(false)}${settings.links?.length ? `<div class="neos-hub-links">${settings.links.map(x => `<a href="${safeUrl(x.url)}" class="neos-link-card">${icon('link',14)}<span>${esc(x.title)}</span></a>`).join('')}</div>` : ''}</div></div></div></div>`;
    animateLayerOpen(popHost,'.neos-hub-pop','y');
  }

  function hidePop(){
    const finish = () => { popMode=''; fullPreview=false; popHost.replaceChildren(); };
    if(popHost.firstElementChild) animateLayerClose(popHost,'.neos-hub-pop, .neos-context-menu, .neos-fullscreen-panel',finish,'y'); else finish();
  }

  async function load(silent=false) {
    try {
      const data = demo ? demo.overview : await api(root.dataset.overviewUrl);
      if (!data.overview || !data.settings) throw new Error('Réponse API inattendue');
      overview = data.overview;
      if (!settings || !silent) settings = { ...defaults(), ...data.settings, sizes:{...defaultSizes,...(data.settings.sizes||{})}, topApps:data.settings.topApps || ['files','calendar','tasks','talk'], launcherMode:data.settings.launcherMode || 'topbar', accent: data.settings.accent === 'copper' ? 'cyan' : (data.settings.accent || 'cyan') };
      root.dataset.displayName = data.user?.name || 'toi';
      render();
      if (browser.loading || (!browser.items.length && !browser.error)) void browse(browser.path, false);
      if (silent) toast('Actualisé','success');
    } catch (error) {
      console.error('[Neos] chargement impossible', error);
      surface.innerHTML = `<div class="neos-fatal">${icon('alert',28)}<strong>Chargement impossible</strong><button type="button" class="neos-btn" data-action="refresh">Réessayer</button></div>`;
    }
  }

  surface.addEventListener('click', event => {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    if (action === 'refresh') { void load(true); if(activeWorkspace==='files')void browse(browser.path,false); else if(activeWorkspace==='photos')void loadPhotos(true); else if(activeWorkspace==='deck')void loadDeck(true); else if(activeWorkspace==='notes')void loadNotes(true); }
    else if (action === 'customize') { if (editorOpen) closeEditor(); else openEditor(); }
    else if(action==='workspace'){if(popMode)hidePop();void chooseWorkspace(target.dataset.workspace);}
    else if(action==='home-open-folder'){const path=target.dataset.path||'/';void chooseWorkspace('files').then(()=>browse(path));}
    else if(action==='home-open-recent'){const folder=target.dataset.folder||'/';const name=target.dataset.name||'';void chooseWorkspace('files').then(async()=>{if(folder!==browser.path)await browse(folder);const entry=browser.items.find(x=>x.name===name);if(entry)void selectEntry(entry.path);});}
    else if(action==='focus-search'){void chooseWorkspace('files').then(()=>surface.querySelector('[data-browser-search]')?.focus());}
    else if(action==='module-refresh'){if(activeWorkspace==='photos')void loadPhotos(true);else if(activeWorkspace==='deck')void loadDeck(true);else if(activeWorkspace==='notes')void loadNotes(true);}
    else if(action==='photo-open'){photoLightbox(Number(target.dataset.photoIndex));}
    else if(action==='note-select'){noteSelect(target.dataset.noteId);}
    else if(action==='note-new'){void noteCreate();}
    else if(action==='note-save'){void noteSave();}
    else if(action==='deck-board'){void loadDeckStacks(Number(target.dataset.boardId));}
    else if(action==='deck-add'){void deckCreateCard(Number(target.dataset.stackId));}
    else if (action === 'toggle-hub') { if(popMode === 'hub') hidePop(); else {popMode = 'hub'; renderHubPanel();} }
    else if(action==='history-back'&&historyIndex>0){historyIndex--;void browse(history[historyIndex],true,false);}
    else if(action==='history-forward'&&historyIndex<history.length-1){historyIndex++;void browse(history[historyIndex],true,false);}
    else if (action === 'browse-path') { void browse(target.dataset.path || '/'); }
    else if (action === 'reload-folder') { void browse(browser.path, false); }
    else if (action === 'toggle-view') { browser.view = browser.view === 'grid' ? 'list' : 'grid'; render(); }
    else if (action === 'pin-folder') {
      const path = target.dataset.path; if (!path) return;
      const current = settings.pins || [];
      settings.pins = current.includes(path) ? current.filter(x => x !== path) : [...current, path].slice(0,12);
      queueSave(); render();
    }
    else if (action === 'select-entry') { void selectEntry(target.dataset.path || ''); }
    else if(action==='file-menu'){contextPath=target.dataset.path||'';popMode='context';renderContextMenu();}
    else if(action==='copy-selected-link'){void copyCurrentLink(preview.entry);}
    else if(action==='download-selected'){downloadCurrent(preview.entry);}
    else if(action==='share-selected'){void shareEntry(preview.entry);}
    else if(action==='expand-preview'){fullPreview=true;renderFullPreview();}
    else if(action==='new-folder'){void createFolder();}
    else if(action==='upload-trigger'){surface.querySelector('[data-upload-input]')?.click();}
    else if (action === 'open-file') { const entry = browser.items.find(x => x.path === target.dataset.path); if (entry?.url) window.location.assign(entry.url); }
    else if (action === 'save-note') { settings.notes = surface.querySelector('#neos-note')?.value || ''; queueSave(); toast('Note enregistrée', 'success'); }
    else if (action === 'preview-dav') { void previewFromDav(target.dataset.url || '', target.dataset.name || '', target.dataset.mime || '', Number(target.dataset.size)||0); }
    pulse(target);
  });

  surface.addEventListener('input', event => {
    const el = event.target;
    if(el.matches('[data-browser-search]')){ browser.query=el.value; const results=surface.querySelector('#neos-file-results');if(results)results.innerHTML=browserItems(); } 
    if (el.matches('#neos-note')) settings.notes = el.value;
    if(el.matches('[data-note-title]')){notesState.draftTitle=el.value;notesState.dirty=true;surface.querySelector('.neos-note-bottom>span')?.replaceChildren(document.createTextNode('Modifications non enregistrées'));}
    if(el.matches('[data-note-content]')){notesState.draftContent=el.value;notesState.dirty=true;surface.querySelector('.neos-note-bottom>span')?.replaceChildren(document.createTextNode('Modifications non enregistrées'));}
  });
  surface.addEventListener('change', event => {
    const uploadEl = event.target;
    if(uploadEl.matches('[data-upload-input]')){ const files=uploadEl.files; void uploadSelection(files); uploadEl.value=''; }
  });
  surface.addEventListener('change', event => {
    const el = event.target;
    if(el.matches('[data-browser-sort]')){ browser.sort=el.value; const results=surface.querySelector('#neos-file-results');if(results)results.innerHTML=browserItems();animateRows(); }
    if(el.matches('[data-browser-type]')){ browser.type=el.value; const results=surface.querySelector('#neos-file-results');if(results)results.innerHTML=browserItems();animateRows(); }
  });

  editorHost.addEventListener('click', event => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    const action = actionEl.dataset.action;
    if (action === 'editor-backdrop' && event.target === actionEl) { closeEditor(); return; }
    if (action === 'close-editor') { closeEditor(); return; }
    if (action === 'arrange') { closeEditor(true); return; }
    if (action === 'add-link') { harvestLinks(); if ((settings.links || []).length < 12) settings.links.push({title:'Lien', url:'/'}); queueSave(); renderEditor(); render(); }
    if (action === 'remove-link') { harvestLinks(); settings.links.splice(Number(actionEl.dataset.index), 1); queueSave(); renderEditor(); render(); }
    if (action === 'move-up' || action === 'move-down') {
      const id = actionEl.dataset.id; const idx = settings.order.indexOf(id); const next = idx + (action === 'move-up' ? -1 : 1); if (idx < 0 || next < 0 || next >= settings.order.length) return;
      [settings.order[idx], settings.order[next]] = [settings.order[next], settings.order[idx]]; queueSave(); renderEditor(); render();
    }
  });
  editorHost.addEventListener('change', event => {
    const el = event.target;
    if (el.matches('input[type="radio"]')) {
      settings[el.name] = el.value;
      if (el.name === 'launcherMode' && el.value === 'widget') settings.hidden = settings.hidden.filter(id=>id!=='shortcuts');
      queueSave(); render();
      if (el.name === 'launcherMode') renderEditor();
    }
    else if (el.matches('[data-toggle]')) { const id = el.dataset.toggle; settings.hidden = el.checked ? settings.hidden.filter(x => x !== id) : [...settings.hidden, id]; queueSave(); render(); }
    else if (el.matches('[data-size]')) { settings.sizes[el.dataset.size] = Number(el.value); queueSave(); render(); }
    else if (el.matches('[data-topapp]')) {
      const id = el.dataset.topapp;
      settings.topApps = el.checked ? [...new Set([...(settings.topApps || []), id])] : (settings.topApps || []).filter(x => x !== id);
      queueSave(); render();
    }
    else if (el.matches('[data-link-title],[data-link-url]')) { harvestLinks(); queueSave(); }
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (editorOpen) { event.preventDefault(); closeEditor(); }
      else if (popMode || fullPreview) { event.preventDefault(); hidePop(); }
    }
    if(!editorOpen&&!popMode&&!fullPreview&&event.key==='/'&&!/INPUT|TEXTAREA/.test(document.activeElement?.tagName||'')){event.preventDefault();if(activeWorkspace!=='files')void chooseWorkspace('files').then(()=>surface.querySelector('[data-browser-search]')?.focus());else surface.querySelector('[data-browser-search]')?.focus();}
  }, true);
  popHost.addEventListener('click', event => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;
    const action=actionEl.dataset.action;
    if(action==='workspace') { const id=actionEl.dataset.workspace; hidePop(); void chooseWorkspace(id); return; }
    if(action==='close-full-preview'){if(event.target===actionEl||actionEl.tagName==='BUTTON'){hidePop();}return;}
    if(action==='download-selected'){downloadCurrent(preview.entry);return;}
    if(['menu-preview','menu-download','menu-copy','menu-share','menu-rename','menu-delete','menu-open-folder'].includes(action)){const entry=browser.items.find(x=>x.path===contextPath);if(!entry)return;hidePop();if(action==='menu-preview')void selectEntry(contextPath);else if(action==='menu-download')downloadCurrent(entry);else if(action==='menu-copy')void copyCurrentLink(entry);else if(action==='menu-share')void shareEntry(entry);else if(action==='menu-rename')void renameEntry(entry);else if(action==='menu-delete')void deleteEntry(entry);else if(action==='menu-open-folder')void browse(entry.path);return;}
    if(action==='close-pop'){if(event.target===actionEl||actionEl.tagName==='BUTTON'){hidePop();}}
  });

  surface.addEventListener('dragstart', event => {
    if (!editing) return;
    const card = event.target.closest('[data-widget]'); if (!card) return;
    event.dataTransfer?.setData('text/plain', card.dataset.widget); if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
    card.classList.add('is-dragging');
  });
  surface.addEventListener('dragend', event => event.target.closest('[data-widget]')?.classList.remove('is-dragging'));
  surface.addEventListener('dragover', event => { if (editing && event.target.closest('[data-widget]')) event.preventDefault(); });
  surface.addEventListener('drop', event => {
    if (!editing) return;
    const target = event.target.closest('[data-widget]'); if (!target) return;
    event.preventDefault();
    const from = event.dataTransfer?.getData('text/plain'); const to = target.dataset.widget;
    if (!widgetIds.includes(from) || !widgetIds.includes(to) || from === to) return;
    const order = [...settings.order]; const fromIndex = order.indexOf(from), toIndex = order.indexOf(to); if (fromIndex < 0 || toIndex < 0) return;
    order.splice(fromIndex, 1); order.splice(toIndex, 0, from); settings.order = order; queueSave(); render();
  });

  surface.addEventListener('pointermove', event => {
    if (!motionEnabled() || event.pointerType === 'touch') return;
    const card = event.target.closest('.neos-card'); if (!card) return;
    const rect = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${event.clientX - rect.left}px`); card.style.setProperty('--my', `${event.clientY - rect.top}px`);
  }, { passive:true });

  window.matchMedia?.('(prefers-color-scheme: light)').addEventListener?.('change',()=>{if(settings?.theme==='system')applyTheme();});
  root.addEventListener('error',event=>{
    const img=event.target;
    if(!(img instanceof HTMLImageElement))return;
    if(img.dataset.davFallback && img.dataset.davFallback!=='#' && !img.dataset.fallbackUsed){
      img.dataset.fallbackUsed='1';img.src=img.dataset.davFallback;return;
    }
    if(img.matches('.neos-thumb,.neos-office-thumb') || img.dataset.fallbackUsed){img.style.display='none';}
  },true);
  clockTimer = setInterval(updateClock, 30000);
  void load();
  launchDatafield();
})();
