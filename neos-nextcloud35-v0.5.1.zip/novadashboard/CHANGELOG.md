## 0.5.1 — Workspace Navigation
- Accueil distinct de l’onglet Fichiers avec un widget Fichiers compact, activable sur la page d’accueil.
- Navigation latérale animée slide/fade entre onglets (API Web Animations, inspirée d’Anime.js).
- Onglets Deck et Notes toujours visibles, avec gestion des modules indisponibles.
- Hub d’applications simplifié : icônes sans tuiles/encarts.
- Correction du défilement vertical de la surface Neos et restauration des positions par onglet.
- Conservation des API, préférences, chemins et permissions existants.

# Neos — changelog

## 0.5.0 — Espaces intégrés

- Navigation interne : la topbar change de module sans ouvrir une autre page Nextcloud.
- Fichiers : l’explorateur Neos reste prioritaire, avec prévisualisations et actions rapides (nouveau dossier, téléversement, partage public confirmé, renommage et suppression confirmée).
- Photos : découverte bornée des images auxquelles l’utilisateur a accès, grille et visionneuse dans Neos ; albums natifs toujours disponibles par un lien explicite.
- Notes : accès à l’API officielle de Notes, liste, création, édition et sauvegarde avec protection `If-Match` des éditions concurrentes. Nécessite l’app Notes activée et une API accessible depuis la session.
- Deck : tableaux, listes/cartes et ajout de carte via l’API officielle de Deck. Nécessite l’app Deck activée et une API accessible depuis la session.
- Agenda et Tâches : consultation sans changement de page, données issues de l’API déjà utilisée par Neos.
- Autres apps : panneau interne et lien explicite de retour à l’application native, pas d’intégration factice ni d’iframe.
- Nouveau thème adapté de `NEOS_UI_Kit_v1` fourni par l’utilisateur : logo SVG, 10 icônes d’apps et motifs de panneaux. Aucun CDN ajouté.
- Correctif du chemin des assets et suppression des doublons d’apps dans le widget Hub.
- Conservation de l’ID technique `novadashboard` et des préférences existantes ; aucune table SQL supplémentaire.

## Compatibilité

- Nextcloud 35.x, PHP 8.3+.
- Application non testée contre une instance serveur réelle ; les tests navigateur utilisent des données simulées.
- Les privilèges de lecture et modification restent ceux du compte Nextcloud connecté. Les fonctionnalités peuvent être limitées si un administrateur a désactivé une API ou une application.
