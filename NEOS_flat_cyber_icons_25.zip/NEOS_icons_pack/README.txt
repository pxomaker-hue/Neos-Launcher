NEOS — Flat Cyber icon pack (original artwork)

25 icons + NEOS logo.

Directories:
- svg/glyphs/ : transparent vector glyphs (for navigation buttons and compact use).
- svg/tiles/  : dark rounded app tiles (for launch center).
- png/glyphs_128/ : transparent 128×128 PNG glyphs.
- png/tiles_128/ and png/tiles_256/ : rounded dark app tiles.

Recommended use in NEOS Nextcloud dashboard:
- Navigation / headers: glyph SVG at 18–22 px.
- Application launcher: tile SVG or PNG at 48–80 px.
- Keep app label outside the image for accessibility and responsive rendering.

Style colors: midnight #0B1730, cyan #2CC9FC, amber #FFBC4B, mint #36D6AD, purple #B480FF, coral #F77BAE.

Editable SVGs use only elementary vector primitives and a 24×24 icon grid.
