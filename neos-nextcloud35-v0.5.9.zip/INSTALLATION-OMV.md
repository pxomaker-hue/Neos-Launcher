# Neos v0.5.9 — installation sur OMV / Nextcloud 35

Neos continue de porter l'identifiant applicatif `novadashboard` pour conserver les préférences existantes et la configuration d'accueil par défaut.

## Préparation — Windows PowerShell

Place `neos-nextcloud35-v0.5.9.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher`, puis :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.5.9.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## Sur le NAS — prérequis

```bash
sudo docker exec nextcloud occ status
```

Vérifier Nextcloud 35.x, `maintenance: false`, `needsDbUpgrade: false`, et aucune autre opération de mise à jour active. Une sauvegarde de l'application **n'est pas** une sauvegarde de la base, des fichiers utilisateurs ou du NAS.

## Sauvegarde de l'application actuelle

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/neos-backup-avant-v059.tar.gz -C /config/www/nextcloud/apps novadashboard'
```

## Installer les fichiers

```bash
mkdir -p /tmp/neos-v059
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.5.9.zip /tmp/neos-v059
sudo docker cp /tmp/neos-v059/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

Actualise Neos avec **Ctrl + F5**.

## Nouvelles fonctions

- **Recherche globale par nom** : clique dans la recherche de la topbar, ou `Ctrl + K` sur ordinateur. Sur mobile, ouvre Fichiers puis appuie sur **Partout**. La recherche est limitée à **2 500 entrées** et **6 niveaux de dossiers** (40 résultats maximum). Elle suit les permissions Nextcloud et peut afficher des résultats partiels. Elle ne recherche pas dans le contenu des fichiers.
- **Volume de données** : l'administrateur peut voir la capacité du système de fichiers contenant le répertoire de données de Nextcloud, si PHP sait la lire. La capacité affichée n'est pas nécessairement la somme brute des disques du NAS ou l'ensemble d'un RAID. Les autres utilisateurs ne voient que leurs informations de stockage Nextcloud.

### Vérification indépendante de la capacité du volume

```bash
sudo docker exec nextcloud df -h /data
```

Cette commande est en lecture seule. Sur OMV, `/data` doit correspondre au volume monté pour Nextcloud. Consulte la configuration des montages Docker si tu héberges les données ailleurs.

## Retour arrière

D'abord, vérifier la présence de la sauvegarde :

```bash
sudo docker exec nextcloud sh -c 'test -s /config/neos-backup-avant-v059.tar.gz && tar -tzf /config/neos-backup-avant-v059.tar.gz | head'
```

Si la sauvegarde est valide, restaurer le dossier applicatif :

```bash
sudo docker exec nextcloud sh -c 'rm -rf /config/www/nextcloud/apps/novadashboard && tar -xzf /config/neos-backup-avant-v059.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Puis recharge Neos avec **Ctrl + F5**. Les préférences utilisateurs restent normalement en base de données et ne sont pas supprimées par ces commandes.

## Validation

Tests statiques PHP et JavaScript et intégrité du ZIP, tests Chromium du widget stockage, de la palette de recherche et de sa version mobile, ainsi qu'un test unitaire PHP de la recherche imbriquée et du respect des permissions avec objets simulés. Les données et fichiers réels de ton NAS ne sont pas accessibles ici : vérifier la nouvelle route API sur l'instance avant de s'y fier.
