# Feuille de route Neos → v0.7 (après v0.6.16)

## Socle confirmé sur NAS (selon les retours)

- Explorateur, Notes, Deck, Agenda, Tâches, Planning et topbar personnalisable.
- Talk : lecture et envoi de messages texte.
- Contacts : consultation, création, modification CardDAV.
- Mail : réception, lecture HTML sécurisée, navigation entre courriels.

## Nouveauté v0.6.16 à valider sur NAS

- Composer un mail texte et répondre dans Neos, compte expéditeur et À/Cc.
- Envoi Outbox en 2 étapes avec confirmation et gestion des réponses incertaines.
- Prise en charge d'un brouillon « Nouveau message » uniquement en mémoire de la page (non synchronisé avec les brouillons de Mail natif).

## Prochaines étapes suggérées

**v0.6.17** : vérifier la compatibilité réelle du flux d'envoi, l'affichage des comptes/alias, le rattachement des réponses aux fils et les diagnostics d'erreur.

**v0.6.18** : pièces jointes et brouillons persistants (API Mail testée avec la version du NAS) ; Contacts : plusieurs e-mails/téléphones.

**v0.6.19** : Talk (messages non lus et options de conversation), Activité (filtres serveur) ; régressions sur mobile.

**v0.7 candidate** : vérification multi-module, stabilité de l'édition et documentation complète, test de restauration et sécurité des API.

Aucune fonction non validée sur le NAS ne doit être considérée comme définitivement stable.
