# Historique

## 0.6.16
- Rédaction de messages texte dans Neos avec compte expéditeur, À, Cc et objet.
- Réponse depuis le lecteur Mail (adresse expéditeur et objet Re: préremplis).
- Utilisation de POST /api/outbox puis POST /api/outbox/{id} avec gestion des erreurs et prévention du double envoi.
- Éditeur compatible mobile, mode démo sans expédition.
- Aucun changement aux autres modules et à l’icône Planning.
