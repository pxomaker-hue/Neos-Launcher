# Neos v0.6.16 — Installation OMV / Nextcloud 35

Cette mise à jour conserve le thème Flat Cyber, l'icône Planning, la topbar personnalisable et les modules validés. Elle ajoute dans Mail **Nouveau message** et **Répondre** (texte uniquement, compte expéditeur sélectionnable, destinataires À/Cc). L'envoi passe par les deux opérations officielles de la boîte d'envoi Nextcloud Mail. La compatibilité avec l'instance réelle reste à confirmer.

> **Premier test :** utilise uniquement une adresse qui t'appartient. Si l'interface affiche « envoi non confirmé », vérifie **Mail natif → Boîte d'envoi / Envoyés** avant de réessayer. Ne renvoie jamais immédiatement le même message dans ce cas.

## 1. PowerShell sur Windows — commandes séparées

Télécharge `neos-nextcloud35-v0.6.16.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.16.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Sur le NAS — vérifier et sauvegarder

À partir de maintenant, exécute les commandes dans **le terminal SSH du NAS**, l'une après l'autre.

```bash
sudo docker exec nextcloud occ status
```

**Arrête-toi** si `maintenance: true` ou `needsDbUpgrade: true`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.16.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

Continuer uniquement si `Neos trouvé` s'affiche.

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0616.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0616.tar.gz
```

## 3. Mise à jour — commandes séparées

```bash
mkdir -p /tmp/neos-v0616
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.16.zip /tmp/neos-v0616
```

```bash
test -f /tmp/neos-v0616/novadashboard/appinfo/info.xml && echo "Archive prête"
```

Si `Archive prête` s'affiche :

```bash
sudo docker cp /tmp/neos-v0616/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : **`novadashboard: 0.6.16`**. Recharge Neos avec **Ctrl + F5**.

## 4. Test réel prudent

1. Ouvre **Mail → Rédiger** ; vérifie le compte expéditeur.
2. Saisis **ta propre adresse** dans « À », un objet de test et un message court, puis clique **Envoyer** une seule fois.
3. Vérifie que Neos confirme l'envoi **et que le message arrive** dans Mail natif. Si erreur ou état incertain, examine les dossiers Boîte d'envoi et Envoyés avant une nouvelle tentative.
4. Ouvre un de tes messages, clique sur **Répondre** et vérifie que le destinataire et l'objet `Re:` se préremplissent. Teste ensuite sur une conversation non sensible.
5. Contrôle les régressions : lecture HTML, Contacts, Talk, Activité, Deck, Planning et ordre des onglets.

**Limites de cette version :** envoi **texte uniquement**, sans pièces jointes, sans brouillons persistants, sans chiffrement S/MIME. Selon le format du message d'origine, le rattachement automatique de la réponse au fil peut ne pas être disponible. Ces fonctions restent accessibles dans Mail natif.

## 5. Retour arrière vers v0.6.15

À effectuer seulement si nécessaire, sur OMV :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
sudo docker exec nextcloud test -f /config/neos-backup-avant-v0616.tar.gz && echo "Sauvegarde trouvée"
```

Si `Sauvegarde trouvée` s'affiche :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0616.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Résultat attendu : `novadashboard: 0.6.15`. Recharge avec Ctrl + F5.

Ne pas exécuter `occ upgrade` ni modifier le reverse proxy pour cette mise à jour de fichiers.
