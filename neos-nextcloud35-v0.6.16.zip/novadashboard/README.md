# Neos Launcher v0.6.16 — Nextcloud 35

Basée sur la v0.6.15 validée sur NAS. Conserve thème Flat Cyber, Planning, Talk, Activité, Contacts, Deck et topbar personnalisable.

**Mail** : formulaire texte intégré (nouveau message / réponse), choix du compte, À/Cc, validation, intégration à l’API Outbox de Nextcloud Mail, confirmation d’envoi en deux étapes. Les messages ne sont envoyés que sur clic explicite. En cas de réponse réseau incertaine, pas de relance automatique afin d’éviter un doublon. Les pièces jointes, les brouillons persistants, le S/MIME et les envois différés restent dans Mail natif.

**Attention** : l’envoi réel doit être testé avec un message vers sa propre adresse. Un message créé dans la boîte d’envoi mais non expédié doit être inspecté dans Mail natif. Neos ne prétend pas à un envoi confirmé sans réponse de l’API.
