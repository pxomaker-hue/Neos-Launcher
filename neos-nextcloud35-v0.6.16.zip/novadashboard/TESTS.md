# Tests Neos v0.6.16

- Analyse syntaxique de `js/app.js` (`node --check`) : réussie.
- Contrôle syntaxique de tous les fichiers PHP (`php -l`) : réussi.
- Tests Playwright / Chromium de l'aperçu interactif : réussis sur ordinateur (1450 px) et mobile (390 px) : rédaction, sélection du compte, réponse, simulation de clic d'envoi, absence d'erreurs JavaScript.
- Tests du flux d'envoi avec API simulée : `POST /api/outbox` suivi de `POST /api/outbox/{id}` confirmé (201/202) : réussi.
- API simulée : erreur HTTP 500 à la deuxième étape → message conservé en boîte d'envoi, pas de nouvelle requête sur deuxième clic : réussi.
- API simulée : erreur HTTP 400 à la création → aucune deuxième requête : réussi.
- Pas de mot de passe SMTP stocké, utilisation des cookies de session Nextcloud et du jeton CSRF existant.
- Archive ZIP et version XML vérifiées : voir contrôle d'archive de livraison.

**Non testé :** envoi réel avec la version exacte de Nextcloud Mail sur le NAS (aucun accès au serveur de l'utilisateur). Il reste indispensable de tester d'abord vers sa propre adresse, puis une réponse non sensible.
