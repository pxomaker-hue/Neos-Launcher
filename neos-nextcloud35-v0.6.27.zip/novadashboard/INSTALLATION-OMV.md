# Neos v0.6.26 — installation OMV / Nextcloud 35

Cette version ajoute le filtre par carnet et le chargement progressif dans Contacts. Les fichiers Contact CardDAV déjà enregistrés ne sont pas modifiés par l'installation.

Récupère `neos-nextcloud35-v0.6.26.zip` dans `X:\Travail\Apprentissage\Codage\Neos Launcher`, puis exécute le script local `Deploy-Neos.ps1`. Vérifie que la version proposée est 0.6.26 avant de confirmer `INSTALLER`. Le script réalise une sauvegarde avant de copier les nouveaux fichiers, puis vérifie Nextcloud et la version déployée. Le mot de passe sudo reste distinct de la phrase secrète de la clé SSH.

# Neos v0.6.26 — Déploiement OpenMediaVault

**Cible :** NAS OMV `192.168.1.200`, SSH `ssh-pxo`, conteneur Docker `nextcloud`, Nextcloud 35 et application `novadashboard`.

**Important :** cette livraison préserve les fonctionnalités de v0.6.21. Elle améliore la stabilité des rafraîchissements Talk et Mail, avec reprise de lecture après erreur. Le comportement des brouillons vides et le bouton Talk « Marquer comme lu » déjà validés sont conservés. Elle **ne modifie ni ne supprime le brouillon IMAP original**. Les modifications de brouillons avec pièces jointes restent dans Mail natif.

## Déploiement simplifié : script PowerShell existant

Si tu as conservé `Deploy-Neos.ps1` dans le dossier des ZIP, place également `neos-nextcloud35-v0.6.26.zip` dans ce dossier, puis lance dans PowerShell :

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "X:\Travail\Apprentissage\Codage\Neos Launcher\Deploy-Neos.ps1"
```

Le script existant sélectionne le ZIP le plus récent, vérifie sa version, demande confirmation puis effectue les sauvegardes et la copie. **Vérifie la version choisie avant de taper `INSTALLER`.** Le script PowerShell déjà corrigé utilise ssh-agent : la phrase secrète est demandée au plus une fois lorsqu’elle n’est pas déjà chargée, puis sudo est demandé séparément.

## Installation manuelle — une commande à la fois

### PowerShell Windows

Après avoir téléchargé le ZIP dans `X:\Travail\Apprentissage\Codage\Neos Launcher\` :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.26.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

### NAS OpenMediaVault / terminal SSH

Vérifie que Nextcloud **n'est pas en maintenance** et n'attend pas de mise à niveau :

```bash
sudo docker exec nextcloud occ status
```

Ne continue que si `maintenance: false` et `needsDbUpgrade: false`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.26.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

**Sauvegarde de la v0.6.22 (avant toute modification) :**

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0626.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0626.tar.gz
```

Prépare la mise à jour :

```bash
mkdir -p /tmp/neos-v0626
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.26.zip /tmp/neos-v0626
```

```bash
test -f /tmp/neos-v0626/novadashboard/appinfo/info.xml && echo "Archive prête"
```

Si toutes les vérifications précédentes réussissent, installe :

```bash
sudo docker cp /tmp/neos-v0626/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

**Résultat attendu :** `novadashboard: 0.6.26`. Dans ton navigateur, **Ctrl + F5**.

## Vérifications sur le NAS

1. **Mail → Brouillons :** ouvre un brouillon vide puis un brouillon avec texte, confirme que les deux peuvent être repris en copie ; puis ouvre un brouillon de test et clique **Reprendre le texte dans Neos (copie)**. Vérifie que le texte et le destinataire sont repris dans un **nouveau** message. Ne clique pas sur Envoyer. Ferme l'éditeur et constate que le brouillon original est toujours présent. Une pièce jointe de l'original ne doit pas être considérée comme copiée.
2. **Talk :** ouvre une conversation avec des messages non lus, clique **Marquer comme lu** et vérifie que les compteurs changent. En cas d'erreur de l'API, Neos doit conserver le compteur et afficher un diagnostic.
3. Contrôle rapide : Contacts (édition et suppression test déjà validées en v0.6.21), Planning, Deck, Tâches, Mail, topbar personnalisée.

## Retour arrière manuel

Dans la session SSH où `APP_PATH` a été défini :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0626.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Termine avec **Ctrl + F5**. Le retour arrière restaure les fichiers présents dans l'archive de sauvegarde ; il ne supprime pas nécessairement d'éventuels fichiers ajoutés par une version future.

## Sécurité

Aucune modification des CSP, du proxy, des paramètres SMTP ni de la base de données. Les contenus des mails ne sont pas enregistrés en local par Neos. Ne transmets jamais des cookies de session, des jetons CSRF, des identifiants ou des adresses privées dans les captures de F12.

## Déploiement de Neos v0.6.27

Récupérer le ZIP depuis https://github.com/pxomaker-hue/Neos-Launcher puis utiliser le script `Deploy-Neos.ps1` avec confirmation `INSTALLER` et sauvegarde préalable. Le script vérifie Nextcloud et conserve une sauvegarde dans `/config/`. Contrôler la version et faire Ctrl+F5. Pour retour arrière, voir le fichier `INSTALLATION-OMV-v0.6.27.md` livré séparément.
