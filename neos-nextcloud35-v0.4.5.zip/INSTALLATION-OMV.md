# Neos 0.4.5 — Flat Cyber

## Compatibilité et périmètre

Version conçue pour Nextcloud **35.x**, PHP **8.3+**, l'image LinuxServer.io et le conteneur Docker **`nextcloud`** sur OMV.

- Le nom visible reste **Neos**, l'identifiant technique reste **`novadashboard`**.
- Seuls des fichiers de l'application sont remplacés. Aucune nouvelle table SQL, aucun nouveau conteneur et aucun service externe.
- Tes fichiers Nextcloud et les préférences par utilisateur sont conservés.
- Les préférences existantes de thèmes, de widgets et du lanceur restent utilisées.
- Les animations utilisent des API natives du navigateur, avec prise en charge de `prefers-reduced-motion`.

## 1. Copier le ZIP sur ton NAS

Sur **Windows Terminal / PowerShell**, après avoir téléchargé l'archive dans ton dossier habituel :

```powershell
scp "X:\Travail\Apprentissage\Codage\neos-nextcloud35-v0.4.5.zip" ssh-pxo@192.168.1.200:/tmp/
ssh ssh-pxo@192.168.1.200
```

## 2. Vérifier l'état de Nextcloud

Depuis **SSH sur OMV** :

```bash
sudo docker exec nextcloud occ status
```

Vérifie : Nextcloud 35.x, **`maintenance: false`** et **`needsDbUpgrade: false`**. Si une opération de mise à niveau est en cours, ne continue pas.

## 3. Sauvegarder l'application v0.4.4

Avant de toucher au code, vérifie que tu possèdes également une sauvegarde récente de Nextcloud (volumes et base de données) :

```bash
sudo docker exec nextcloud sh -c 'tar -czf /config/novadashboard-backup-avant-v045.tar.gz -C /config/www/nextcloud/apps novadashboard'
sudo docker exec nextcloud ls -lh /config/novadashboard-backup-avant-v045.tar.gz
```

La sauvegarde ci-dessus couvre le code Neos uniquement, pas la base de données ni les fichiers utilisateurs.

## 4. Installer

```bash
mkdir -p /tmp/neos-v045
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.4.5.zip /tmp/neos-v045
ls /tmp/neos-v045/novadashboard/appinfo/info.xml
sudo docker cp /tmp/neos-v045/novadashboard/. nextcloud:/config/www/nextcloud/apps/novadashboard/
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
sudo docker exec nextcloud occ status
```

**N'exécute pas `occ upgrade` ou une recréation de conteneur en réponse à une erreur sans avoir d'abord diagnostiqué l'état.**

## 5. Actualiser et tester

Recharge Neos avec **Ctrl + F5**. Vérifie :

- plein écran / pleine largeur ;
- navigation et aperçus de fichiers ;
- hub d’applications avec icônes SVG originales, y compris **Deck** et **Notes** si ces apps sont installées ;
- panneau Personnaliser (fermeture via Échap, croix, bouton Terminer ou clic extérieur) ;
- réglage **Position du lanceur : topbar / widget** ;
- réglage **Animations : animées, discrètes ou désactivées**.

En cas de *Mode maintenance* :

```bash
sudo docker exec nextcloud occ status
sudo docker logs --tail 80 nextcloud
```

Ne désactive pas la maintenance si `needsDbUpgrade` est `true` ou qu'une mise à niveau est en cours.

## 6. Retour arrière (code)

Vérifie la présence et le contenu du fichier de sauvegarde :

```bash
sudo docker exec nextcloud sh -c 'tar -tzf /config/novadashboard-backup-avant-v045.tar.gz | head'
```

Pour restaurer le code précédent, **uniquement si nécessaire** :

```bash
sudo docker exec nextcloud sh -c 'rm -rf /config/www/nextcloud/apps/novadashboard && tar -xzf /config/novadashboard-backup-avant-v045.tar.gz -C /config/www/nextcloud/apps'
sudo docker exec nextcloud chown -R abc:abc /config/www/nextcloud/apps/novadashboard
```

Actualise ton navigateur. Ces commandes concernent **le dossier de l'application uniquement** ; elles ne touchent ni à la base de données ni au volume `/data`.

## Limites de la v0.4.5

L'explorateur Neos reste en lecture seule. Prévisualisations internes : images, texte, Markdown, CSV/TSV et PDF selon les possibilités du navigateur ; aperçu limité pour les fichiers Office. L'édition Office, le téléversement, le partage, le déplacement et la suppression continuent de passer par les applications Nextcloud correspondantes.
