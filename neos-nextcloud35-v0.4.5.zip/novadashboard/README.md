# Neos 0.4.5 — Flat Cyber

Application Nextcloud 35, identifiant `novadashboard` (conservé pour mise à jour).

- Interface pleine largeur, cartes sobres et grille responsive.
- Logo et pictogrammes SVG originaux créés pour cette version.
- Fond animé indépendant des widgets, léger et réactif au pointeur.
- Explorateur de fichiers à double panneau : navigation, favoris, recherche locale, tri, actions et aperçu.
- Lecture intégrée : images, fichiers texte/Markdown, CSV/TSV, PDF (selon navigateur).
- Fichiers Office : aperçu basique ou ouverture via l'application associée.
- Hub d'applications configurable : topbar ou widget, sans liste d'apps redondante.
- Personnalisation par utilisateur, réglage des animations et prise en charge de la préférence de réduction du mouvement.

La lecture via Neos est en lecture seule ; modifications, partage, suppression et téléversements restent dans Nextcloud Fichiers.
Aucune ressource distante n'est nécessaire pour afficher le dashboard.
