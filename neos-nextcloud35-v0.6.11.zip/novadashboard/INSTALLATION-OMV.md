# Neos v0.6.11 — Installation OMV / Nextcloud 35

Application : `novadashboard` · OpenMediaVault · Docker LinuxServer.io · design Flat Cyber conservé.

**Règle : une commande par bloc, à exécuter séparément.** Ne pas modifier Nginx Proxy Manager, les permissions des fichiers personnels ni les réglages CSP pour cette mise à jour.

## 1. PowerShell sous Windows

Télécharger `neos-nextcloud35-v0.6.11.zip` puis le placer dans `X:\Travail\Apprentissage\Codage\Neos Launcher\`.

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.11.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

## 2. Terminal SSH du NAS

Vérifier que Nextcloud n'est ni en maintenance ni en attente d'une mise à niveau (`maintenance: false` et `needsDbUpgrade: false`) :

```bash
sudo docker exec nextcloud occ status
```

Vérifier la présence de l'archive :

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.11.zip
```

Récupérer le chemin de l'application :

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

Vérifier **avant toute modification** :

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé : $APP_PATH"
```

**Si `Neos trouvé` n'apparaît pas, arrêter ici.**

Sauvegarder la version validée v0.6.10 :

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0611.tar.gz -C "$APP_PATH" .
```

Contrôler la sauvegarde :

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0611.tar.gz
```

Créer le dossier temporaire :

```bash
mkdir -p /tmp/neos-v0611
```

Extraire le ZIP :

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.11.zip /tmp/neos-v0611
```

Valider la structure :

```bash
test -f /tmp/neos-v0611/novadashboard/appinfo/info.xml && echo "Archive prête"
```

**Poursuivre seulement si `Archive prête` apparaît.**

Installer :

```bash
sudo docker cp /tmp/neos-v0611/novadashboard/. "nextcloud:$APP_PATH/"
```

Rétablir les propriétaires des fichiers LinuxServer.io :

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

Vérifier la version :

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Attendu : `novadashboard: 0.6.11`. Recharger Neos avec **Ctrl + F5**.

## 3. Tests à effectuer sur ton NAS

1. **Talk** : ouvrir une conversation, charger l'historique, envoyer un message de test puis vérifier sa réception dans l'application Talk native. Le bouton « Messages plus anciens » s'affiche si une page supplémentaire est disponible.
2. **Activité** : ouvrir l'espace, filtrer par source, puis cliquer sur « Charger les activités précédentes depuis Nextcloud » si le bouton apparaît.
3. **Contacts** : ouvrir une fiche et vérifier que nom, e-mail, téléphone et organisation correspondent à Contacts.
4. **Mail** : la consultation de la boîte reste expérimentale ; la rédaction/envoi se font toujours dans Mail natif, en attendant de vérifier la version de l'API Mail.
5. **Régression** : valider une tâche Deck, vérifier qu'elle disparaît immédiatement de « À faire » et contrôler que l'ordre des onglets est toujours conservé après actualisation.

### Si Talk échoue

Dans **F12 → Réseau**, relever **uniquement** le code HTTP de `/ocs/v2.php/apps/spreed/api/v1/chat/...` et le message d'erreur affiché, sans partager les cookies, jetons de session, contenu de conversations ni en-têtes d'autorisation. Les erreurs 403/404 peuvent correspondre à un salon en lecture seule, aux permissions ou à une route Talk indisponible.

## 4. Retour arrière vers v0.6.10

Ces étapes sont uniquement nécessaires en cas de problème sérieux. Dans la même session SSH, avec `APP_PATH` toujours défini :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0611.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Terminer par **Ctrl + F5**. Les préférences et fichiers personnels Nextcloud ne sont pas modifiés par cette opération.
