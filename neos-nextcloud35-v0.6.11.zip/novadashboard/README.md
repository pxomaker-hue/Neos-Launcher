# Neos Launcher v0.6.11 — Nextcloud 35

Module Nextcloud `novadashboard` développé pour l'environnement OMV / LinuxServer.io.

## Changements v0.6.11

- Talk : conversations et messages texte intégrés à Neos, chargement de l'historique, pagination, envoi et rafraîchissement via OCS Talk.
- Activité : pagination serveur OCS avec `since` / `X-Activity-Last-Given`, filtres et déduplication.
- Contacts : détails d'une fiche CardDAV (nom, e-mail, téléphone, organisation et carnet).
- Les modules de la v0.6.10, dont la topbar personnalisable et les tâches Deck, sont conservés.

Lire `INSTALLATION-OMV.md` avant toute installation.

Note : les captures/aperçus de démonstration utilisent des données fictives. Les opérations réseau ont été vérifiées d'après la documentation des API Nextcloud mais nécessitent validation sur le NAS réel.
