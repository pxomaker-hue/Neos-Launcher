# Tests v0.6.23 — à valider sur NAS

- Brouillon IMAP vide : reprise autorisée seulement après chargement réussi, éditeur texte vide, original inchangé.
- Brouillon IMAP avec texte : reprise identique à v0.6.22.
- Erreur de lecture IMAP : aucune reprise autorisée.
- L’envoi d’un courriel vide reste refusé par la validation Neos.

# Tests Neos v0.6.20

## Environnement

- Base : ZIP officiel Neos v0.6.19 de cette conversation.
- Nouvelle archive : v0.6.20 pour Nextcloud 35 / LinuxServer.io.
- Chromium headless local (aperçu autonome sur données fictives), ordinateur 1440×900 et mobile 420×900.

## Résultats

- Syntaxe JavaScript : `node --check` OK.
- Contacts : création vCard 3.0 avec 2 EMAIL/2 TEL ; modification d'une vCard avec conservation d'un troisième courriel, d'une PHOTO et d'un champ X-NEOS-CUSTOM : OK (tests JS).
- Interfaces : ouverture de Mail, liste Brouillons, ouverture du détail et retour, formulaire Contacts avec champs supplémentaires, validation de démonstration : OK.
- Erreurs JavaScript sur les scénarios visuels : aucune détectée.
- Archive ZIP : contenu, structure et intégrité contrôlés.

## Limites

- Aucune authentification à ton NAS lors des tests : la consultation des vrais brouillons et l'écriture CardDAV des valeurs multiples doivent être validées.
- Les brouillons IMAP sont lus dans Neos mais **ne sont pas édités ni supprimés par Neos**. Le bouton d'édition ouvre Mail natif pour préserver les éventuelles pièces jointes et propriétés non prises en charge.
- Les captures sont des captures d'exécution de l'aperçu avec des données fictives, pas de ton NAS.
