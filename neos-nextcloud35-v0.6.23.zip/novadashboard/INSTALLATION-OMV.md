# Neos v0.6.23 — Déploiement OpenMediaVault

**Cible :** NAS OMV `192.168.1.200`, SSH `ssh-pxo`, conteneur Docker `nextcloud`, Nextcloud 35 et application `novadashboard`.

**Important :** cette livraison préserve les fonctionnalités de v0.6.21. Elle corrige la reprise **en copie texte, y compris pour les brouillons vides** des brouillons IMAP et un bouton Talk « Marquer comme lu ». Elle **ne modifie ni ne supprime le brouillon IMAP original**. Les modifications de brouillons avec pièces jointes restent dans Mail natif.

## Déploiement simplifié : script PowerShell existant

Si tu as conservé `Deploy-Neos.ps1` dans le dossier des ZIP, place également `neos-nextcloud35-v0.6.23.zip` dans ce dossier, puis lance dans PowerShell :

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "X:\Travail\Apprentissage\Codage\Neos Launcher\Deploy-Neos.ps1"
```

Le script existant sélectionne le ZIP le plus récent, vérifie sa version, demande confirmation puis effectue les sauvegardes et la copie. **Vérifie la version choisie avant de taper `INSTALLER`.** La modification éventuelle du script pour ne demander sudo qu'une fois est un chantier distinct ; ne considère pas cette archive comme une mise à jour du script.

## Installation manuelle — une commande à la fois

### PowerShell Windows

Après avoir téléchargé le ZIP dans `X:\Travail\Apprentissage\Codage\Neos Launcher\` :

```powershell
scp "X:\Travail\Apprentissage\Codage\Neos Launcher\neos-nextcloud35-v0.6.23.zip" ssh-pxo@192.168.1.200:/tmp/
```

```powershell
ssh ssh-pxo@192.168.1.200
```

### NAS OpenMediaVault / terminal SSH

Vérifie que Nextcloud **n'est pas en maintenance** et n'attend pas de mise à niveau :

```bash
sudo docker exec nextcloud occ status
```

Ne continue que si `maintenance: false` et `needsDbUpgrade: false`.

```bash
ls -lh /tmp/neos-nextcloud35-v0.6.23.zip
```

```bash
APP_PATH="$(sudo docker exec nextcloud occ app:getpath novadashboard)"
```

```bash
test -n "$APP_PATH" && sudo docker exec nextcloud test -f "$APP_PATH/appinfo/info.xml" && echo "Neos trouvé"
```

**Sauvegarde de la v0.6.22 (avant toute modification) :**

```bash
sudo docker exec nextcloud tar -czf /config/neos-backup-avant-v0623.tar.gz -C "$APP_PATH" .
```

```bash
sudo docker exec nextcloud ls -lh /config/neos-backup-avant-v0623.tar.gz
```

Prépare la mise à jour :

```bash
mkdir -p /tmp/neos-v0623
```

```bash
python3 -m zipfile -e /tmp/neos-nextcloud35-v0.6.23.zip /tmp/neos-v0623
```

```bash
test -f /tmp/neos-v0623/novadashboard/appinfo/info.xml && echo "Archive prête"
```

Si toutes les vérifications précédentes réussissent, installe :

```bash
sudo docker cp /tmp/neos-v0623/novadashboard/. "nextcloud:$APP_PATH/"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

**Résultat attendu :** `novadashboard: 0.6.23`. Dans ton navigateur, **Ctrl + F5**.

## Vérifications sur le NAS

1. **Mail → Brouillons :** ouvre un brouillon vide puis un brouillon avec texte, confirme que les deux peuvent être repris en copie ; puis ouvre un brouillon de test et clique **Reprendre le texte dans Neos (copie)**. Vérifie que le texte et le destinataire sont repris dans un **nouveau** message. Ne clique pas sur Envoyer. Ferme l'éditeur et constate que le brouillon original est toujours présent. Une pièce jointe de l'original ne doit pas être considérée comme copiée.
2. **Talk :** ouvre une conversation avec des messages non lus, clique **Marquer comme lu** et vérifie que les compteurs changent. En cas d'erreur de l'API, Neos doit conserver le compteur et afficher un diagnostic.
3. Contrôle rapide : Contacts (édition et suppression test déjà validées en v0.6.21), Planning, Deck, Tâches, Mail, topbar personnalisée.

## Retour arrière manuel

Dans la session SSH où `APP_PATH` a été défini :

```bash
sudo docker exec nextcloud tar -xzf /config/neos-backup-avant-v0623.tar.gz -C "$APP_PATH"
```

```bash
sudo docker exec nextcloud chown -R abc:abc "$APP_PATH"
```

```bash
sudo docker exec nextcloud occ app:list | grep -i novadashboard
```

Termine avec **Ctrl + F5**. Le retour arrière restaure les fichiers présents dans l'archive de sauvegarde ; il ne supprime pas nécessairement d'éventuels fichiers ajoutés par une version future.

## Sécurité

Aucune modification des CSP, du proxy, des paramètres SMTP ni de la base de données. Les contenus des mails ne sont pas enregistrés en local par Neos. Ne transmets jamais des cookies de session, des jetons CSRF, des identifiants ou des adresses privées dans les captures de F12.
